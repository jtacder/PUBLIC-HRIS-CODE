-- Add optional P.O. number field to tasks table
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS po_number VARCHAR;