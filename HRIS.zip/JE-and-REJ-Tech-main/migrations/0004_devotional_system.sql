-- ============================================
-- DEVOTIONAL SYSTEM TABLES
-- 365-Day Devotional Plan
-- ============================================

-- Devotionals table (365 base entries that rotate yearly)
CREATE TABLE IF NOT EXISTS devotionals (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
    day_number INTEGER NOT NULL UNIQUE,
    verse TEXT NOT NULL,
    reference VARCHAR NOT NULL,
    base_excerpt TEXT NOT NULL,
    theme VARCHAR,
    year1_focus TEXT,
    year2_focus TEXT,
    year3_focus TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Employee Devotional Progress (tracks each employee's journey)
CREATE TABLE IF NOT EXISTS employee_devotional_progress (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
    employee_id VARCHAR NOT NULL REFERENCES employees(id),
    start_date DATE NOT NULL,
    current_year INTEGER NOT NULL DEFAULT 1,
    last_read_day INTEGER DEFAULT 0,
    last_read_date DATE,
    total_days_read INTEGER DEFAULT 0,
    current_streak INTEGER DEFAULT 0,
    longest_streak INTEGER DEFAULT 0,
    today_read BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Devotional Reading Logs (historical record of readings)
CREATE TABLE IF NOT EXISTS devotional_reading_logs (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid()::text,
    employee_id VARCHAR NOT NULL REFERENCES employees(id),
    devotional_id VARCHAR NOT NULL REFERENCES devotionals(id),
    read_date DATE NOT NULL,
    day_number INTEGER NOT NULL,
    year_number INTEGER NOT NULL,
    personal_note TEXT,
    is_favorite BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes for efficient lookups
CREATE INDEX IF NOT EXISTS idx_devotional_day ON devotionals(day_number);
CREATE INDEX IF NOT EXISTS idx_devotional_theme ON devotionals(theme);
CREATE INDEX IF NOT EXISTS idx_devotional_progress_employee ON employee_devotional_progress(employee_id);
CREATE INDEX IF NOT EXISTS idx_devotional_progress_year ON employee_devotional_progress(current_year);
CREATE INDEX IF NOT EXISTS idx_reading_log_employee ON devotional_reading_logs(employee_id);
CREATE INDEX IF NOT EXISTS idx_reading_log_date ON devotional_reading_logs(read_date);
CREATE INDEX IF NOT EXISTS idx_reading_log_employee_date ON devotional_reading_logs(employee_id, read_date);
