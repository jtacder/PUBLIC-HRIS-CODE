CREATE TABLE "cash_advances" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" varchar NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"reason" text,
	"status" varchar DEFAULT 'Pending' NOT NULL,
	"approved_by_id" varchar,
	"approved_at" timestamp,
	"disbursed_at" timestamp,
	"deduction_per_cutoff" numeric(12, 2),
	"remaining_balance" numeric(12, 2),
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "company_settings" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"key" varchar NOT NULL,
	"value" text,
	"category" varchar,
	"description" text,
	"updated_at" timestamp DEFAULT now(),
	CONSTRAINT "company_settings_key_unique" UNIQUE("key")
);
--> statement-breakpoint
CREATE TABLE "holidays" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar NOT NULL,
	"date" date NOT NULL,
	"type" varchar DEFAULT 'Regular' NOT NULL,
	"year" integer NOT NULL,
	"is_nationwide" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "leave_requests" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"employee_id" varchar NOT NULL,
	"leave_type_id" varchar NOT NULL,
	"start_date" date NOT NULL,
	"end_date" date NOT NULL,
	"total_days" numeric(4, 1) NOT NULL,
	"reason" text,
	"status" varchar DEFAULT 'Pending' NOT NULL,
	"approved_by_id" varchar,
	"approved_at" timestamp,
	"remarks" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "leave_types" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar NOT NULL,
	"code" varchar,
	"description" text,
	"annual_allocation" integer DEFAULT 0,
	"is_paid" boolean DEFAULT true,
	"requires_approval" boolean DEFAULT true,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "payroll_cutoffs" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar NOT NULL,
	"start_day" integer NOT NULL,
	"end_day" integer NOT NULL,
	"payout_day" integer NOT NULL,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "payroll_periods" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar,
	"cutoff_start" date NOT NULL,
	"cutoff_end" date NOT NULL,
	"pay_date" date NOT NULL,
	"period_type" varchar DEFAULT 'semi-monthly',
	"status" varchar DEFAULT 'Draft' NOT NULL,
	"total_employees" integer DEFAULT 0,
	"total_gross_pay" numeric(15, 2) DEFAULT '0',
	"total_deductions" numeric(15, 2) DEFAULT '0',
	"total_net_pay" numeric(15, 2) DEFAULT '0',
	"generated_by_id" varchar,
	"generated_at" timestamp,
	"released_by_id" varchar,
	"released_at" timestamp,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "scheduled_shift_start" varchar;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "scheduled_shift_end" varchar;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "scheduled_shift_date" date;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "actual_shift_type" varchar;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "regular_minutes" integer DEFAULT 0;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "overtime_minutes" integer DEFAULT 0;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "is_late" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "late_deductible" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "lunch_deduction_minutes" integer DEFAULT 0;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "lunch_paid" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "ot_status" varchar DEFAULT 'Pending';--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "ot_minutes_approved" integer DEFAULT 0;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "ot_approved_by_id" varchar;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "ot_approved_at" timestamp;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "ot_reason" text;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "is_overtime_session" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD COLUMN "parent_attendance_id" varchar;--> statement-breakpoint
ALTER TABLE "employees" ADD COLUMN "shift_start_time" varchar;--> statement-breakpoint
ALTER TABLE "employees" ADD COLUMN "shift_end_time" varchar;--> statement-breakpoint
ALTER TABLE "employees" ADD COLUMN "shift_work_days" jsonb;--> statement-breakpoint
ALTER TABLE "employees" ADD COLUMN "qr_token" varchar;--> statement-breakpoint
ALTER TABLE "employees" ADD COLUMN "enable_sss_deduction" boolean DEFAULT true;--> statement-breakpoint
ALTER TABLE "employees" ADD COLUMN "enable_philhealth_deduction" boolean DEFAULT true;--> statement-breakpoint
ALTER TABLE "employees" ADD COLUMN "enable_pagibig_deduction" boolean DEFAULT true;--> statement-breakpoint
ALTER TABLE "employees" ADD COLUMN "enable_tax_withholding" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "period_id" varchar;--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "pay_date" date;--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "regular_ot_minutes" integer DEFAULT 0;--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "rest_day_ot_minutes" integer DEFAULT 0;--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "holiday_ot_minutes" integer DEFAULT 0;--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "bonus_amount" numeric(12, 2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "bonus_notes" text;--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "undertime_deduction" numeric(12, 2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "other_deduction_amount" numeric(12, 2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "other_deduction_notes" text;--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "cash_advance_deduction" numeric(12, 2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "is_edited" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "override_net_pay" numeric(12, 2);--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "edit_notes" text;--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "payslip_status" varchar DEFAULT 'Draft';--> statement-breakpoint
ALTER TABLE "payroll_records" ADD COLUMN "pdf_url" text;--> statement-breakpoint
ALTER TABLE "projects" ADD COLUMN "is_office" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "projects" ADD COLUMN "location_address" text;--> statement-breakpoint
ALTER TABLE "projects" ADD COLUMN "allocated_hours" numeric(10, 2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE "cash_advances" ADD CONSTRAINT "cash_advances_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "cash_advances" ADD CONSTRAINT "cash_advances_approved_by_id_employees_id_fk" FOREIGN KEY ("approved_by_id") REFERENCES "public"."employees"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "leave_requests" ADD CONSTRAINT "leave_requests_employee_id_employees_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "leave_requests" ADD CONSTRAINT "leave_requests_leave_type_id_leave_types_id_fk" FOREIGN KEY ("leave_type_id") REFERENCES "public"."leave_types"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "leave_requests" ADD CONSTRAINT "leave_requests_approved_by_id_employees_id_fk" FOREIGN KEY ("approved_by_id") REFERENCES "public"."employees"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payroll_periods" ADD CONSTRAINT "payroll_periods_generated_by_id_employees_id_fk" FOREIGN KEY ("generated_by_id") REFERENCES "public"."employees"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payroll_periods" ADD CONSTRAINT "payroll_periods_released_by_id_employees_id_fk" FOREIGN KEY ("released_by_id") REFERENCES "public"."employees"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_cash_advance_employee" ON "cash_advances" USING btree ("employee_id");--> statement-breakpoint
CREATE INDEX "idx_cash_advance_status" ON "cash_advances" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_holiday_year" ON "holidays" USING btree ("year");--> statement-breakpoint
CREATE INDEX "idx_holiday_date" ON "holidays" USING btree ("date");--> statement-breakpoint
CREATE INDEX "idx_leave_request_employee" ON "leave_requests" USING btree ("employee_id");--> statement-breakpoint
CREATE INDEX "idx_leave_request_status" ON "leave_requests" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_leave_request_dates" ON "leave_requests" USING btree ("start_date","end_date");--> statement-breakpoint
CREATE INDEX "idx_payroll_period_dates" ON "payroll_periods" USING btree ("cutoff_start","cutoff_end");--> statement-breakpoint
CREATE INDEX "idx_payroll_period_status" ON "payroll_periods" USING btree ("status");--> statement-breakpoint
ALTER TABLE "attendance_logs" ADD CONSTRAINT "attendance_logs_ot_approved_by_id_employees_id_fk" FOREIGN KEY ("ot_approved_by_id") REFERENCES "public"."employees"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_attendance_ot_status" ON "attendance_logs" USING btree ("ot_status");--> statement-breakpoint
CREATE INDEX "idx_attendance_is_late" ON "attendance_logs" USING btree ("is_late");--> statement-breakpoint
CREATE INDEX "idx_attendance_scheduled_date" ON "attendance_logs" USING btree ("scheduled_shift_date");--> statement-breakpoint
CREATE INDEX "idx_employee_email" ON "employees" USING btree ("email");--> statement-breakpoint
CREATE INDEX "idx_employee_no" ON "employees" USING btree ("employee_no");--> statement-breakpoint
CREATE INDEX "idx_employee_status" ON "employees" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_employee_role" ON "employees" USING btree ("role");--> statement-breakpoint
CREATE INDEX "idx_employee_user_id" ON "employees" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "idx_payroll_period" ON "payroll_records" USING btree ("period_id");--> statement-breakpoint
ALTER TABLE "employees" ADD CONSTRAINT "employees_qr_token_unique" UNIQUE("qr_token");