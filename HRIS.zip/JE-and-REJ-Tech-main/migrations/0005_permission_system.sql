-- Permission Role Management System Migration
-- This migration adds tables for granular permission management

-- 1. Permissions table (registry of all available permissions)
CREATE TABLE IF NOT EXISTS "permissions" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "feature" varchar(50) NOT NULL,
  "action" varchar(50) NOT NULL,
  "code" varchar(100) NOT NULL UNIQUE,
  "name" varchar(100) NOT NULL,
  "description" text,
  "category" varchar(50) NOT NULL,
  "sort_order" integer DEFAULT 0,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp DEFAULT now()
);

-- 2. Roles table (Superadmin, HR/Admin, custom roles)
CREATE TABLE IF NOT EXISTS "roles" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "name" varchar(50) NOT NULL UNIQUE,
  "display_name" varchar(100) NOT NULL,
  "description" text,
  "is_system_role" boolean DEFAULT false,
  "is_superadmin" boolean DEFAULT false,
  "created_at" timestamp DEFAULT now(),
  "updated_at" timestamp DEFAULT now()
);

-- 3. Role-Permission mapping table
CREATE TABLE IF NOT EXISTS "role_permissions" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "role_id" varchar NOT NULL REFERENCES "roles"("id") ON DELETE CASCADE,
  "permission_id" varchar NOT NULL REFERENCES "permissions"("id") ON DELETE CASCADE,
  "created_at" timestamp DEFAULT now()
);

-- 4. User-Permission overrides table (individual grants)
CREATE TABLE IF NOT EXISTS "user_permissions" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "employee_id" varchar NOT NULL REFERENCES "employees"("id") ON DELETE CASCADE,
  "permission_id" varchar NOT NULL REFERENCES "permissions"("id") ON DELETE CASCADE,
  "granted_by_id" varchar NOT NULL REFERENCES "employees"("id"),
  "granted_at" timestamp DEFAULT now(),
  "expires_at" timestamp
);

-- 5. Permission Audit Log table
CREATE TABLE IF NOT EXISTS "permission_audit_logs" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "actor_id" varchar NOT NULL REFERENCES "employees"("id"),
  "target_employee_id" varchar REFERENCES "employees"("id"),
  "action" varchar(50) NOT NULL,
  "permission_code" varchar(100),
  "role_id" varchar REFERENCES "roles"("id"),
  "old_value" jsonb,
  "new_value" jsonb,
  "ip_address" varchar(50),
  "user_agent" text,
  "created_at" timestamp DEFAULT now()
);

-- 6. Add role_id column to employees table
ALTER TABLE "employees" ADD COLUMN IF NOT EXISTS "role_id" varchar REFERENCES "roles"("id");

-- 7. Create indexes for performance
CREATE INDEX IF NOT EXISTS "idx_permission_feature" ON "permissions"("feature");
CREATE INDEX IF NOT EXISTS "idx_permission_category" ON "permissions"("category");
CREATE INDEX IF NOT EXISTS "idx_permission_code" ON "permissions"("code");
CREATE INDEX IF NOT EXISTS "idx_role_permission_role" ON "role_permissions"("role_id");
CREATE INDEX IF NOT EXISTS "idx_role_permission_permission" ON "role_permissions"("permission_id");
CREATE INDEX IF NOT EXISTS "idx_user_permission_employee" ON "user_permissions"("employee_id");
CREATE INDEX IF NOT EXISTS "idx_user_permission_permission" ON "user_permissions"("permission_id");
CREATE INDEX IF NOT EXISTS "idx_permission_audit_actor" ON "permission_audit_logs"("actor_id");
CREATE INDEX IF NOT EXISTS "idx_permission_audit_target" ON "permission_audit_logs"("target_employee_id");
CREATE INDEX IF NOT EXISTS "idx_permission_audit_created" ON "permission_audit_logs"("created_at");
CREATE INDEX IF NOT EXISTS "idx_employee_role_id" ON "employees"("role_id");
