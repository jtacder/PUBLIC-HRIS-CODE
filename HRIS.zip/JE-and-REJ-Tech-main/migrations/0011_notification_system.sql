-- Notification System Migration
-- Adds notifications, notification_preferences, and push_subscriptions tables

-- Notifications table
CREATE TABLE IF NOT EXISTS "notifications" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "recipient_id" varchar NOT NULL REFERENCES "employees"("id"),
  "title" varchar(255) NOT NULL,
  "message" text NOT NULL,
  "category" varchar NOT NULL,
  "priority" varchar NOT NULL DEFAULT 'normal',
  "action_url" varchar(500),
  "entity_type" varchar(50),
  "entity_id" varchar,
  "actor_id" varchar REFERENCES "employees"("id"),
  "is_read" boolean NOT NULL DEFAULT false,
  "read_at" timestamp,
  "push_sent" boolean DEFAULT false,
  "email_sent" boolean DEFAULT false,
  "is_broadcast" boolean DEFAULT false,
  "created_at" timestamp NOT NULL DEFAULT now(),
  "expires_at" timestamp
);

CREATE INDEX IF NOT EXISTS "idx_notification_recipient" ON "notifications" ("recipient_id");
CREATE INDEX IF NOT EXISTS "idx_notification_recipient_read" ON "notifications" ("recipient_id", "is_read");
CREATE INDEX IF NOT EXISTS "idx_notification_category" ON "notifications" ("category");
CREATE INDEX IF NOT EXISTS "idx_notification_created" ON "notifications" ("created_at");
CREATE INDEX IF NOT EXISTS "idx_notification_entity" ON "notifications" ("entity_type", "entity_id");
CREATE INDEX IF NOT EXISTS "idx_notification_expires" ON "notifications" ("expires_at");

-- Notification preferences table
CREATE TABLE IF NOT EXISTS "notification_preferences" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "employee_id" varchar NOT NULL REFERENCES "employees"("id") ON DELETE CASCADE,
  "enabled" boolean NOT NULL DEFAULT true,
  "preferences" jsonb NOT NULL,
  "quiet_hours_start" varchar,
  "quiet_hours_end" varchar,
  "created_at" timestamp DEFAULT now(),
  "updated_at" timestamp DEFAULT now()
);

CREATE INDEX IF NOT EXISTS "idx_notification_pref_employee" ON "notification_preferences" ("employee_id");

-- Push subscriptions table
CREATE TABLE IF NOT EXISTS "push_subscriptions" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "employee_id" varchar NOT NULL REFERENCES "employees"("id") ON DELETE CASCADE,
  "endpoint" text NOT NULL,
  "p256dh" text NOT NULL,
  "auth" text NOT NULL,
  "user_agent" text,
  "device_name" varchar(100),
  "is_active" boolean NOT NULL DEFAULT true,
  "last_used_at" timestamp,
  "fail_count" integer DEFAULT 0,
  "created_at" timestamp DEFAULT now()
);

CREATE INDEX IF NOT EXISTS "idx_push_sub_employee" ON "push_subscriptions" ("employee_id");
CREATE INDEX IF NOT EXISTS "idx_push_sub_endpoint" ON "push_subscriptions" ("endpoint");
CREATE INDEX IF NOT EXISTS "idx_push_sub_active" ON "push_subscriptions" ("employee_id", "is_active");
