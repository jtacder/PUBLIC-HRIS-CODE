-- Migration: Add GPS Location Accuracy Field
-- Purpose: Store GPS accuracy measurement for better geofencing validation
-- This field tracks the GPS accuracy (in meters) reported by the device
-- to enable accuracy-aware geofence validation and audit trails

ALTER TABLE "attendance_logs"
ADD COLUMN IF NOT EXISTS "location_accuracy" DECIMAL(10, 2);

COMMENT ON COLUMN "attendance_logs"."location_accuracy" IS 'GPS accuracy in meters (±) as reported by the device. Used for accuracy-aware geofence validation.';
