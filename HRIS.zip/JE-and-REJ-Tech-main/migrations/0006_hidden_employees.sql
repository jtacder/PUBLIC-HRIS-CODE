-- Migration: Add is_hidden column to employees table
-- This allows system administrators/owners to be hidden from employee lists
-- while still maintaining full system access

-- Add is_hidden column to employees table
ALTER TABLE employees ADD COLUMN IF NOT EXISTS is_hidden BOOLEAN NOT NULL DEFAULT FALSE;

-- Create index for efficient filtering of hidden employees
CREATE INDEX IF NOT EXISTS idx_employee_is_hidden ON employees(is_hidden);

-- Combined index for common queries filtering by status and hidden
CREATE INDEX IF NOT EXISTS idx_employee_status_hidden ON employees(status, is_hidden);

-- Comment: To mark an admin as hidden, run:
-- UPDATE employees SET is_hidden = TRUE WHERE id = '<admin-employee-id>';
