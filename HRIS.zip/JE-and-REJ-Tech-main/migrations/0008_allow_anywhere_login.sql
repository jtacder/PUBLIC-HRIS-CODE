-- Migration: Add allow_anywhere_login column to employees table
-- This allows specific employees to bypass geofencing restrictions during clock-in
-- Useful for roaming employees, supervisors, or those who work at multiple sites

-- Add allow_anywhere_login column to employees table
ALTER TABLE employees ADD COLUMN IF NOT EXISTS allow_anywhere_login BOOLEAN DEFAULT FALSE;

-- Create index for efficient filtering when checking geofencing override
CREATE INDEX IF NOT EXISTS idx_employee_allow_anywhere_login ON employees(allow_anywhere_login);

-- Comment: To allow an employee to login from anywhere, run:
-- UPDATE employees SET allow_anywhere_login = TRUE WHERE id = '<employee-id>';
