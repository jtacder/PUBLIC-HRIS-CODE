-- Migration: Add password_reset_tokens table for email-based password reset
-- This migration adds support for self-service password reset via email

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id VARCHAR NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    token_hash VARCHAR NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    used_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),

    -- Each employee can only have one active reset token at a time
    -- Old tokens are invalidated when a new one is created
    CONSTRAINT unique_active_token UNIQUE (employee_id, token_hash)
);

-- Index for fast token lookup
CREATE INDEX idx_reset_tokens_hash ON password_reset_tokens(token_hash);

-- Index for cleanup of expired tokens
CREATE INDEX idx_reset_tokens_expires ON password_reset_tokens(expires_at);

-- Index for finding tokens by employee
CREATE INDEX idx_reset_tokens_employee ON password_reset_tokens(employee_id);

COMMENT ON TABLE password_reset_tokens IS 'Stores password reset tokens for email-based password recovery';
COMMENT ON COLUMN password_reset_tokens.token_hash IS 'SHA-256 hash of the reset token (never store raw tokens)';
COMMENT ON COLUMN password_reset_tokens.expires_at IS 'Token expiration time (default 1 hour from creation)';
COMMENT ON COLUMN password_reset_tokens.used_at IS 'When the token was used to reset password (null if unused)';
