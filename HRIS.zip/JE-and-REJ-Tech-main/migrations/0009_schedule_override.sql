-- Migration: Add schedule override columns to attendance_logs table
-- This allows HR/Admin to override an employee's scheduled shift for a specific day
-- Useful when an employee has a sudden shift change (e.g., from morning to afternoon shift)
-- The override values are used instead of scheduledShiftStart/End for late/OT calculations

-- Add scheduled_shift_start_override column
ALTER TABLE attendance_logs ADD COLUMN IF NOT EXISTS scheduled_shift_start_override VARCHAR;

-- Add scheduled_shift_end_override column
ALTER TABLE attendance_logs ADD COLUMN IF NOT EXISTS scheduled_shift_end_override VARCHAR;

-- Comment: To set a schedule override for an attendance record, run:
-- UPDATE attendance_logs
-- SET scheduled_shift_start_override = '13:00', scheduled_shift_end_override = '22:00'
-- WHERE id = '<attendance-log-id>';
--
-- This will recalculate late status and overtime based on the override values.
