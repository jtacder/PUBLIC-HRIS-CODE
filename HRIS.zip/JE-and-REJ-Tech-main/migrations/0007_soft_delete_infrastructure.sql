-- Migration: Add soft delete infrastructure
-- Purpose: Add deletedAt column to support soft deletes for key tables
-- Tables affected: employees, projects, payroll_records, disciplinary_actions, leave_requests

-- Add deletedAt column to employees table
ALTER TABLE employees ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP;
CREATE INDEX IF NOT EXISTS idx_employee_deleted_at ON employees (deleted_at);

-- Add deletedAt column to projects table
ALTER TABLE projects ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP;
CREATE INDEX IF NOT EXISTS idx_project_deleted_at ON projects (deleted_at);

-- Add deletedAt column to payroll_records table
ALTER TABLE payroll_records ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP;
CREATE INDEX IF NOT EXISTS idx_payroll_deleted_at ON payroll_records (deleted_at);

-- Add deletedAt column to disciplinary_actions table
ALTER TABLE disciplinary_actions ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP;
CREATE INDEX IF NOT EXISTS idx_disciplinary_deleted_at ON disciplinary_actions (deleted_at);

-- Add deletedAt column to leave_requests table
ALTER TABLE leave_requests ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP;
CREATE INDEX IF NOT EXISTS idx_leave_request_deleted_at ON leave_requests (deleted_at);

-- Create composite indexes for common soft delete queries
-- These help with "WHERE deleted_at IS NULL AND ..." queries
CREATE INDEX IF NOT EXISTS idx_employee_status_not_deleted ON employees (status) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_project_status_not_deleted ON projects (status) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_payroll_status_not_deleted ON payroll_records (status) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_disciplinary_status_not_deleted ON disciplinary_actions (status) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_leave_request_status_not_deleted ON leave_requests (status) WHERE deleted_at IS NULL;
