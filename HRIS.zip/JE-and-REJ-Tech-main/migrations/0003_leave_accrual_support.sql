-- Add accrual mode to leave_types table
ALTER TABLE leave_types ADD COLUMN IF NOT EXISTS accrual_mode VARCHAR DEFAULT 'annual';

-- Add accrual tracking fields to employee_leave_allocations table
ALTER TABLE employee_leave_allocations ADD COLUMN IF NOT EXISTS accrued_to_date DECIMAL(5,1) DEFAULT 0;
ALTER TABLE employee_leave_allocations ADD COLUMN IF NOT EXISTS last_accrual_month INTEGER DEFAULT 0;

-- Update existing allocations to have accrued_to_date equal to total_allocated (for backward compatibility)
UPDATE employee_leave_allocations
SET accrued_to_date = total_allocated
WHERE accrued_to_date IS NULL OR accrued_to_date = 0;

-- Create index for efficient lookups
CREATE INDEX IF NOT EXISTS idx_leave_allocation_unique ON employee_leave_allocations(employee_id, leave_type_id, year);
