-- Migration: Add cash_advance_payments table for tracking deduction history
CREATE TABLE IF NOT EXISTS "cash_advance_payments" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"cash_advance_id" varchar NOT NULL,
	"payroll_record_id" varchar,
	"payroll_period_id" varchar,
	"deduction_amount" numeric(12, 2) NOT NULL,
	"remaining_balance_after" numeric(12, 2) NOT NULL,
	"payment_date" date NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "cash_advance_payments" ADD CONSTRAINT "cash_advance_payments_cash_advance_id_cash_advances_id_fk" FOREIGN KEY ("cash_advance_id") REFERENCES "public"."cash_advances"("id") ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE "cash_advance_payments" ADD CONSTRAINT "cash_advance_payments_payroll_record_id_payroll_records_id_fk" FOREIGN KEY ("payroll_record_id") REFERENCES "public"."payroll_records"("id") ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE "cash_advance_payments" ADD CONSTRAINT "cash_advance_payments_payroll_period_id_payroll_periods_id_fk" FOREIGN KEY ("payroll_period_id") REFERENCES "public"."payroll_periods"("id") ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
CREATE INDEX "idx_payment_cash_advance" ON "cash_advance_payments" USING btree ("cash_advance_id");
--> statement-breakpoint
CREATE INDEX "idx_payment_payroll_record" ON "cash_advance_payments" USING btree ("payroll_record_id");
