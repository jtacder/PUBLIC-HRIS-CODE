-- Add per-loan-type deduction columns to payroll_records
-- SSS Loan, Pag-IBIG Loan, and Bank Loan each get their own dedicated field
-- The existing loan_deduction column becomes the total (sum of all three)

ALTER TABLE payroll_records ADD COLUMN IF NOT EXISTS sss_loan_deduction DECIMAL(12, 2) DEFAULT '0';
ALTER TABLE payroll_records ADD COLUMN IF NOT EXISTS pagibig_loan_deduction DECIMAL(12, 2) DEFAULT '0';
ALTER TABLE payroll_records ADD COLUMN IF NOT EXISTS bank_loan_deduction DECIMAL(12, 2) DEFAULT '0';
