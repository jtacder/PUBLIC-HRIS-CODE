-- Migration: Payroll Integrity Fixes
-- Purpose: Add constraints and flags to prevent data inconsistencies in payroll processing
-- Date: 2026-02-04
--
-- This migration addresses critical payroll issues:
-- 1. Prevent duplicate payroll records for same employee/cutoff period
-- 2. Add idempotency flags to prevent double deductions
-- 3. Add negative net pay tracking

-- =============================================================================
-- 1. UNIQUE CONSTRAINT ON PAYROLL RECORDS
-- =============================================================================
-- Prevent duplicate payroll records for the same employee and cutoff period.
-- This protects against race conditions during concurrent payroll computation.
-- Note: We only enforce this for non-deleted records using a partial index.

CREATE UNIQUE INDEX IF NOT EXISTS idx_payroll_unique_employee_cutoff
ON payroll_records (employee_id, cutoff_start, cutoff_end)
WHERE deleted_at IS NULL;

-- =============================================================================
-- 2. IDEMPOTENCY FLAGS FOR PAYMENT RECORDS
-- =============================================================================
-- Add flags to track whether deductions have been applied to actual balances.
-- This prevents double deductions if approval/release is retried after partial failure.

-- Add 'deduction_applied' flag to cash_advance_payments
-- TRUE = the deduction has been applied to the cash advance's remaining balance
-- FALSE/NULL = the deduction is tracked but not yet applied (Draft state)
ALTER TABLE cash_advance_payments
ADD COLUMN IF NOT EXISTS deduction_applied BOOLEAN DEFAULT FALSE;

-- Add 'deduction_applied' flag to loan_payments
ALTER TABLE loan_payments
ADD COLUMN IF NOT EXISTS deduction_applied BOOLEAN DEFAULT FALSE;

-- Add index for faster lookups of unapplied deductions
CREATE INDEX IF NOT EXISTS idx_ca_payments_unapplied
ON cash_advance_payments (payroll_record_id)
WHERE deduction_applied = FALSE;

CREATE INDEX IF NOT EXISTS idx_loan_payments_unapplied
ON loan_payments (payroll_record_id)
WHERE deduction_applied = FALSE;

-- =============================================================================
-- 3. VALIDATION FLAG FOR NEGATIVE NET PAY
-- =============================================================================
-- Track if net pay is negative (deductions exceed gross pay)
-- This is informational - actual validation is done in application code

ALTER TABLE payroll_records
ADD COLUMN IF NOT EXISTS has_negative_net_pay BOOLEAN DEFAULT FALSE;

-- =============================================================================
-- 4. PAYROLL PROCESSING LOCK (Optional - for future distributed lock support)
-- =============================================================================
-- Add a processing lock timestamp to prevent concurrent operations
-- If processing_started_at is set and recent (< 5 minutes), block new operations

ALTER TABLE payroll_records
ADD COLUMN IF NOT EXISTS processing_started_at TIMESTAMP;

ALTER TABLE payroll_records
ADD COLUMN IF NOT EXISTS processing_user_id VARCHAR;

-- =============================================================================
-- MIGRATION NOTES
-- =============================================================================
-- After applying this migration:
-- 1. Existing payment records will have deduction_applied = FALSE
-- 2. You should run the backfill query below to mark existing payments as applied
--    for payroll records that are already Approved or Released
--
-- BACKFILL QUERY (run manually after migration if needed):
--
-- UPDATE cash_advance_payments cap
-- SET deduction_applied = TRUE
-- FROM payroll_records pr
-- WHERE cap.payroll_record_id = pr.id
--   AND pr.status IN ('Approved', 'Released');
--
-- UPDATE loan_payments lp
-- SET deduction_applied = TRUE
-- FROM payroll_records pr
-- WHERE lp.payroll_record_id = pr.id
--   AND pr.status IN ('Approved', 'Released');
