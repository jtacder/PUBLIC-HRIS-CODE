import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, date, jsonb, index, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Re-export auth models
export * from "./models/auth";
export * from "./models/password-reset";

// ============================================
// ENUMS & TYPES
// ============================================
export const employeeRoleEnum = ["ADMIN", "HR", "ENGINEER", "WORKER"] as const;
export type EmployeeRole = typeof employeeRoleEnum[number];

// Permission categories for grouping
export const permissionCategoryEnum = ["Operations", "Human Resources", "Finance", "Administration"] as const;
export type PermissionCategory = typeof permissionCategoryEnum[number];

// Permission action types
export const permissionActionEnum = ["view", "create", "edit", "delete", "approve", "process", "release", "manage", "export", "bulk_upload", "reset_password", "assign", "disburse", "reimburse", "issue", "resolve"] as const;
export type PermissionAction = typeof permissionActionEnum[number];

export const employeeStatusEnum = ["Active", "Probationary", "Suspended", "Terminated", "Inactive"] as const;
export type EmployeeStatus = typeof employeeStatusEnum[number];

export const rateTypeEnum = ["daily", "monthly"] as const;
export type RateType = typeof rateTypeEnum[number];

export const projectStatusEnum = ["Planning", "Active", "On Hold", "Completed", "Cancelled"] as const;
export type ProjectStatus = typeof projectStatusEnum[number];

export const taskStatusEnum = ["Todo", "In_Progress", "Blocked", "Done"] as const;
export type TaskStatus = typeof taskStatusEnum[number];

export const taskPriorityEnum = ["Low", "Medium", "High", "Critical"] as const;
export type TaskPriority = typeof taskPriorityEnum[number];

export const verificationStatusEnum = ["Verified", "Pending", "Flagged", "Off-site"] as const;
export type VerificationStatus = typeof verificationStatusEnum[number];

export const otStatusEnum = ["Pending", "Approved", "Rejected"] as const;
export type OTStatus = typeof otStatusEnum[number];

export const payrollStatusEnum = ["Draft", "Approved", "Released"] as const;
export type PayrollStatus = typeof payrollStatusEnum[number];

export const payrollPeriodStatusEnum = ["Draft", "Processing", "Completed", "Released"] as const;
export type PayrollPeriodStatus = typeof payrollPeriodStatusEnum[number];

export const payslipStatusEnum = ["Draft", "Finalized"] as const;
export type PayslipStatus = typeof payslipStatusEnum[number];

export const nteStatusEnum = ["Issued", "Explanation_Received", "Under_Review", "Resolved", "Escalated"] as const;
export type NTEStatus = typeof nteStatusEnum[number];

export const violationTypeEnum = ["Tardiness", "Absenteeism", "Safety_Violation", "Misconduct", "Insubordination", "Policy_Violation", "Other"] as const;
export type ViolationType = typeof violationTypeEnum[number];

export const expenseStatusEnum = ["Pending", "Approved", "Rejected", "Reimbursed"] as const;
export type ExpenseStatus = typeof expenseStatusEnum[number];

export const expenseCategoryEnum = ["Material", "Equipment", "Transport", "Food", "Lodging", "Safety_Gear", "Tools", "Other"] as const;
export type ExpenseCategory = typeof expenseCategoryEnum[number];

// ============================================
// EMPLOYEES (Extended 201 File)
// ============================================
export const employees = pgTable("employees", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  
  // Personal Info
  firstName: varchar("first_name").notNull(),
  lastName: varchar("last_name").notNull(),
  middleName: varchar("middle_name"),
  email: varchar("email").unique(),
  phone: varchar("phone"),
  address: text("address"),
  birthDate: date("birth_date"),
  gender: varchar("gender"),
  civilStatus: varchar("civil_status"),
  nationality: varchar("nationality").default("Filipino"),
  profilePhotoUrl: varchar("profile_photo_url"),
  
  // Emergency Contact
  emergencyContactName: varchar("emergency_contact_name"),
  emergencyContactPhone: varchar("emergency_contact_phone"),
  emergencyContactRelation: varchar("emergency_contact_relation"),
  
  // Employment Details
  role: varchar("role").$type<EmployeeRole>().notNull().default("WORKER"),
  position: varchar("position"),
  department: varchar("department"),
  employeeNo: varchar("employee_no"),
  
  // Compensation
  rateType: varchar("rate_type").$type<RateType>().notNull().default("daily"),
  baseRate: decimal("base_rate", { precision: 12, scale: 2 }).notNull().default("0"),
  colaAllowance: decimal("cola_allowance", { precision: 12, scale: 2 }).default("0"), // Monthly COLA (Cost of Living Allowance)
  
  // Government IDs (PH)
  sssNo: varchar("sss_no"),
  tinNo: varchar("tin_no"),
  philhealthNo: varchar("philhealth_no"),
  pagibigNo: varchar("pagibig_no"),
  
  // Banking
  bankName: varchar("bank_name"),
  bankAccountNo: varchar("bank_account_no"),
  
  // Status
  status: varchar("status").$type<EmployeeStatus>().notNull().default("Active"),
  startDate: date("start_date"),
  endDate: date("end_date"),
  regularizationDate: date("regularization_date"),
  
  // Shift Schedule
  shiftStartTime: varchar("shift_start_time"), // e.g., "08:00"
  shiftEndTime: varchar("shift_end_time"), // e.g., "17:00"
  shiftWorkDays: jsonb("shift_work_days").$type<string[]>(), // e.g., ["Mon","Tue","Wed","Thu","Fri"]
  
  // QR Code Attendance
  qrToken: varchar("qr_token").unique(), // Unique token for QR-based attendance

  // Geofencing Override
  allowAnywhereLogin: boolean("allow_anywhere_login").default(false), // If true, bypasses geofencing restrictions

  // Payroll Deduction Configuration (per employee)
  enableSSSDeduction: boolean("enable_sss_deduction").default(true),
  enablePhilhealthDeduction: boolean("enable_philhealth_deduction").default(true),
  enablePagibigDeduction: boolean("enable_pagibig_deduction").default(true),
  enableTaxWithholding: boolean("enable_tax_withholding").default(false), // Tax not applied by default
  
  // System
  userId: varchar("user_id"),
  roleId: varchar("role_id"), // References roles table for permission management
  isHidden: boolean("is_hidden").default(false).notNull(), // Hidden from employee lists (for system admin accounts)
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),

  // Soft delete support (null = not deleted, timestamp = when deleted)
  deletedAt: timestamp("deleted_at"),
}, (table) => [
  index("idx_employee_no").on(table.employeeNo),
  index("idx_employee_status").on(table.status),
  index("idx_employee_role").on(table.role),
  index("idx_employee_status_role").on(table.status, table.role),
  index("idx_employee_role_id").on(table.roleId),
  index("idx_employee_deleted_at").on(table.deletedAt),
]);

export const insertEmployeeSchema = createInsertSchema(employees).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Employee = typeof employees.$inferSelect;

// ============================================
// PROJECTS (with Geolocation for Geo-fencing)
// ============================================
export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),

  // P.O Number (for non-office projects)
  poNumber: varchar("po_number"),

  // Project Info
  name: varchar("name").notNull(),
  code: varchar("code"),
  description: text("description"),
  client: varchar("client"),
  
  // Office/Site Type
  isOffice: boolean("is_office").default(false), // If true, this is a permanent hub
  
  // Location (for Geo-fencing)
  locationName: varchar("location_name"),
  locationAddress: text("location_address"),
  locationLat: decimal("location_lat", { precision: 10, scale: 7 }),
  locationLng: decimal("location_lng", { precision: 10, scale: 7 }),
  geoRadius: integer("geo_radius").default(100), // meters
  
  // Timeline (disabled for offices)
  startDate: date("start_date"),
  deadline: date("deadline"),
  completedDate: date("completed_date"),
  
  // Budget
  budget: decimal("budget", { precision: 15, scale: 2 }).default("0"),
  actualCost: decimal("actual_cost", { precision: 15, scale: 2 }).default("0"),
  
  // Allocated Hours Tracking
  allocatedHours: decimal("allocated_hours", { precision: 10, scale: 2 }).default("0"),

  // Meal Allowance (per head per day amount)
  mealAllowance: decimal("meal_allowance", { precision: 12, scale: 2 }).default("0"),
  
  // Status & Management
  status: varchar("status").$type<ProjectStatus>().notNull().default("Planning"),
  projectManagerId: varchar("project_manager_id").references(() => employees.id),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),

  // Soft delete support (null = not deleted, timestamp = when deleted)
  deletedAt: timestamp("deleted_at"),
}, (table) => [
  index("idx_project_status").on(table.status),
  index("idx_project_manager").on(table.projectManagerId),
  index("idx_project_deleted_at").on(table.deletedAt),
]);

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// ============================================
// PROJECT ASSIGNMENTS
// ============================================
export const projectAssignments = pgTable("project_assignments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  role: varchar("role"), // Role in this specific project
  startDate: date("start_date"),
  endDate: date("end_date"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_assignment_project").on(table.projectId),
  index("idx_assignment_employee").on(table.employeeId),
]);

export const insertProjectAssignmentSchema = createInsertSchema(projectAssignments).omit({
  id: true,
  createdAt: true,
});

export type InsertProjectAssignment = z.infer<typeof insertProjectAssignmentSchema>;
export type ProjectAssignment = typeof projectAssignments.$inferSelect;

// ============================================
// TASKS (Kanban Board Support)
// ============================================
export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  
  // Task Info
  title: varchar("title").notNull(),
  description: text("description"),

  // P.O Number (optional, for tracking purchase orders)
  poNumber: varchar("po_number"),
  
  // Assignment
  assignedToId: varchar("assigned_to_id").references(() => employees.id),
  createdById: varchar("created_by_id").references(() => employees.id),
  
  // Status & Priority
  status: varchar("status").$type<TaskStatus>().notNull().default("Todo"),
  priority: varchar("priority").$type<TaskPriority>().notNull().default("Medium"),
  
  // Dates
  dueDate: date("due_date"),
  completedDate: date("completed_date"),
  
  // Progress
  estimatedHours: decimal("estimated_hours", { precision: 5, scale: 2 }),
  actualHours: decimal("actual_hours", { precision: 5, scale: 2 }),
  
  // Proof of completion
  completionPhotoUrl: text("completion_photo_url"),
  completionNotes: text("completion_notes"),
  
  // Order for Kanban
  sortOrder: integer("sort_order").default(0),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_task_project").on(table.projectId),
  index("idx_task_assigned").on(table.assignedToId),
  index("idx_task_status").on(table.status),
]);

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

// ============================================
// TASK COMMENTS
// ============================================
export const taskComments = pgTable("task_comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").notNull().references(() => tasks.id),
  authorId: varchar("author_id").notNull().references(() => employees.id),
  content: text("content").notNull(),
  attachmentUrl: text("attachment_url"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_comment_task").on(table.taskId),
]);

export const insertTaskCommentSchema = createInsertSchema(taskComments).omit({
  id: true,
  createdAt: true,
});

export type InsertTaskComment = z.infer<typeof insertTaskCommentSchema>;
export type TaskComment = typeof taskComments.$inferSelect;

// ============================================
// PROJECT COMMENTS
// ============================================
export const projectComments = pgTable("project_comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  authorId: varchar("author_id").notNull().references(() => employees.id),
  content: text("content").notNull(),
  // Supports multiple attachments as JSON array (PDFs, DOCS, XLS, images)
  attachments: jsonb("attachments").$type<{ url: string; name: string; type: string; size?: number }[]>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_project_comment_project").on(table.projectId),
  index("idx_project_comment_author").on(table.authorId),
]);

export const insertProjectCommentSchema = createInsertSchema(projectComments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProjectComment = z.infer<typeof insertProjectCommentSchema>;
export type ProjectComment = typeof projectComments.$inferSelect;

// ============================================
// ATTENDANCE LOGS (with Project/Geo-fencing)
// ============================================
export const attendanceLogs = pgTable("attendance_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  projectId: varchar("project_id").references(() => projects.id),
  
  // Time Tracking
  timeIn: timestamp("time_in").notNull(),
  timeOut: timestamp("time_out"),
  totalHours: decimal("total_hours", { precision: 5, scale: 2 }),
  
  // Scheduled Shift (captured at clock-in for reference)
  scheduledShiftStart: varchar("scheduled_shift_start"), // e.g., "08:00"
  scheduledShiftEnd: varchar("scheduled_shift_end"), // e.g., "17:00"

  // Schedule Override (one-time override for sudden shift changes)
  // When set, these values are used instead of scheduledShiftStart/End for late/OT calculations
  scheduledShiftStartOverride: varchar("scheduled_shift_start_override"), // e.g., "13:00" for afternoon shift
  scheduledShiftEndOverride: varchar("scheduled_shift_end_override"), // e.g., "22:00" for afternoon shift

  scheduledShiftDate: date("scheduled_shift_date"), // The date this attendance is counted for
  actualShiftType: varchar("actual_shift_type"), // "day" or "night" (manual selection only, no auto-detect)
  
  // Computed Work Minutes (calculated after clock-out)
  regularMinutes: integer("regular_minutes").default(0), // Capped at scheduled shift length
  overtimeMinutes: integer("overtime_minutes").default(0), // Excess beyond scheduled shift
  
  // Location (for Geo-fencing)
  locationLat: decimal("location_lat", { precision: 10, scale: 7 }),
  locationLng: decimal("location_lng", { precision: 10, scale: 7 }),
  locationSource: varchar("location_source"), // GPS, IP, Manual
  locationAccuracy: decimal("location_accuracy", { precision: 10, scale: 2 }), // GPS accuracy in meters (±)
  distanceFromSite: decimal("distance_from_site", { precision: 10, scale: 2 }), // meters
  
  // Verification
  photoSnapshotUrl: text("photo_snapshot_url"),
  faceVerified: boolean("face_verified").default(false),
  verificationStatus: varchar("verification_status").$type<VerificationStatus>().notNull().default("Pending"),
  
  // Tardiness/Undertime
  isLate: boolean("is_late").default(false), // Flagged for NTE/demerit (any lateness)
  lateMinutes: integer("late_minutes").default(0),
  lateDeductible: boolean("late_deductible").default(false), // Only true if 15+ minutes late (for payroll)
  undertimeMinutes: integer("undertime_minutes").default(0),
  
  // Lunch Deduction
  lunchDeductionMinutes: integer("lunch_deduction_minutes").default(0), // Auto-calculated lunch break deduction
  lunchPaid: boolean("lunch_paid").default(false), // If true, skip the lunch deduction (paid lunch)
  
  // Overtime Approval Workflow
  overtimeHours: decimal("overtime_hours", { precision: 5, scale: 2 }).default("0"),
  overtimeType: varchar("overtime_type"), // Regular, RestDay, Holiday
  overtimeApproved: boolean("overtime_approved").default(false),
  otStatus: varchar("ot_status").$type<OTStatus>().default("Pending"), // Pending, Approved, Rejected
  otMinutesApproved: integer("ot_minutes_approved").default(0), // Final approved OT minutes for payroll
  otApprovedById: varchar("ot_approved_by_id").references(() => employees.id),
  otApprovedAt: timestamp("ot_approved_at"),
  otReason: text("ot_reason"), // Reason/notes for OT approval or rejection
  
  // OT Session Tracking (for multiple clock-ins per day)
  isOvertimeSession: boolean("is_overtime_session").default(false), // True if this is a secondary clock-in
  parentAttendanceId: varchar("parent_attendance_id"), // Links OT session to main shift
  
  // Justification (for off-site/late)
  justification: text("justification"),
  
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_attendance_employee").on(table.employeeId),
  index("idx_attendance_project").on(table.projectId),
  index("idx_attendance_time_in").on(table.timeIn),
  index("idx_attendance_ot_status").on(table.otStatus),
  index("idx_attendance_is_late").on(table.isLate),
  index("idx_attendance_scheduled_date").on(table.scheduledShiftDate),
  index("idx_attendance_employee_date").on(table.employeeId, table.scheduledShiftDate),
  index("idx_attendance_project_date").on(table.projectId, table.scheduledShiftDate),
]);

export const insertAttendanceLogSchema = createInsertSchema(attendanceLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertAttendanceLog = z.infer<typeof insertAttendanceLogSchema>;
export type AttendanceLog = typeof attendanceLogs.$inferSelect;

// ============================================
// PAYROLL RECORDS (Payslips)
// ============================================
export const payrollRecords = pgTable("payroll_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  
  // Link to Payroll Period
  periodId: varchar("period_id"), // References payroll_periods.id
  
  // Cutoff Period (copied from period for reference)
  cutoffStart: date("cutoff_start").notNull(),
  cutoffEnd: date("cutoff_end").notNull(),
  payDate: date("pay_date"), // When this payslip is due
  
  // Work Summary
  daysWorked: decimal("days_worked", { precision: 5, scale: 2 }).default("0"),
  hoursWorked: decimal("hours_worked", { precision: 7, scale: 2 }).default("0"),
  
  // Overtime Breakdown (in minutes for precision)
  regularOTMinutes: integer("regular_ot_minutes").default(0),
  restDayOTMinutes: integer("rest_day_ot_minutes").default(0),
  holidayOTMinutes: integer("holiday_ot_minutes").default(0),
  
  // Legacy hours fields (kept for backward compatibility)
  regularOTHours: decimal("regular_ot_hours", { precision: 5, scale: 2 }).default("0"),
  restDayOTHours: decimal("rest_day_ot_hours", { precision: 5, scale: 2 }).default("0"),
  holidayOTHours: decimal("holiday_ot_hours", { precision: 5, scale: 2 }).default("0"),
  
  // Tardiness
  totalLateMinutes: integer("total_late_minutes").default(0),
  totalUndertimeMinutes: integer("total_undertime_minutes").default(0),
  
  // Earnings
  basicPay: decimal("basic_pay", { precision: 12, scale: 2 }).default("0"),
  regularOTPay: decimal("regular_ot_pay", { precision: 12, scale: 2 }).default("0"),
  restDayOTPay: decimal("rest_day_ot_pay", { precision: 12, scale: 2 }).default("0"),
  holidayOTPay: decimal("holiday_ot_pay", { precision: 12, scale: 2 }).default("0"),
  allowances: decimal("allowances", { precision: 12, scale: 2 }).default("0"),
  
  // Bonuses (with notes for adjustments)
  bonusAmount: decimal("bonus_amount", { precision: 12, scale: 2 }).default("0"),
  bonusNotes: text("bonus_notes"),

  // COLA (Cost of Living Allowance) - tax-exempt, pro-rated per cutoff
  colaAllowance: decimal("cola_allowance", { precision: 12, scale: 2 }).default("0"),

  grossPay: decimal("gross_pay", { precision: 12, scale: 2 }).default("0"),

  // Meal Allowance (FYI only - NOT included in gross/net pay)
  // Calculated from project meal allowance rate × days worked on that project
  mealAllowanceTotal: decimal("meal_allowance_total", { precision: 12, scale: 2 }).default("0"),
  
  // Deductions (Philippine Government)
  sssDeduction: decimal("sss_deduction", { precision: 12, scale: 2 }).default("0"),
  philhealthDeduction: decimal("philhealth_deduction", { precision: 12, scale: 2 }).default("0"),
  pagibigDeduction: decimal("pagibig_deduction", { precision: 12, scale: 2 }).default("0"),
  taxDeduction: decimal("tax_deduction", { precision: 12, scale: 2 }).default("0"),
  
  // Time-based deductions
  lateDeduction: decimal("late_deduction", { precision: 12, scale: 2 }).default("0"),
  undertimeDeduction: decimal("undertime_deduction", { precision: 12, scale: 2 }).default("0"),
  
  // Other deductions (manual adjustments with notes)
  otherDeductionAmount: decimal("other_deduction_amount", { precision: 12, scale: 2 }).default("0"),
  otherDeductionNotes: text("other_deduction_notes"),
  otherDeductions: jsonb("other_deductions").$type<{ name: string; amount: number }[]>().default([]),
  
  // Cash advance deduction
  cashAdvanceDeduction: decimal("cash_advance_deduction", { precision: 12, scale: 2 }).default("0"),

  // Loan deductions (per type)
  sssLoanDeduction: decimal("sss_loan_deduction", { precision: 12, scale: 2 }).default("0"),
  pagibigLoanDeduction: decimal("pagibig_loan_deduction", { precision: 12, scale: 2 }).default("0"),
  bankLoanDeduction: decimal("bank_loan_deduction", { precision: 12, scale: 2 }).default("0"),
  // Total loan deduction (sum of all loan types above)
  loanDeduction: decimal("loan_deduction", { precision: 12, scale: 2 }).default("0"),

  // Leave deductions
  unpaidLeaveDays: decimal("unpaid_leave_days", { precision: 4, scale: 1 }).default("0"),
  unpaidLeaveDeduction: decimal("unpaid_leave_deduction", { precision: 12, scale: 2 }).default("0"),
  paidLeaveDays: decimal("paid_leave_days", { precision: 4, scale: 1 }).default("0"),

  totalDeductions: decimal("total_deductions", { precision: 12, scale: 2 }).default("0"),
  
  // Net
  netPay: decimal("net_pay", { precision: 12, scale: 2 }).default("0"),
  
  // Override flags (for manual adjustments)
  isEdited: boolean("is_edited").default(false),
  overrideNetPay: decimal("override_net_pay", { precision: 12, scale: 2 }), // If set, this is the final net pay
  editNotes: text("edit_notes"), // Notes explaining manual edits
  
  // Payslip Status (separate from payroll period status)
  payslipStatus: varchar("payslip_status").$type<PayslipStatus>().default("Draft"),
  
  // Legacy status field
  status: varchar("status").$type<PayrollStatus>().notNull().default("Draft"),
  processedBy: varchar("processed_by").references(() => employees.id),
  processedAt: timestamp("processed_at"),
  approvedBy: varchar("approved_by").references(() => employees.id),
  approvedAt: timestamp("approved_at"),
  releasedAt: timestamp("released_at"),
  
  // PDF storage
  pdfUrl: text("pdf_url"),

  // Validation flags
  hasNegativeNetPay: boolean("has_negative_net_pay").default(false), // TRUE if net pay < 0

  // Processing lock (prevents concurrent operations)
  processingStartedAt: timestamp("processing_started_at"),
  processingUserId: varchar("processing_user_id"),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),

  // Soft delete support (null = not deleted, timestamp = when deleted)
  deletedAt: timestamp("deleted_at"),
}, (table) => [
  index("idx_payroll_employee").on(table.employeeId),
  index("idx_payroll_period").on(table.periodId),
  index("idx_payroll_cutoff").on(table.cutoffStart, table.cutoffEnd),
  index("idx_payroll_status").on(table.status),
  index("idx_payroll_deleted_at").on(table.deletedAt),
]);

export const insertPayrollRecordSchema = createInsertSchema(payrollRecords).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPayrollRecord = z.infer<typeof insertPayrollRecordSchema>;
export type PayrollRecord = typeof payrollRecords.$inferSelect;

// ============================================
// DISCIPLINARY ACTIONS (NTE System)
// ============================================
export const disciplinaryActions = pgTable("disciplinary_actions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  issuerId: varchar("issuer_id").notNull().references(() => employees.id),
  
  // Violation Details
  violationType: varchar("violation_type").$type<ViolationType>().notNull(),
  incidentDate: date("incident_date").notNull(),
  description: text("description").notNull(),
  attachmentUrl: text("attachment_url"),
  
  // NTE Process
  nteIssuedDate: date("nte_issued_date"),
  responseDeadline: date("response_deadline"),
  
  // Employee Response
  employeeExplanation: text("employee_explanation"),
  explanationDate: timestamp("explanation_date"),
  
  // Resolution
  status: varchar("status").$type<NTEStatus>().notNull().default("Issued"),
  resolution: text("resolution"),
  sanction: varchar("sanction"), // Warning, Suspension, Termination, etc.
  sanctionDays: integer("sanction_days"),
  resolvedById: varchar("resolved_by_id").references(() => employees.id),
  resolvedAt: timestamp("resolved_at"),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),

  // Soft delete support (null = not deleted, timestamp = when deleted)
  deletedAt: timestamp("deleted_at"),
}, (table) => [
  index("idx_disciplinary_employee").on(table.employeeId),
  index("idx_disciplinary_status").on(table.status),
  index("idx_disciplinary_deleted_at").on(table.deletedAt),
]);

export const insertDisciplinaryActionSchema = createInsertSchema(disciplinaryActions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertDisciplinaryAction = z.infer<typeof insertDisciplinaryActionSchema>;
export type DisciplinaryAction = typeof disciplinaryActions.$inferSelect;

// ============================================
// EXPENSES (Finance Module)
// ============================================
export const expenses = pgTable("expenses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id),
  requesterId: varchar("requester_id").notNull().references(() => employees.id),
  
  // Expense Details
  category: varchar("category").$type<ExpenseCategory>().notNull(),
  description: text("description").notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  receiptUrl: text("receipt_url"),
  expenseDate: date("expense_date").notNull(),
  
  // Approval Workflow
  status: varchar("status").$type<ExpenseStatus>().notNull().default("Pending"),
  approvedById: varchar("approved_by_id").references(() => employees.id),
  approvedAt: timestamp("approved_at"),
  rejectionReason: text("rejection_reason"),
  
  // Reimbursement
  reimbursedAt: timestamp("reimbursed_at"),
  reimbursementRef: varchar("reimbursement_ref"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_expense_project").on(table.projectId),
  index("idx_expense_requester").on(table.requesterId),
  index("idx_expense_status").on(table.status),
  index("idx_expense_requester_status").on(table.requesterId, table.status),
]);

export const insertExpenseSchema = createInsertSchema(expenses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;

// ============================================
// EMPLOYEE DOCUMENTS (201 File Attachments)
// ============================================
export const employeeDocuments = pgTable("employee_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  
  documentType: varchar("document_type").notNull(), // Resume, Contract, ID, Certificate, etc.
  documentName: varchar("document_name").notNull(),
  fileUrl: text("file_url").notNull(),
  
  uploadedById: varchar("uploaded_by_id").references(() => employees.id),
  expiryDate: date("expiry_date"),
  
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_document_employee").on(table.employeeId),
]);

export const insertEmployeeDocumentSchema = createInsertSchema(employeeDocuments).omit({
  id: true,
  createdAt: true,
});

export type InsertEmployeeDocument = z.infer<typeof insertEmployeeDocumentSchema>;
export type EmployeeDocument = typeof employeeDocuments.$inferSelect;

// ============================================
// AUDIT LOG
// ============================================
export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  
  userId: varchar("user_id"),
  action: varchar("action").notNull(), // CREATE, UPDATE, DELETE, LOGIN, etc.
  entityType: varchar("entity_type").notNull(), // Employee, Project, Task, etc.
  entityId: varchar("entity_id"),
  
  oldValues: jsonb("old_values"),
  newValues: jsonb("new_values"),
  
  ipAddress: varchar("ip_address"),
  userAgent: text("user_agent"),
  
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_audit_user").on(table.userId),
  index("idx_audit_entity").on(table.entityType, table.entityId),
  index("idx_audit_created").on(table.createdAt),
]);

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;

// ============================================
// HR SETTINGS & CONFIGURATION
// ============================================

// Payroll Cutoff Periods
export const payrollCutoffs = pgTable("payroll_cutoffs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(), // e.g., "1st Cutoff", "2nd Cutoff"
  startDay: integer("start_day").notNull(), // e.g., 1, 16
  endDay: integer("end_day").notNull(), // e.g., 15, 31 (or last day)
  payoutDay: integer("payout_day").notNull(), // e.g., 20, 5
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPayrollCutoffSchema = createInsertSchema(payrollCutoffs).omit({
  id: true,
  createdAt: true,
});

export type InsertPayrollCutoff = z.infer<typeof insertPayrollCutoffSchema>;
export type PayrollCutoff = typeof payrollCutoffs.$inferSelect;

// Payroll Periods (actual payroll runs with specific dates)
export const payrollPeriods = pgTable("payroll_periods", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  
  // Period Details
  name: varchar("name"), // e.g., "January 1-15, 2026"
  cutoffStart: date("cutoff_start").notNull(),
  cutoffEnd: date("cutoff_end").notNull(),
  payDate: date("pay_date").notNull(),
  
  // Type: semi-monthly or monthly
  periodType: varchar("period_type").default("semi-monthly"), // "semi-monthly" or "monthly"
  
  // Status & Processing
  status: varchar("status").$type<PayrollPeriodStatus>().notNull().default("Draft"),
  totalEmployees: integer("total_employees").default(0),
  totalGrossPay: decimal("total_gross_pay", { precision: 15, scale: 2 }).default("0"),
  totalDeductions: decimal("total_deductions", { precision: 15, scale: 2 }).default("0"),
  totalNetPay: decimal("total_net_pay", { precision: 15, scale: 2 }).default("0"),
  
  // Processing metadata
  generatedById: varchar("generated_by_id").references(() => employees.id),
  generatedAt: timestamp("generated_at"),
  releasedById: varchar("released_by_id").references(() => employees.id),
  releasedAt: timestamp("released_at"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_payroll_period_dates").on(table.cutoffStart, table.cutoffEnd),
  index("idx_payroll_period_status").on(table.status),
]);

export const insertPayrollPeriodSchema = createInsertSchema(payrollPeriods).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPayrollPeriod = z.infer<typeof insertPayrollPeriodSchema>;
export type PayrollPeriod = typeof payrollPeriods.$inferSelect;

// Leave Types
export const leaveTypeEnum = ["Vacation", "Sick", "Emergency", "Bereavement", "Maternity", "Paternity", "Birthday", "Other"] as const;
export type LeaveType = typeof leaveTypeEnum[number];

// Accrual modes for leave allocation
export const leaveAccrualModeEnum = ["annual", "monthly", "none"] as const;
export type LeaveAccrualMode = typeof leaveAccrualModeEnum[number];

export const leaveTypes = pgTable("leave_types", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  code: varchar("code"), // e.g., "VL", "SL"
  description: text("description"),
  annualAllocation: integer("annual_allocation").default(0), // days per year
  accrualMode: varchar("accrual_mode").$type<LeaveAccrualMode>().default("annual"), // "annual" = full amount at year start, "monthly" = earned per month, "none" = manual only
  isPaid: boolean("is_paid").default(true),
  requiresApproval: boolean("requires_approval").default(true),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertLeaveTypeSchema = createInsertSchema(leaveTypes).omit({
  id: true,
  createdAt: true,
});

export type InsertLeaveType = z.infer<typeof insertLeaveTypeSchema>;
export type LeaveTypeRecord = typeof leaveTypes.$inferSelect;

// Leave Requests
export const leaveStatusEnum = ["Pending", "Approved", "Rejected", "Cancelled"] as const;
export type LeaveStatus = typeof leaveStatusEnum[number];

export const leaveRequests = pgTable("leave_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  leaveTypeId: varchar("leave_type_id").notNull().references(() => leaveTypes.id),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  totalDays: decimal("total_days", { precision: 4, scale: 1 }).notNull(),
  reason: text("reason"),
  status: varchar("status").$type<LeaveStatus>().notNull().default("Pending"),
  approvedById: varchar("approved_by_id").references(() => employees.id),
  approvedAt: timestamp("approved_at"),
  remarks: text("remarks"),
  createdAt: timestamp("created_at").defaultNow(),

  // Track who submitted the request (for HR on-behalf submissions)
  // If submittedById === employeeId, it was self-submitted
  // If submittedById !== employeeId, it was submitted by HR on behalf of the employee
  submittedById: varchar("submitted_by_id").references(() => employees.id),

  // Paid vs Unpaid days tracking
  // When employee exceeds available leave credits, excess days become unpaid
  paidDays: decimal("paid_days", { precision: 4, scale: 1 }), // Days covered by leave credits
  unpaidDays: decimal("unpaid_days", { precision: 4, scale: 1 }), // Days exceeding leave credits

  // Available balance at time of request (for audit trail)
  availableBalanceAtRequest: decimal("available_balance_at_request", { precision: 5, scale: 1 }),

  // Soft delete support (null = not deleted, timestamp = when deleted)
  deletedAt: timestamp("deleted_at"),
}, (table) => [
  index("idx_leave_request_employee").on(table.employeeId),
  index("idx_leave_request_status").on(table.status),
  index("idx_leave_request_dates").on(table.startDate, table.endDate),
  index("idx_leave_request_employee_status").on(table.employeeId, table.status),
  index("idx_leave_request_deleted_at").on(table.deletedAt),
]);

export const insertLeaveRequestSchema = createInsertSchema(leaveRequests).omit({
  id: true,
  createdAt: true,
  approvedAt: true,
});

export type InsertLeaveRequest = z.infer<typeof insertLeaveRequestSchema>;
export type LeaveRequest = typeof leaveRequests.$inferSelect;

// Holidays
export const holidayTypeEnum = ["Regular", "Special_Non_Working", "Special_Working"] as const;
export type HolidayType = typeof holidayTypeEnum[number];

export const holidays = pgTable("holidays", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  date: date("date").notNull(),
  type: varchar("type").$type<HolidayType>().notNull().default("Regular"),
  year: integer("year").notNull(),
  isNationwide: boolean("is_nationwide").default(true),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_holiday_year").on(table.year),
  index("idx_holiday_date").on(table.date),
]);

export const insertHolidaySchema = createInsertSchema(holidays).omit({
  id: true,
  createdAt: true,
});

export type InsertHoliday = z.infer<typeof insertHolidaySchema>;
export type Holiday = typeof holidays.$inferSelect;

// Cash Advance Requests
export const cashAdvanceStatusEnum = ["Pending", "Approved", "Rejected", "Disbursed", "Fully_Paid"] as const;
export type CashAdvanceStatus = typeof cashAdvanceStatusEnum[number];

// Loan Types (hardcoded preset options)
export const loanTypeEnum = ["SSS_Loan", "Pagibig_Loan", "Bank_Loan"] as const;
export type LoanType = typeof loanTypeEnum[number];

// Loan Status (same workflow as cash advance)
export const loanStatusEnum = ["Pending", "Approved", "Rejected", "Disbursed", "Fully_Paid"] as const;
export type LoanStatus = typeof loanStatusEnum[number];

// Balance Adjustment Types (for audit trail)
export const balanceAdjustmentTypeEnum = ["Manual_Override", "Correction", "Partial_Waiver", "Full_Write_Off"] as const;
export type BalanceAdjustmentType = typeof balanceAdjustmentTypeEnum[number];

export const cashAdvances = pgTable("cash_advances", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  reason: text("reason"),
  status: varchar("status").$type<CashAdvanceStatus>().notNull().default("Pending"),
  approvedById: varchar("approved_by_id").references(() => employees.id),
  approvedAt: timestamp("approved_at"),
  disbursedAt: timestamp("disbursed_at"),
  deductionPerCutoff: decimal("deduction_per_cutoff", { precision: 12, scale: 2 }),
  remainingBalance: decimal("remaining_balance", { precision: 12, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),

  // Track who submitted the request (for HR on-behalf submissions)
  submittedById: varchar("submitted_by_id").references(() => employees.id),
}, (table) => [
  index("idx_cash_advance_employee").on(table.employeeId),
  index("idx_cash_advance_status").on(table.status),
]);

export const insertCashAdvanceSchema = createInsertSchema(cashAdvances).omit({
  id: true,
  createdAt: true,
  approvedAt: true,
  disbursedAt: true,
});

export type InsertCashAdvance = z.infer<typeof insertCashAdvanceSchema>;
export type CashAdvance = typeof cashAdvances.$inferSelect;

// Company Settings (key-value store for flexible configuration)
export const companySettings = pgTable("company_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: varchar("key").notNull().unique(),
  value: text("value"),
  category: varchar("category"), // "payroll", "attendance", "leave", etc.
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCompanySettingSchema = createInsertSchema(companySettings).omit({
  id: true,
  updatedAt: true,
});

export type InsertCompanySetting = z.infer<typeof insertCompanySettingSchema>;
export type CompanySetting = typeof companySettings.$inferSelect;

// Employee Leave Allocations (per employee, per leave type, per year)
export const employeeLeaveAllocations = pgTable("employee_leave_allocations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  leaveTypeId: varchar("leave_type_id").notNull().references(() => leaveTypes.id),
  year: integer("year").notNull(),
  totalAllocated: decimal("total_allocated", { precision: 5, scale: 1 }).notNull().default("0"), // Full annual entitlement
  accruedToDate: decimal("accrued_to_date", { precision: 5, scale: 1 }).notNull().default("0"), // Amount accrued so far (for monthly mode)
  used: decimal("used", { precision: 5, scale: 1 }).notNull().default("0"),
  remaining: decimal("remaining", { precision: 5, scale: 1 }).notNull().default("0"),
  carriedOver: decimal("carried_over", { precision: 5, scale: 1 }).default("0"),
  lastAccrualMonth: integer("last_accrual_month").default(0), // 1-12, tracks last processed month for accrual
  expiresAt: date("expires_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_leave_allocation_employee").on(table.employeeId),
  index("idx_leave_allocation_year").on(table.year),
  index("idx_leave_allocation_employee_year").on(table.employeeId, table.year),
  index("idx_leave_allocation_unique").on(table.employeeId, table.leaveTypeId, table.year),
]);

export const insertEmployeeLeaveAllocationSchema = createInsertSchema(employeeLeaveAllocations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertEmployeeLeaveAllocation = z.infer<typeof insertEmployeeLeaveAllocationSchema>;
export type EmployeeLeaveAllocation = typeof employeeLeaveAllocations.$inferSelect;

// Cash Advance Payments (tracks deductions per payroll)
export const cashAdvancePayments = pgTable("cash_advance_payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  cashAdvanceId: varchar("cash_advance_id").notNull().references(() => cashAdvances.id),
  payrollRecordId: varchar("payroll_record_id").references(() => payrollRecords.id),
  payrollPeriodId: varchar("payroll_period_id").references(() => payrollPeriods.id),
  deductionAmount: decimal("deduction_amount", { precision: 12, scale: 2 }).notNull(),
  remainingBalanceAfter: decimal("remaining_balance_after", { precision: 12, scale: 2 }).notNull(),
  paymentDate: date("payment_date").notNull(),
  notes: text("notes"),
  // Idempotency flag: TRUE = deduction applied to cash advance balance, FALSE = tracked but not applied
  deductionApplied: boolean("deduction_applied").default(false),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_payment_cash_advance").on(table.cashAdvanceId),
  index("idx_payment_payroll_record").on(table.payrollRecordId),
]);

export const insertCashAdvancePaymentSchema = createInsertSchema(cashAdvancePayments).omit({
  id: true,
  createdAt: true,
});

export type InsertCashAdvancePayment = z.infer<typeof insertCashAdvancePaymentSchema>;
export type CashAdvancePayment = typeof cashAdvancePayments.$inferSelect;

// ============================================
// LOANS (Similar workflow to Cash Advances)
// ============================================
export const loans = pgTable("loans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  loanType: varchar("loan_type").$type<LoanType>().notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  interest: decimal("interest", { precision: 12, scale: 2 }).default("0"), // Optional interest amount
  totalAmount: decimal("total_amount", { precision: 12, scale: 2 }).notNull(), // amount + interest
  reason: text("reason"),
  status: varchar("status").$type<LoanStatus>().notNull().default("Pending"),
  approvedById: varchar("approved_by_id").references(() => employees.id),
  approvedAt: timestamp("approved_at"),
  disbursedAt: timestamp("disbursed_at"),
  deductionPerCutoff: decimal("deduction_per_cutoff", { precision: 12, scale: 2 }),
  remainingBalance: decimal("remaining_balance", { precision: 12, scale: 2 }),
  startDeductionDate: date("start_deduction_date"), // When to start payroll deductions
  remarks: text("remarks"), // HR remarks for approval/rejection
  createdAt: timestamp("created_at").defaultNow(),

  // Track who submitted the request (for HR on-behalf submissions)
  submittedById: varchar("submitted_by_id").references(() => employees.id),
}, (table) => [
  index("idx_loan_employee").on(table.employeeId),
  index("idx_loan_status").on(table.status),
  index("idx_loan_type").on(table.loanType),
  index("idx_loan_employee_status").on(table.employeeId, table.status),
]);

export const insertLoanSchema = createInsertSchema(loans).omit({
  id: true,
  createdAt: true,
  approvedAt: true,
  disbursedAt: true,
});

export type InsertLoan = z.infer<typeof insertLoanSchema>;
export type Loan = typeof loans.$inferSelect;

// Loan Payments (tracks deductions per payroll - mirrors cashAdvancePayments)
export const loanPayments = pgTable("loan_payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  loanId: varchar("loan_id").notNull().references(() => loans.id),
  payrollRecordId: varchar("payroll_record_id").references(() => payrollRecords.id),
  payrollPeriodId: varchar("payroll_period_id").references(() => payrollPeriods.id),
  deductionAmount: decimal("deduction_amount", { precision: 12, scale: 2 }).notNull(),
  remainingBalanceAfter: decimal("remaining_balance_after", { precision: 12, scale: 2 }).notNull(),
  paymentDate: date("payment_date").notNull(),
  notes: text("notes"),
  // Idempotency flag: TRUE = deduction applied to loan balance, FALSE = tracked but not applied
  deductionApplied: boolean("deduction_applied").default(false),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_loan_payment_loan").on(table.loanId),
  index("idx_loan_payment_payroll_record").on(table.payrollRecordId),
]);

export const insertLoanPaymentSchema = createInsertSchema(loanPayments).omit({
  id: true,
  createdAt: true,
});

export type InsertLoanPayment = z.infer<typeof insertLoanPaymentSchema>;
export type LoanPayment = typeof loanPayments.$inferSelect;

// ============================================
// BALANCE ADJUSTMENTS (Audit trail for manual overrides)
// ============================================
export const balanceAdjustments = pgTable("balance_adjustments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entityType: varchar("entity_type").notNull(), // "CashAdvance" or "Loan"
  entityId: varchar("entity_id").notNull(), // ID of the cash advance or loan
  adjustedById: varchar("adjusted_by_id").notNull().references(() => employees.id),
  previousBalance: decimal("previous_balance", { precision: 12, scale: 2 }).notNull(),
  newBalance: decimal("new_balance", { precision: 12, scale: 2 }).notNull(),
  adjustmentType: varchar("adjustment_type").$type<BalanceAdjustmentType>().notNull(),
  reason: text("reason").notNull(), // Required for accountability
  ipAddress: varchar("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_balance_adjustment_entity").on(table.entityType, table.entityId),
  index("idx_balance_adjustment_adjusted_by").on(table.adjustedById),
  index("idx_balance_adjustment_created").on(table.createdAt),
]);

export const insertBalanceAdjustmentSchema = createInsertSchema(balanceAdjustments).omit({
  id: true,
  createdAt: true,
});

export type InsertBalanceAdjustment = z.infer<typeof insertBalanceAdjustmentSchema>;
export type BalanceAdjustment = typeof balanceAdjustments.$inferSelect;

// ============================================
// PERMISSION & ROLE MANAGEMENT SYSTEM
// ============================================

// Permission definitions (registry of all available permissions)
export const permissions = pgTable("permissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  feature: varchar("feature", { length: 50 }).notNull(), // e.g., "employees", "payroll"
  action: varchar("action", { length: 50 }).notNull(), // e.g., "view", "create", "edit", "delete"
  code: varchar("code", { length: 100 }).notNull().unique(), // e.g., "employees.view"
  name: varchar("name", { length: 100 }).notNull(), // e.g., "View Employees"
  description: text("description"), // e.g., "Can view employee list and details"
  category: varchar("category", { length: 50 }).$type<PermissionCategory>().notNull(), // e.g., "Human Resources"
  sortOrder: integer("sort_order").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_permission_feature").on(table.feature),
  index("idx_permission_category").on(table.category),
  index("idx_permission_code").on(table.code),
]);

export const insertPermissionSchema = createInsertSchema(permissions).omit({
  id: true,
  createdAt: true,
});

export type InsertPermission = z.infer<typeof insertPermissionSchema>;
export type Permission = typeof permissions.$inferSelect;

// Role definitions (Superadmin, HR/Admin, custom roles)
export const roles = pgTable("roles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 50 }).notNull().unique(), // e.g., "SUPERADMIN", "HR_ADMIN"
  displayName: varchar("display_name", { length: 100 }).notNull(), // e.g., "Super Administrator"
  description: text("description"),
  isSystemRole: boolean("is_system_role").default(false), // Cannot delete system roles
  isSuperadmin: boolean("is_superadmin").default(false), // Bypasses all permission checks
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertRoleSchema = createInsertSchema(roles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertRole = z.infer<typeof insertRoleSchema>;
export type Role = typeof roles.$inferSelect;

// Role-Permission mapping (what permissions each role has)
export const rolePermissions = pgTable("role_permissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roleId: varchar("role_id").notNull().references(() => roles.id, { onDelete: "cascade" }),
  permissionId: varchar("permission_id").notNull().references(() => permissions.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_role_permission_role").on(table.roleId),
  index("idx_role_permission_permission").on(table.permissionId),
]);

export const insertRolePermissionSchema = createInsertSchema(rolePermissions).omit({
  id: true,
  createdAt: true,
});

export type InsertRolePermission = z.infer<typeof insertRolePermissionSchema>;
export type RolePermission = typeof rolePermissions.$inferSelect;

// User-Permission overrides (individual user permission grants/revokes)
export const userPermissions = pgTable("user_permissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id, { onDelete: "cascade" }),
  permissionId: varchar("permission_id").notNull().references(() => permissions.id, { onDelete: "cascade" }),
  grantedById: varchar("granted_by_id").notNull().references(() => employees.id),
  grantedAt: timestamp("granted_at").defaultNow(),
  expiresAt: timestamp("expires_at"), // Optional expiration
}, (table) => [
  index("idx_user_permission_employee").on(table.employeeId),
  index("idx_user_permission_permission").on(table.permissionId),
]);

export const insertUserPermissionSchema = createInsertSchema(userPermissions).omit({
  id: true,
  grantedAt: true,
});

export type InsertUserPermission = z.infer<typeof insertUserPermissionSchema>;
export type UserPermission = typeof userPermissions.$inferSelect;

// Permission Audit Log (tracks all permission changes)
export const permissionAuditLogs = pgTable("permission_audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  actorId: varchar("actor_id").notNull().references(() => employees.id),
  targetEmployeeId: varchar("target_employee_id").references(() => employees.id),
  action: varchar("action", { length: 50 }).notNull(), // "granted", "revoked", "role_changed"
  permissionCode: varchar("permission_code", { length: 100 }),
  roleId: varchar("role_id").references(() => roles.id),
  oldValue: jsonb("old_value"),
  newValue: jsonb("new_value"),
  ipAddress: varchar("ip_address", { length: 50 }),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_permission_audit_actor").on(table.actorId),
  index("idx_permission_audit_target").on(table.targetEmployeeId),
  index("idx_permission_audit_created").on(table.createdAt),
]);

export const insertPermissionAuditLogSchema = createInsertSchema(permissionAuditLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertPermissionAuditLog = z.infer<typeof insertPermissionAuditLogSchema>;
export type PermissionAuditLog = typeof permissionAuditLogs.$inferSelect;

// ============================================
// RELATIONS
// ============================================
export const employeesRelations = relations(employees, ({ one, many }) => ({
  attendanceLogs: many(attendanceLogs),
  payrollRecords: many(payrollRecords),
  projectAssignments: many(projectAssignments),
  tasksAssigned: many(tasks),
  disciplinaryActions: many(disciplinaryActions),
  expenses: many(expenses),
  documents: many(employeeDocuments),
  userPermissions: many(userPermissions),
  cashAdvances: many(cashAdvances),
  loans: many(loans),
  assignedRole: one(roles, {
    fields: [employees.roleId],
    references: [roles.id],
  }),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  projectManager: one(employees, {
    fields: [projects.projectManagerId],
    references: [employees.id],
  }),
  assignments: many(projectAssignments),
  tasks: many(tasks),
  attendanceLogs: many(attendanceLogs),
  expenses: many(expenses),
  comments: many(projectComments),
}));

export const projectAssignmentsRelations = relations(projectAssignments, ({ one }) => ({
  project: one(projects, {
    fields: [projectAssignments.projectId],
    references: [projects.id],
  }),
  employee: one(employees, {
    fields: [projectAssignments.employeeId],
    references: [employees.id],
  }),
}));

export const tasksRelations = relations(tasks, ({ one, many }) => ({
  project: one(projects, {
    fields: [tasks.projectId],
    references: [projects.id],
  }),
  assignedTo: one(employees, {
    fields: [tasks.assignedToId],
    references: [employees.id],
  }),
  createdBy: one(employees, {
    fields: [tasks.createdById],
    references: [employees.id],
  }),
  comments: many(taskComments),
}));

export const taskCommentsRelations = relations(taskComments, ({ one }) => ({
  task: one(tasks, {
    fields: [taskComments.taskId],
    references: [tasks.id],
  }),
  author: one(employees, {
    fields: [taskComments.authorId],
    references: [employees.id],
  }),
}));

export const projectCommentsRelations = relations(projectComments, ({ one }) => ({
  project: one(projects, {
    fields: [projectComments.projectId],
    references: [projects.id],
  }),
  author: one(employees, {
    fields: [projectComments.authorId],
    references: [employees.id],
  }),
}));

export const attendanceLogsRelations = relations(attendanceLogs, ({ one }) => ({
  employee: one(employees, {
    fields: [attendanceLogs.employeeId],
    references: [employees.id],
  }),
  project: one(projects, {
    fields: [attendanceLogs.projectId],
    references: [projects.id],
  }),
}));

export const payrollRecordsRelations = relations(payrollRecords, ({ one }) => ({
  employee: one(employees, {
    fields: [payrollRecords.employeeId],
    references: [employees.id],
  }),
}));

export const cashAdvancesRelations = relations(cashAdvances, ({ one, many }) => ({
  employee: one(employees, {
    fields: [cashAdvances.employeeId],
    references: [employees.id],
  }),
  approvedBy: one(employees, {
    fields: [cashAdvances.approvedById],
    references: [employees.id],
  }),
  payments: many(cashAdvancePayments),
}));

export const cashAdvancePaymentsRelations = relations(cashAdvancePayments, ({ one }) => ({
  cashAdvance: one(cashAdvances, {
    fields: [cashAdvancePayments.cashAdvanceId],
    references: [cashAdvances.id],
  }),
  payrollRecord: one(payrollRecords, {
    fields: [cashAdvancePayments.payrollRecordId],
    references: [payrollRecords.id],
  }),
}));

export const loansRelations = relations(loans, ({ one, many }) => ({
  employee: one(employees, {
    fields: [loans.employeeId],
    references: [employees.id],
  }),
  approvedBy: one(employees, {
    fields: [loans.approvedById],
    references: [employees.id],
  }),
  payments: many(loanPayments),
}));

export const loanPaymentsRelations = relations(loanPayments, ({ one }) => ({
  loan: one(loans, {
    fields: [loanPayments.loanId],
    references: [loans.id],
  }),
  payrollRecord: one(payrollRecords, {
    fields: [loanPayments.payrollRecordId],
    references: [payrollRecords.id],
  }),
}));

export const balanceAdjustmentsRelations = relations(balanceAdjustments, ({ one }) => ({
  adjustedBy: one(employees, {
    fields: [balanceAdjustments.adjustedById],
    references: [employees.id],
  }),
}));

export const disciplinaryActionsRelations = relations(disciplinaryActions, ({ one }) => ({
  employee: one(employees, {
    fields: [disciplinaryActions.employeeId],
    references: [employees.id],
  }),
  issuer: one(employees, {
    fields: [disciplinaryActions.issuerId],
    references: [employees.id],
  }),
  resolvedBy: one(employees, {
    fields: [disciplinaryActions.resolvedById],
    references: [employees.id],
  }),
}));

export const expensesRelations = relations(expenses, ({ one }) => ({
  project: one(projects, {
    fields: [expenses.projectId],
    references: [projects.id],
  }),
  requester: one(employees, {
    fields: [expenses.requesterId],
    references: [employees.id],
  }),
  approvedBy: one(employees, {
    fields: [expenses.approvedById],
    references: [employees.id],
  }),
}));

export const employeeDocumentsRelations = relations(employeeDocuments, ({ one }) => ({
  employee: one(employees, {
    fields: [employeeDocuments.employeeId],
    references: [employees.id],
  }),
  uploadedBy: one(employees, {
    fields: [employeeDocuments.uploadedById],
    references: [employees.id],
  }),
}));

// ============================================
// DEVOTIONAL SYSTEM (365-Day Devotional Plan)
// ============================================

// Devotionals table (365 base entries)
export const devotionals = pgTable("devotionals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dayNumber: integer("day_number").notNull().unique(), // 1-365

  // Scripture
  verse: text("verse").notNull(),
  reference: varchar("reference").notNull(), // e.g., "Proverbs 3:5-6"

  // Core content
  baseExcerpt: text("base_excerpt").notNull(), // ~150 word reflection
  theme: varchar("theme"), // e.g., "Integrity", "Perseverance"

  // Year-specific focus (deprecated - kept for backward compatibility)
  year1Focus: text("year1_focus"),
  year2Focus: text("year2_focus"),
  year3Focus: text("year3_focus"),

  // Metadata
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_devotional_day").on(table.dayNumber),
  index("idx_devotional_theme").on(table.theme),
]);

export const insertDevotionalSchema = createInsertSchema(devotionals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertDevotional = z.infer<typeof insertDevotionalSchema>;
export type Devotional = typeof devotionals.$inferSelect;

// Employee Devotional Progress (tracks each employee's journey)
export const employeeDevotionalProgress = pgTable("employee_devotional_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),

  // Journey tracking
  startDate: date("start_date").notNull(), // When they started the plan
  currentYear: integer("current_year").notNull().default(1), // 1, 2, or 3

  // Reading progress
  lastReadDay: integer("last_read_day").default(0), // 1-365 (day of year)
  lastReadDate: date("last_read_date"),

  // Statistics
  totalDaysRead: integer("total_days_read").default(0), // Lifetime counter
  currentStreak: integer("current_streak").default(0), // Consecutive days
  longestStreak: integer("longest_streak").default(0),

  // Today's status (reset daily)
  todayRead: boolean("today_read").default(false),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_devotional_progress_employee").on(table.employeeId),
  index("idx_devotional_progress_year").on(table.currentYear),
]);

export const insertEmployeeDevotionalProgressSchema = createInsertSchema(employeeDevotionalProgress).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertEmployeeDevotionalProgress = z.infer<typeof insertEmployeeDevotionalProgressSchema>;
export type EmployeeDevotionalProgress = typeof employeeDevotionalProgress.$inferSelect;

// Devotional reading log (historical record of readings)
export const devotionalReadingLogs = pgTable("devotional_reading_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  devotionalId: varchar("devotional_id").notNull().references(() => devotionals.id),

  // Reading details
  readDate: date("read_date").notNull(),
  dayNumber: integer("day_number").notNull(), // 1-365
  yearNumber: integer("year_number").notNull(), // 1, 2, or 3

  // Optional user engagement
  personalNote: text("personal_note"),
  isFavorite: boolean("is_favorite").default(false),

  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_reading_log_employee").on(table.employeeId),
  index("idx_reading_log_date").on(table.readDate),
  index("idx_reading_log_employee_date").on(table.employeeId, table.readDate),
]);

export const insertDevotionalReadingLogSchema = createInsertSchema(devotionalReadingLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertDevotionalReadingLog = z.infer<typeof insertDevotionalReadingLogSchema>;
export type DevotionalReadingLog = typeof devotionalReadingLogs.$inferSelect;

// Relations for devotional system
export const devotionalsRelations = relations(devotionals, ({ many }) => ({
  readingLogs: many(devotionalReadingLogs),
}));

export const employeeDevotionalProgressRelations = relations(employeeDevotionalProgress, ({ one }) => ({
  employee: one(employees, {
    fields: [employeeDevotionalProgress.employeeId],
    references: [employees.id],
  }),
}));

export const devotionalReadingLogsRelations = relations(devotionalReadingLogs, ({ one }) => ({
  employee: one(employees, {
    fields: [devotionalReadingLogs.employeeId],
    references: [employees.id],
  }),
  devotional: one(devotionals, {
    fields: [devotionalReadingLogs.devotionalId],
    references: [devotionals.id],
  }),
}));

// ============================================
// 13TH MONTH BONUS SYSTEM
// ============================================

// Status for 13th month release tracking
export const thirteenthMonthStatusEnum = ["Pending", "Partial", "Released"] as const;
export type ThirteenthMonthStatus = typeof thirteenthMonthStatusEnum[number];

// 13th Month Accruals - Tracks accumulated amounts per employee per year
export const thirteenthMonthAccruals = pgTable("thirteenth_month_accruals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  year: integer("year").notNull(),

  // Accumulated basic pay from released payrolls
  accumulatedBasicPay: decimal("accumulated_basic_pay", { precision: 12, scale: 2 }).default("0"),

  // Calculated 13th month amount (accumulatedBasicPay / 12)
  accruedAmount: decimal("accrued_amount", { precision: 12, scale: 2 }).default("0"),

  // Months worked for proration display
  monthsWorked: decimal("months_worked", { precision: 4, scale: 2 }).default("0"),

  // Total amount released so far
  releasedAmount: decimal("released_amount", { precision: 12, scale: 2 }).default("0"),

  // Percentage released (0-100)
  releasedPercentage: decimal("released_percentage", { precision: 5, scale: 2 }).default("0"),

  // Status: Pending, Partial, Released
  status: varchar("status").$type<ThirteenthMonthStatus>().default("Pending"),

  // Last payroll that updated this accrual
  lastPayrollId: varchar("last_payroll_id").references(() => payrollRecords.id),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_13th_month_accrual_employee").on(table.employeeId),
  index("idx_13th_month_accrual_year").on(table.year),
  index("idx_13th_month_accrual_employee_year").on(table.employeeId, table.year),
  index("idx_13th_month_accrual_status").on(table.status),
]);

export const insertThirteenthMonthAccrualSchema = createInsertSchema(thirteenthMonthAccruals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertThirteenthMonthAccrual = z.infer<typeof insertThirteenthMonthAccrualSchema>;
export type ThirteenthMonthAccrual = typeof thirteenthMonthAccruals.$inferSelect;

// 13th Month Releases - Audit trail for all releases
export const thirteenthMonthReleases = pgTable("thirteenth_month_releases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id),
  year: integer("year").notNull(),

  // Release details
  releaseAmount: decimal("release_amount", { precision: 12, scale: 2 }).notNull(),
  releasePercentage: decimal("release_percentage", { precision: 5, scale: 2 }).default("100"), // For partial releases

  // Target payroll record where bonus was applied
  payrollRecordId: varchar("payroll_record_id").references(() => payrollRecords.id),

  // Cutoff period for reference
  cutoffStart: date("cutoff_start"),
  cutoffEnd: date("cutoff_end"),

  // Who released it
  releasedById: varchar("released_by_id").references(() => employees.id),
  releasedAt: timestamp("released_at").defaultNow(),

  // Notes for audit
  notes: text("notes"),

  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_13th_month_release_employee").on(table.employeeId),
  index("idx_13th_month_release_year").on(table.year),
  index("idx_13th_month_release_payroll").on(table.payrollRecordId),
  index("idx_13th_month_release_date").on(table.releasedAt),
]);

export const insertThirteenthMonthReleaseSchema = createInsertSchema(thirteenthMonthReleases).omit({
  id: true,
  createdAt: true,
  releasedAt: true,
});

export type InsertThirteenthMonthRelease = z.infer<typeof insertThirteenthMonthReleaseSchema>;
export type ThirteenthMonthRelease = typeof thirteenthMonthReleases.$inferSelect;

// Relations for 13th month system
export const thirteenthMonthAccrualsRelations = relations(thirteenthMonthAccruals, ({ one, many }) => ({
  employee: one(employees, {
    fields: [thirteenthMonthAccruals.employeeId],
    references: [employees.id],
  }),
  lastPayroll: one(payrollRecords, {
    fields: [thirteenthMonthAccruals.lastPayrollId],
    references: [payrollRecords.id],
  }),
  releases: many(thirteenthMonthReleases),
}));

export const thirteenthMonthReleasesRelations = relations(thirteenthMonthReleases, ({ one }) => ({
  employee: one(employees, {
    fields: [thirteenthMonthReleases.employeeId],
    references: [employees.id],
  }),
  payrollRecord: one(payrollRecords, {
    fields: [thirteenthMonthReleases.payrollRecordId],
    references: [payrollRecords.id],
  }),
  releasedBy: one(employees, {
    fields: [thirteenthMonthReleases.releasedById],
    references: [employees.id],
  }),
  accrual: one(thirteenthMonthAccruals, {
    fields: [thirteenthMonthReleases.employeeId, thirteenthMonthReleases.year],
    references: [thirteenthMonthAccruals.employeeId, thirteenthMonthAccruals.year],
  }),
}));

// ============================================
// PERMISSION SYSTEM RELATIONS
// ============================================

export const rolesRelations = relations(roles, ({ many }) => ({
  rolePermissions: many(rolePermissions),
  employees: many(employees),
}));

export const permissionsRelations = relations(permissions, ({ many }) => ({
  rolePermissions: many(rolePermissions),
  userPermissions: many(userPermissions),
}));

export const rolePermissionsRelations = relations(rolePermissions, ({ one }) => ({
  role: one(roles, {
    fields: [rolePermissions.roleId],
    references: [roles.id],
  }),
  permission: one(permissions, {
    fields: [rolePermissions.permissionId],
    references: [permissions.id],
  }),
}));

export const userPermissionsRelations = relations(userPermissions, ({ one }) => ({
  employee: one(employees, {
    fields: [userPermissions.employeeId],
    references: [employees.id],
  }),
  permission: one(permissions, {
    fields: [userPermissions.permissionId],
    references: [permissions.id],
  }),
  grantedBy: one(employees, {
    fields: [userPermissions.grantedById],
    references: [employees.id],
  }),
}));

export const permissionAuditLogsRelations = relations(permissionAuditLogs, ({ one }) => ({
  actor: one(employees, {
    fields: [permissionAuditLogs.actorId],
    references: [employees.id],
  }),
  targetEmployee: one(employees, {
    fields: [permissionAuditLogs.targetEmployeeId],
    references: [employees.id],
  }),
  role: one(roles, {
    fields: [permissionAuditLogs.roleId],
    references: [roles.id],
  }),
}));

// ============================================
// NOTIFICATION SYSTEM
// ============================================

// Notification categories for preference grouping
export const notificationCategoryEnum = [
  "leave",          // Leave requests & approvals
  "payroll",        // Payroll processing & payslip availability
  "attendance",     // Tardiness, flagging, geofence violations
  "tasks",          // Task assignments, due dates, status changes
  "expenses",       // Expense requests & approvals
  "cash_advance",   // Cash advance & loan workflows
  "disciplinary",   // NTE issuance, deadlines, resolutions
  "projects",       // Project assignments, status changes, comments
  "permissions",    // Role/permission changes
  "system",         // System-wide announcements, holidays
  "devotional",     // Devotional streaks, milestones
] as const;
export type NotificationCategory = typeof notificationCategoryEnum[number];

// Notification priority levels
export const notificationPriorityEnum = ["low", "normal", "high", "urgent"] as const;
export type NotificationPriority = typeof notificationPriorityEnum[number];

// Notification channel for delivery preferences
export const notificationChannelEnum = ["in_app", "push", "email"] as const;
export type NotificationChannel = typeof notificationChannelEnum[number];

// Notifications table - stores all notifications
export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),

  // Recipient
  recipientId: varchar("recipient_id").notNull().references(() => employees.id),

  // Content
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  category: varchar("category").$type<NotificationCategory>().notNull(),
  priority: varchar("priority").$type<NotificationPriority>().notNull().default("normal"),

  // Navigation - where clicking the notification should go
  actionUrl: varchar("action_url", { length: 500 }),

  // Source entity - what triggered this notification
  entityType: varchar("entity_type", { length: 50 }), // "leave_request", "expense", "task", etc.
  entityId: varchar("entity_id"),

  // Actor - who triggered this notification (null for system-generated)
  actorId: varchar("actor_id").references(() => employees.id),

  // Status
  isRead: boolean("is_read").default(false).notNull(),
  readAt: timestamp("read_at"),

  // Delivery tracking
  pushSent: boolean("push_sent").default(false),
  emailSent: boolean("email_sent").default(false),

  // For admin broadcast notifications
  isBroadcast: boolean("is_broadcast").default(false),

  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"), // For auto-cleanup
}, (table) => [
  index("idx_notification_recipient").on(table.recipientId),
  index("idx_notification_recipient_read").on(table.recipientId, table.isRead),
  index("idx_notification_category").on(table.category),
  index("idx_notification_created").on(table.createdAt),
  index("idx_notification_entity").on(table.entityType, table.entityId),
  index("idx_notification_expires").on(table.expiresAt),
]);

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

// Notification preferences - per employee, per category, per channel
export const notificationPreferences = pgTable("notification_preferences", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id, { onDelete: "cascade" }),

  // Master toggle
  enabled: boolean("enabled").default(true).notNull(), // Global on/off

  // Category-channel preferences stored as JSONB
  // Structure: { "leave": { "in_app": true, "push": true, "email": false }, ... }
  preferences: jsonb("preferences").$type<Record<NotificationCategory, Record<NotificationChannel, boolean>>>().notNull(),

  // Quiet hours (optional)
  quietHoursStart: varchar("quiet_hours_start"), // e.g., "22:00"
  quietHoursEnd: varchar("quiet_hours_end"),     // e.g., "07:00"

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_notification_pref_employee").on(table.employeeId),
]);

export const insertNotificationPreferenceSchema = createInsertSchema(notificationPreferences).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertNotificationPreference = z.infer<typeof insertNotificationPreferenceSchema>;
export type NotificationPreference = typeof notificationPreferences.$inferSelect;

// Push subscriptions - stores Web Push API subscriptions per device
export const pushSubscriptions = pgTable("push_subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => employees.id, { onDelete: "cascade" }),

  // Web Push subscription object
  endpoint: text("endpoint").notNull(),
  p256dh: text("p256dh").notNull(),    // Public key
  auth: text("auth").notNull(),         // Auth secret

  // Device info
  userAgent: text("user_agent"),
  deviceName: varchar("device_name", { length: 100 }),

  // Status
  isActive: boolean("is_active").default(true).notNull(),
  lastUsedAt: timestamp("last_used_at"),
  failCount: integer("fail_count").default(0), // Increment on push failure, deactivate after threshold

  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_push_sub_employee").on(table.employeeId),
  index("idx_push_sub_endpoint").on(table.endpoint),
  index("idx_push_sub_active").on(table.employeeId, table.isActive),
]);

export const insertPushSubscriptionSchema = createInsertSchema(pushSubscriptions).omit({
  id: true,
  createdAt: true,
});

export type InsertPushSubscription = z.infer<typeof insertPushSubscriptionSchema>;
export type PushSubscription = typeof pushSubscriptions.$inferSelect;

// Relations for notification system
export const notificationsRelations = relations(notifications, ({ one }) => ({
  recipient: one(employees, {
    fields: [notifications.recipientId],
    references: [employees.id],
  }),
  actor: one(employees, {
    fields: [notifications.actorId],
    references: [employees.id],
  }),
}));

export const notificationPreferencesRelations = relations(notificationPreferences, ({ one }) => ({
  employee: one(employees, {
    fields: [notificationPreferences.employeeId],
    references: [employees.id],
  }),
}));

export const pushSubscriptionsRelations = relations(pushSubscriptions, ({ one }) => ({
  employee: one(employees, {
    fields: [pushSubscriptions.employeeId],
    references: [employees.id],
  }),
}));
