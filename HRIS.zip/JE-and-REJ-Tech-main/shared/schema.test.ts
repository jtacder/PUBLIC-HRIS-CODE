/**
 * Tests for Shared Schema Validations
 *
 * Tests all Zod schemas and type definitions including:
 * - Employee schema validation
 * - Project schema validation
 * - Task schema validation
 * - Attendance schema validation
 * - Payroll schema validation
 * - Leave request schema validation
 * - And other entity schemas
 */

import { describe, it, expect } from 'vitest';
import { z } from 'zod';
import {
  employeeRoleEnum,
  employeeStatusEnum,
  rateTypeEnum,
  projectStatusEnum,
  taskStatusEnum,
  taskPriorityEnum,
  otStatusEnum,
  payrollStatusEnum,
  nteStatusEnum,
  expenseStatusEnum,
} from './schema';

// ============================================
// ENUM VALIDATIONS
// ============================================

describe('Employee Role Enum', () => {
  it('should contain all valid roles', () => {
    expect(employeeRoleEnum).toContain('ADMIN');
    expect(employeeRoleEnum).toContain('HR');
    expect(employeeRoleEnum).toContain('ENGINEER');
    expect(employeeRoleEnum).toContain('WORKER');
  });

  it('should have exactly 4 roles', () => {
    expect(employeeRoleEnum.length).toBe(4);
  });

  it('should validate role using zod', () => {
    const roleSchema = z.enum(employeeRoleEnum);

    expect(roleSchema.safeParse('ADMIN').success).toBe(true);
    expect(roleSchema.safeParse('HR').success).toBe(true);
    expect(roleSchema.safeParse('ENGINEER').success).toBe(true);
    expect(roleSchema.safeParse('WORKER').success).toBe(true);
    expect(roleSchema.safeParse('INVALID').success).toBe(false);
  });
});

describe('Employee Status Enum', () => {
  it('should contain all valid statuses', () => {
    expect(employeeStatusEnum).toContain('Active');
    expect(employeeStatusEnum).toContain('Probationary');
    expect(employeeStatusEnum).toContain('Suspended');
    expect(employeeStatusEnum).toContain('Terminated');
    expect(employeeStatusEnum).toContain('Inactive');
  });

  it('should have exactly 5 statuses', () => {
    expect(employeeStatusEnum.length).toBe(5);
  });

  it('should validate status using zod', () => {
    const statusSchema = z.enum(employeeStatusEnum);

    expect(statusSchema.safeParse('Active').success).toBe(true);
    expect(statusSchema.safeParse('Probationary').success).toBe(true);
    expect(statusSchema.safeParse('Retired').success).toBe(false);
  });
});

describe('Rate Type Enum', () => {
  it('should contain daily and monthly', () => {
    expect(rateTypeEnum).toContain('daily');
    expect(rateTypeEnum).toContain('monthly');
  });

  it('should have exactly 2 rate types', () => {
    expect(rateTypeEnum.length).toBe(2);
  });

  it('should validate rate type using zod', () => {
    const rateTypeSchema = z.enum(rateTypeEnum);

    expect(rateTypeSchema.safeParse('daily').success).toBe(true);
    expect(rateTypeSchema.safeParse('monthly').success).toBe(true);
    expect(rateTypeSchema.safeParse('hourly').success).toBe(false);
  });
});

describe('Project Status Enum', () => {
  it('should contain all valid project statuses', () => {
    expect(projectStatusEnum).toContain('Planning');
    expect(projectStatusEnum).toContain('Active');
    expect(projectStatusEnum).toContain('On Hold');
    expect(projectStatusEnum).toContain('Completed');
    expect(projectStatusEnum).toContain('Cancelled');
  });

  it('should have exactly 5 statuses', () => {
    expect(projectStatusEnum.length).toBe(5);
  });
});

describe('Task Status Enum', () => {
  it('should contain all valid task statuses', () => {
    expect(taskStatusEnum).toContain('Todo');
    expect(taskStatusEnum).toContain('In_Progress');
    expect(taskStatusEnum).toContain('Blocked');
    expect(taskStatusEnum).toContain('Done');
  });

  it('should have exactly 4 statuses', () => {
    expect(taskStatusEnum.length).toBe(4);
  });
});

describe('Task Priority Enum', () => {
  it('should contain all valid priorities', () => {
    expect(taskPriorityEnum).toContain('Low');
    expect(taskPriorityEnum).toContain('Medium');
    expect(taskPriorityEnum).toContain('High');
    expect(taskPriorityEnum).toContain('Critical');
  });

  it('should have exactly 4 priorities', () => {
    expect(taskPriorityEnum.length).toBe(4);
  });
});

describe('OT Status Enum', () => {
  it('should contain all valid OT statuses', () => {
    expect(otStatusEnum).toContain('Pending');
    expect(otStatusEnum).toContain('Approved');
    expect(otStatusEnum).toContain('Rejected');
  });

  it('should have exactly 3 statuses', () => {
    expect(otStatusEnum.length).toBe(3);
  });
});

describe('Payroll Status Enum', () => {
  it('should contain all valid payroll statuses', () => {
    expect(payrollStatusEnum).toContain('Draft');
    expect(payrollStatusEnum).toContain('Approved');
    expect(payrollStatusEnum).toContain('Released');
  });

  it('should have exactly 3 statuses', () => {
    expect(payrollStatusEnum.length).toBe(3);
  });
});

describe('NTE Status Enum', () => {
  it('should contain all valid NTE statuses', () => {
    expect(nteStatusEnum).toContain('Issued');
    expect(nteStatusEnum).toContain('Explanation_Received');
    expect(nteStatusEnum).toContain('Under_Review');
    expect(nteStatusEnum).toContain('Resolved');
    expect(nteStatusEnum).toContain('Escalated');
  });

  it('should have exactly 5 statuses', () => {
    expect(nteStatusEnum.length).toBe(5);
  });
});

describe('Expense Status Enum', () => {
  it('should contain all valid expense statuses', () => {
    expect(expenseStatusEnum).toContain('Pending');
    expect(expenseStatusEnum).toContain('Approved');
    expect(expenseStatusEnum).toContain('Rejected');
    expect(expenseStatusEnum).toContain('Reimbursed');
  });

  it('should have exactly 4 statuses', () => {
    expect(expenseStatusEnum.length).toBe(4);
  });
});

// ============================================
// SCHEMA VALIDATIONS
// ============================================

describe('Employee Schema Validation', () => {
  const employeeSchema = z.object({
    firstName: z.string().min(1),
    lastName: z.string().min(1),
    middleName: z.string().optional().nullable(),
    email: z.string().email().optional().nullable(),
    phone: z.string().optional().nullable(),
    role: z.enum(employeeRoleEnum).default('WORKER'),
    rateType: z.enum(rateTypeEnum).default('daily'),
    baseRate: z.string().default('0'),
    status: z.enum(employeeStatusEnum).default('Active'),
  });

  it('should accept valid employee data', () => {
    const validEmployee = {
      firstName: 'Juan',
      lastName: 'Dela Cruz',
      email: 'juan@company.com',
      role: 'WORKER' as const,
      rateType: 'daily' as const,
      baseRate: '700',
      status: 'Active' as const,
    };

    const result = employeeSchema.safeParse(validEmployee);
    expect(result.success).toBe(true);
  });

  it('should require firstName', () => {
    const invalidEmployee = {
      lastName: 'Dela Cruz',
    };

    const result = employeeSchema.safeParse(invalidEmployee);
    expect(result.success).toBe(false);
  });

  it('should require lastName', () => {
    const invalidEmployee = {
      firstName: 'Juan',
    };

    const result = employeeSchema.safeParse(invalidEmployee);
    expect(result.success).toBe(false);
  });

  it('should validate email format', () => {
    const invalidEmail = {
      firstName: 'Juan',
      lastName: 'Dela Cruz',
      email: 'invalid-email',
    };

    const result = employeeSchema.safeParse(invalidEmail);
    expect(result.success).toBe(false);
  });

  it('should accept null email', () => {
    const validEmployee = {
      firstName: 'Juan',
      lastName: 'Dela Cruz',
      email: null,
    };

    const result = employeeSchema.safeParse(validEmployee);
    expect(result.success).toBe(true);
  });

  it('should use default values', () => {
    const minimalEmployee = {
      firstName: 'Juan',
      lastName: 'Dela Cruz',
    };

    const result = employeeSchema.safeParse(minimalEmployee);
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.role).toBe('WORKER');
      expect(result.data.rateType).toBe('daily');
      expect(result.data.status).toBe('Active');
    }
  });
});

describe('Project Schema Validation', () => {
  const projectSchema = z.object({
    name: z.string().min(1),
    code: z.string().optional().nullable(),
    description: z.string().optional().nullable(),
    isOffice: z.boolean().default(false),
    locationLat: z.string().optional().nullable(),
    locationLng: z.string().optional().nullable(),
    geoRadius: z.number().default(100),
    startDate: z.string().optional().nullable(),
    deadline: z.string().optional().nullable(),
    status: z.enum(projectStatusEnum).default('Planning'),
    budget: z.string().default('0'),
    allocatedHours: z.string().default('0'),
  });

  it('should accept valid project data', () => {
    const validProject = {
      name: 'Office Building Electrical',
      code: 'OBE-2025',
      description: 'Full electrical installation',
      isOffice: false,
      startDate: '2025-01-01',
      deadline: '2025-06-30',
      status: 'Active' as const,
    };

    const result = projectSchema.safeParse(validProject);
    expect(result.success).toBe(true);
  });

  it('should require name', () => {
    const invalidProject = {
      code: 'TEST',
    };

    const result = projectSchema.safeParse(invalidProject);
    expect(result.success).toBe(false);
  });

  it('should use default values', () => {
    const minimalProject = {
      name: 'Test Project',
    };

    const result = projectSchema.safeParse(minimalProject);
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.isOffice).toBe(false);
      expect(result.data.status).toBe('Planning');
      expect(result.data.geoRadius).toBe(100);
    }
  });
});

describe('Task Schema Validation', () => {
  const taskSchema = z.object({
    projectId: z.string().min(1),
    title: z.string().min(1),
    description: z.string().optional().nullable(),
    status: z.enum(taskStatusEnum).default('Todo'),
    priority: z.enum(taskPriorityEnum).default('Medium'),
    assignedToId: z.string().optional().nullable(),
    dueDate: z.string().optional().nullable(),
    completedDate: z.string().optional().nullable(),
    estimatedHours: z.string().optional().nullable(),
    actualHours: z.string().optional().nullable(),
  });

  it('should accept valid task data', () => {
    const validTask = {
      projectId: 'proj-001',
      title: 'Install main panel',
      description: 'Install 200A main panel',
      status: 'Todo' as const,
      priority: 'High' as const,
    };

    const result = taskSchema.safeParse(validTask);
    expect(result.success).toBe(true);
  });

  it('should require projectId', () => {
    const invalidTask = {
      title: 'Test Task',
    };

    const result = taskSchema.safeParse(invalidTask);
    expect(result.success).toBe(false);
  });

  it('should require title', () => {
    const invalidTask = {
      projectId: 'proj-001',
    };

    const result = taskSchema.safeParse(invalidTask);
    expect(result.success).toBe(false);
  });

  it('should use default values', () => {
    const minimalTask = {
      projectId: 'proj-001',
      title: 'Test Task',
    };

    const result = taskSchema.safeParse(minimalTask);
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.status).toBe('Todo');
      expect(result.data.priority).toBe('Medium');
    }
  });
});

describe('Attendance Schema Validation', () => {
  const attendanceSchema = z.object({
    employeeId: z.string().min(1),
    projectId: z.string().optional().nullable(),
    qrToken: z.string().min(1),
    timeIn: z.date(),
    timeOut: z.date().optional().nullable(),
    locationInLat: z.string().optional().nullable(),
    locationInLng: z.string().optional().nullable(),
    photoInUrl: z.string().optional().nullable(),
    status: z.enum(['Incomplete', 'Complete', 'Absent']).default('Incomplete'),
  });

  it('should accept valid attendance data', () => {
    const validAttendance = {
      employeeId: 'emp-001',
      qrToken: 'abc123token',
      timeIn: new Date(),
      locationInLat: '14.5547',
      locationInLng: '121.0244',
    };

    const result = attendanceSchema.safeParse(validAttendance);
    expect(result.success).toBe(true);
  });

  it('should require employeeId', () => {
    const invalidAttendance = {
      qrToken: 'abc123token',
      timeIn: new Date(),
    };

    const result = attendanceSchema.safeParse(invalidAttendance);
    expect(result.success).toBe(false);
  });

  it('should require qrToken', () => {
    const invalidAttendance = {
      employeeId: 'emp-001',
      timeIn: new Date(),
    };

    const result = attendanceSchema.safeParse(invalidAttendance);
    expect(result.success).toBe(false);
  });
});

describe('Payroll Record Schema Validation', () => {
  const payrollSchema = z.object({
    employeeId: z.string().min(1),
    cutoffStart: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    cutoffEnd: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    daysWorked: z.string().default('0'),
    hoursWorked: z.string().default('0'),
    basicPay: z.string().default('0'),
    grossPay: z.string().default('0'),
    totalDeductions: z.string().default('0'),
    netPay: z.string().default('0'),
    status: z.enum(payrollStatusEnum).default('Draft'),
  });

  it('should accept valid payroll data', () => {
    const validPayroll = {
      employeeId: 'emp-001',
      cutoffStart: '2025-01-01',
      cutoffEnd: '2025-01-15',
      daysWorked: '11',
      basicPay: '7700',
      grossPay: '7918.75',
      totalDeductions: '656.72',
      netPay: '7262.03',
      status: 'Draft' as const,
    };

    const result = payrollSchema.safeParse(validPayroll);
    expect(result.success).toBe(true);
  });

  it('should validate date format', () => {
    const invalidPayroll = {
      employeeId: 'emp-001',
      cutoffStart: '01-01-2025', // Invalid format
      cutoffEnd: '2025-01-15',
    };

    const result = payrollSchema.safeParse(invalidPayroll);
    expect(result.success).toBe(false);
  });
});

describe('Leave Request Schema Validation', () => {
  const leaveRequestSchema = z.object({
    employeeId: z.string().min(1),
    leaveTypeId: z.string().min(1),
    startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    totalDays: z.string().default('1'),
    reason: z.string().optional().nullable(),
    status: z.enum(['Pending', 'Approved', 'Rejected', 'Cancelled']).default('Pending'),
  });

  it('should accept valid leave request data', () => {
    const validLeave = {
      employeeId: 'emp-001',
      leaveTypeId: 'lt-001',
      startDate: '2025-02-01',
      endDate: '2025-02-03',
      totalDays: '3',
      reason: 'Family vacation',
      status: 'Pending' as const,
    };

    const result = leaveRequestSchema.safeParse(validLeave);
    expect(result.success).toBe(true);
  });

  it('should require employeeId', () => {
    const invalidLeave = {
      leaveTypeId: 'lt-001',
      startDate: '2025-02-01',
      endDate: '2025-02-03',
    };

    const result = leaveRequestSchema.safeParse(invalidLeave);
    expect(result.success).toBe(false);
  });

  it('should validate date format', () => {
    const invalidLeave = {
      employeeId: 'emp-001',
      leaveTypeId: 'lt-001',
      startDate: '02/01/2025', // Invalid format
      endDate: '2025-02-03',
    };

    const result = leaveRequestSchema.safeParse(invalidLeave);
    expect(result.success).toBe(false);
  });
});

describe('Cash Advance Schema Validation', () => {
  const cashAdvanceSchema = z.object({
    employeeId: z.string().min(1),
    amount: z.string().min(1),
    reason: z.string().optional().nullable(),
    status: z.enum(['Pending', 'Approved', 'Rejected', 'Disbursed', 'Fully_Paid']).default('Pending'),
    deductionPerCutoff: z.string().optional().nullable(),
    remainingBalance: z.string().optional().nullable(),
  });

  it('should accept valid cash advance data', () => {
    const validAdvance = {
      employeeId: 'emp-001',
      amount: '5000',
      reason: 'Emergency expenses',
      status: 'Pending' as const,
    };

    const result = cashAdvanceSchema.safeParse(validAdvance);
    expect(result.success).toBe(true);
  });

  it('should require employeeId', () => {
    const invalidAdvance = {
      amount: '5000',
    };

    const result = cashAdvanceSchema.safeParse(invalidAdvance);
    expect(result.success).toBe(false);
  });

  it('should require amount', () => {
    const invalidAdvance = {
      employeeId: 'emp-001',
    };

    const result = cashAdvanceSchema.safeParse(invalidAdvance);
    expect(result.success).toBe(false);
  });
});

describe('Disciplinary Action Schema Validation', () => {
  const disciplinarySchema = z.object({
    employeeId: z.string().min(1),
    issuerId: z.string().min(1),
    violationType: z.string().min(1),
    incidentDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    description: z.string().min(1),
    status: z.enum(nteStatusEnum).default('Issued'),
    nteIssuedDate: z.string().optional().nullable(),
    responseDeadline: z.string().optional().nullable(),
    employeeExplanation: z.string().optional().nullable(),
    resolution: z.string().optional().nullable(),
    sanction: z.string().optional().nullable(),
    sanctionDays: z.number().optional().nullable(),
  });

  it('should accept valid disciplinary action data', () => {
    const validAction = {
      employeeId: 'emp-001',
      issuerId: 'hr-001',
      violationType: 'Tardiness',
      incidentDate: '2025-01-10',
      description: 'Multiple late arrivals',
      status: 'Issued' as const,
    };

    const result = disciplinarySchema.safeParse(validAction);
    expect(result.success).toBe(true);
  });

  it('should require description', () => {
    const invalidAction = {
      employeeId: 'emp-001',
      issuerId: 'hr-001',
      violationType: 'Tardiness',
      incidentDate: '2025-01-10',
    };

    const result = disciplinarySchema.safeParse(invalidAction);
    expect(result.success).toBe(false);
  });
});

describe('Expense Schema Validation', () => {
  const expenseSchema = z.object({
    projectId: z.string().min(1),
    submittedById: z.string().min(1),
    category: z.string().min(1),
    description: z.string().optional().nullable(),
    amount: z.string().min(1),
    receiptUrl: z.string().optional().nullable(),
    expenseDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    status: z.enum(expenseStatusEnum).default('Pending'),
  });

  it('should accept valid expense data', () => {
    const validExpense = {
      projectId: 'proj-001',
      submittedById: 'emp-001',
      category: 'Materials',
      description: 'Electrical wires',
      amount: '5000',
      expenseDate: '2025-01-15',
      status: 'Pending' as const,
    };

    const result = expenseSchema.safeParse(validExpense);
    expect(result.success).toBe(true);
  });

  it('should require amount', () => {
    const invalidExpense = {
      projectId: 'proj-001',
      submittedById: 'emp-001',
      category: 'Materials',
      expenseDate: '2025-01-15',
    };

    const result = expenseSchema.safeParse(invalidExpense);
    expect(result.success).toBe(false);
  });
});

// ============================================
// TYPE GUARDS
// ============================================

describe('Type Guards', () => {
  it('should validate employee role', () => {
    const isValidRole = (role: string): role is typeof employeeRoleEnum[number] =>
      employeeRoleEnum.includes(role as any);

    expect(isValidRole('ADMIN')).toBe(true);
    expect(isValidRole('INVALID')).toBe(false);
  });

  it('should validate employee status', () => {
    const isValidStatus = (status: string): status is typeof employeeStatusEnum[number] =>
      employeeStatusEnum.includes(status as any);

    expect(isValidStatus('Active')).toBe(true);
    expect(isValidStatus('Unknown')).toBe(false);
  });

  it('should validate task status', () => {
    const isValidStatus = (status: string): status is typeof taskStatusEnum[number] =>
      taskStatusEnum.includes(status as any);

    expect(isValidStatus('Done')).toBe(true);
    expect(isValidStatus('Completed')).toBe(false);
  });
});

// ============================================
// DATE VALIDATION
// ============================================

describe('Date Format Validation', () => {
  const dateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);

  it('should accept YYYY-MM-DD format', () => {
    expect(dateSchema.safeParse('2025-01-15').success).toBe(true);
    expect(dateSchema.safeParse('2025-12-31').success).toBe(true);
  });

  it('should reject DD-MM-YYYY format', () => {
    expect(dateSchema.safeParse('15-01-2025').success).toBe(false);
  });

  it('should reject MM/DD/YYYY format', () => {
    expect(dateSchema.safeParse('01/15/2025').success).toBe(false);
  });

  it('should reject incomplete dates', () => {
    expect(dateSchema.safeParse('2025-01').success).toBe(false);
    expect(dateSchema.safeParse('2025').success).toBe(false);
  });

  it('should reject timestamps', () => {
    expect(dateSchema.safeParse('2025-01-15T10:30:00').success).toBe(false);
  });
});

// ============================================
// COORDINATE VALIDATION
// ============================================

describe('Coordinate Validation', () => {
  const latitudeSchema = z.coerce.number().min(-90).max(90);
  const longitudeSchema = z.coerce.number().min(-180).max(180);

  it('should accept valid latitude', () => {
    expect(latitudeSchema.safeParse(14.5547).success).toBe(true);
    expect(latitudeSchema.safeParse(-90).success).toBe(true);
    expect(latitudeSchema.safeParse(90).success).toBe(true);
  });

  it('should reject invalid latitude', () => {
    expect(latitudeSchema.safeParse(91).success).toBe(false);
    expect(latitudeSchema.safeParse(-91).success).toBe(false);
  });

  it('should accept valid longitude', () => {
    expect(longitudeSchema.safeParse(121.0244).success).toBe(true);
    expect(longitudeSchema.safeParse(-180).success).toBe(true);
    expect(longitudeSchema.safeParse(180).success).toBe(true);
  });

  it('should reject invalid longitude', () => {
    expect(longitudeSchema.safeParse(181).success).toBe(false);
    expect(longitudeSchema.safeParse(-181).success).toBe(false);
  });

  it('should coerce string coordinates', () => {
    expect(latitudeSchema.safeParse('14.5547').success).toBe(true);
    expect(longitudeSchema.safeParse('121.0244').success).toBe(true);
  });
});

// ============================================
// AMOUNT VALIDATION
// ============================================

describe('Amount Validation', () => {
  const amountSchema = z.coerce.number().nonnegative();

  it('should accept positive amounts', () => {
    expect(amountSchema.safeParse(1000).success).toBe(true);
    expect(amountSchema.safeParse('5000.50').success).toBe(true);
  });

  it('should accept zero', () => {
    expect(amountSchema.safeParse(0).success).toBe(true);
  });

  it('should reject negative amounts', () => {
    expect(amountSchema.safeParse(-100).success).toBe(false);
  });

  it('should coerce string amounts', () => {
    const result = amountSchema.safeParse('1234.56');
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data).toBe(1234.56);
    }
  });
});
