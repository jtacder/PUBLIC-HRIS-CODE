/**
 * Seed script for devotional data
 * Run with: npx tsx server/seed-devotionals.ts
 */

import { db } from "./db";
import { devotionals } from "@shared/schema";

// Sample devotionals covering different themes and days
const sampleDevotionals = [
  {
    dayNumber: 1,
    verse: "Trust in the LORD with all your heart and lean not on your own understanding; in all your ways submit to him, and he will make your paths straight.",
    reference: "Proverbs 3:5-6 (NIV)",
    baseExcerpt: "Beginning a new journey requires trust. Just as you wouldn't navigate unfamiliar terrain without a guide, your professional life needs divine direction. This verse reminds us that our limited perspective often leads us astray. When workplace challenges seem overwhelming or career decisions feel impossible, surrender your understanding to God's infinite wisdom. He sees the complete picture when we can only see fragments. Today, practice releasing control and inviting God into your daily decisions, both big and small.",
    theme: "Trust",
  },
  {
    dayNumber: 2,
    verse: "Whatever you do, work at it with all your heart, as working for the Lord, not for human masters.",
    reference: "Colossians 3:23 (NIV)",
    baseExcerpt: "Excellence in work is worship. When we view our tasks through the lens of serving God, even mundane responsibilities become meaningful. This perspective shift transforms how we approach deadlines, interact with colleagues, and handle setbacks. The quality of our work reflects our values and our faith. Today, commit to giving your best effort not for recognition or reward, but as an offering to God who gave you your talents and opportunities.",
    theme: "Excellence",
  },
  {
    dayNumber: 3,
    verse: "Be completely humble and gentle; be patient, bearing with one another in love.",
    reference: "Ephesians 4:2 (NIV)",
    baseExcerpt: "The workplace tests our character daily. Difficult colleagues, missed expectations, and communication breakdowns reveal what's truly in our hearts. Humility isn't weakness—it's strength under control. Gentleness doesn't mean being a pushover—it means responding with measured grace. Patience isn't passive—it's active endurance rooted in hope. Today's verse calls us to bear with others, recognizing that we too need grace extended to us.",
    theme: "Humility",
  },
  {
    dayNumber: 4,
    verse: "For I know the plans I have for you, declares the LORD, plans to prosper you and not to harm you, plans to give you hope and a future.",
    reference: "Jeremiah 29:11 (NIV)",
    baseExcerpt: "Career anxiety is common in our achievement-driven culture. We worry about promotions, job security, and whether we're on the right path. This beloved verse, originally spoken to exiles in Babylon, reminds us that God's plans extend beyond our current circumstances. Your present position—whether comfortable or challenging—is part of a larger story God is writing. Hope isn't wishful thinking; it's confident expectation rooted in God's character.",
    theme: "Hope",
  },
  {
    dayNumber: 5,
    verse: "Do nothing out of selfish ambition or vain conceit. Rather, in humility value others above yourselves.",
    reference: "Philippians 2:3 (NIV)",
    baseExcerpt: "Ambition itself isn't wrong—it's the 'selfish' qualifier that causes problems. Healthy ambition drives us to develop our gifts and serve others effectively. Selfish ambition, however, uses people as stepping stones. Vain conceit measures success by comparison. The antidote is actively valuing others, seeking their success as earnestly as our own. In a competitive workplace, this countercultural approach actually builds stronger teams and lasting influence.",
    theme: "Servant Leadership",
  },
  // Add more days to cover the current day of the year
  {
    dayNumber: 20,
    verse: "The Lord is my light and my salvation—whom shall I fear? The Lord is the stronghold of my life—of whom shall I be afraid?",
    reference: "Psalm 27:1 (NIV)",
    baseExcerpt: "Fear is a common companion in professional life—fear of failure, rejection, inadequacy, or the unknown. This psalm declares that with God as our light, darkness loses its power. With Him as our salvation, threats lose their grip. With Him as our stronghold, we have an unshakeable foundation. Fear may knock, but we don't have to answer the door. Today, identify what fears are holding you back and declare God's truth over them.",
    theme: "Courage",
  },
  {
    dayNumber: 21,
    verse: "But the fruit of the Spirit is love, joy, peace, forbearance, kindness, goodness, faithfulness, gentleness and self-control.",
    reference: "Galatians 5:22-23 (NIV)",
    baseExcerpt: "These qualities aren't achieved through effort alone—they're fruit that grows naturally when we're connected to the Spirit. In workplace contexts, this fruit manifests as love for difficult coworkers, joy despite challenges, peace amid uncertainty, patience with processes, kindness in competition, goodness in ethics, faithfulness in commitments, gentleness in leadership, and self-control in reactions. Which fruit needs more cultivation in your professional life?",
    theme: "Character",
  },
  {
    dayNumber: 22,
    verse: "And we know that in all things God works for the good of those who love him, who have been called according to his purpose.",
    reference: "Romans 8:28 (NIV)",
    baseExcerpt: "This verse doesn't promise that all things are good, but that God works in all things for good. The failed project, the missed promotion, the difficult boss—none of these are wasted in God's economy. He weaves every thread, including the dark ones, into a beautiful tapestry. Our job isn't to understand the pattern but to trust the Weaver. Today, choose faith over frustration, knowing God is at work even in what seems random or painful.",
    theme: "Providence",
  },
  {
    dayNumber: 23,
    verse: "Commit to the Lord whatever you do, and he will establish your plans.",
    reference: "Proverbs 16:3 (NIV)",
    baseExcerpt: "True commitment to God means surrendering our agenda while still planning diligently. It's not passive resignation but active partnership. We bring our best ideas, strategies, and efforts, then release the outcomes to Him. This doesn't guarantee every plan succeeds as we envision, but it ensures our lives move in alignment with divine purposes. Today's verse promises establishment—a firm foundation—when we commit our work to the Lord.",
    theme: "Dedication",
  },
  {
    dayNumber: 24,
    verse: "Iron sharpens iron, and one person sharpens another.",
    reference: "Proverbs 27:17 (NIV)",
    baseExcerpt: "Growth happens in relationship. Just as iron blades sharpen each other through friction, we develop through challenging interactions with others. Isolation feels safe but leads to dullness. Surrounding yourself with people who challenge your thinking, question your assumptions, and push you to excellence is essential for professional and spiritual growth. Seek out relationships that sharpen you, and be willing to do the same for others.",
    theme: "Community",
  },
];

// Generate more days to cover a full month (for testing)
function generateAdditionalDays(): typeof sampleDevotionals {
  const additionalDays: typeof sampleDevotionals = [];
  const themes = ["Faith", "Integrity", "Perseverance", "Wisdom", "Compassion", "Gratitude", "Service"];
  const verses = [
    { verse: "I can do all this through him who gives me strength.", reference: "Philippians 4:13 (NIV)" },
    { verse: "The fear of the LORD is the beginning of wisdom, and knowledge of the Holy One is understanding.", reference: "Proverbs 9:10 (NIV)" },
    { verse: "Be strong and courageous. Do not be afraid; do not be discouraged, for the LORD your God will be with you wherever you go.", reference: "Joshua 1:9 (NIV)" },
    { verse: "Let us not become weary in doing good, for at the proper time we will reap a harvest if we do not give up.", reference: "Galatians 6:9 (NIV)" },
    { verse: "The LORD is my shepherd, I lack nothing.", reference: "Psalm 23:1 (NIV)" },
  ];

  for (let day = 6; day <= 19; day++) {
    if (!sampleDevotionals.find(d => d.dayNumber === day)) {
      const verseData = verses[(day - 6) % verses.length];
      additionalDays.push({
        dayNumber: day,
        verse: verseData.verse,
        reference: verseData.reference,
        baseExcerpt: `Day ${day} reflection: This verse speaks to the heart of our professional calling. As we navigate the complexities of work life, we're reminded that our strength comes not from our own abilities, but from God who empowers us. Take time today to meditate on this truth and apply it to your current work situation.`,
        theme: themes[(day - 6) % themes.length],
      });
    }
  }

  // Add days 25-31 for the current month
  for (let day = 25; day <= 31; day++) {
    const verseData = verses[(day - 25) % verses.length];
    additionalDays.push({
      dayNumber: day,
      verse: verseData.verse,
      reference: verseData.reference,
      baseExcerpt: `Day ${day} reflection: God's word provides guidance and comfort for every situation we face. As professionals, we often encounter challenges that test our faith and character. This verse reminds us to stay grounded in truth while pursuing excellence in all we do.`,
      theme: themes[(day - 25) % themes.length],
    });
  }

  return additionalDays;
}

async function seedDevotionals() {
  console.log("Seeding devotional data...");

  const allDevotionals = [...sampleDevotionals, ...generateAdditionalDays()];

  for (const devotional of allDevotionals) {
    try {
      // Check if already exists
      const existing = await db.select().from(devotionals).where(
        // @ts-ignore
        devotionals.dayNumber.eq(devotional.dayNumber)
      );

      if (existing.length === 0) {
        await db.insert(devotionals).values(devotional);
        console.log(`Created devotional for day ${devotional.dayNumber}`);
      } else {
        console.log(`Devotional for day ${devotional.dayNumber} already exists, skipping`);
      }
    } catch (error) {
      console.error(`Error creating devotional for day ${devotional.dayNumber}:`, error);
    }
  }

  console.log("Devotional seeding complete!");
}

// Run if called directly
seedDevotionals()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Seeding failed:", err);
    process.exit(1);
  });
