import { Router } from "express";
import { z } from "zod";
import multer from "multer";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import {
  getPhilippineTime,
  formatAttendanceLogForClient,
  calculateShiftMinutes,
  createPHTDateStart,
  createPHTDateEnd,
  getPhilippineDateString,
  getPhilippineDayName,
  extractDateString,
  parseShiftWorkDays
} from "../utils/datetime";
import { calculateDistance } from "../utils/geo";
import { clockInSchema, clockOutSchema } from "../utils/validation";
import { attendanceTimeSchema, attendanceAdjustmentSchema, validateBody } from "../validation/schemas";
import logger from "../utils/logger";
import { config } from "../config";
import { generateAttendanceTemplate } from "../utils/attendance-template";
import {
  parseAttendanceFile,
  convertToAttendanceLog,
  type AttendanceImportError
} from "../utils/attendance-import";
import { uploadPhoto, isLegacyBase64 } from "../utils/object-storage";
import { notifyOvertimeDecision, notifyTardinessRecorded, notifyAttendanceFlagged } from "../services/notification-triggers";

const router = Router();

// Configure multer for file uploads (memory storage)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    const allowedMimes = [
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/vnd.ms-excel",
      "text/csv",
      "application/csv",
    ];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Only Excel (.xlsx, .xls) and CSV files are allowed"));
    }
  },
});

// Download attendance bulk upload template
router.get("/template/download", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "attendance.view_all", "attendance.edit"), async (req, res) => {
  try {
    const buffer = generateAttendanceTemplate();
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.setHeader(
      "Content-Disposition",
      "attachment; filename=attendance_upload_template.xlsx"
    );
    res.send(buffer);
  } catch (error) {
    logger.error("Error generating attendance template:", error);
    res.status(500).json({ message: "Failed to generate template" });
  }
});

// Bulk upload attendance records
router.post("/bulk-upload", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "attendance.view_all", "attendance.edit"), upload.single("file"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const fileBuffer = req.file.buffer;
    const fileName = req.file.originalname.toLowerCase();
    const fileType: "xlsx" | "csv" = fileName.endsWith(".csv") ? "csv" : "xlsx";

    // Get all employees and projects for lookup
    const employees = await storage.getEmployees();
    const projects = await storage.getProjects();

    // Parse the file
    const parseResult = parseAttendanceFile(fileBuffer, fileType, employees, projects);

    if (!parseResult.success && parseResult.data.length === 0) {
      return res.status(400).json({
        success: false,
        message: parseResult.errors[0]?.message || "Failed to parse file",
        summary: {
          total: parseResult.totalRows,
          created: 0,
          failed: parseResult.errors.length,
        },
        errors: parseResult.errors,
      });
    }

    // Check for existing attendance records (same employee + same date)
    const allErrors: AttendanceImportError[] = [...parseResult.errors];
    const toCreate: typeof parseResult.data = [];

    for (let i = 0; i < parseResult.data.length; i++) {
      const entry = parseResult.data[i];

      // Check if there's already an attendance record for this employee on this date
      // Use PHT date utilities to ensure correct timezone handling for the query
      const existingLogs = await storage.getEmployeeAttendance(
        entry.employeeId,
        createPHTDateStart(entry.date),
        createPHTDateEnd(entry.date)
      );

      if (existingLogs.length > 0) {
        allErrors.push({
          row: i + 2, // +2 for header and 0-index
          field: "duplicate",
          message: `Attendance record already exists for employee "${entry.employeeName}" on ${entry.date}`,
          value: `${entry.employeeName}:${entry.date}`,
        });
      } else if (!allErrors.some(e => e.row === i + 2)) {
        toCreate.push(entry);
      }
    }

    // Create attendance records
    const createdRecords: { id: string; employeeName: string; date: string; timeIn: string; timeOut: string | null }[] = [];

    for (const entry of toCreate) {
      try {
        const logData = convertToAttendanceLog(entry, entry.date);
        const log = await storage.createAttendanceLog(logData as any);
        createdRecords.push({
          id: log.id,
          employeeName: entry.employeeName,
          date: entry.date,
          timeIn: entry.timeIn,
          timeOut: entry.timeOut,
        });
      } catch (error: any) {
        allErrors.push({
          row: parseResult.data.indexOf(entry) + 2,
          field: "creation",
          message: `Failed to create record: ${error.message}`,
        });
      }
    }

    // Create audit log for bulk upload
    const userId = req.session.user?.id || "system";
    await storage.createAuditLog({
      userId,
      action: "BULK_UPLOAD",
      entityType: "Attendance",
      entityId: null,
      newValues: {
        fileName: req.file.originalname,
        totalRows: parseResult.totalRows,
        created: createdRecords.length,
        failed: allErrors.length,
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    const finalErrors = allErrors.filter(
      (error, index, self) =>
        index === self.findIndex((e) => e.row === error.row && e.field === error.field)
    );

    res.status(createdRecords.length > 0 ? 201 : 400).json({
      success: createdRecords.length > 0,
      message: createdRecords.length > 0
        ? `Successfully created ${createdRecords.length} attendance record(s)`
        : "No attendance records were created",
      summary: {
        total: parseResult.totalRows,
        created: createdRecords.length,
        failed: finalErrors.length,
      },
      errors: finalErrors,
      createdRecords,
    });
  } catch (error: any) {
    logger.error("Error processing bulk attendance upload:", error);
    res.status(500).json({
      success: false,
      message: error.message || "Failed to process bulk upload"
    });
  }
});

router.get("/today", isAuthenticated, async (req, res) => {
  try {
    const logs = await storage.getTodayAttendance();

    // Filter out attendance for hidden employees
    const visibleEmployees = await storage.getVisibleEmployees();
    const visibleEmployeeIds = new Set(visibleEmployees.map(e => e.id));
    const filteredLogs = logs.filter(log => visibleEmployeeIds.has(log.employeeId));

    const formattedLogs = filteredLogs.map(formatAttendanceLogForClient);
    res.json(formattedLogs);
  } catch (error) {
    logger.error("Error fetching today's attendance:", error);
    res.status(500).json({ message: "Failed to fetch attendance" });
  }
});

router.get("/", isAuthenticated, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    // Use PHT-aware date boundaries so that "Feb 3" means midnight PHT Feb 3,
    // not midnight UTC (which is 8 AM PHT, missing early morning entries)
    const start = startDate ? createPHTDateStart(startDate as string) : undefined;
    const end = endDate ? createPHTDateEnd(endDate as string) : undefined;
    const logs = await storage.getAttendanceLogs(start, end);

    // Filter out attendance for hidden employees
    const visibleEmployees = await storage.getVisibleEmployees();
    const visibleEmployeeIds = new Set(visibleEmployees.map(e => e.id));
    const filteredLogs = logs.filter(log => visibleEmployeeIds.has(log.employeeId));

    const formattedLogs = filteredLogs.map(formatAttendanceLogForClient);
    res.json(formattedLogs);
  } catch (error) {
    logger.error("Error fetching attendance:", error);
    res.status(500).json({ message: "Failed to fetch attendance" });
  }
});

// Check clock-in status for an employee (day off, on leave, etc.)
// This endpoint is called before clock-in to determine if confirmation is needed
router.get("/clock-in-status/:qrToken", isAuthenticated, async (req, res) => {
  try {
    const { qrToken } = req.params;

    const employee = await storage.getEmployeeByQRToken(qrToken);
    if (!employee) {
      return res.status(404).json({
        message: "Invalid QR code. Employee not found.",
        code: "INVALID_QR_TOKEN"
      });
    }

    const todayStr = getPhilippineDateString();
    const todayName = getPhilippineDayName();

    // Check if today is employee's day off
    // Use parseShiftWorkDays to handle both array and JSON string formats
    const workDays = parseShiftWorkDays(employee.shiftWorkDays);
    let isDayOff = false;
    if (workDays) {
      isDayOff = !workDays.includes(todayName);
    } else {
      // If no schedule defined, assume Mon-Fri. Day off if Sat/Sun
      isDayOff = todayName === 'Sat' || todayName === 'Sun';
    }

    // Check if employee has approved leave today
    const leaveRequests = await storage.getLeaveRequests(employee.id);
    const approvedLeaveToday = leaveRequests.find(lr => {
      if (lr.status !== 'Approved') return false;
      const startDate = extractDateString(lr.startDate);
      const endDate = extractDateString(lr.endDate);
      return todayStr >= startDate && todayStr <= endDate;
    });

    const isOnLeave = !!approvedLeaveToday;

    // Get leave type name if on leave
    let leaveTypeName: string | null = null;
    if (approvedLeaveToday) {
      const leaveTypes = await storage.getLeaveTypes();
      const leaveType = leaveTypes.find(lt => lt.id === approvedLeaveToday.leaveTypeId);
      leaveTypeName = leaveType?.name || 'Leave';
    }

    res.json({
      employeeId: employee.id,
      employeeName: `${employee.firstName} ${employee.lastName}`,
      employeeNo: employee.employeeNo,
      isDayOff,
      isOnLeave,
      leaveTypeName,
      scheduledWorkDays: workDays || [],
      todayName,
      // Provide helpful message
      requiresConfirmation: isDayOff || isOnLeave,
      message: isDayOff && isOnLeave
        ? `Today (${todayName}) is your scheduled day off and you have approved ${leaveTypeName}.`
        : isDayOff
        ? `Today (${todayName}) is your scheduled day off.`
        : isOnLeave
        ? `You have approved ${leaveTypeName} today.`
        : null,
    });
  } catch (error) {
    logger.error("Error checking clock-in status:", error);
    res.status(500).json({ message: "Failed to check clock-in status" });
  }
});

router.post("/clock-in", isAuthenticated, async (req, res) => {
  try {
    const validatedData = clockInSchema.parse(req.body);
    const { qrToken, photoSnapshotUrl, locationLat, locationLng, locationSource, locationAccuracy } = validatedData;

    const employee = await storage.getEmployeeByQRToken(qrToken);
    if (!employee) {
      return res.status(404).json({ 
        message: "Invalid QR code. Employee not found.",
        code: "INVALID_QR_TOKEN"
      });
    }

    const now = getPhilippineTime();
    const actualTimeIn = new Date(); // Store actual UTC time in database
    const currentHour = now.getUTCHours();

    // Use employee's configured shift times (no auto-detection)
    // If an employee has a sudden shift change, HR can use "Sched Change" to override
    const scheduledShiftStart = employee.shiftStartTime || "08:00";
    const scheduledShiftEnd = employee.shiftEndTime || "17:00";

    // Determine shift type based on employee's configured shift start time
    // Night shift is when start time is in the evening (after 6pm)
    const shiftStartHour = parseInt(scheduledShiftStart.split(':')[0]);
    const actualShiftType: "day" | "night" = shiftStartHour >= 18 || shiftStartHour < 6 ? "night" : "day";

    // For date attribution: use today's date by default
    // Night shift employees clocking in after midnight (before 6am) get attributed to yesterday
    let scheduledShiftDate = now.toISOString().split('T')[0];
    if (actualShiftType === "night" && currentHour < 6) {
      const yesterday = new Date(now);
      yesterday.setUTCDate(yesterday.getUTCDate() - 1);
      scheduledShiftDate = yesterday.toISOString().split('T')[0];
    }
    
    const todayLogs = await storage.getTodayAttendance();
    const existingActiveLog = todayLogs.find(log => log.employeeId === employee.id && !log.timeOut);
    
    if (existingActiveLog) {
      return res.status(400).json({ 
        message: "You have already clocked in today",
        code: "ALREADY_CLOCKED_IN"
      });
    }
    
    const completedShiftToday = todayLogs.find(log => 
      log.employeeId === employee.id && 
      log.timeOut && 
      !log.isOvertimeSession
    );
    
    const isOvertimeSession = !!completedShiftToday;
    const parentAttendanceId = completedShiftToday?.id || null;

    const assignments = await storage.getEmployeeAssignments(employee.id);
    const activeAssignments = assignments.filter(a => a.isActive);
    
    if (activeAssignments.length === 0) {
      return res.status(400).json({ 
        message: "No active project assignment found. Please contact HR.",
        code: "NO_ACTIVE_ASSIGNMENT"
      });
    }

    let matchedProjectId: string | null = null;
    let minDistance: number = Infinity;
    let verificationStatus: "Verified" | "Pending" | "Off-site" | "Flagged" = "Off-site";

    // Check if employee is allowed to login from anywhere (bypass geofencing)
    const allowAnywhereLogin = employee.allowAnywhereLogin === true;

    // GPS accuracy thresholds for validation
    const POOR_ACCURACY_THRESHOLD = 100; // Accuracy worse than 100m is considered poor
    const SUSPICIOUS_ACCURACY_THRESHOLD = 300; // Accuracy worse than 300m is highly suspicious (likely cell tower)

    // Flag if GPS accuracy is suspiciously poor (likely cell tower triangulation)
    const isPoorAccuracy = locationAccuracy && locationAccuracy > POOR_ACCURACY_THRESHOLD;
    const isSuspiciousAccuracy = locationAccuracy && locationAccuracy > SUSPICIOUS_ACCURACY_THRESHOLD;

    for (const assignment of activeAssignments) {
      const project = await storage.getProject(assignment.projectId);
      if (project && project.locationLat && project.locationLng) {
        const distance = calculateDistance(
          locationLat,
          locationLng,
          parseFloat(String(project.locationLat)),
          parseFloat(String(project.locationLng))
        );

        const geoRadius = project.geoRadius || config.geo.defaultRadius;

        // Accuracy-aware geofence validation:
        // If the GPS accuracy error margin could place the user within the geofence,
        // consider it a potential match but flag for review if accuracy is poor
        const effectiveDistance = locationAccuracy
          ? Math.max(0, distance - locationAccuracy) // Best-case position accounting for accuracy
          : distance;

        if (distance <= geoRadius) {
          // User is clearly within geofence
          matchedProjectId = project.id;
          minDistance = distance;
          verificationStatus = "Verified";
          break;
        } else if (effectiveDistance <= geoRadius && locationAccuracy) {
          // User might be within geofence when accounting for GPS accuracy
          // This means they could be at the site but GPS error placed them outside
          matchedProjectId = project.id;
          minDistance = distance;
          // Flag for review instead of outright rejection
          verificationStatus = isPoorAccuracy ? "Flagged" : "Verified";
          break;
        } else if (distance < minDistance) {
          minDistance = distance;
          matchedProjectId = project.id;
        }
      }
    }

    // If employee has allowAnywhereLogin enabled, bypass geofencing restrictions
    // But still flag if accuracy is suspiciously poor (potential GPS spoofing or cell tower)
    if (allowAnywhereLogin && (verificationStatus === "Off-site" || verificationStatus === "Flagged")) {
      // For allowAnywhereLogin employees with very poor accuracy, flag for audit
      if (isSuspiciousAccuracy && minDistance > SUSPICIOUS_ACCURACY_THRESHOLD) {
        verificationStatus = "Flagged";
      } else {
        verificationStatus = "Verified";
      }
      // Keep the minDistance and matchedProjectId for record-keeping
    }

    if (verificationStatus === "Off-site") {
      // Format distance: use KM for distances >= 1000m, otherwise use meters
      const distanceDisplay = minDistance >= 1000
        ? `${(minDistance / 1000).toFixed(1)} KM`
        : `${Math.round(minDistance)} meters`;

      return res.status(400).json({
        message: `You are logging in outside of your assigned location. You are ${distanceDisplay} away. If this is a mistake, contact HR to update your Location assignment.`,
        code: "OUTSIDE_GEOFENCE",
        distance: Math.round(minDistance),
        distanceKm: minDistance / 1000
      });
    }

    // Upload photo to Object Storage instead of storing base64 in database
    let storedPhotoUrl = photoSnapshotUrl;
    if (photoSnapshotUrl && photoSnapshotUrl.startsWith("data:image/")) {
      const uploadResult = await uploadPhoto(photoSnapshotUrl, "attendance", employee.id);
      if (uploadResult) {
        storedPhotoUrl = uploadResult.key; // Store the object key, not base64
      } else {
        console.warn(`Failed to upload attendance photo for employee ${employee.id}, falling back to base64`);
        // Fall back to base64 storage if upload fails
      }
    }

    const shiftStartToday = new Date(now);
    const [shiftHours, shiftMinutes] = scheduledShiftStart.split(':').map(Number);
    shiftStartToday.setUTCHours(shiftHours, shiftMinutes, 0, 0);
    
    let lateMinutes = 0;
    let isLate = false;
    let lateDeductible = false;
    
    if (!isOvertimeSession) {
      if (!(actualShiftType === "night" && currentHour < 6)) {
        if (now > shiftStartToday) {
          lateMinutes = Math.floor((now.getTime() - shiftStartToday.getTime()) / (1000 * 60));
          isLate = lateMinutes > 0;
          lateDeductible = lateMinutes >= config.payroll.lateGraceMinutes;
        }
      }
    }

    const log = await storage.createAttendanceLog({
      employeeId: employee.id,
      projectId: matchedProjectId,
      timeIn: actualTimeIn,
      locationLat: locationLat.toString(),
      locationLng: locationLng.toString(),
      locationSource: locationSource || "GPS",
      locationAccuracy: locationAccuracy?.toString() || null,
      photoSnapshotUrl: storedPhotoUrl,
      faceVerified: false,
      distanceFromSite: minDistance.toString(),
      verificationStatus,
      lateMinutes,
      isLate,
      lateDeductible,
      scheduledShiftStart,
      scheduledShiftEnd,
      scheduledShiftDate,
      actualShiftType,
      isOvertimeSession,
      parentAttendanceId,
      otStatus: "Pending",
    });

    res.status(201).json({
      ...log,
      employee: {
        id: employee.id,
        firstName: employee.firstName,
        lastName: employee.lastName,
        employeeNo: employee.employeeNo,
      },
      isOvertimeSession,
    });
  } catch (error) {
    logger.error("Error clocking in:", error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: error.errors[0].message });
    }
    res.status(500).json({ message: "Failed to record attendance" });
  }
});

router.post("/clock-out", isAuthenticated, async (req, res) => {
  try {
    const validatedData = clockOutSchema.parse(req.body);
    const { attendanceId } = validatedData;

    const todayLogs = await storage.getTodayAttendance();
    const log = todayLogs.find(l => l.id === attendanceId && !l.timeOut);

    if (!log) {
      return res.status(400).json({ message: "No active clock-in found for today" });
    }

    const user = req.session.user;
    const isAdminOrHR = user?.role === "ADMIN" || user?.role === "HR";
    if (!isAdminOrHR && user?.employeeId && log.employeeId !== user.employeeId) {
      return res.status(403).json({ message: "You can only clock out your own attendance" });
    }

    const employee = await storage.getEmployee(log.employeeId);

    const actualTimeOut = new Date(); // Store actual UTC time in database
    const timeIn = new Date(log.timeIn);
    const grossMinutesWorked = Math.floor((actualTimeOut.getTime() - timeIn.getTime()) / (1000 * 60));

    // Use override values if present, otherwise fall back to original schedule
    const shiftStart = log.scheduledShiftStartOverride || log.scheduledShiftStart || employee?.shiftStartTime || "08:00";
    const shiftEnd = log.scheduledShiftEndOverride || log.scheduledShiftEnd || employee?.shiftEndTime || "17:00";

    const scheduledShiftMinutes = calculateShiftMinutes(shiftStart, shiftEnd);

    // Calculate OT from GROSS minutes (before lunch deduction)
    // This ensures employees get OT credit for actual hours worked beyond schedule
    const overtimeMinutes = Math.max(0, grossMinutesWorked - scheduledShiftMinutes);
    const overtimeHours = overtimeMinutes / 60;

    // Calculate undertime based on actual clock-out vs scheduled end time
    // NOT based on total minutes worked (which would double-penalize late arrivals)
    const [shiftStartH, shiftStartM] = shiftStart.split(':').map(Number);
    const [shiftEndH, shiftEndM] = shiftEnd.split(':').map(Number);
    const shiftStartTotalMinutes = shiftStartH * 60 + shiftStartM;
    const shiftEndTotalMinutes = shiftEndH * 60 + shiftEndM;

    // Convert times to PHT for comparison
    const timeInPHT = new Date(timeIn.getTime() + (config.timezone.offset * 60 * 60 * 1000));
    const timeOutPHT = new Date(actualTimeOut.getTime() + (config.timezone.offset * 60 * 60 * 1000));

    // Build scheduled end datetime based on timeIn date
    const scheduledEndPHT = new Date(timeInPHT);
    scheduledEndPHT.setUTCHours(shiftEndH, shiftEndM, 0, 0);

    // If overnight shift (scheduled end time < scheduled start time numerically),
    // the scheduled end is on the next day
    if (shiftEndTotalMinutes < shiftStartTotalMinutes) {
      scheduledEndPHT.setUTCDate(scheduledEndPHT.getUTCDate() + 1);
    }

    // Undertime = if employee left before scheduled end time
    let undertimeMinutes = 0;
    const undertimeDiffMinutes = Math.floor((scheduledEndPHT.getTime() - timeOutPHT.getTime()) / (1000 * 60));
    if (overtimeMinutes === 0 && undertimeDiffMinutes > 0) {
      undertimeMinutes = undertimeDiffMinutes;
    }

    // Apply lunch deduction ONLY to paid hours calculation, not OT/undertime
    const lunchDeductionMinutes = grossMinutesWorked >= 300 ? config.payroll.lunchBreakMinutes : 0;
    const totalMinutesWorked = grossMinutesWorked - lunchDeductionMinutes;
    const totalHours = totalMinutesWorked / 60;

    // Regular minutes = net paid minutes minus OT (for tracking purposes)
    const regularMinutes = Math.max(0, totalMinutesWorked - overtimeMinutes);
    
    const hasOvertime = overtimeMinutes > 0 || log.isOvertimeSession;
    const otStatus = hasOvertime ? "Pending" : undefined;

    const updatedLog = await storage.updateAttendanceLog(log.id, {
      timeOut: actualTimeOut,
      totalHours: totalHours.toFixed(2),
      regularMinutes,
      overtimeMinutes,
      undertimeMinutes,
      lunchDeductionMinutes,
      lunchPaid: false,
      overtimeHours: overtimeHours.toFixed(2),
      overtimeType: hasOvertime ? "Regular" : undefined,
      otStatus: hasOvertime ? "Pending" : log.otStatus,
    });

    res.json(updatedLog);
  } catch (error) {
    logger.error("Error clocking out:", error);
    res.status(500).json({ message: "Failed to record clock-out" });
  }
});

router.post("/:id/justification", isAuthenticated, async (req, res) => {
  try {
    const { justification } = req.body;
    const updated = await storage.updateAttendanceLog(req.params.id, {
      justification,
      verificationStatus: "Pending",
    });
    res.json(updated);
  } catch (error) {
    logger.error("Error adding justification:", error);
    res.status(500).json({ message: "Failed to add justification" });
  }
});

router.post("/manual", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "attendance.view_all", "attendance.edit"), async (req, res) => {
  try {
    const { employeeId, verificationStatus } = req.body;

    if (!employeeId || !req.body.timeIn) {
      return res.status(400).json({ message: "Employee and time in are required" });
    }

    // Validate time format
    const validation = validateBody(attendanceTimeSchema, { timeIn: req.body.timeIn, timeOut: req.body.timeOut });
    if (!validation.success) {
      return res.status(400).json({ message: "Validation failed", errors: validation.errors });
    }

    const { timeIn, timeOut } = validation.data;

    const employee = await storage.getEmployee(employeeId);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    const timeInDate = new Date(timeIn!);
    let timeOutDate = timeOut ? new Date(timeOut) : undefined;
    let totalHours = undefined;
    let lateMinutes = 0;
    let overtimeMinutes = 0;
    let overtimeHours = "0.00";
    let undertimeMinutes = 0;
    let lunchDeductionMinutes = 0;
    let regularMinutes = 0;
    let otStatus = undefined;
    let isLate = false;
    let lateDeductible = false;

    // Calculate late minutes
    if (employee.shiftStartTime) {
      const [startHours, startMinutes] = employee.shiftStartTime.split(':').map(Number);
      const shiftStart = new Date(timeInDate);
      shiftStart.setUTCHours(startHours, startMinutes, 0, 0);
      if (timeInDate > shiftStart) {
        lateMinutes = Math.floor((timeInDate.getTime() - shiftStart.getTime()) / (1000 * 60));
        isLate = lateMinutes > 0;
        lateDeductible = lateMinutes >= config.payroll.lateGraceMinutes;
      }
    }

    // Calculate hours, lunch deduction, and OT if timeOut is provided
    if (timeOutDate) {
      const grossMinutesWorked = Math.floor((timeOutDate.getTime() - timeInDate.getTime()) / (1000 * 60));

      // Get shift schedule for OT calculation
      const shiftStart = employee.shiftStartTime || "08:00";
      const shiftEnd = employee.shiftEndTime || "17:00";
      const scheduledShiftMinutes = calculateShiftMinutes(shiftStart, shiftEnd);

      // Calculate OT from GROSS minutes (before lunch deduction)
      overtimeMinutes = Math.max(0, grossMinutesWorked - scheduledShiftMinutes);
      overtimeHours = (overtimeMinutes / 60).toFixed(2);

      // Calculate undertime based on actual clock-out vs scheduled end time
      // NOT based on total minutes worked (which would double-penalize late arrivals)
      const [shiftStartH, shiftStartM] = shiftStart.split(':').map(Number);
      const [shiftEndH, shiftEndM] = shiftEnd.split(':').map(Number);
      const shiftStartTotalMinutes = shiftStartH * 60 + shiftStartM;
      const shiftEndTotalMinutes = shiftEndH * 60 + shiftEndM;

      // Convert times to PHT for undertime comparison (must match clock-out handler pattern)
      const timeInPHT = new Date(timeInDate.getTime() + (config.timezone.offset * 60 * 60 * 1000));
      const timeOutPHT = new Date(timeOutDate.getTime() + (config.timezone.offset * 60 * 60 * 1000));

      // Build scheduled end datetime based on timeIn date (in PHT space)
      const scheduledEndPHT = new Date(timeInPHT);
      scheduledEndPHT.setUTCHours(shiftEndH, shiftEndM, 0, 0);

      // If overnight shift (scheduled end time < scheduled start time numerically),
      // the scheduled end is on the next day
      if (shiftEndTotalMinutes < shiftStartTotalMinutes) {
        scheduledEndPHT.setUTCDate(scheduledEndPHT.getUTCDate() + 1);
      }

      // Undertime = if employee left before scheduled end time (compare PHT to PHT)
      const undertimeDiffMinutes = Math.floor((scheduledEndPHT.getTime() - timeOutPHT.getTime()) / (1000 * 60));
      if (overtimeMinutes === 0 && undertimeDiffMinutes > 0) {
        undertimeMinutes = undertimeDiffMinutes;
      }

      // Apply lunch deduction ONLY to paid hours (not OT calculation)
      lunchDeductionMinutes = grossMinutesWorked >= 300 ? config.payroll.lunchBreakMinutes : 0;
      const totalMinutesWorked = grossMinutesWorked - lunchDeductionMinutes;
      totalHours = (totalMinutesWorked / 60).toFixed(2);

      // Regular minutes = net paid minus OT
      regularMinutes = Math.max(0, totalMinutesWorked - overtimeMinutes);

      // Auto-set OT status to Pending if there's overtime
      if (overtimeMinutes > 0) {
        otStatus = "Pending";
      }
    }

    const log = await storage.createAttendanceLog({
      employeeId,
      timeIn: timeInDate,
      timeOut: timeOutDate,
      totalHours,
      lateMinutes,
      isLate,
      lateDeductible,
      overtimeMinutes,
      overtimeHours,
      undertimeMinutes,
      lunchDeductionMinutes,
      lunchPaid: false,
      regularMinutes,
      otStatus,
      overtimeType: overtimeMinutes > 0 ? "Regular" : undefined,
      verificationStatus: verificationStatus || "Verified",
      locationSource: "Manual",
      scheduledShiftStart: employee.shiftStartTime || "08:00",
      scheduledShiftEnd: employee.shiftEndTime || "17:00",
    });

    res.status(201).json(log);
  } catch (error) {
    logger.error("Error creating manual attendance:", error);
    res.status(500).json({ message: "Failed to create attendance record" });
  }
});

router.patch("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "attendance.view_all", "attendance.edit"), async (req, res) => {
  try {
    // Validate lateMinutes if provided
    if (req.body.lateMinutes !== undefined) {
      const validation = validateBody(attendanceAdjustmentSchema, { lateMinutes: req.body.lateMinutes });
      if (!validation.success) {
        return res.status(400).json({ message: "Validation failed", errors: validation.errors });
      }
    }

    const { timeIn, timeOut, lateMinutes, verificationStatus, notes, otStatus, otMinutesApproved, otReason, lunchPaid } = req.body;
    const updateData: any = {};

    if (timeIn !== undefined) updateData.timeIn = new Date(timeIn);
    if (timeOut !== undefined) updateData.timeOut = timeOut ? new Date(timeOut) : null;
    if (lateMinutes !== undefined) updateData.lateMinutes = lateMinutes;
    if (verificationStatus !== undefined) updateData.verificationStatus = verificationStatus;
    if (notes !== undefined) updateData.notes = notes;
    if (lunchPaid !== undefined) updateData.lunchPaid = lunchPaid;
    
    const currentLog = await storage.getAttendanceLog(req.params.id);
    
    if (otStatus !== undefined) {
      updateData.otStatus = otStatus;
      if (otStatus === "Approved") {
        if (currentLog) {
          updateData.otMinutesApproved = otMinutesApproved !== undefined 
            ? Number(otMinutesApproved) 
            : Number(currentLog.overtimeMinutes || 0);
          updateData.overtimeApproved = true;
        }
      } else if (otStatus === "Rejected") {
        updateData.otMinutesApproved = 0;
        updateData.overtimeApproved = false;
      } else if (otStatus === "Pending") {
        updateData.otMinutesApproved = null;
        updateData.overtimeApproved = false;
      }
    } else if (otMinutesApproved !== undefined && currentLog) {
      if (currentLog.otStatus === "Approved" || currentLog.overtimeApproved) {
        updateData.otMinutesApproved = Number(otMinutesApproved);
        updateData.overtimeApproved = true;
      }
    }
    if (otReason !== undefined) updateData.otReason = otReason;
    
    const effectiveTimeIn = updateData.timeIn || (currentLog ? new Date(currentLog.timeIn) : null);
    const effectiveTimeOut = updateData.timeOut !== undefined 
      ? updateData.timeOut 
      : (currentLog?.timeOut ? new Date(currentLog.timeOut) : null);
    
    const effectiveLunchPaid = updateData.lunchPaid !== undefined 
      ? updateData.lunchPaid 
      : (currentLog?.lunchPaid ?? false);
    
    if (effectiveTimeIn && effectiveTimeOut) {
      const diffMs = effectiveTimeOut.getTime() - effectiveTimeIn.getTime();
      const grossMinutesWorked = Math.floor(diffMs / (1000 * 60));
      
      let lunchDeduction = 0;
      if (grossMinutesWorked >= 300 && !effectiveLunchPaid) {
        lunchDeduction = config.payroll.lunchBreakMinutes;
      }
      updateData.lunchDeductionMinutes = lunchDeduction;
      
      // Use override values if present, otherwise fall back to original schedule
      const shiftStart = currentLog?.scheduledShiftStartOverride || currentLog?.scheduledShiftStart || "08:00";
      const shiftEnd = currentLog?.scheduledShiftEndOverride || currentLog?.scheduledShiftEnd || "17:00";

      const scheduledShiftMinutes = calculateShiftMinutes(shiftStart, shiftEnd);

      // Calculate OT from GROSS minutes (before lunch deduction)
      updateData.overtimeMinutes = Math.max(0, grossMinutesWorked - scheduledShiftMinutes);
      updateData.overtimeHours = (updateData.overtimeMinutes / 60).toFixed(2);

      // Calculate undertime based on actual clock-out vs scheduled end time
      // NOT based on total minutes worked (which would double-penalize late arrivals)
      const [shiftStartH, shiftStartM] = shiftStart.split(':').map(Number);
      const [shiftEndH, shiftEndM] = shiftEnd.split(':').map(Number);
      const shiftStartTotalMins = shiftStartH * 60 + shiftStartM;
      const shiftEndTotalMins = shiftEndH * 60 + shiftEndM;

      // Convert times to PHT for undertime comparison (must match clock-out handler pattern)
      const effectiveTimeInPHT = new Date(effectiveTimeIn.getTime() + (config.timezone.offset * 60 * 60 * 1000));
      const effectiveTimeOutPHT = new Date(effectiveTimeOut.getTime() + (config.timezone.offset * 60 * 60 * 1000));

      // Build scheduled end datetime based on timeIn date (in PHT space)
      const scheduledEndPHT = new Date(effectiveTimeInPHT);
      scheduledEndPHT.setUTCHours(shiftEndH, shiftEndM, 0, 0);

      // If overnight shift (scheduled end time < scheduled start time numerically),
      // the scheduled end is on the next day
      if (shiftEndTotalMins < shiftStartTotalMins) {
        scheduledEndPHT.setUTCDate(scheduledEndPHT.getUTCDate() + 1);
      }

      // Undertime = if employee left before scheduled end time (compare PHT to PHT)
      const undertimeDiffMinutes = Math.floor((scheduledEndPHT.getTime() - effectiveTimeOutPHT.getTime()) / (1000 * 60));
      if (updateData.overtimeMinutes === 0 && undertimeDiffMinutes > 0) {
        updateData.undertimeMinutes = undertimeDiffMinutes;
      } else {
        updateData.undertimeMinutes = 0;
      }

      // Apply lunch deduction ONLY to paid hours calculation
      const totalMinutesWorked = grossMinutesWorked - lunchDeduction;
      const hours = totalMinutesWorked / 60;
      updateData.totalHours = hours.toFixed(2);

      // Regular minutes = net paid minus OT
      updateData.regularMinutes = Math.max(0, totalMinutesWorked - updateData.overtimeMinutes);

      const [startH, startM] = shiftStart.split(':').map(Number);
      const clockInHours = effectiveTimeIn.getUTCHours() + config.timezone.offset;
      const clockInMinutes = effectiveTimeIn.getUTCMinutes();
      const clockInTotalMinutes = (clockInHours >= 24 ? clockInHours - 24 : clockInHours) * 60 + clockInMinutes;
      const shiftStartTotalMinutes = startH * 60 + startM;
      
      if (clockInTotalMinutes > shiftStartTotalMinutes) {
        updateData.lateMinutes = clockInTotalMinutes - shiftStartTotalMinutes;
        updateData.isLate = true;
      } else {
        updateData.lateMinutes = 0;
        updateData.isLate = false;
      }
      
      if (updateData.overtimeMinutes > 0 && !updateData.otStatus) {
        updateData.otStatus = "Pending";
        updateData.overtimeType = "Regular";
      }
    } else if (updateData.timeOut === null) {
      updateData.totalHours = null;
      updateData.overtimeMinutes = 0;
      updateData.undertimeMinutes = 0;
      updateData.regularMinutes = 0;
    }

    // Recalculate isLate whenever timeIn is updated, even if there's no timeOut yet
    // This ensures the "Late Today" dashboard notification updates correctly after HR fixes timeIn
    if (effectiveTimeIn && currentLog) {
      const shiftStart = currentLog.scheduledShiftStartOverride || currentLog.scheduledShiftStart || "08:00";
      const [startH, startM] = shiftStart.split(':').map(Number);
      const clockInHours = effectiveTimeIn.getUTCHours() + config.timezone.offset;
      const clockInMinutes = effectiveTimeIn.getUTCMinutes();
      const clockInTotalMinutes = (clockInHours >= 24 ? clockInHours - 24 : clockInHours) * 60 + clockInMinutes;
      const shiftStartTotalMinutes = startH * 60 + startM;

      // Only override isLate if we haven't already set it in the timeIn+timeOut block
      // or if this is a timeIn-only update (no timeOut exists yet)
      if (!effectiveTimeOut || updateData.isLate === undefined) {
        if (clockInTotalMinutes > shiftStartTotalMinutes) {
          updateData.lateMinutes = clockInTotalMinutes - shiftStartTotalMinutes;
          updateData.isLate = true;
        } else {
          updateData.lateMinutes = 0;
          updateData.isLate = false;
        }
      }
    }

    const updated = await storage.updateAttendanceLog(req.params.id, updateData);

    // Fire-and-forget notification triggers
    if (currentLog) {
      const attendanceDate = currentLog.scheduledShiftDate || extractDateString(currentLog.timeIn);
      const user = req.session.user;

      // Notify employee when OT status changes to Approved or Rejected
      if (otStatus === "Approved" || otStatus === "Rejected") {
        notifyOvertimeDecision({
          employeeId: currentLog.employeeId,
          approverId: user?.employeeId || user?.id || "system",
          approverName: user ? `${user.firstName} ${user.lastName}` : "HR",
          status: otStatus,
          date: attendanceDate,
          attendanceId: req.params.id,
        }).catch(() => {});
      }

      // Notify employee when attendance is flagged
      if (verificationStatus === "Flagged" || verificationStatus === "Off-site") {
        notifyAttendanceFlagged({
          employeeId: currentLog.employeeId,
          verificationStatus,
          date: attendanceDate,
          attendanceId: req.params.id,
        }).catch(() => {});
      }
    }

    res.json(updated);
  } catch (error) {
    logger.error("Error updating attendance log:", error);
    res.status(500).json({ message: "Failed to update attendance log" });
  }
});

// Schedule Override - allows HR/Admin to override scheduled shift for a specific attendance entry
// This is used when an employee has a sudden shift change (e.g., from morning to afternoon shift)
router.patch("/:id/schedule-override", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "attendance.view_all", "attendance.edit"), async (req, res) => {
  try {
    const { scheduledShiftStartOverride, scheduledShiftEndOverride } = req.body;

    if (!scheduledShiftStartOverride || !scheduledShiftEndOverride) {
      return res.status(400).json({ message: "Both scheduled time in and time out are required" });
    }

    // Validate time format (HH:mm)
    const timeRegex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
    if (!timeRegex.test(scheduledShiftStartOverride) || !timeRegex.test(scheduledShiftEndOverride)) {
      return res.status(400).json({ message: "Invalid time format. Use HH:mm (e.g., 08:00, 17:00)" });
    }

    const currentLog = await storage.getAttendanceLog(req.params.id);
    if (!currentLog) {
      return res.status(404).json({ message: "Attendance record not found" });
    }

    const updateData: any = {
      scheduledShiftStartOverride,
      scheduledShiftEndOverride,
    };

    // Recalculate late status based on override schedule
    const timeIn = new Date(currentLog.timeIn);
    const [overrideStartHours, overrideStartMinutes] = scheduledShiftStartOverride.split(':').map(Number);

    // Convert timeIn to PHT for comparison
    const timeInPHT = new Date(timeIn.getTime() + (config.timezone.offset * 60 * 60 * 1000));
    const clockInHours = timeInPHT.getUTCHours();
    const clockInMinutes = timeInPHT.getUTCMinutes();
    const clockInTotalMinutes = clockInHours * 60 + clockInMinutes;
    const shiftStartTotalMinutes = overrideStartHours * 60 + overrideStartMinutes;

    if (clockInTotalMinutes > shiftStartTotalMinutes) {
      updateData.lateMinutes = clockInTotalMinutes - shiftStartTotalMinutes;
      updateData.isLate = true;
      updateData.lateDeductible = updateData.lateMinutes >= config.payroll.lateGraceMinutes;
    } else {
      updateData.lateMinutes = 0;
      updateData.isLate = false;
      updateData.lateDeductible = false;
    }

    // Recalculate overtime/undertime if timeOut exists
    if (currentLog.timeOut) {
      const timeOut = new Date(currentLog.timeOut);
      const grossMinutesWorked = Math.floor((timeOut.getTime() - timeIn.getTime()) / (1000 * 60));

      // Use override schedule for calculations
      const scheduledShiftMinutes = calculateShiftMinutes(scheduledShiftStartOverride, scheduledShiftEndOverride);

      // Calculate OT from GROSS minutes (before lunch deduction)
      updateData.overtimeMinutes = Math.max(0, grossMinutesWorked - scheduledShiftMinutes);
      updateData.overtimeHours = (updateData.overtimeMinutes / 60).toFixed(2);

      // Calculate undertime based on actual clock-out vs scheduled end time
      // NOT based on total minutes worked (which would double-penalize late arrivals)
      const [schedEndH, schedEndM] = scheduledShiftEndOverride.split(':').map(Number);
      const timeOutPHT = new Date(timeOut.getTime() + (config.timezone.offset * 60 * 60 * 1000));

      // Build scheduled end datetime based on timeIn date
      const scheduledEndPHT = new Date(timeInPHT);
      scheduledEndPHT.setUTCHours(schedEndH, schedEndM, 0, 0);

      // If overnight shift (scheduled end time < scheduled start time numerically),
      // the scheduled end is on the next day
      const schedEndTotalMinutes = schedEndH * 60 + schedEndM;
      if (schedEndTotalMinutes < shiftStartTotalMinutes) {
        scheduledEndPHT.setUTCDate(scheduledEndPHT.getUTCDate() + 1);
      }

      // Undertime = if employee left before scheduled end time
      const undertimeDiffMinutes = Math.floor((scheduledEndPHT.getTime() - timeOutPHT.getTime()) / (1000 * 60));
      if (updateData.overtimeMinutes === 0 && undertimeDiffMinutes > 0) {
        updateData.undertimeMinutes = undertimeDiffMinutes;
      } else {
        updateData.undertimeMinutes = 0;
      }

      // Apply lunch deduction ONLY to paid hours calculation
      const effectiveLunchPaid = currentLog.lunchPaid ?? false;
      const lunchDeduction = (grossMinutesWorked >= 300 && !effectiveLunchPaid)
        ? config.payroll.lunchBreakMinutes
        : 0;
      updateData.lunchDeductionMinutes = lunchDeduction;

      const totalMinutesWorked = grossMinutesWorked - lunchDeduction;
      const hours = totalMinutesWorked / 60;
      updateData.totalHours = hours.toFixed(2);

      // Regular minutes = net paid minus OT
      updateData.regularMinutes = Math.max(0, totalMinutesWorked - updateData.overtimeMinutes);

      // Set OT status if overtime exists
      if (updateData.overtimeMinutes > 0 && !currentLog.otStatus) {
        updateData.otStatus = "Pending";
        updateData.overtimeType = "Regular";
      }
    }

    const updated = await storage.updateAttendanceLog(req.params.id, updateData);

    logger.info(`Schedule override applied to attendance ${req.params.id}: ${scheduledShiftStartOverride} - ${scheduledShiftEndOverride}`);

    res.json(updated);
  } catch (error) {
    logger.error("Error applying schedule override:", error);
    res.status(500).json({ message: "Failed to apply schedule override" });
  }
});

router.delete("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "attendance.view_all", "attendance.edit"), async (req, res) => {
  try {
    await storage.deleteAttendanceLog(req.params.id);
    res.json({ message: "Attendance log deleted successfully" });
  } catch (error) {
    logger.error("Error deleting attendance log:", error);
    res.status(500).json({ message: "Failed to delete attendance log" });
  }
});

export default router;
