import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { balanceAdjustmentTypeEnum } from "@shared/schema";
import { z } from "zod";
import logger from "../utils/logger";
import { notifyBalanceAdjustment } from "../services/notification-triggers";

const router = Router();

// Schema for balance adjustment
const adjustBalanceSchema = z.object({
  newBalance: z.string().refine(val => !isNaN(parseFloat(val)) && parseFloat(val) >= 0, {
    message: "New balance must be a non-negative number"
  }),
  adjustmentType: z.enum(balanceAdjustmentTypeEnum),
  reason: z.string().min(20, "Reason must be at least 20 characters for accountability"),
});

// Get all balance adjustments (HR/Admin only)
router.get("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve"), async (req, res) => {
  try {
    const { entityType, entityId } = req.query;
    const adjustments = await storage.getBalanceAdjustments(
      entityType as string | undefined,
      entityId as string | undefined
    );

    // Enrich with adjuster info
    const enriched = await Promise.all(adjustments.map(async (adj) => {
      const adjuster = await storage.getEmployee(adj.adjustedById);
      return {
        ...adj,
        adjustedByName: adjuster ? `${adjuster.firstName} ${adjuster.lastName}` : "Unknown",
      };
    }));

    res.json(enriched);
  } catch (error) {
    logger.error("Error fetching balance adjustments:", error);
    res.status(500).json({ message: "Failed to fetch balance adjustments" });
  }
});

// Adjust cash advance balance (HR/Admin only)
router.post("/cash-advances/:id/adjust", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve"), async (req, res) => {
  try {
    const user = req.session.user as any;
    const { id } = req.params;

    // Validate request body
    const validationResult = adjustBalanceSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: "Validation failed",
        errors: validationResult.error.errors
      });
    }

    const { newBalance, adjustmentType, reason } = validationResult.data;

    // Get existing cash advance
    const cashAdvance = await storage.getCashAdvance(id);
    if (!cashAdvance) {
      return res.status(404).json({ message: "Cash advance not found" });
    }

    // Only allow adjustments on disbursed cash advances
    if (cashAdvance.status !== "Disbursed" && cashAdvance.status !== "Fully_Paid") {
      return res.status(400).json({
        message: "Can only adjust balance for disbursed or fully paid cash advances"
      });
    }

    const previousBalance = cashAdvance.remainingBalance || "0";
    const newBalanceNum = parseFloat(newBalance);

    // Create balance adjustment record for audit trail
    await storage.createBalanceAdjustment({
      entityType: "CashAdvance",
      entityId: id,
      adjustedById: user.employeeId,
      previousBalance: previousBalance.toString(),
      newBalance: newBalance,
      adjustmentType,
      reason,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    // Update cash advance balance
    const newStatus = newBalanceNum === 0 ? "Fully_Paid" : "Disbursed";
    const updatedAdvance = await storage.updateCashAdvance(id, {
      remainingBalance: newBalance,
      status: newStatus,
    });

    // Create audit log
    await storage.createAuditLog({
      userId: user.employeeId,
      action: "ADJUST_BALANCE",
      entityType: "CashAdvance",
      entityId: id,
      oldValues: { remainingBalance: previousBalance },
      newValues: { remainingBalance: newBalance, adjustmentType, reason },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    // Notify the affected employee about the balance adjustment
    notifyBalanceAdjustment({
      employeeId: cashAdvance.employeeId,
      adjustedBy: user.employeeId,
      type: adjustmentType,
      entityType: "cash_advance",
      reason,
    }).catch(() => {});

    res.json({
      ...updatedAdvance,
      adjustmentRecorded: true,
    });
  } catch (error) {
    logger.error("Error adjusting cash advance balance:", error);
    res.status(500).json({ message: "Failed to adjust balance" });
  }
});

// Get adjustment history for a cash advance
router.get("/cash-advances/:id/history", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve"), async (req, res) => {
  try {
    const adjustments = await storage.getBalanceAdjustments("CashAdvance", req.params.id);

    // Enrich with adjuster info
    const enriched = await Promise.all(adjustments.map(async (adj) => {
      const adjuster = await storage.getEmployee(adj.adjustedById);
      return {
        ...adj,
        adjustedByName: adjuster ? `${adjuster.firstName} ${adjuster.lastName}` : "Unknown",
      };
    }));

    res.json(enriched);
  } catch (error) {
    logger.error("Error fetching adjustment history:", error);
    res.status(500).json({ message: "Failed to fetch adjustment history" });
  }
});

// Adjust loan balance (HR/Admin only)
router.post("/loans/:id/adjust", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve"), async (req, res) => {
  try {
    const user = req.session.user as any;
    const { id } = req.params;

    // Validate request body
    const validationResult = adjustBalanceSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: "Validation failed",
        errors: validationResult.error.errors
      });
    }

    const { newBalance, adjustmentType, reason } = validationResult.data;

    // Get existing loan
    const loan = await storage.getLoan(id);
    if (!loan) {
      return res.status(404).json({ message: "Loan not found" });
    }

    // Only allow adjustments on disbursed loans
    if (loan.status !== "Disbursed" && loan.status !== "Fully_Paid") {
      return res.status(400).json({
        message: "Can only adjust balance for disbursed or fully paid loans"
      });
    }

    const previousBalance = loan.remainingBalance || "0";
    const newBalanceNum = parseFloat(newBalance);

    // Create balance adjustment record for audit trail
    await storage.createBalanceAdjustment({
      entityType: "Loan",
      entityId: id,
      adjustedById: user.employeeId,
      previousBalance: previousBalance.toString(),
      newBalance: newBalance,
      adjustmentType,
      reason,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    // Update loan balance
    const newStatus = newBalanceNum === 0 ? "Fully_Paid" : "Disbursed";
    const updatedLoan = await storage.updateLoan(id, {
      remainingBalance: newBalance,
      status: newStatus,
    });

    // Create audit log
    await storage.createAuditLog({
      userId: user.employeeId,
      action: "ADJUST_BALANCE",
      entityType: "Loan",
      entityId: id,
      oldValues: { remainingBalance: previousBalance },
      newValues: { remainingBalance: newBalance, adjustmentType, reason },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    // Notify the affected employee about the balance adjustment
    notifyBalanceAdjustment({
      employeeId: loan.employeeId,
      adjustedBy: user.employeeId,
      type: adjustmentType,
      entityType: "loan",
      reason,
    }).catch(() => {});

    res.json({
      ...updatedLoan,
      adjustmentRecorded: true,
    });
  } catch (error) {
    logger.error("Error adjusting loan balance:", error);
    res.status(500).json({ message: "Failed to adjust balance" });
  }
});

// Get adjustment history for a loan
router.get("/loans/:id/history", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve"), async (req, res) => {
  try {
    const adjustments = await storage.getBalanceAdjustments("Loan", req.params.id);

    // Enrich with adjuster info
    const enriched = await Promise.all(adjustments.map(async (adj) => {
      const adjuster = await storage.getEmployee(adj.adjustedById);
      return {
        ...adj,
        adjustedByName: adjuster ? `${adjuster.firstName} ${adjuster.lastName}` : "Unknown",
      };
    }));

    res.json(enriched);
  } catch (error) {
    logger.error("Error fetching adjustment history:", error);
    res.status(500).json({ message: "Failed to fetch adjustment history" });
  }
});

// Get adjustment type options
router.get("/types", isAuthenticated, async (req, res) => {
  try {
    const types = balanceAdjustmentTypeEnum.map(type => ({
      value: type,
      label: type.replace(/_/g, " "),
    }));
    res.json(types);
  } catch (error) {
    logger.error("Error fetching adjustment types:", error);
    res.status(500).json({ message: "Failed to fetch adjustment types" });
  }
});

export default router;
