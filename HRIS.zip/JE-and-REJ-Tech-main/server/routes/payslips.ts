import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import logger from "../utils/logger";

const router = Router();

router.get("/:id", isAuthenticated, async (req, res) => {
  try {
    const payslip = await storage.getPayrollRecord(req.params.id);
    if (!payslip) {
      return res.status(404).json({ message: "Payslip not found" });
    }

    // Ownership check - admins/HR can view all, others only their own
    const user = req.session.user!;
    const isAdminOrHR = user.isSuperadmin || user.role === "ADMIN" || user.role === "HR";
    if (!isAdminOrHR && payslip.employeeId !== user.employeeId) {
      return res.status(403).json({ message: "Access denied" });
    }

    res.json(payslip);
  } catch (error) {
    logger.error("Error fetching payslip:", error);
    res.status(500).json({ message: "Failed to fetch payslip" });
  }
});

router.patch("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.edit"), async (req, res) => {
  try {
    const { bonusAmount, bonusNotes, otherDeductionAmount, otherDeductionNotes, 
            overrideNetPay, editNotes } = req.body;
    
    const updates: any = {
      isEdited: true,
      editNotes: editNotes || null,
    };
    
    if (bonusAmount !== undefined) updates.bonusAmount = bonusAmount.toString();
    if (bonusNotes !== undefined) updates.bonusNotes = bonusNotes;
    if (otherDeductionAmount !== undefined) updates.otherDeductionAmount = otherDeductionAmount.toString();
    if (otherDeductionNotes !== undefined) updates.otherDeductionNotes = otherDeductionNotes;
    if (overrideNetPay !== undefined) updates.overrideNetPay = overrideNetPay.toString();
    
    const payslip = await storage.updatePayrollRecord(req.params.id, updates);
    if (!payslip) {
      return res.status(404).json({ message: "Payslip not found" });
    }
    res.json(payslip);
  } catch (error) {
    logger.error("Error updating payslip:", error);
    res.status(500).json({ message: "Failed to update payslip" });
  }
});

export default router;
