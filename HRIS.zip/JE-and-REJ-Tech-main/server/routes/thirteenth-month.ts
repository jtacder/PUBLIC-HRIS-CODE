import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import logger from "../utils/logger";
import { z } from "zod";
import type { Employee, ThirteenthMonthAccrual, ThirteenthMonthRelease, PayrollRecord } from "@shared/schema";

const router = Router();

// Helper: Calculate 13th month from released payrolls
async function calculateThirteenthMonthForEmployee(
  employeeId: string,
  year: number
): Promise<{ accumulatedBasicPay: number; accruedAmount: number; monthsWorked: number }> {
  const releasedPayrolls = await storage.getReleasedPayrollsForYear(year);
  const employeePayrolls = releasedPayrolls.filter(p => p.employeeId === employeeId);

  let accumulatedBasicPay = 0;
  const uniqueMonths = new Set<string>();

  for (const payroll of employeePayrolls) {
    accumulatedBasicPay += parseFloat(String(payroll.basicPay) || "0");
    // Track unique months for months worked calculation
    const cutoffDate = new Date(payroll.cutoffStart);
    uniqueMonths.add(`${cutoffDate.getFullYear()}-${cutoffDate.getMonth()}`);
  }

  // 13th month = Total Basic Pay / 12 (DOLE standard)
  const accruedAmount = accumulatedBasicPay / 12;

  // Calculate months worked (approximate based on unique months in payrolls)
  const monthsWorked = uniqueMonths.size;

  return { accumulatedBasicPay, accruedAmount, monthsWorked };
}

// Helper: Update accrual for a single employee after payroll release
export async function updateThirteenthMonthAccrualForPayroll(payrollRecord: PayrollRecord) {
  const year = new Date(payrollRecord.cutoffStart).getFullYear();
  const employeeId = payrollRecord.employeeId;

  const { accumulatedBasicPay, accruedAmount, monthsWorked } =
    await calculateThirteenthMonthForEmployee(employeeId, year);

  // Get existing accrual to check released amounts
  const existingAccrual = await storage.getThirteenthMonthAccrual(employeeId, year);
  const releasedAmount = existingAccrual ? parseFloat(String(existingAccrual.releasedAmount) || "0") : 0;
  const releasedPercentage = existingAccrual ? parseFloat(String(existingAccrual.releasedPercentage) || "0") : 0;

  // Determine status based on released percentage
  let status: "Pending" | "Partial" | "Released" = "Pending";
  if (releasedPercentage >= 100) {
    status = "Released";
  } else if (releasedPercentage > 0) {
    status = "Partial";
  }

  await storage.upsertThirteenthMonthAccrual({
    employeeId,
    year,
    accumulatedBasicPay: accumulatedBasicPay.toFixed(2),
    accruedAmount: accruedAmount.toFixed(2),
    monthsWorked: monthsWorked.toFixed(2),
    releasedAmount: releasedAmount.toFixed(2),
    releasedPercentage: releasedPercentage.toFixed(2),
    status,
    lastPayrollId: payrollRecord.id,
  });
}

// Helper: Sync accrual for a single employee after payroll revert (from Released to Draft)
// This recalculates the accrual excluding the reverted payroll since it's no longer Released
export async function syncThirteenthMonthAccrualOnRevert(payrollRecord: PayrollRecord) {
  const year = new Date(payrollRecord.cutoffStart).getFullYear();
  const employeeId = payrollRecord.employeeId;

  // Recalculate from Released payrolls only (the reverted payroll is now Draft, so it's excluded)
  const { accumulatedBasicPay, accruedAmount, monthsWorked } =
    await calculateThirteenthMonthForEmployee(employeeId, year);

  // Get existing accrual to preserve released amounts
  const existingAccrual = await storage.getThirteenthMonthAccrual(employeeId, year);

  if (!existingAccrual) {
    // No accrual record exists, nothing to sync
    return;
  }

  const releasedAmount = parseFloat(String(existingAccrual.releasedAmount) || "0");
  const releasedPercentage = parseFloat(String(existingAccrual.releasedPercentage) || "0");

  // Determine status based on released percentage
  let status: "Pending" | "Partial" | "Released" = "Pending";
  if (releasedPercentage >= 100) {
    status = "Released";
  } else if (releasedPercentage > 0) {
    status = "Partial";
  }

  // Clear lastPayrollId if the reverted payroll was the last one
  const newLastPayrollId = existingAccrual.lastPayrollId === payrollRecord.id
    ? null
    : existingAccrual.lastPayrollId;

  await storage.upsertThirteenthMonthAccrual({
    employeeId,
    year,
    accumulatedBasicPay: accumulatedBasicPay.toFixed(2),
    accruedAmount: accruedAmount.toFixed(2),
    monthsWorked: monthsWorked.toFixed(2),
    releasedAmount: releasedAmount.toFixed(2),
    releasedPercentage: releasedPercentage.toFixed(2),
    status,
    lastPayrollId: newLastPayrollId,
  });
}

// GET /api/settings/13th-month - Get all 13th month accruals with employee data
router.get("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const { year } = req.query;
    const targetYear = year ? parseInt(year as string) : new Date().getFullYear();

    // Get all accruals for the year
    const accruals = await storage.getThirteenthMonthAccruals(targetYear);

    // Get all active employees
    const employees = await storage.getVisibleEmployees();
    const activeEmployees = employees.filter(e => e.status === "Active" || e.status === "Probationary");

    // Create a map of existing accruals by employee ID
    const accrualMap = new Map(accruals.map(a => [a.employeeId, a]));

    // Build the response with employee data
    const result = await Promise.all(activeEmployees.map(async (employee) => {
      let accrual = accrualMap.get(employee.id);

      // If no accrual exists, calculate from released payrolls
      if (!accrual) {
        const { accumulatedBasicPay, accruedAmount, monthsWorked } =
          await calculateThirteenthMonthForEmployee(employee.id, targetYear);

        // Only create accrual record if there's data
        if (accumulatedBasicPay > 0) {
          accrual = await storage.createThirteenthMonthAccrual({
            employeeId: employee.id,
            year: targetYear,
            accumulatedBasicPay: accumulatedBasicPay.toFixed(2),
            accruedAmount: accruedAmount.toFixed(2),
            monthsWorked: monthsWorked.toFixed(2),
            releasedAmount: "0",
            releasedPercentage: "0",
            status: "Pending",
          });
        }
      }

      return {
        employee: {
          id: employee.id,
          firstName: employee.firstName,
          lastName: employee.lastName,
          employeeNo: employee.employeeNo,
          position: employee.position,
          department: employee.department,
          startDate: employee.startDate,
          status: employee.status,
        },
        accrual: accrual || {
          id: null,
          employeeId: employee.id,
          year: targetYear,
          accumulatedBasicPay: "0",
          accruedAmount: "0",
          monthsWorked: "0",
          releasedAmount: "0",
          releasedPercentage: "0",
          status: "Pending",
        },
      };
    }));

    // Calculate summary
    const summary = {
      year: targetYear,
      totalAccrued: result.reduce((sum, r) => sum + parseFloat(r.accrual.accruedAmount || "0"), 0),
      totalReleased: result.reduce((sum, r) => sum + parseFloat(r.accrual.releasedAmount || "0"), 0),
      employeeCount: result.length,
      pendingCount: result.filter(r => r.accrual.status === "Pending").length,
      partialCount: result.filter(r => r.accrual.status === "Partial").length,
      releasedCount: result.filter(r => r.accrual.status === "Released").length,
    };

    res.json({ data: result, summary });
  } catch (error) {
    logger.error("Error fetching 13th month accruals:", error);
    res.status(500).json({ message: "Failed to fetch 13th month accruals" });
  }
});

// POST /api/settings/13th-month/sync - Recalculate/backfill accruals from existing payroll data
router.post("/sync", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const { year } = req.body;
    const targetYear = year || new Date().getFullYear();

    // Get all released payrolls for the year
    const releasedPayrolls = await storage.getReleasedPayrollsForYear(targetYear);

    // Get unique employee IDs from payrolls
    const employeeIdsWithPayrolls = new Set(releasedPayrolls.map(p => p.employeeId));

    let synced = 0;
    for (const employeeId of employeeIdsWithPayrolls) {
      const { accumulatedBasicPay, accruedAmount, monthsWorked } =
        await calculateThirteenthMonthForEmployee(employeeId, targetYear);

      // Get existing to preserve released amounts
      const existing = await storage.getThirteenthMonthAccrual(employeeId, targetYear);
      const releasedAmount = existing ? parseFloat(String(existing.releasedAmount) || "0") : 0;
      const releasedPercentage = existing ? parseFloat(String(existing.releasedPercentage) || "0") : 0;

      let status: "Pending" | "Partial" | "Released" = "Pending";
      if (releasedPercentage >= 100) {
        status = "Released";
      } else if (releasedPercentage > 0) {
        status = "Partial";
      }

      await storage.upsertThirteenthMonthAccrual({
        employeeId,
        year: targetYear,
        accumulatedBasicPay: accumulatedBasicPay.toFixed(2),
        accruedAmount: accruedAmount.toFixed(2),
        monthsWorked: monthsWorked.toFixed(2),
        releasedAmount: releasedAmount.toFixed(2),
        releasedPercentage: releasedPercentage.toFixed(2),
        status,
      });
      synced++;
    }

    // Also reset stale accrual records for employees who no longer have Released payrolls
    const existingAccruals = await storage.getThirteenthMonthAccruals(targetYear);
    let reset = 0;
    for (const accrual of existingAccruals) {
      // Skip if this employee still has Released payrolls (already handled above)
      if (employeeIdsWithPayrolls.has(accrual.employeeId)) {
        continue;
      }

      // This employee has an accrual record but no Released payrolls - reset to 0
      const releasedAmount = parseFloat(String(accrual.releasedAmount) || "0");
      const releasedPercentage = parseFloat(String(accrual.releasedPercentage) || "0");

      let status: "Pending" | "Partial" | "Released" = "Pending";
      if (releasedPercentage >= 100) {
        status = "Released";
      } else if (releasedPercentage > 0) {
        status = "Partial";
      }

      await storage.upsertThirteenthMonthAccrual({
        employeeId: accrual.employeeId,
        year: targetYear,
        accumulatedBasicPay: "0.00",
        accruedAmount: "0.00",
        monthsWorked: "0.00",
        releasedAmount: releasedAmount.toFixed(2),
        releasedPercentage: releasedPercentage.toFixed(2),
        status,
        lastPayrollId: null,
      });
      reset++;
    }

    // Audit log
    await storage.createAuditLog({
      userId: req.session.user?.id,
      action: "SYNC",
      entityType: "ThirteenthMonthAccrual",
      entityId: String(targetYear),
      newValues: { year: targetYear, syncedCount: synced, resetCount: reset },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    const totalUpdated = synced + reset;
    res.json({ message: `Synced ${totalUpdated} employee accruals for year ${targetYear}`, synced: totalUpdated });
  } catch (error) {
    logger.error("Error syncing 13th month accruals:", error);
    res.status(500).json({ message: "Failed to sync 13th month accruals" });
  }
});

// GET /api/settings/13th-month/preview - Preview release amounts before releasing
router.get("/preview", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const { year, cutoffStart, cutoffEnd, employeeIds, releasePercentage } = req.query;
    const targetYear = year ? parseInt(year as string) : new Date().getFullYear();
    const percentage = releasePercentage ? parseFloat(releasePercentage as string) : 100;

    // Validate cutoff exists with draft payslips
    if (!cutoffStart || !cutoffEnd) {
      return res.status(400).json({ message: "Cutoff start and end dates are required" });
    }

    const payrollRecords = await storage.getPayrollRecordsForCutoff(cutoffStart as string, cutoffEnd as string);
    const draftRecords = payrollRecords.filter(r => r.status === "Draft");

    if (draftRecords.length === 0) {
      return res.status(400).json({
        message: "No draft payslips found for the selected cutoff period. Please compute payroll first."
      });
    }

    // Get accruals for the year
    const accruals = await storage.getThirteenthMonthAccruals(targetYear);
    const accrualMap = new Map(accruals.map(a => [a.employeeId, a]));

    // Filter by employee IDs if provided
    let targetEmployeeIds: string[] = [];
    if (employeeIds) {
      targetEmployeeIds = (employeeIds as string).split(",");
    } else {
      // All employees with draft payslips
      targetEmployeeIds = draftRecords.map(r => r.employeeId);
    }

    // Get employee details
    const employees = await storage.getVisibleEmployees();
    const employeeMap = new Map(employees.map(e => [e.id, e]));

    // Build preview data
    const preview = targetEmployeeIds.map(employeeId => {
      const accrual = accrualMap.get(employeeId);
      const employee = employeeMap.get(employeeId);
      const draftPayslip = draftRecords.find(r => r.employeeId === employeeId);

      if (!employee || !draftPayslip) {
        return null;
      }

      const accruedAmount = parseFloat(accrual?.accruedAmount || "0");
      const releasedAmount = parseFloat(accrual?.releasedAmount || "0");
      const releasedPercentage = parseFloat(accrual?.releasedPercentage || "0");
      const remainingPercentage = Math.min(100 - releasedPercentage, percentage);
      const releaseAmount = (accruedAmount * remainingPercentage) / 100;

      return {
        employeeId,
        employeeName: `${employee.firstName} ${employee.lastName}`,
        employeeNo: employee.employeeNo,
        accruedAmount,
        alreadyReleased: releasedAmount,
        releasedPercentage,
        remainingPercentage,
        releaseAmount: parseFloat(releaseAmount.toFixed(2)),
        payrollRecordId: draftPayslip.id,
        cutoffStart,
        cutoffEnd,
      };
    }).filter(Boolean);

    const total = preview.reduce((sum, p) => sum + (p?.releaseAmount || 0), 0);

    res.json({
      preview,
      summary: {
        employeeCount: preview.length,
        totalReleaseAmount: total,
        releasePercentage: percentage,
      },
    });
  } catch (error) {
    logger.error("Error previewing 13th month release:", error);
    res.status(500).json({ message: "Failed to preview 13th month release" });
  }
});

// Release validation schema
const releaseSchema = z.object({
  year: z.number(),
  cutoffStart: z.string(),
  cutoffEnd: z.string(),
  employeeIds: z.array(z.string()).optional(),
  releasePercentage: z.number().min(1).max(100).default(100),
  notes: z.string().optional(),
});

// POST /api/settings/13th-month/release - Release 13th month to draft payslips
router.post("/release", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const validated = releaseSchema.parse(req.body);
    const { year, cutoffStart, cutoffEnd, employeeIds, releasePercentage, notes } = validated;
    const userId = req.session.user?.id;

    // Get draft payslips for the cutoff
    const payrollRecords = await storage.getPayrollRecordsForCutoff(cutoffStart, cutoffEnd);
    const draftRecords = payrollRecords.filter(r => r.status === "Draft");

    if (draftRecords.length === 0) {
      return res.status(400).json({
        message: "No draft payslips found for the selected cutoff period. Please compute payroll first."
      });
    }

    // Get accruals for the year
    const accruals = await storage.getThirteenthMonthAccruals(year);
    const accrualMap = new Map(accruals.map(a => [a.employeeId, a]));

    // Determine target employees
    let targetEmployeeIds: string[] = [];
    if (employeeIds && employeeIds.length > 0) {
      targetEmployeeIds = employeeIds;
    } else {
      targetEmployeeIds = draftRecords.map(r => r.employeeId);
    }

    const released: ThirteenthMonthRelease[] = [];
    const errors: { employeeId: string; error: string }[] = [];

    for (const employeeId of targetEmployeeIds) {
      try {
        const accrual = accrualMap.get(employeeId);
        const draftPayslip = draftRecords.find(r => r.employeeId === employeeId);

        if (!draftPayslip) {
          errors.push({ employeeId, error: "No draft payslip found for this employee" });
          continue;
        }

        if (!accrual || parseFloat(accrual.accruedAmount || "0") === 0) {
          errors.push({ employeeId, error: "No 13th month accrual found for this employee" });
          continue;
        }

        const currentReleasedPercentage = parseFloat(accrual.releasedPercentage || "0");
        if (currentReleasedPercentage >= 100) {
          errors.push({ employeeId, error: "13th month already fully released for this employee" });
          continue;
        }

        const accruedAmount = parseFloat(accrual.accruedAmount || "0");
        const currentReleasedAmount = parseFloat(accrual.releasedAmount || "0");
        const remainingPercentage = Math.min(100 - currentReleasedPercentage, releasePercentage);
        const releaseAmount = (accruedAmount * remainingPercentage) / 100;

        // Update the payroll record's bonus amount
        const existingBonus = parseFloat(String(draftPayslip.bonusAmount) || "0");
        const newBonusAmount = existingBonus + releaseAmount;
        const bonusNotes = draftPayslip.bonusNotes
          ? `${draftPayslip.bonusNotes}; 13th Month (${remainingPercentage}%)`
          : `13th Month Pay (${remainingPercentage}%)`;

        // Recalculate gross pay and net pay
        const grossPay = parseFloat(String(draftPayslip.basicPay) || "0") +
          parseFloat(String(draftPayslip.regularOTPay) || "0") +
          parseFloat(String(draftPayslip.restDayOTPay) || "0") +
          parseFloat(String(draftPayslip.holidayOTPay) || "0") +
          parseFloat(String(draftPayslip.allowances) || "0") +
          newBonusAmount;

        const totalDeductions = parseFloat(String(draftPayslip.totalDeductions) || "0");
        const netPay = grossPay - totalDeductions;

        await storage.updatePayrollRecord(draftPayslip.id, {
          bonusAmount: newBonusAmount.toFixed(2),
          bonusNotes,
          grossPay: grossPay.toFixed(2),
          netPay: netPay.toFixed(2),
          isEdited: true,
          editNotes: `13th month bonus (${remainingPercentage}%) added: ₱${releaseAmount.toFixed(2)}`,
        });

        // Create release record
        const release = await storage.createThirteenthMonthRelease({
          employeeId,
          year,
          releaseAmount: releaseAmount.toFixed(2),
          releasePercentage: remainingPercentage.toFixed(2),
          payrollRecordId: draftPayslip.id,
          cutoffStart,
          cutoffEnd,
          releasedById: userId,
          notes,
        });
        released.push(release);

        // Update accrual record
        const newTotalReleasedPercentage = currentReleasedPercentage + remainingPercentage;
        const newTotalReleasedAmount = currentReleasedAmount + releaseAmount;
        const newStatus = newTotalReleasedPercentage >= 100 ? "Released" : "Partial";

        await storage.updateThirteenthMonthAccrual(accrual.id, {
          releasedAmount: newTotalReleasedAmount.toFixed(2),
          releasedPercentage: newTotalReleasedPercentage.toFixed(2),
          status: newStatus,
        });

      } catch (error) {
        errors.push({ employeeId, error: String(error) });
      }
    }

    // Audit log
    await storage.createAuditLog({
      userId,
      action: "RELEASE_13TH_MONTH",
      entityType: "ThirteenthMonthRelease",
      entityId: `${year}-${cutoffStart}-${cutoffEnd}`,
      newValues: {
        year,
        cutoffStart,
        cutoffEnd,
        releasedCount: released.length,
        releasePercentage,
        totalAmount: released.reduce((sum, r) => sum + parseFloat(r.releaseAmount), 0),
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json({
      message: `Released 13th month for ${released.length} employees`,
      releasedCount: released.length,
      errorCount: errors.length,
      totalAmount: released.reduce((sum, r) => sum + parseFloat(r.releaseAmount), 0),
      errors: errors.length > 0 ? errors : undefined,
    });
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error releasing 13th month:", error);
    res.status(500).json({ message: "Failed to release 13th month" });
  }
});

// GET /api/settings/13th-month/history - Get release history
router.get("/history", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const { year, employeeId } = req.query;
    const targetYear = year ? parseInt(year as string) : undefined;

    const releases = await storage.getThirteenthMonthReleases(targetYear, employeeId as string);

    // Enrich with employee data
    const employees = await storage.getVisibleEmployees();
    const employeeMap = new Map(employees.map(e => [e.id, e]));

    const enrichedReleases = releases.map(release => {
      const employee = employeeMap.get(release.employeeId);
      return {
        ...release,
        employeeName: employee ? `${employee.firstName} ${employee.lastName}` : "Unknown",
        employeeNo: employee?.employeeNo,
      };
    });

    res.json(enrichedReleases);
  } catch (error) {
    logger.error("Error fetching 13th month history:", error);
    res.status(500).json({ message: "Failed to fetch 13th month history" });
  }
});

// GET /api/settings/13th-month/export - Export 13th month report as CSV
router.get("/export", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const { year } = req.query;
    const targetYear = year ? parseInt(year as string) : new Date().getFullYear();

    // Get all accruals for the year
    const accruals = await storage.getThirteenthMonthAccruals(targetYear);

    // Get all employees
    const employees = await storage.getVisibleEmployees();
    const employeeMap = new Map(employees.map(e => [e.id, e]));

    // Get releases for the year
    const releases = await storage.getThirteenthMonthReleases(targetYear);

    // Build export data
    const exportData = accruals.map(accrual => {
      const employee = employeeMap.get(accrual.employeeId);
      const employeeReleases = releases.filter(r => r.employeeId === accrual.employeeId);
      const lastRelease = employeeReleases[0];

      return {
        employeeId: accrual.employeeId,
        employeeNo: employee?.employeeNo || "",
        employeeName: employee ? `${employee.firstName} ${employee.lastName}` : "Unknown",
        department: employee?.department || "",
        position: employee?.position || "",
        hireDate: employee?.startDate || "",
        monthsWorked: accrual.monthsWorked,
        accumulatedBasicPay: accrual.accumulatedBasicPay,
        thirteenthMonthAmount: accrual.accruedAmount,
        releasedAmount: accrual.releasedAmount,
        releasedPercentage: accrual.releasedPercentage,
        status: accrual.status,
        lastReleaseDate: lastRelease?.releasedAt?.toISOString().split("T")[0] || "",
      };
    });

    // Generate CSV
    const headers = [
      "Employee ID",
      "Employee No",
      "Employee Name",
      "Department",
      "Position",
      "Hire Date",
      "Months Worked",
      "Accumulated Basic Pay",
      "13th Month Amount",
      "Released Amount",
      "Released %",
      "Status",
      "Last Release Date",
    ];

    const csvRows = [
      headers.join(","),
      ...exportData.map(row => [
        row.employeeId,
        row.employeeNo,
        `"${row.employeeName}"`,
        `"${row.department}"`,
        `"${row.position}"`,
        row.hireDate,
        row.monthsWorked,
        row.accumulatedBasicPay,
        row.thirteenthMonthAmount,
        row.releasedAmount,
        row.releasedPercentage,
        row.status,
        row.lastReleaseDate,
      ].join(",")),
    ];

    const csv = csvRows.join("\n");

    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", `attachment; filename="13th-month-report-${targetYear}.csv"`);
    res.send(csv);
  } catch (error) {
    logger.error("Error exporting 13th month report:", error);
    res.status(500).json({ message: "Failed to export 13th month report" });
  }
});

// GET /api/settings/13th-month/draft-cutoffs - Get available draft cutoffs for release
router.get("/draft-cutoffs", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    // Get all existing cutoffs with draft records
    const cutoffs = await storage.getExistingPayrollCutoffs();

    const draftCutoffs = [];
    for (const cutoff of cutoffs) {
      const records = await storage.getPayrollRecordsForCutoff(cutoff.cutoffStart, cutoff.cutoffEnd);
      const draftCount = records.filter(r => r.status === "Draft").length;

      if (draftCount > 0) {
        draftCutoffs.push({
          cutoffStart: cutoff.cutoffStart,
          cutoffEnd: cutoff.cutoffEnd,
          draftCount,
          label: `${cutoff.cutoffStart} to ${cutoff.cutoffEnd}`,
        });
      }
    }

    res.json(draftCutoffs);
  } catch (error) {
    logger.error("Error fetching draft cutoffs:", error);
    res.status(500).json({ message: "Failed to fetch draft cutoffs" });
  }
});

export default router;
