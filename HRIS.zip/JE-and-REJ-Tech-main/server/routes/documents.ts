import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import logger from "../utils/logger";

const router = Router();

// SECURITY FIX: Document deletion requires ADMIN or HR role
// Previously any authenticated user could delete any document
router.delete("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "employees.edit", "employees.delete"), async (req, res) => {
  try {
    const userId = req.session.user?.id;

    // Get document info for audit log before deletion
    const document = await storage.getEmployeeDocument(req.params.id);
    if (!document) {
      return res.status(404).json({ message: "Document not found" });
    }

    await storage.deleteEmployeeDocument(req.params.id);

    // Audit log for document deletion
    await storage.createAuditLog({
      userId,
      action: "DELETE",
      entityType: "EmployeeDocument",
      entityId: req.params.id,
      oldValues: {
        employeeId: document.employeeId,
        documentType: document.documentType,
        documentName: document.documentName,
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.status(204).send();
  } catch (error) {
    logger.error("Error deleting document:", error);
    res.status(500).json({ message: "Failed to delete document" });
  }
});

export default router;
