import { Express, Router, Request, Response, NextFunction } from "express";
import healthRouter from "./health";
import dashboardRouter from "./dashboard";
import employeesRouter from "./employees";
import projectsRouter from "./projects";
import tasksRouter from "./tasks";
import attendanceRouter from "./attendance";
import payrollRouter from "./payroll";
import payrollPeriodsRouter from "./payroll-periods";
import payslipsRouter from "./payslips";
import disciplinaryRouter from "./disciplinary";
import expensesRouter from "./expenses";
import employeeSelfServiceRouter from "./employee-self-service";
import hrSettingsRouter from "./hr-settings";
import leaveRequestsRouter from "./leave-requests";
import cashAdvancesRouter from "./cash-advances";
import loansRouter from "./loans";
import balanceAdjustmentsRouter from "./balance-adjustments";
import documentsRouter from "./documents";
import leaveAllocationsRouter from "./leave-allocations";
import leaveTypesRouter from "./leave-types";
import auditLogsRouter from "./audit-logs";
import devotionalsRouter from "./devotionals";
import permissionsRouter from "./permissions";
import photosRouter from "./photos";
import thirteenthMonthRouter from "./thirteenth-month";
import scheduleManagementRouter from "./schedule-management";
import notificationsRouter from "./notifications";
import { logger } from "../utils/logger";

/**
 * Middleware to add deprecation warning header for non-versioned API routes
 */
function deprecationWarning(req: Request, res: Response, next: NextFunction): void {
  res.setHeader("X-API-Deprecation", "Use /api/v1/ prefix. Non-versioned endpoints will be removed in a future release.");
  res.setHeader("Deprecation", "true");
  res.setHeader("Sunset", "2027-01-01T00:00:00Z");

  // Log deprecation usage for monitoring (only in development)
  if (process.env.NODE_ENV !== "production") {
    logger.debug(`Deprecated API path used: ${req.method} ${req.originalUrl}`, {
      recommend: `/api/v1${req.path}`,
    });
  }

  next();
}

/**
 * Create a router with all v1 API routes
 */
function createV1Router(): Router {
  const router = Router();

  router.use("/dashboard", dashboardRouter);
  router.use("/employees", employeesRouter);
  router.use("/projects", projectsRouter);
  router.use("/tasks", tasksRouter);
  router.use("/attendance", attendanceRouter);
  router.use("/payroll", payrollRouter);
  router.use("/payroll-periods", payrollPeriodsRouter);
  router.use("/payslips", payslipsRouter);
  router.use("/disciplinary", disciplinaryRouter);
  router.use("/expenses", expensesRouter);
  router.use("/my", employeeSelfServiceRouter);
  router.use("/settings", hrSettingsRouter);
  router.use("/leave-requests", leaveRequestsRouter);
  router.use("/cash-advances", cashAdvancesRouter);
  router.use("/loans", loansRouter);
  router.use("/balance-adjustments", balanceAdjustmentsRouter);
  router.use("/leave-allocations", leaveAllocationsRouter);
  router.use("/documents", documentsRouter);
  router.use("/leave-types", leaveTypesRouter);
  router.use("/audit-logs", auditLogsRouter);
  router.use("/devotionals", devotionalsRouter);
  router.use("/permissions", permissionsRouter);
  router.use("/settings/13th-month", thirteenthMonthRouter);
  router.use("/schedule-management", scheduleManagementRouter);
  router.use("/notifications", notificationsRouter);

  return router;
}

export function registerApiRoutes(app: Express): void {
  // Health check routes - NOT versioned (monitoring infrastructure should use consistent paths)
  app.use("/api/health", healthRouter);

  // Photos route - NOT versioned (serves static content from object storage)
  app.use("/api/photos", photosRouter);

  // Create the v1 router
  const v1Router = createV1Router();

  // Mount versioned API routes at /api/v1/
  app.use("/api/v1", v1Router);

  // Mount deprecated non-versioned routes at /api/ for backward compatibility
  // These routes add deprecation headers to encourage migration to /api/v1/
  app.use("/api/dashboard", deprecationWarning, dashboardRouter);
  app.use("/api/employees", deprecationWarning, employeesRouter);
  app.use("/api/projects", deprecationWarning, projectsRouter);
  app.use("/api/tasks", deprecationWarning, tasksRouter);
  app.use("/api/attendance", deprecationWarning, attendanceRouter);
  app.use("/api/payroll", deprecationWarning, payrollRouter);
  app.use("/api/payroll-periods", deprecationWarning, payrollPeriodsRouter);
  app.use("/api/payslips", deprecationWarning, payslipsRouter);
  app.use("/api/disciplinary", deprecationWarning, disciplinaryRouter);
  app.use("/api/expenses", deprecationWarning, expensesRouter);
  app.use("/api/my", deprecationWarning, employeeSelfServiceRouter);
  app.use("/api/settings", deprecationWarning, hrSettingsRouter);
  app.use("/api/leave-requests", deprecationWarning, leaveRequestsRouter);
  app.use("/api/cash-advances", deprecationWarning, cashAdvancesRouter);
  app.use("/api/loans", deprecationWarning, loansRouter);
  app.use("/api/balance-adjustments", deprecationWarning, balanceAdjustmentsRouter);
  app.use("/api/leave-allocations", deprecationWarning, leaveAllocationsRouter);
  app.use("/api/documents", deprecationWarning, documentsRouter);
  app.use("/api/leave-types", deprecationWarning, leaveTypesRouter);
  app.use("/api/audit-logs", deprecationWarning, auditLogsRouter);
  app.use("/api/devotionals", deprecationWarning, devotionalsRouter);
  app.use("/api/permissions", deprecationWarning, permissionsRouter);
  app.use("/api/settings/13th-month", deprecationWarning, thirteenthMonthRouter);
  app.use("/api/schedule-management", deprecationWarning, scheduleManagementRouter);
  app.use("/api/notifications", deprecationWarning, notificationsRouter);

  logger.info("API routes registered with v1 versioning and backward compatibility");
}
