import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import logger from "../utils/logger";

const router = Router();

// Get all leave types - available to all authenticated users
// This endpoint allows employees to see leave types when submitting leave requests
router.get("/", isAuthenticated, async (req, res) => {
  try {
    const leaveTypes = await storage.getLeaveTypes();
    res.json(leaveTypes);
  } catch (error) {
    logger.error("Error fetching leave types:", error);
    res.status(500).json({ message: "Failed to fetch leave types" });
  }
});

export default router;
