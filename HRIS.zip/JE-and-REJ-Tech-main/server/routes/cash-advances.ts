import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { insertCashAdvanceSchema } from "@shared/schema";
import { z } from "zod";
import logger from "../utils/logger";
import { notifyCashAdvanceUpdate, notifyNewRequestPending, notifyCashAdvanceSubmittedOnBehalf } from "../services/notification-triggers";

const router = Router();

router.get("/", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user as any;
    const { employeeId } = req.query;

    // Role-based filtering: HR/Admin see all, employees see only their own
    if (user.role === "ADMIN" || user.role === "HR") {
      const advances = await storage.getCashAdvances(employeeId as string | undefined);
      res.json(advances);
    } else {
      // Regular employees only see their own advances
      const advances = await storage.getCashAdvances(user.employeeId);
      res.json(advances);
    }
  } catch (error) {
    logger.error("Error fetching cash advances:", error);
    res.status(500).json({ message: "Failed to fetch cash advances" });
  }
});

// Create cash advance (HR/Admin only - for creating on behalf of employee)
router.post("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve", "cash_advances.disburse"), async (req, res) => {
  try {
    const user = req.session.user as any;

    // Verify the target employee exists
    const targetEmployeeId = req.body.employeeId;
    if (targetEmployeeId) {
      const targetEmployee = await storage.getEmployee(targetEmployeeId);
      if (!targetEmployee) {
        return res.status(400).json({ message: "Target employee not found" });
      }
    }

    // Determine if this is an on-behalf submission
    const isOnBehalf = targetEmployeeId && targetEmployeeId !== user.employeeId;

    const validated = insertCashAdvanceSchema.parse({
      ...req.body,
      remainingBalance: req.body.amount,
      status: "Pending",
      submittedById: user.employeeId, // Track who submitted
    });
    const advance = await storage.createCashAdvance(validated);

    // Notify admins of new cash advance request
    const employee = await storage.getEmployee(advance.employeeId);
    const employeeName = employee ? `${employee.firstName} ${employee.lastName}` : "Unknown";
    notifyNewRequestPending({
      employeeId: advance.employeeId,
      employeeName,
      requestType: "cash_advance",
      amount: advance.amount as string,
      requestId: advance.id,
    }).catch(() => {});

    // If on-behalf submission, notify the employee
    if (isOnBehalf) {
      notifyCashAdvanceSubmittedOnBehalf({
        employeeId: advance.employeeId,
        submittedById: user.employeeId,
        submitterName: `${user.firstName} ${user.lastName}`,
        amount: advance.amount as string,
        cashAdvanceId: advance.id,
      }).catch(() => {});
    }

    res.status(201).json(advance);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error creating cash advance:", error);
    res.status(500).json({ message: "Failed to create cash advance" });
  }
});

// Approve cash advance (HR/Admin only)
router.post("/:id/approve", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve", "cash_advances.disburse"), async (req, res) => {
  try {
    const user = req.session.user as any;
    const { deductionPerCutoff } = req.body;

    if (!deductionPerCutoff || parseFloat(deductionPerCutoff) <= 0) {
      return res.status(400).json({ message: "Deduction per cutoff is required and must be greater than 0" });
    }

    const existingAdvance = await storage.getCashAdvance(req.params.id);
    if (!existingAdvance) {
      return res.status(404).json({ message: "Cash advance not found" });
    }

    if (existingAdvance.status !== "Pending") {
      return res.status(400).json({
        message: `Cannot approve cash advance with status: ${existingAdvance.status}`
      });
    }

    const amount = parseFloat(existingAdvance.amount as any);
    const deduction = parseFloat(deductionPerCutoff);

    if (deduction > amount) {
      return res.status(400).json({
        message: "Deduction per cutoff cannot be greater than the total amount"
      });
    }

    const advance = await storage.updateCashAdvance(req.params.id, {
      status: "Approved",
      approvedById: user.employeeId,
      deductionPerCutoff: deductionPerCutoff.toString(),
      remainingBalance: existingAdvance.amount, // Remains same until disbursed
    } as any);

    // Notify employee of approval
    notifyCashAdvanceUpdate({
      employeeId: existingAdvance.employeeId,
      processedBy: user.employeeId,
      status: "Approved",
      amount: existingAdvance.amount as string,
      cashAdvanceId: req.params.id,
    }).catch(() => {});

    res.json(advance);
  } catch (error) {
    logger.error("Error approving cash advance:", error);
    res.status(500).json({ message: "Failed to approve cash advance" });
  }
});

// Reject cash advance (HR/Admin only)
router.post("/:id/reject", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve", "cash_advances.disburse"), async (req, res) => {
  try {
    const user = req.session.user as any;

    const existingAdvance = await storage.getCashAdvance(req.params.id);
    if (!existingAdvance) {
      return res.status(404).json({ message: "Cash advance not found" });
    }

    if (existingAdvance.status !== "Pending") {
      return res.status(400).json({
        message: `Cannot reject cash advance with status: ${existingAdvance.status}`
      });
    }

    const advance = await storage.updateCashAdvance(req.params.id, {
      status: "Rejected",
      approvedById: user.employeeId,
    } as any);

    // Notify employee of rejection
    notifyCashAdvanceUpdate({
      employeeId: existingAdvance.employeeId,
      processedBy: user.employeeId,
      status: "Rejected",
      amount: existingAdvance.amount as string,
      cashAdvanceId: req.params.id,
    }).catch(() => {});

    res.json(advance);
  } catch (error) {
    logger.error("Error rejecting cash advance:", error);
    res.status(500).json({ message: "Failed to reject cash advance" });
  }
});

// Disburse cash advance (HR/Admin only - mark as disbursed/cash given)
router.post("/:id/disburse", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve", "cash_advances.disburse"), async (req, res) => {
  try {
    const existingAdvance = await storage.getCashAdvance(req.params.id);
    if (!existingAdvance) {
      return res.status(404).json({ message: "Cash advance not found" });
    }

    if (existingAdvance.status !== "Approved") {
      return res.status(400).json({
        message: `Cannot disburse cash advance with status: ${existingAdvance.status}. Must be Approved first.`
      });
    }

    const advance = await storage.updateCashAdvance(req.params.id, {
      status: "Disbursed",
      remainingBalance: existingAdvance.amount, // Start with full amount
    } as any);

    // Notify employee of disbursement
    const disbursingUser = req.session.user as any;
    notifyCashAdvanceUpdate({
      employeeId: existingAdvance.employeeId,
      processedBy: disbursingUser.employeeId,
      status: "Disbursed",
      amount: existingAdvance.amount as string,
      cashAdvanceId: req.params.id,
    }).catch(() => {});

    res.json(advance);
  } catch (error) {
    logger.error("Error disbursing cash advance:", error);
    res.status(500).json({ message: "Failed to disburse cash advance" });
  }
});

// SECURITY FIX: Explicit field whitelist for cash advance updates
const cashAdvanceUpdateSchema = z.object({
  amount: z.string().optional(),
  reason: z.string().optional(),
  deductionPerCutoff: z.string().optional(),
  remainingBalance: z.string().optional(),
}).strict(); // strict() rejects unknown fields

// Update cash advance (HR/Admin only - for general edits)
router.patch("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve", "cash_advances.disburse"), async (req, res) => {
  try {
    // Validate and whitelist allowed fields
    const validationResult = cashAdvanceUpdateSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: "Validation failed - only amount, reason, deductionPerCutoff, remainingBalance can be updated",
        errors: validationResult.error.errors
      });
    }

    const updates = validationResult.data;

    // Prevent direct status changes via PATCH - use dedicated endpoints
    if ((req.body as any).status) {
      return res.status(400).json({
        message: "Use dedicated endpoints: /approve, /reject, or /disburse to change status"
      });
    }

    const advance = await storage.updateCashAdvance(req.params.id, updates);
    if (!advance) {
      return res.status(404).json({ message: "Cash advance not found" });
    }
    res.json(advance);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error updating cash advance:", error);
    res.status(500).json({ message: "Failed to update cash advance" });
  }
});

// Get payment history for a cash advance
router.get("/:id/payments", isAuthenticated, async (req, res) => {
  try {
    const payments = await storage.getCashAdvancePayments(req.params.id);
    res.json(payments);
  } catch (error) {
    logger.error("Error fetching cash advance payments:", error);
    res.status(500).json({ message: "Failed to fetch payment history" });
  }
});

export default router;
