import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import logger from "../utils/logger";

const router = Router();

router.get("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const periods = await storage.getPayrollPeriods();
    res.json(periods);
  } catch (error) {
    logger.error("Error fetching payroll periods:", error);
    res.status(500).json({ message: "Failed to fetch payroll periods" });
  }
});

router.get("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const period = await storage.getPayrollPeriod(req.params.id);
    if (!period) {
      return res.status(404).json({ message: "Payroll period not found" });
    }
    res.json(period);
  } catch (error) {
    logger.error("Error fetching payroll period:", error);
    res.status(500).json({ message: "Failed to fetch payroll period" });
  }
});

router.post("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const { cutoffStart, cutoffEnd, payDate, periodType, name } = req.body;
    const period = await storage.createPayrollPeriod({
      name: name || `${cutoffStart} to ${cutoffEnd}`,
      cutoffStart,
      cutoffEnd,
      payDate,
      periodType: periodType || "semi-monthly",
      status: "Draft",
    });
    res.status(201).json(period);
  } catch (error) {
    logger.error("Error creating payroll period:", error);
    res.status(500).json({ message: "Failed to create payroll period" });
  }
});

router.patch("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const period = await storage.updatePayrollPeriod(req.params.id, req.body);
    if (!period) {
      return res.status(404).json({ message: "Payroll period not found" });
    }
    res.json(period);
  } catch (error) {
    logger.error("Error updating payroll period:", error);
    res.status(500).json({ message: "Failed to update payroll period" });
  }
});

router.delete("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    await storage.deletePayrollRecordsByPeriod(req.params.id);
    await storage.deletePayrollPeriod(req.params.id);
    res.status(204).send();
  } catch (error) {
    logger.error("Error deleting payroll period:", error);
    res.status(500).json({ message: "Failed to delete payroll period" });
  }
});

router.get("/:id/payslips", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const payslips = await storage.getPayrollRecordsByPeriod(req.params.id);
    res.json(payslips);
  } catch (error) {
    logger.error("Error fetching payslips:", error);
    res.status(500).json({ message: "Failed to fetch payslips" });
  }
});

export default router;
