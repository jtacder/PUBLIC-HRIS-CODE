/**
 * Tests for Devotionals Route
 *
 * Tests all devotional-related endpoints including:
 * - Employee devotional access (today, progress, favorites)
 * - Mark as read functionality
 * - Streak tracking
 * - Admin CRUD operations
 * - Bulk creation
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { Devotional, EmployeeDevotionalProgress, DevotionalReadingLog } from '@shared/schema';

// Mock storage
const mockStorage = {
  getDevotionals: vi.fn(),
  getDevotional: vi.fn(),
  getDevotionalByDay: vi.fn(),
  createDevotional: vi.fn(),
  updateDevotional: vi.fn(),
  deleteDevotional: vi.fn(),
  getEmployeeDevotionalProgress: vi.fn(),
  createEmployeeDevotionalProgress: vi.fn(),
  updateEmployeeDevotionalProgress: vi.fn(),
  getDevotionalReadingLogByDate: vi.fn(),
  getDevotionalReadingLogs: vi.fn(),
  createDevotionalReadingLog: vi.fn(),
  updateDevotionalReadingLog: vi.fn(),
  getFavoriteDevotionals: vi.fn(),
};

vi.mock('../storage', () => ({
  storage: mockStorage,
}));

// Helper functions (replicated from route)
function getDayOfYear(date: Date = new Date()): number {
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = date.getTime() - start.getTime();
  const oneDay = 1000 * 60 * 60 * 24;
  return Math.floor(diff / oneDay);
}

function getTodayString(): string {
  const now = new Date();
  return now.toISOString().split('T')[0];
}

// Test fixtures
const mockDevotional: Devotional = {
  id: 'dev-001',
  dayNumber: 1,
  verse: 'For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life.',
  reference: 'John 3:16',
  baseExcerpt: 'God\'s love is the foundation of our faith...',
  theme: 'Love',
  year1Focus: null,
  year2Focus: null,
  year3Focus: null,
  createdAt: new Date(),
  updatedAt: new Date(),
};

const mockProgress: EmployeeDevotionalProgress = {
  id: 'prog-001',
  employeeId: 'emp-001',
  startDate: '2025-01-01',
  currentYear: 1,
  lastReadDay: 15,
  lastReadDate: '2025-01-15',
  totalDaysRead: 15,
  currentStreak: 5,
  longestStreak: 10,
  todayRead: false,
  createdAt: new Date(),
  updatedAt: new Date(),
};

const mockReadingLog: DevotionalReadingLog = {
  id: 'log-001',
  employeeId: 'emp-001',
  devotionalId: 'dev-001',
  readDate: '2025-01-15',
  dayNumber: 15,
  yearNumber: 1,
  personalNote: 'This verse spoke to me today',
  isFavorite: false,
  createdAt: new Date(),
};

describe('Devotionals Route Logic', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('GET /devotionals/today', () => {
    it('should return today\'s devotional', async () => {
      const dayOfYear = getDayOfYear();
      mockStorage.getEmployeeDevotionalProgress.mockResolvedValue(mockProgress);
      mockStorage.getDevotionalByDay.mockResolvedValue(mockDevotional);
      mockStorage.getDevotionalReadingLogByDate.mockResolvedValue(null);

      const progress = await mockStorage.getEmployeeDevotionalProgress('emp-001');
      const devotional = await mockStorage.getDevotionalByDay(dayOfYear);
      const todayLog = await mockStorage.getDevotionalReadingLogByDate('emp-001', getTodayString());

      expect(progress).toBeDefined();
      expect(devotional).toBeDefined();
      expect(todayLog).toBeNull(); // Not read today
    });

    it('should create new progress for first-time user', async () => {
      mockStorage.getEmployeeDevotionalProgress.mockResolvedValue(null);
      mockStorage.createEmployeeDevotionalProgress.mockResolvedValue({
        ...mockProgress,
        totalDaysRead: 0,
        currentStreak: 0,
        longestStreak: 0,
      });

      const progress = await mockStorage.getEmployeeDevotionalProgress('emp-002');
      expect(progress).toBeNull();

      // Should create new progress
      const newProgress = await mockStorage.createEmployeeDevotionalProgress({
        employeeId: 'emp-002',
        startDate: getTodayString(),
        currentYear: 1,
        lastReadDay: 0,
        totalDaysRead: 0,
        currentStreak: 0,
        longestStreak: 0,
        todayRead: false,
      });

      expect(newProgress.totalDaysRead).toBe(0);
    });

    it('should return devotional content without year-specific focus', () => {
      // Year focus fields are deprecated but kept in schema for backward compatibility
      expect(mockDevotional.year1Focus).toBeNull();
      expect(mockDevotional.year2Focus).toBeNull();
      expect(mockDevotional.year3Focus).toBeNull();
    });

    it('should indicate if already read today', async () => {
      const todayString = getTodayString();
      mockStorage.getDevotionalReadingLogByDate.mockResolvedValue(mockReadingLog);

      const todayLog = await mockStorage.getDevotionalReadingLogByDate('emp-001', todayString);

      expect(todayLog).toBeDefined();
      const todayRead = !!todayLog;
      expect(todayRead).toBe(true);
    });

    it('should handle missing devotional for the day', async () => {
      mockStorage.getDevotionalByDay.mockResolvedValue(null);

      const devotional = await mockStorage.getDevotionalByDay(999);

      expect(devotional).toBeNull();
    });
  });

  describe('POST /devotionals/mark-read', () => {
    it('should mark devotional as read', async () => {
      mockStorage.getEmployeeDevotionalProgress.mockResolvedValue(mockProgress);
      mockStorage.getDevotionalReadingLogByDate.mockResolvedValue(null);
      mockStorage.getDevotionalByDay.mockResolvedValue(mockDevotional);
      mockStorage.createDevotionalReadingLog.mockResolvedValue(mockReadingLog);
      mockStorage.updateEmployeeDevotionalProgress.mockResolvedValue({
        ...mockProgress,
        totalDaysRead: 16,
        currentStreak: 6,
      });

      // Create reading log
      const log = await mockStorage.createDevotionalReadingLog({
        employeeId: 'emp-001',
        devotionalId: mockDevotional.id,
        readDate: getTodayString(),
        dayNumber: getDayOfYear(),
        yearNumber: 1,
        personalNote: null,
        isFavorite: false,
      });

      expect(log).toBeDefined();
    });

    it('should not allow marking twice in same day', async () => {
      mockStorage.getDevotionalReadingLogByDate.mockResolvedValue(mockReadingLog);

      const existingLog = await mockStorage.getDevotionalReadingLogByDate('emp-001', getTodayString());

      expect(existingLog).toBeDefined();
      // Should return error
    });

    it('should update streak correctly - continuation', async () => {
      // Read yesterday
      const yesterdayLog = { ...mockReadingLog };
      mockStorage.getDevotionalReadingLogByDate.mockResolvedValue(yesterdayLog);

      const currentStreak = mockProgress.currentStreak;
      const newStreak = currentStreak + 1;

      expect(newStreak).toBe(6);
    });

    it('should reset streak if skipped a day', async () => {
      // No yesterday log
      mockStorage.getDevotionalReadingLogByDate.mockResolvedValue(null);

      const newStreak = 1; // Reset to 1

      expect(newStreak).toBe(1);
    });

    it('should update longest streak if current exceeds it', () => {
      const currentStreak = 12;
      const longestStreak = 10;
      const newLongestStreak = Math.max(longestStreak, currentStreak);

      expect(newLongestStreak).toBe(12);
    });
  });

  describe('GET /devotionals/progress', () => {
    it('should return employee progress', async () => {
      mockStorage.getEmployeeDevotionalProgress.mockResolvedValue(mockProgress);
      mockStorage.getDevotionalReadingLogs.mockResolvedValue([mockReadingLog]);

      const progress = await mockStorage.getEmployeeDevotionalProgress('emp-001');
      const recentLogs = await mockStorage.getDevotionalReadingLogs('emp-001', 7);

      expect(progress).toBeDefined();
      expect(progress?.totalDaysRead).toBe(15);
      expect(progress?.currentStreak).toBe(5);
      expect(recentLogs).toHaveLength(1);
    });

    it('should calculate percent complete', () => {
      const totalDaysRead = 15;
      const percentComplete = Math.round((totalDaysRead / 365) * 100);

      expect(percentComplete).toBe(4); // 15/365 * 100 ≈ 4%
    });

    it('should return not started for new employee', async () => {
      mockStorage.getEmployeeDevotionalProgress.mockResolvedValue(null);

      const progress = await mockStorage.getEmployeeDevotionalProgress('emp-new');

      expect(progress).toBeNull();
    });
  });

  describe('POST /devotionals/favorite/:logId', () => {
    it('should toggle favorite status', async () => {
      mockStorage.getDevotionalReadingLogs.mockResolvedValue([mockReadingLog]);
      mockStorage.updateDevotionalReadingLog.mockResolvedValue({
        ...mockReadingLog,
        isFavorite: true,
      });

      const logs = await mockStorage.getDevotionalReadingLogs('emp-001');
      const log = logs.find(l => l.id === 'log-001');

      expect(log).toBeDefined();

      const updated = await mockStorage.updateDevotionalReadingLog('log-001', { isFavorite: true });

      expect(updated.isFavorite).toBe(true);
    });
  });

  describe('GET /devotionals/favorites', () => {
    it('should return favorite devotionals', async () => {
      const favorites = [{ ...mockReadingLog, isFavorite: true }];
      mockStorage.getFavoriteDevotionals.mockResolvedValue(favorites);

      const result = await mockStorage.getFavoriteDevotionals('emp-001');

      expect(result).toHaveLength(1);
      expect(result[0].isFavorite).toBe(true);
    });
  });

  describe('GET /devotionals/:day', () => {
    it('should return devotional for specific day', async () => {
      mockStorage.getDevotionalByDay.mockResolvedValue(mockDevotional);

      const result = await mockStorage.getDevotionalByDay(1);

      expect(result).toBeDefined();
      expect(result?.dayNumber).toBe(1);
    });

    it('should validate day number (1-365)', () => {
      const validDay = 100;
      const invalidDayLow = 0;
      const invalidDayHigh = 400;

      expect(validDay >= 1 && validDay <= 365).toBe(true);
      expect(invalidDayLow >= 1 && invalidDayLow <= 365).toBe(false);
      expect(invalidDayHigh >= 1 && invalidDayHigh <= 365).toBe(false);
    });
  });

  describe('Admin Endpoints', () => {
    describe('GET /devotionals/admin/all', () => {
      it('should return all devotionals', async () => {
        const devotionals = [mockDevotional];
        mockStorage.getDevotionals.mockResolvedValue(devotionals);

        const result = await mockStorage.getDevotionals();

        expect(result).toHaveLength(1);
      });
    });

    describe('POST /devotionals/admin/create', () => {
      it('should create a new devotional', async () => {
        const newDevotional = {
          dayNumber: 2,
          verse: 'Trust in the LORD with all your heart...',
          reference: 'Proverbs 3:5',
          baseExcerpt: 'Trust is foundational to our walk with God...',
          theme: 'Trust',
        };

        mockStorage.getDevotionalByDay.mockResolvedValue(null);
        mockStorage.createDevotional.mockResolvedValue({
          ...mockDevotional,
          ...newDevotional,
          id: 'dev-new',
        });

        // Check if day exists
        const existing = await mockStorage.getDevotionalByDay(2);
        expect(existing).toBeNull();

        const result = await mockStorage.createDevotional(newDevotional as any);

        expect(result.id).toBe('dev-new');
        expect(result.dayNumber).toBe(2);
      });

      it('should not create duplicate day', async () => {
        mockStorage.getDevotionalByDay.mockResolvedValue(mockDevotional);

        const existing = await mockStorage.getDevotionalByDay(1);

        expect(existing).toBeDefined();
        // Should return error
      });
    });

    describe('PUT /devotionals/admin/:id', () => {
      it('should update a devotional', async () => {
        const updates = { theme: 'Grace' };

        mockStorage.getDevotional.mockResolvedValue(mockDevotional);
        mockStorage.updateDevotional.mockResolvedValue({
          ...mockDevotional,
          ...updates,
        });

        const existing = await mockStorage.getDevotional('dev-001');
        expect(existing).toBeDefined();

        const result = await mockStorage.updateDevotional('dev-001', updates);

        expect(result.theme).toBe('Grace');
      });
    });

    describe('DELETE /devotionals/admin/:id', () => {
      it('should delete a devotional (ADMIN only)', async () => {
        mockStorage.getDevotional.mockResolvedValue(mockDevotional);
        mockStorage.deleteDevotional.mockResolvedValue(undefined);

        const existing = await mockStorage.getDevotional('dev-001');
        expect(existing).toBeDefined();

        await mockStorage.deleteDevotional('dev-001');

        expect(mockStorage.deleteDevotional).toHaveBeenCalledWith('dev-001');
      });
    });

    describe('POST /devotionals/admin/bulk', () => {
      it('should bulk create devotionals', async () => {
        const devotionals = [
          { dayNumber: 5, verse: 'Verse 5', reference: 'Ref 5', baseExcerpt: 'Excerpt 5', theme: 'Theme 5' },
          { dayNumber: 6, verse: 'Verse 6', reference: 'Ref 6', baseExcerpt: 'Excerpt 6', theme: 'Theme 6' },
        ];

        mockStorage.getDevotionalByDay.mockResolvedValue(null);
        mockStorage.createDevotional.mockResolvedValue({ id: 'dev-new' });

        const results = {
          created: 0,
          skipped: 0,
          errors: [] as string[],
        };

        for (const item of devotionals) {
          const existing = await mockStorage.getDevotionalByDay(item.dayNumber);
          if (!existing) {
            await mockStorage.createDevotional(item as any);
            results.created++;
          } else {
            results.skipped++;
          }
        }

        expect(results.created).toBe(2);
        expect(results.skipped).toBe(0);
      });

      it('should skip existing days', async () => {
        mockStorage.getDevotionalByDay.mockResolvedValue(mockDevotional);

        const existing = await mockStorage.getDevotionalByDay(1);

        expect(existing).toBeDefined();
        // Should skip
      });
    });
  });
});

describe('Day of Year Calculation', () => {
  it('should calculate day 1 for January 1', () => {
    const jan1 = new Date(2025, 0, 1);
    const dayOfYear = getDayOfYear(jan1);

    expect(dayOfYear).toBe(1);
  });

  it('should calculate day 365 for December 31 (non-leap year)', () => {
    const dec31 = new Date(2025, 11, 31);
    const dayOfYear = getDayOfYear(dec31);

    expect(dayOfYear).toBe(365);
  });

  it('should calculate day 366 for December 31 (leap year)', () => {
    const dec31 = new Date(2024, 11, 31);
    const dayOfYear = getDayOfYear(dec31);

    expect(dayOfYear).toBe(366);
  });

  it('should calculate middle of year correctly', () => {
    const july1 = new Date(2025, 6, 1);
    const dayOfYear = getDayOfYear(july1);

    // Jan(31) + Feb(28) + Mar(31) + Apr(30) + May(31) + Jun(30) + 1 = 182
    expect(dayOfYear).toBe(182);
  });
});

describe('Streak Calculation', () => {
  it('should increment streak for consecutive days', () => {
    const currentStreak = 5;
    const yesterdayRead = true;
    const newStreak = yesterdayRead ? currentStreak + 1 : 1;

    expect(newStreak).toBe(6);
  });

  it('should reset streak when day is skipped', () => {
    const currentStreak = 5;
    const yesterdayRead = false;
    const newStreak = yesterdayRead ? currentStreak + 1 : 1;

    expect(newStreak).toBe(1);
  });

  it('should update longest streak when exceeded', () => {
    const currentStreak = 15;
    const longestStreak = 10;
    const newLongestStreak = Math.max(longestStreak, currentStreak);

    expect(newLongestStreak).toBe(15);
  });

  it('should not update longest streak when not exceeded', () => {
    const currentStreak = 5;
    const longestStreak = 10;
    const newLongestStreak = Math.max(longestStreak, currentStreak);

    expect(newLongestStreak).toBe(10);
  });
});

// Year Number Calculation tests removed - yearly theme feature deprecated

describe('Role-Based Access Control', () => {
  describe('Employee access', () => {
    it('any authenticated user can access today devotional', () => {
      const isAuthenticated = true;
      expect(isAuthenticated).toBe(true);
    });

    it('any authenticated user can mark as read', () => {
      const isAuthenticated = true;
      expect(isAuthenticated).toBe(true);
    });

    it('any authenticated user can view progress', () => {
      const isAuthenticated = true;
      expect(isAuthenticated).toBe(true);
    });
  });

  describe('Admin access', () => {
    it('only HR/ADMIN can access admin endpoints', () => {
      const hrRole = 'HR';
      const canAdmin = hrRole === 'ADMIN' || hrRole === 'HR';
      expect(canAdmin).toBe(true);
    });

    it('only ADMIN can delete devotionals', () => {
      const adminRole = 'ADMIN';
      const canDelete = adminRole === 'ADMIN';
      expect(canDelete).toBe(true);
    });

    it('HR cannot delete devotionals', () => {
      const hrRole = 'HR';
      const canDelete = hrRole === 'ADMIN';
      expect(canDelete).toBe(false);
    });
  });
});

describe('Personal Note Handling', () => {
  it('should store personal note', () => {
    expect(mockReadingLog.personalNote).toBe('This verse spoke to me today');
  });

  it('should allow null personal note', () => {
    const logWithoutNote = { ...mockReadingLog, personalNote: null };
    expect(logWithoutNote.personalNote).toBeNull();
  });
});
