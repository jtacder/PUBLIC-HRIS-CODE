/**
 * Payroll Workflow Integration Tests
 *
 * Tests the complete payroll lifecycle:
 * 1. Compute - Creates Draft payroll records
 * 2. Approve - Applies deductions and transitions to Approved
 * 3. Release - Marks as Released for payment
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { IStorage } from '../storage';
import type { Employee, PayrollRecord, AttendanceLog, CashAdvance, CashAdvancePayment } from '@shared/schema';

// Mock the storage module
vi.mock('../storage', () => ({
  storage: {} as IStorage,
}));

// Mock the config module
vi.mock('../config', () => ({
  config: {
    payroll: {
      defaultWorkingDaysPerMonth: 22,
      defaultWorkingHoursPerDay: 8,
      overtimeRates: { regular: 1.25, restDay: 1.30, holiday: 2.00 },
      lateDeductionPerMinute: 1,
      undertimeDeductionPerMinute: 1,
    },
  },
}));

// Test fixtures
const mockEmployee: Employee = {
  id: 'emp-001',
  firstName: 'Juan',
  lastName: 'Dela Cruz',
  email: 'juan@example.com',
  phone: '09171234567',
  department: 'Engineering',
  position: 'Software Engineer',
  role: 'ENGINEER',
  status: 'Active',
  baseRate: '700',
  rateType: 'daily',
  enableSSSDeduction: true,
  enablePhilhealthDeduction: true,
  enablePagibigDeduction: true,
  enableTaxWithholding: false,
  hireDate: '2023-01-15',
  qrToken: 'abc123',
  createdAt: new Date(),
  updatedAt: new Date(),
  employeeNo: 'EMP-001',
  tin: null,
  sssNo: null,
  philhealthNo: null,
  pagibigNo: null,
  address: null,
  emergencyContact: null,
  emergencyContactPhone: null,
  profileImageUrl: null,
  notes: null,
  resignationDate: null,
};

const mockAttendance: AttendanceLog[] = [
  {
    id: 'att-001',
    employeeId: 'emp-001',
    timeIn: new Date('2025-01-01T08:00:00'),
    timeOut: new Date('2025-01-01T17:00:00'),
    totalHours: '8',
    lateMinutes: 0,
    undertimeMinutes: 0,
    overtimeMinutes: 0,
    overtimeApproved: false,
    otStatus: null,
    otMinutesApproved: null,
    overtimeType: null,
    notes: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: 'att-002',
    employeeId: 'emp-001',
    timeIn: new Date('2025-01-02T08:00:00'),
    timeOut: new Date('2025-01-02T17:00:00'),
    totalHours: '8',
    lateMinutes: 0,
    undertimeMinutes: 0,
    overtimeMinutes: 0,
    overtimeApproved: false,
    otStatus: null,
    otMinutesApproved: null,
    overtimeType: null,
    notes: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
];

const mockPayrollRecord: PayrollRecord = {
  id: 'pay-001',
  employeeId: 'emp-001',
  periodId: null,
  cutoffStart: '2025-01-01',
  cutoffEnd: '2025-01-15',
  daysWorked: '2',
  hoursWorked: '16',
  totalLateMinutes: 0,
  totalUndertimeMinutes: 0,
  regularOTMinutes: 0,
  restDayOTMinutes: 0,
  holidayOTMinutes: 0,
  basicPay: '1400.00',
  regularOTPay: '0.00',
  restDayOTPay: '0.00',
  holidayOTPay: '0.00',
  grossPay: '1400.00',
  sssDeduction: '140.00',
  philhealthDeduction: '70.00',
  pagibigDeduction: '100.00',
  taxDeduction: '0.00',
  lateDeduction: '0.00',
  undertimeDeduction: '0.00',
  cashAdvanceDeduction: '0.00',
  unpaidLeaveDays: '0',
  unpaidLeaveDeduction: '0.00',
  paidLeaveDays: '0',
  totalDeductions: '310.00',
  netPay: '1090.00',
  status: 'Draft',
  bonusAmount: null,
  bonusNotes: null,
  allowances: null,
  otherDeductionAmount: null,
  otherDeductionNotes: null,
  overrideNetPay: null,
  isEdited: false,
  editNotes: null,
  approvedAt: null,
  releasedAt: null,
  createdAt: new Date(),
  updatedAt: new Date(),
};

describe('Payroll Workflow Integration Tests', () => {
  let mockStorage: IStorage;

  beforeEach(() => {
    // Reset mock storage for each test
    mockStorage = {
      getEmployees: vi.fn(),
      getEmployee: vi.fn(),
      getEmployeeByEmail: vi.fn(),
      getEmployeeByQRToken: vi.fn(),
      createEmployee: vi.fn(),
      updateEmployee: vi.fn(),
      deleteEmployee: vi.fn(),
      getProjects: vi.fn(),
      getProject: vi.fn(),
      createProject: vi.fn(),
      updateProject: vi.fn(),
      deleteProject: vi.fn(),
      getProjectAssignments: vi.fn(),
      getEmployeeAssignments: vi.fn(),
      createProjectAssignment: vi.fn(),
      deleteProjectAssignment: vi.fn(),
      getTasks: vi.fn(),
      getTask: vi.fn(),
      getEmployeeTasks: vi.fn(),
      createTask: vi.fn(),
      updateTask: vi.fn(),
      deleteTask: vi.fn(),
      getTaskComments: vi.fn(),
      createTaskComment: vi.fn(),
      getAttendanceLogs: vi.fn(),
      getAttendanceLog: vi.fn(),
      getTodayAttendance: vi.fn(),
      getEmployeeAttendance: vi.fn(),
      createAttendanceLog: vi.fn(),
      updateAttendanceLog: vi.fn(),
      deleteAttendanceLog: vi.fn(),
      getPayrollPeriods: vi.fn(),
      getPayrollPeriod: vi.fn(),
      createPayrollPeriod: vi.fn(),
      updatePayrollPeriod: vi.fn(),
      deletePayrollPeriod: vi.fn(),
      getPayrollRecords: vi.fn(),
      getPayrollRecordsByPeriod: vi.fn(),
      getExistingPayrollCutoffs: vi.fn(),
      getPayrollRecord: vi.fn(),
      getEmployeePayroll: vi.fn(),
      createPayrollRecord: vi.fn(),
      updatePayrollRecord: vi.fn(),
      deletePayrollRecordsForCutoff: vi.fn(),
      getPayrollRecordsForCutoff: vi.fn(),
      deletePayrollRecordsByPeriod: vi.fn(),
      getDisciplinaryActions: vi.fn(),
      getDisciplinaryAction: vi.fn(),
      createDisciplinaryAction: vi.fn(),
      updateDisciplinaryAction: vi.fn(),
      getExpenses: vi.fn(),
      getExpense: vi.fn(),
      createExpense: vi.fn(),
      updateExpense: vi.fn(),
      getEmployeeDocuments: vi.fn(),
      createEmployeeDocument: vi.fn(),
      deleteEmployeeDocument: vi.fn(),
      createAuditLog: vi.fn(),
      getAuditLogs: vi.fn(),
      getPayrollCutoffs: vi.fn(),
      createPayrollCutoff: vi.fn(),
      updatePayrollCutoff: vi.fn(),
      deletePayrollCutoff: vi.fn(),
      getLeaveTypes: vi.fn(),
      createLeaveType: vi.fn(),
      updateLeaveType: vi.fn(),
      deleteLeaveType: vi.fn(),
      getLeaveRequests: vi.fn(),
      getLeaveRequest: vi.fn(),
      createLeaveRequest: vi.fn(),
      updateLeaveRequest: vi.fn(),
      getHolidays: vi.fn(),
      createHoliday: vi.fn(),
      updateHoliday: vi.fn(),
      deleteHoliday: vi.fn(),
      getCashAdvances: vi.fn(),
      getCashAdvance: vi.fn(),
      createCashAdvance: vi.fn(),
      updateCashAdvance: vi.fn(),
      getCashAdvancePayments: vi.fn(),
      getCashAdvancePaymentsByPayrollRecord: vi.fn(),
      createCashAdvancePayment: vi.fn(),
      deleteCashAdvancePaymentsByPayrollRecord: vi.fn(),
      getCompanySettings: vi.fn(),
      getCompanySetting: vi.fn(),
      upsertCompanySetting: vi.fn(),
      getEmployeeLeaveAllocations: vi.fn(),
      createEmployeeLeaveAllocation: vi.fn(),
      updateEmployeeLeaveAllocation: vi.fn(),
      deleteEmployeeLeaveAllocation: vi.fn(),
    } as IStorage;
  });

  describe('Payroll Computation', () => {
    it('should compute payroll for active employees only', async () => {
      const activeEmployee = { ...mockEmployee, status: 'Active' };
      const inactiveEmployee = { ...mockEmployee, id: 'emp-002', status: 'Resigned' };

      vi.mocked(mockStorage.getEmployees).mockResolvedValue([activeEmployee, inactiveEmployee]);
      vi.mocked(mockStorage.getAttendanceLogs).mockResolvedValue(mockAttendance);
      vi.mocked(mockStorage.getLeaveRequests).mockResolvedValue([]);
      vi.mocked(mockStorage.getLeaveTypes).mockResolvedValue([]);
      vi.mocked(mockStorage.getCashAdvances).mockResolvedValue([]);
      vi.mocked(mockStorage.deletePayrollRecordsForCutoff).mockResolvedValue();
      vi.mocked(mockStorage.createPayrollRecord).mockResolvedValue(mockPayrollRecord);

      // The computation should only process active employees
      const activeStatuses = ['Active', 'Probationary'];
      const employees = [activeEmployee, inactiveEmployee];
      const filtered = employees.filter(e => activeStatuses.includes(e.status || ''));

      expect(filtered).toHaveLength(1);
      expect(filtered[0].id).toBe('emp-001');
    });

    it('should include probationary employees in payroll', async () => {
      const probationaryEmployee = { ...mockEmployee, status: 'Probationary' };

      const activeStatuses = ['Active', 'Probationary'];
      const employees = [probationaryEmployee];
      const filtered = employees.filter(e => activeStatuses.includes(e.status || ''));

      expect(filtered).toHaveLength(1);
      expect(filtered[0].status).toBe('Probationary');
    });

    it('should exclude resigned employees from payroll', async () => {
      const resignedEmployee = { ...mockEmployee, status: 'Resigned' };

      const activeStatuses = ['Active', 'Probationary'];
      const employees = [resignedEmployee];
      const filtered = employees.filter(e => activeStatuses.includes(e.status || ''));

      expect(filtered).toHaveLength(0);
    });

    it('should delete existing draft records before recomputing', async () => {
      const cutoffStart = '2025-01-01';
      const cutoffEnd = '2025-01-15';

      vi.mocked(mockStorage.deletePayrollRecordsForCutoff).mockResolvedValue();

      await mockStorage.deletePayrollRecordsForCutoff(cutoffStart, cutoffEnd);

      expect(mockStorage.deletePayrollRecordsForCutoff).toHaveBeenCalledWith(cutoffStart, cutoffEnd);
    });

    it('should create payroll records with Draft status', async () => {
      vi.mocked(mockStorage.createPayrollRecord).mockResolvedValue(mockPayrollRecord);

      const record = await mockStorage.createPayrollRecord({
        employeeId: 'emp-001',
        cutoffStart: '2025-01-01',
        cutoffEnd: '2025-01-15',
        daysWorked: '2',
        hoursWorked: '16',
        basicPay: '1400.00',
        grossPay: '1400.00',
        netPay: '1090.00',
        status: 'Draft',
      });

      expect(record.status).toBe('Draft');
    });

    it('should calculate overtime pay correctly', async () => {
      const employeeWithOT: AttendanceLog[] = [
        {
          ...mockAttendance[0],
          overtimeMinutes: 60,
          overtimeApproved: true,
          otStatus: 'Approved',
          otMinutesApproved: 60,
          overtimeType: 'Regular',
        },
      ];

      vi.mocked(mockStorage.getAttendanceLogs).mockResolvedValue(employeeWithOT);

      // Verify OT minutes are captured
      const regularOTMinutes = employeeWithOT.reduce((sum, log) => {
        if ((log.overtimeType === 'Regular' || !log.overtimeType) &&
            (log.otStatus === 'Approved' || log.overtimeApproved)) {
          return sum + Number(log.otMinutesApproved ?? log.overtimeMinutes ?? 0);
        }
        return sum;
      }, 0);

      expect(regularOTMinutes).toBe(60);
    });
  });

  describe('Payroll Approval', () => {
    it('should transition status from Draft to Approved', async () => {
      const draftRecord = { ...mockPayrollRecord, status: 'Draft' as const };
      const approvedRecord = {
        ...mockPayrollRecord,
        status: 'Approved' as const,
        approvedAt: new Date()
      };

      vi.mocked(mockStorage.getPayrollRecord).mockResolvedValue(draftRecord);
      vi.mocked(mockStorage.updatePayrollRecord).mockResolvedValue(approvedRecord);
      vi.mocked(mockStorage.getCashAdvancePaymentsByPayrollRecord).mockResolvedValue([]);

      const existingRecord = await mockStorage.getPayrollRecord('pay-001');
      expect(existingRecord?.status).toBe('Draft');

      const updated = await mockStorage.updatePayrollRecord('pay-001', {
        status: 'Approved',
        approvedAt: new Date(),
      });

      expect(updated?.status).toBe('Approved');
      expect(updated?.approvedAt).toBeDefined();
    });

    it('should apply cash advance deductions on approval', async () => {
      const mockCashAdvance: CashAdvance = {
        id: 'ca-001',
        employeeId: 'emp-001',
        amount: '5000',
        remainingBalance: '5000',
        deductionPerCutoff: '500',
        reason: 'Emergency',
        status: 'Disbursed',
        disbursedAt: new Date(),
        approvedAt: new Date(),
        approvedBy: 'admin-001',
        requestedAt: new Date(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const mockPayment: CashAdvancePayment = {
        id: 'cap-001',
        cashAdvanceId: 'ca-001',
        payrollRecordId: 'pay-001',
        payrollPeriodId: null,
        deductionAmount: '500',
        remainingBalanceAfter: '4500',
        paymentDate: '2025-01-15',
        createdAt: new Date(),
      };

      vi.mocked(mockStorage.getCashAdvancePaymentsByPayrollRecord).mockResolvedValue([mockPayment]);
      vi.mocked(mockStorage.getCashAdvance).mockResolvedValue(mockCashAdvance);
      vi.mocked(mockStorage.updateCashAdvance).mockResolvedValue({
        ...mockCashAdvance,
        remainingBalance: '4500',
      });

      // Simulate the approval process
      const payments = await mockStorage.getCashAdvancePaymentsByPayrollRecord('pay-001');
      expect(payments).toHaveLength(1);

      for (const payment of payments) {
        const advance = await mockStorage.getCashAdvance(payment.cashAdvanceId);
        if (advance) {
          const newBalance = parseFloat(String(payment.remainingBalanceAfter) || '0');
          await mockStorage.updateCashAdvance(payment.cashAdvanceId, {
            remainingBalance: newBalance.toString(),
            status: newBalance === 0 ? 'Fully_Paid' : 'Disbursed',
          });
        }
      }

      expect(mockStorage.updateCashAdvance).toHaveBeenCalledWith('ca-001', {
        remainingBalance: '4500',
        status: 'Disbursed',
      });
    });

    it('should mark cash advance as Fully_Paid when balance reaches zero', async () => {
      const mockCashAdvance: CashAdvance = {
        id: 'ca-002',
        employeeId: 'emp-001',
        amount: '500',
        remainingBalance: '500',
        deductionPerCutoff: '500',
        reason: 'Small advance',
        status: 'Disbursed',
        disbursedAt: new Date(),
        approvedAt: new Date(),
        approvedBy: 'admin-001',
        requestedAt: new Date(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const mockPayment: CashAdvancePayment = {
        id: 'cap-002',
        cashAdvanceId: 'ca-002',
        payrollRecordId: 'pay-001',
        payrollPeriodId: null,
        deductionAmount: '500',
        remainingBalanceAfter: '0',
        paymentDate: '2025-01-15',
        createdAt: new Date(),
      };

      vi.mocked(mockStorage.getCashAdvancePaymentsByPayrollRecord).mockResolvedValue([mockPayment]);
      vi.mocked(mockStorage.getCashAdvance).mockResolvedValue(mockCashAdvance);
      vi.mocked(mockStorage.updateCashAdvance).mockResolvedValue({
        ...mockCashAdvance,
        remainingBalance: '0',
        status: 'Fully_Paid',
      });

      const payments = await mockStorage.getCashAdvancePaymentsByPayrollRecord('pay-001');
      for (const payment of payments) {
        const newBalance = parseFloat(String(payment.remainingBalanceAfter) || '0');
        await mockStorage.updateCashAdvance(payment.cashAdvanceId, {
          remainingBalance: newBalance.toString(),
          status: newBalance === 0 ? 'Fully_Paid' : 'Disbursed',
        });
      }

      expect(mockStorage.updateCashAdvance).toHaveBeenCalledWith('ca-002', {
        remainingBalance: '0',
        status: 'Fully_Paid',
      });
    });

    it('should return 404 when approving non-existent record', async () => {
      vi.mocked(mockStorage.getPayrollRecord).mockResolvedValue(undefined);

      const record = await mockStorage.getPayrollRecord('non-existent');
      expect(record).toBeUndefined();
    });
  });

  describe('Payroll Release', () => {
    it('should transition status from Approved to Released', async () => {
      const approvedRecord = {
        ...mockPayrollRecord,
        status: 'Approved' as const
      };
      const releasedRecord = {
        ...mockPayrollRecord,
        status: 'Released' as const,
        releasedAt: new Date()
      };

      vi.mocked(mockStorage.getPayrollRecord).mockResolvedValue(approvedRecord);
      vi.mocked(mockStorage.updatePayrollRecord).mockResolvedValue(releasedRecord);

      const updated = await mockStorage.updatePayrollRecord('pay-001', {
        status: 'Released',
        releasedAt: new Date(),
      });

      expect(updated?.status).toBe('Released');
      expect(updated?.releasedAt).toBeDefined();
    });

    it('should set releasedAt timestamp', async () => {
      const beforeRelease = new Date();

      const releasedRecord = {
        ...mockPayrollRecord,
        status: 'Released' as const,
        releasedAt: new Date()
      };

      vi.mocked(mockStorage.updatePayrollRecord).mockResolvedValue(releasedRecord);

      const updated = await mockStorage.updatePayrollRecord('pay-001', {
        status: 'Released',
        releasedAt: new Date(),
      });

      expect(updated?.releasedAt).toBeDefined();
      expect(updated!.releasedAt!.getTime()).toBeGreaterThanOrEqual(beforeRelease.getTime());
    });
  });

  describe('Payroll Deletion', () => {
    it('should only delete Draft records', async () => {
      const draftRecords = [
        { ...mockPayrollRecord, status: 'Draft' as const },
      ];
      const approvedRecords = [
        { ...mockPayrollRecord, id: 'pay-002', status: 'Approved' as const },
      ];
      const allRecords = [...draftRecords, ...approvedRecords];

      vi.mocked(mockStorage.getPayrollRecordsForCutoff).mockResolvedValue(allRecords);

      const records = await mockStorage.getPayrollRecordsForCutoff('2025-01-01', '2025-01-15');
      const nonDraftRecords = records.filter(r => r.status !== 'Draft');

      // Should not proceed with deletion if non-draft records exist
      expect(nonDraftRecords).toHaveLength(1);
    });

    it('should delete cash advance payments when deleting draft records', async () => {
      vi.mocked(mockStorage.deleteCashAdvancePaymentsByPayrollRecord).mockResolvedValue();
      vi.mocked(mockStorage.deletePayrollRecordsForCutoff).mockResolvedValue();

      // Simulate deleting payments before records
      await mockStorage.deleteCashAdvancePaymentsByPayrollRecord('pay-001');
      await mockStorage.deletePayrollRecordsForCutoff('2025-01-01', '2025-01-15');

      expect(mockStorage.deleteCashAdvancePaymentsByPayrollRecord).toHaveBeenCalled();
      expect(mockStorage.deletePayrollRecordsForCutoff).toHaveBeenCalled();
    });
  });

  describe('Payroll Record Updates', () => {
    it('should allow manual edits to payroll record', async () => {
      const editedRecord = {
        ...mockPayrollRecord,
        bonusAmount: '1000',
        bonusNotes: 'Performance bonus',
        isEdited: true,
      };

      vi.mocked(mockStorage.getPayrollRecord).mockResolvedValue(mockPayrollRecord);
      vi.mocked(mockStorage.updatePayrollRecord).mockResolvedValue(editedRecord);

      const updated = await mockStorage.updatePayrollRecord('pay-001', {
        bonusAmount: '1000',
        bonusNotes: 'Performance bonus',
        isEdited: true,
      });

      expect(updated?.isEdited).toBe(true);
      expect(updated?.bonusAmount).toBe('1000');
    });

    it('should recalculate gross pay when basic pay changes', async () => {
      const existingRecord = { ...mockPayrollRecord };

      // Simulate recalculation logic
      const newBasicPay = parseFloat('2000');
      const regularOTPay = parseFloat(existingRecord.regularOTPay || '0');
      const restDayOTPay = parseFloat(existingRecord.restDayOTPay || '0');
      const holidayOTPay = parseFloat(existingRecord.holidayOTPay || '0');
      const bonusAmount = parseFloat(existingRecord.bonusAmount || '0');
      const allowances = parseFloat(existingRecord.allowances || '0');

      const grossPay = newBasicPay + regularOTPay + restDayOTPay +
                       holidayOTPay + bonusAmount + allowances;

      expect(grossPay).toBe(2000);
    });

    it('should recalculate net pay when deductions change', async () => {
      const grossPay = 1400;
      const sssDeduction = 200;
      const philhealthDeduction = 70;
      const pagibigDeduction = 100;
      const taxDeduction = 0;
      const lateDeduction = 0;
      const undertimeDeduction = 0;
      const otherDeduction = 0;
      const cashAdvanceDeduction = 500;

      const totalDeductions = sssDeduction + philhealthDeduction +
                              pagibigDeduction + taxDeduction +
                              lateDeduction + undertimeDeduction +
                              otherDeduction + cashAdvanceDeduction;

      const netPay = grossPay - totalDeductions;

      expect(totalDeductions).toBe(870);
      expect(netPay).toBe(530);
    });
  });

  describe('Complete Workflow: Compute -> Approve -> Release', () => {
    it('should complete full payroll lifecycle', async () => {
      // Step 1: Compute payroll (creates Draft records)
      const draftRecord = { ...mockPayrollRecord, status: 'Draft' as const };
      vi.mocked(mockStorage.createPayrollRecord).mockResolvedValue(draftRecord);

      const created = await mockStorage.createPayrollRecord({
        employeeId: 'emp-001',
        cutoffStart: '2025-01-01',
        cutoffEnd: '2025-01-15',
        basicPay: '1400.00',
        grossPay: '1400.00',
        netPay: '1090.00',
        status: 'Draft',
      });

      expect(created.status).toBe('Draft');

      // Step 2: Approve payroll
      const approvedRecord = {
        ...draftRecord,
        status: 'Approved' as const,
        approvedAt: new Date()
      };
      vi.mocked(mockStorage.getPayrollRecord).mockResolvedValue(draftRecord);
      vi.mocked(mockStorage.getCashAdvancePaymentsByPayrollRecord).mockResolvedValue([]);
      vi.mocked(mockStorage.updatePayrollRecord).mockResolvedValue(approvedRecord);

      const approved = await mockStorage.updatePayrollRecord(created.id, {
        status: 'Approved',
        approvedAt: new Date(),
      });

      expect(approved?.status).toBe('Approved');
      expect(approved?.approvedAt).toBeDefined();

      // Step 3: Release payroll
      const releasedRecord = {
        ...approvedRecord,
        status: 'Released' as const,
        releasedAt: new Date()
      };
      vi.mocked(mockStorage.updatePayrollRecord).mockResolvedValue(releasedRecord);

      const released = await mockStorage.updatePayrollRecord(created.id, {
        status: 'Released',
        releasedAt: new Date(),
      });

      expect(released?.status).toBe('Released');
      expect(released?.releasedAt).toBeDefined();
    });

    it('should process multiple employees in batch', async () => {
      const employees: Employee[] = [
        { ...mockEmployee, id: 'emp-001' },
        { ...mockEmployee, id: 'emp-002', firstName: 'Maria' },
        { ...mockEmployee, id: 'emp-003', firstName: 'Pedro' },
      ];

      vi.mocked(mockStorage.getEmployees).mockResolvedValue(employees);

      const fetchedEmployees = await mockStorage.getEmployees();
      const activeEmployees = fetchedEmployees.filter(e =>
        e.status === 'Active' || e.status === 'Probationary'
      );

      expect(activeEmployees).toHaveLength(3);

      // Each employee should get a payroll record
      const createdRecords: PayrollRecord[] = [];
      for (const emp of activeEmployees) {
        const record = {
          ...mockPayrollRecord,
          id: `pay-${emp.id}`,
          employeeId: emp.id
        };
        vi.mocked(mockStorage.createPayrollRecord).mockResolvedValueOnce(record);
        const created = await mockStorage.createPayrollRecord({
          employeeId: emp.id,
          cutoffStart: '2025-01-01',
          cutoffEnd: '2025-01-15',
          basicPay: '1400.00',
          grossPay: '1400.00',
          netPay: '1090.00',
          status: 'Draft',
        });
        createdRecords.push(created);
      }

      expect(createdRecords).toHaveLength(3);
      expect(new Set(createdRecords.map(r => r.employeeId)).size).toBe(3);
    });
  });

  describe('Edge Cases', () => {
    it('should handle employee with no attendance records', async () => {
      vi.mocked(mockStorage.getAttendanceLogs).mockResolvedValue([]);

      const attendance = await mockStorage.getAttendanceLogs();
      const employeeAttendance = attendance.filter(a => a.employeeId === 'emp-001');

      // Should still create payroll with 0 days worked
      expect(employeeAttendance).toHaveLength(0);

      const daysWorked = employeeAttendance.length;
      expect(daysWorked).toBe(0);
    });

    it('should handle monthly rate employees correctly', async () => {
      const monthlyEmployee = {
        ...mockEmployee,
        baseRate: '22000',
        rateType: 'monthly',
      };

      const defaultWorkingDaysPerMonth = 22;
      const dailyRate = parseFloat(String(monthlyEmployee.baseRate)) || 0;
      const effectiveRate = monthlyEmployee.rateType === 'monthly'
        ? dailyRate / defaultWorkingDaysPerMonth
        : dailyRate;

      expect(effectiveRate).toBe(1000); // 22000 / 22 = 1000
    });

    it('should respect employee deduction preferences', async () => {
      const employeeNoSSS = {
        ...mockEmployee,
        enableSSSDeduction: false,
        enablePhilhealthDeduction: true,
        enablePagibigDeduction: true,
      };

      const deductionConfig = {
        applySss: employeeNoSSS.enableSSSDeduction ?? true,
        applyPhilhealth: employeeNoSSS.enablePhilhealthDeduction ?? true,
        applyPagibig: employeeNoSSS.enablePagibigDeduction ?? true,
        applyTax: employeeNoSSS.enableTaxWithholding ?? false,
      };

      expect(deductionConfig.applySss).toBe(false);
      expect(deductionConfig.applyPhilhealth).toBe(true);
      expect(deductionConfig.applyPagibig).toBe(true);
    });
  });
});
