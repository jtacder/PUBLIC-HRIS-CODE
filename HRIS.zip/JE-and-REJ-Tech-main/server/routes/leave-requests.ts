import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { insertLeaveRequestSchema } from "@shared/schema";
import { z } from "zod";
import logger from "../utils/logger";
import { notifyLeaveRequestSubmitted, notifyLeaveRequestDecision, notifyLeaveRequestSubmittedOnBehalf } from "../services/notification-triggers";

const router = Router();

// Helper function to sync employee leave allocation used days
async function syncEmployeeLeaveUsed(employeeId: string, leaveTypeId: string, year: number) {
  try {
    // Get all approved leave requests for this employee/type/year
    const allRequests = await storage.getLeaveRequests(employeeId);
    const approvedLeaves = allRequests.filter(req =>
      req.leaveTypeId === leaveTypeId &&
      req.status === "Approved" &&
      new Date(req.startDate).getFullYear() === year
    );

    // Calculate total used days
    const usedDays = approvedLeaves.reduce((sum, leave) => {
      return sum + parseFloat(leave.totalDays);
    }, 0);

    // Find or create allocation record
    const allocations = await storage.getEmployeeLeaveAllocations(employeeId, year);
    const allocation = allocations.find(a => a.leaveTypeId === leaveTypeId);

    if (allocation) {
      // Update existing allocation
      const totalAllocated = parseFloat(allocation.totalAllocated);
      const accruedToDate = parseFloat(allocation.accruedToDate || allocation.totalAllocated);
      const carriedOver = parseFloat(allocation.carriedOver || "0");
      const remaining = Math.max(0, accruedToDate + carriedOver - usedDays);

      await storage.updateEmployeeLeaveAllocation(allocation.id, {
        used: usedDays.toString(),
        remaining: remaining.toString(),
      });
    }
    // If no allocation exists, balance is calculated dynamically from leave type defaults
  } catch (error) {
    logger.error("Error syncing leave allocation:", error);
    // Don't throw - this is a non-critical operation
  }
}

router.get("/", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user as any;
    const { employeeId } = req.query;

    // Role-based filtering: HR/Admin see all, employees see only their own
    let requests;
    if (user.role === "ADMIN" || user.role === "HR") {
      requests = await storage.getLeaveRequests(employeeId as string | undefined);
    } else {
      // Regular employees only see their own requests
      requests = await storage.getLeaveRequests(user.employeeId);
    }

    // Enhance leave requests with employee data
    const employees = await storage.getEmployees();
    const employeeMap = new Map(employees.map(e => [e.id, e]));

    const enhancedRequests = requests.map(request => {
      const employee = employeeMap.get(request.employeeId);
      const submitter = request.submittedById ? employeeMap.get(request.submittedById) : null;
      return {
        ...request,
        employee: employee ? {
          id: employee.id,
          firstName: employee.firstName,
          lastName: employee.lastName,
          employeeNo: employee.employeeNo,
          profilePhotoUrl: employee.profilePhotoUrl,
        } : null,
        submittedBy: submitter ? {
          id: submitter.id,
          firstName: submitter.firstName,
          lastName: submitter.lastName,
        } : null,
      };
    });

    res.json(enhancedRequests);
  } catch (error) {
    logger.error("Error fetching leave requests:", error);
    res.status(500).json({ message: "Failed to fetch leave requests" });
  }
});

router.post("/", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user as any;
    const isHrAdmin = user.role === "ADMIN" || user.role === "HR";

    // Determine the employee ID for the request
    // HR/Admin can submit on behalf of any employee; regular employees can only submit for themselves
    let targetEmployeeId = user.employeeId;
    const requestedEmployeeId = req.body.employeeId;

    if (requestedEmployeeId && requestedEmployeeId !== user.employeeId) {
      // Attempting to submit for another employee
      if (!isHrAdmin) {
        return res.status(403).json({
          message: "You can only submit leave requests for yourself. Contact HR for assistance."
        });
      }
      // HR/Admin is submitting on behalf of another employee
      // Verify the target employee exists
      const targetEmployee = await storage.getEmployee(requestedEmployeeId);
      if (!targetEmployee) {
        return res.status(400).json({ message: "Target employee not found" });
      }
      targetEmployeeId = requestedEmployeeId;
    }

    // Determine if this is an on-behalf submission
    const isOnBehalf = targetEmployeeId !== user.employeeId;

    const requestedDays = parseFloat(req.body.totalDays);
    const startDate = new Date(req.body.startDate);
    const endDate = new Date(req.body.endDate);
    const leaveYear = startDate.getFullYear();

    // === OVERLAP DETECTION ===
    // Check for existing pending/approved leave requests that overlap with the requested dates
    const existingRequests = await storage.getLeaveRequests(targetEmployeeId);
    const overlappingRequest = existingRequests.find(existing => {
      if (existing.status === "Rejected" || existing.status === "Cancelled") {
        return false; // Ignore rejected/cancelled requests
      }
      const existingStart = new Date(existing.startDate);
      const existingEnd = new Date(existing.endDate);
      // Check for date overlap
      return startDate <= existingEnd && endDate >= existingStart;
    });

    if (overlappingRequest) {
      return res.status(400).json({
        message: `This leave request overlaps with an existing ${overlappingRequest.status.toLowerCase()} request from ${overlappingRequest.startDate} to ${overlappingRequest.endDate}. Please cancel the existing request first or choose different dates.`,
        overlappingRequestId: overlappingRequest.id,
      });
    }

    // === LEAVE BALANCE CHECK ===
    // Get the leave type to check if it's paid
    const leaveTypes = await storage.getLeaveTypes();
    const leaveType = leaveTypes.find(lt => lt.id === req.body.leaveTypeId);
    if (!leaveType) {
      return res.status(400).json({ message: "Invalid leave type" });
    }

    // Get employee's leave allocation for this leave type and year
    const allocations = await storage.getEmployeeLeaveAllocations(targetEmployeeId, leaveYear);
    const allocation = allocations.find(a => a.leaveTypeId === req.body.leaveTypeId);

    let availableBalance = 0;
    let paidDays = requestedDays;
    let unpaidDays = 0;

    if (allocation) {
      // Calculate available balance (accrued + carried over - already used)
      const accruedToDate = parseFloat(allocation.accruedToDate || allocation.totalAllocated || "0");
      const carriedOver = parseFloat(allocation.carriedOver || "0");
      const used = parseFloat(allocation.used || "0");
      availableBalance = Math.max(0, accruedToDate + carriedOver - used);
    }

    // Calculate paid vs unpaid days based on leave type and available balance
    if (leaveType.isPaid !== false) {
      // For paid leave types, check against available balance
      if (requestedDays > availableBalance) {
        // Employee is requesting more days than they have available
        paidDays = availableBalance;
        unpaidDays = requestedDays - availableBalance;
      } else {
        paidDays = requestedDays;
        unpaidDays = 0;
      }
    } else {
      // Unpaid leave type - all days are unpaid
      paidDays = 0;
      unpaidDays = requestedDays;
    }

    const validated = insertLeaveRequestSchema.parse({
      ...req.body,
      employeeId: targetEmployeeId,
      submittedById: user.employeeId, // Track who actually submitted
      status: "Pending", // Always start as pending
      paidDays: paidDays.toString(),
      unpaidDays: unpaidDays.toString(),
      availableBalanceAtRequest: availableBalance.toString(),
    });
    const request = await storage.createLeaveRequest(validated);

    // Fire-and-forget notifications
    if (isOnBehalf) {
      // Notify HR admins and the employee that request was submitted on their behalf
      notifyLeaveRequestSubmittedOnBehalf({
        employeeId: request.employeeId,
        submittedById: user.employeeId,
        submitterName: `${user.firstName} ${user.lastName}`,
        leaveType: request.leaveTypeId || "Leave",
        startDate: request.startDate,
        endDate: request.endDate,
        requestId: request.id,
      }).catch(() => {});
    } else {
      // Standard self-submission notification
      notifyLeaveRequestSubmitted({
        employeeId: request.employeeId,
        employeeName: `${request.employeeId}`, // We'll use the ID, trigger resolves the name
        leaveType: request.leaveTypeId || "Leave",
        startDate: request.startDate,
        endDate: request.endDate,
        requestId: request.id,
      }).catch(() => {});
    }

    res.status(201).json(request);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error creating leave request:", error);
    res.status(500).json({ message: "Failed to create leave request" });
  }
});

// Get leave balance for a specific employee (HR/Admin can get any, employees only their own)
router.get("/balance/:employeeId", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user as any;
    const isHrAdmin = user.role === "ADMIN" || user.role === "HR";
    const requestedEmployeeId = req.params.employeeId;

    // Authorization check
    if (!isHrAdmin && requestedEmployeeId !== user.employeeId) {
      return res.status(403).json({ message: "You can only view your own leave balance" });
    }

    const year = parseInt(req.query.year as string) || new Date().getFullYear();

    // Get all leave types
    const leaveTypes = await storage.getLeaveTypes();

    // Get employee's leave allocations for the year
    const allocations = await storage.getEmployeeLeaveAllocations(requestedEmployeeId, year);

    // Get pending leave requests for this employee (to show committed but not yet used days)
    const pendingRequests = await storage.getLeaveRequests(requestedEmployeeId);
    const pendingByType = new Map<string, number>();
    pendingRequests
      .filter(r => r.status === "Pending" && new Date(r.startDate).getFullYear() === year)
      .forEach(r => {
        const current = pendingByType.get(r.leaveTypeId) || 0;
        pendingByType.set(r.leaveTypeId, current + parseFloat(r.totalDays));
      });

    // Build balance response for each leave type
    const balances = leaveTypes.map(lt => {
      const allocation = allocations.find(a => a.leaveTypeId === lt.id);
      const accruedToDate = parseFloat(allocation?.accruedToDate || allocation?.totalAllocated || "0");
      const carriedOver = parseFloat(allocation?.carriedOver || "0");
      const used = parseFloat(allocation?.used || "0");
      const pending = pendingByType.get(lt.id) || 0;
      const available = Math.max(0, accruedToDate + carriedOver - used);
      const effectiveAvailable = Math.max(0, available - pending); // Subtract pending requests

      return {
        leaveTypeId: lt.id,
        leaveTypeName: lt.name,
        leaveTypeCode: lt.code,
        isPaid: lt.isPaid,
        year,
        totalAllocated: parseFloat(allocation?.totalAllocated || "0"),
        accruedToDate,
        carriedOver,
        used,
        pending,
        available,
        effectiveAvailable, // What's actually available after pending requests
        hasAllocation: !!allocation,
      };
    });

    res.json({
      employeeId: requestedEmployeeId,
      year,
      balances,
    });
  } catch (error) {
    logger.error("Error fetching leave balance:", error);
    res.status(500).json({ message: "Failed to fetch leave balance" });
  }
});

// Approve leave request (HR/Admin only)
router.post("/:id/approve", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "leave.view_all", "leave.approve"), async (req, res) => {
  try {
    const user = req.session.user as any;
    const { remarks } = req.body;

    const existingRequest = await storage.getLeaveRequest(req.params.id);
    if (!existingRequest) {
      return res.status(404).json({ message: "Leave request not found" });
    }

    if (existingRequest.status !== "Pending") {
      return res.status(400).json({
        message: `Cannot approve request with status: ${existingRequest.status}`
      });
    }

    const request = await storage.updateLeaveRequest(req.params.id, {
      status: "Approved",
      approvedById: user.employeeId,
      remarks: remarks || null,
    } as any);

    // Update the employee's leave allocation used days
    await syncEmployeeLeaveUsed(
      existingRequest.employeeId,
      existingRequest.leaveTypeId,
      new Date(existingRequest.startDate).getFullYear()
    );

    // Fire-and-forget notification
    notifyLeaveRequestDecision({
      employeeId: existingRequest.employeeId,
      approverName: `${user.firstName} ${user.lastName}`,
      approverId: user.employeeId,
      leaveType: existingRequest.leaveTypeId || "Leave",
      status: "Approved",
      remarks: remarks || undefined,
      requestId: req.params.id,
    }).catch(() => {});

    res.json(request);
  } catch (error) {
    logger.error("Error approving leave request:", error);
    res.status(500).json({ message: "Failed to approve leave request" });
  }
});

// Reject leave request (HR/Admin only)
router.post("/:id/reject", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "leave.view_all", "leave.approve"), async (req, res) => {
  try {
    const user = req.session.user as any;
    const { remarks } = req.body;

    if (!remarks || remarks.trim().length === 0) {
      return res.status(400).json({ message: "Remarks are required when rejecting a leave request" });
    }

    const existingRequest = await storage.getLeaveRequest(req.params.id);
    if (!existingRequest) {
      return res.status(404).json({ message: "Leave request not found" });
    }

    if (existingRequest.status !== "Pending") {
      return res.status(400).json({
        message: `Cannot reject request with status: ${existingRequest.status}`
      });
    }

    const request = await storage.updateLeaveRequest(req.params.id, {
      status: "Rejected",
      approvedById: user.employeeId,
      remarks,
    } as any);

    // Fire-and-forget notification
    notifyLeaveRequestDecision({
      employeeId: existingRequest.employeeId,
      approverName: `${user.firstName} ${user.lastName}`,
      approverId: user.employeeId,
      leaveType: existingRequest.leaveTypeId || "Leave",
      status: "Rejected",
      remarks: remarks || undefined,
      requestId: req.params.id,
    }).catch(() => {});

    res.json(request);
  } catch (error) {
    logger.error("Error rejecting leave request:", error);
    res.status(500).json({ message: "Failed to reject leave request" });
  }
});

// Cancel leave request (Employee can cancel their own pending request)
router.post("/:id/cancel", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user as any;

    const existingRequest = await storage.getLeaveRequest(req.params.id);
    if (!existingRequest) {
      return res.status(404).json({ message: "Leave request not found" });
    }

    // Verify ownership unless HR/Admin
    if (user.role !== "ADMIN" && user.role !== "HR") {
      if (existingRequest.employeeId !== user.employeeId) {
        return res.status(403).json({ message: "You can only cancel your own leave requests" });
      }
    }

    if (existingRequest.status === "Approved") {
      return res.status(400).json({
        message: "Cannot cancel an approved leave request. Please contact HR."
      });
    }

    if (existingRequest.status === "Cancelled") {
      return res.status(400).json({ message: "Leave request is already cancelled" });
    }

    const request = await storage.updateLeaveRequest(req.params.id, {
      status: "Cancelled",
      remarks: `Cancelled by ${user.role === "ADMIN" || user.role === "HR" ? "HR" : "employee"}`,
    });

    res.json(request);
  } catch (error) {
    logger.error("Error cancelling leave request:", error);
    res.status(500).json({ message: "Failed to cancel leave request" });
  }
});

export default router;
