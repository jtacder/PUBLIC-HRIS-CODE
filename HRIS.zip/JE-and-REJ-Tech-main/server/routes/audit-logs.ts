import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import logger from "../utils/logger";
import { db } from "../db";
import { employees } from "@shared/schema";
import { inArray } from "drizzle-orm";

const router = Router();

// Maximum allowed limit to prevent memory issues with large queries
const MAX_AUDIT_LOG_LIMIT = 1000;
const DEFAULT_AUDIT_LOG_LIMIT = 100;

router.get("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "audit.view"), async (req, res) => {
  try {
    const { entityType, entityId, limit } = req.query;

    let logs = await storage.getAuditLogs(
      entityType as string | undefined,
      entityId as string | undefined
    );

    // SECURITY FIX: Cap the limit to prevent memory issues
    // Parse limit with bounds checking
    let effectiveLimit = DEFAULT_AUDIT_LOG_LIMIT;
    if (limit) {
      const requestedLimit = parseInt(limit as string, 10);
      if (!isNaN(requestedLimit) && requestedLimit > 0) {
        effectiveLimit = Math.min(requestedLimit, MAX_AUDIT_LOG_LIMIT);
      }
    }
    logs = logs.slice(0, effectiveLimit);
    
    // Enrich logs with user names using batch query
    const userIds = Array.from(new Set(logs.map(log => log.userId).filter(Boolean))) as string[];

    // Single batch query instead of N individual queries
    const employeeRecords = userIds.length > 0
      ? await db.select().from(employees).where(inArray(employees.id, userIds))
      : [];

    // Use Map for O(1) lookup instead of Record
    const userNameMap = new Map(
      employeeRecords.map(emp => [emp.id, `${emp.firstName} ${emp.lastName}`])
    );

    const enrichedLogs = logs.map(log => ({
      ...log,
      userName: log.userId ? (userNameMap.get(log.userId) || null) : null,
    }));
    
    res.json(enrichedLogs);
  } catch (error) {
    logger.error("Error fetching audit logs:", error);
    res.status(500).json({ message: "Failed to fetch audit logs" });
  }
});

export default router;
