import { Router } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { insertProjectSchema, insertProjectAssignmentSchema, insertProjectCommentSchema } from "@shared/schema";
import { sanitizeOptionalFields, OPTIONAL_PROJECT_FIELDS } from "../utils/validation";
import logger from "../utils/logger";
import { notifyProjectAssignment, notifyProjectStatusChanged, notifyProjectComment } from "../services/notification-triggers";
// Note: Attachment uploads for comments not yet implemented

const router = Router();

router.get("/", isAuthenticated, async (req, res) => {
  try {
    const [projects, allTasks, allAttendance, allAssignments, allExpenses, allEmployees] = await Promise.all([
      storage.getProjects(),
      storage.getTasks(),
      storage.getAttendanceLogs(),
      storage.getProjectAssignments(),
      storage.getExpenses(),
      storage.getEmployees(),
    ]);

    const enrichedProjects = projects.map(project => {
      const projectTasks = allTasks.filter(t => t.projectId === project.id);
      const taskCount = projectTasks.length;
      const completedTasks = projectTasks.filter(t => t.status === "Done").length;
      const progress = taskCount > 0
        ? Math.round((completedTasks / taskCount) * 100)
        : 0;

      // Calculate total approved expenses for this project
      const projectExpenses = allExpenses.filter(e =>
        e.projectId === project.id && e.status === "Approved"
      );
      const totalApprovedExpenses = projectExpenses.reduce((sum, e) =>
        sum + parseFloat(e.amount || "0"), 0
      );

      const assignedEmployeeIds = allAssignments
        .filter(a => a.projectId === project.id)
        .map(a => a.employeeId);

      // Filter attendance logs by assigned employees and project date range
      // Use date strings (YYYY-MM-DD) for comparison to avoid timezone issues
      const projectStartDateStr = project.startDate || null;
      const projectEndDateStr = project.deadline || null;

      const projectAttendance = allAttendance.filter(log => {
        // Must be an assigned employee
        if (!assignedEmployeeIds.includes(log.employeeId)) {
          return false;
        }

        // Must have totalHours (completed attendance)
        if (!log.totalHours) {
          return false;
        }

        // Must have project date range defined
        if (!projectStartDateStr || !projectEndDateStr) {
          return false;
        }

        // Extract local date portion (YYYY-MM-DD) from timeIn timestamp
        const logTime = new Date(log.timeIn);
        const logDateStr = `${logTime.getFullYear()}-${String(logTime.getMonth() + 1).padStart(2, '0')}-${String(logTime.getDate()).padStart(2, '0')}`;
        return logDateStr >= projectStartDateStr && logDateStr <= projectEndDateStr;
      });

      // Calculate total hours: regular shift hours + approved OT hours
      const hoursUsed = projectAttendance.reduce((sum, log) => {
        const regularHours = (log.regularMinutes || 0) / 60;
        const approvedOtHours = log.otStatus === "Approved"
          ? parseFloat(log.overtimeHours || "0")
          : 0;
        return sum + regularHours + approvedOtHours;
      }, 0);

      // Calculate total labor cost based on hours logged and employee rates
      const employeeMap = new Map(allEmployees.map(e => [e.id, e]));
      let totalLaborCost = 0;
      for (const employeeId of assignedEmployeeIds) {
        const emp = employeeMap.get(employeeId);
        if (!emp) continue;
        const dailyRate = parseFloat(String(emp.baseRate)) || 0;
        const hourlyRate = emp.rateType === "monthly" ? dailyRate / 22 / 8 : dailyRate / 8;

        const empLogs = projectAttendance.filter(log => log.employeeId === employeeId);
        for (const log of empLogs) {
          const regularHours = (log.regularMinutes || 0) / 60;
          totalLaborCost += hourlyRate * regularHours;

          if (log.otStatus === "Approved") {
            const otHours = parseFloat(log.overtimeHours || "0");
            totalLaborCost += hourlyRate * otHours * 1.25;
          }
        }
      }

      // Calculate estimated meal allowance: perHeadRate × unique employees with attendance × their days worked
      const mealAllowanceRate = parseFloat(project.mealAllowance || "0");
      let estimatedMealAllowance = 0;
      if (mealAllowanceRate > 0) {
        for (const employeeId of assignedEmployeeIds) {
          const empLogs = projectAttendance.filter(log => log.employeeId === employeeId);
          estimatedMealAllowance += mealAllowanceRate * empLogs.length;
        }
      }

      return {
        ...project,
        taskCount,
        completedTasks,
        progress,
        totalApprovedExpenses: parseFloat(totalApprovedExpenses.toFixed(2)),
        hoursUsed: parseFloat(hoursUsed.toFixed(2)),
        totalLaborCost: parseFloat(totalLaborCost.toFixed(2)),
        estimatedMealAllowance: parseFloat(estimatedMealAllowance.toFixed(2)),
      };
    });

    res.json(enrichedProjects);
  } catch (error) {
    logger.error("Error fetching projects:", error);
    res.status(500).json({ message: "Failed to fetch projects" });
  }
});

router.get("/:id", isAuthenticated, async (req, res) => {
  try {
    const project = await storage.getProject(req.params.id);
    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }
    res.json(project);
  } catch (error) {
    logger.error("Error fetching project:", error);
    res.status(500).json({ message: "Failed to fetch project" });
  }
});

router.get("/:id/details", isAuthenticated, async (req, res) => {
  try {
    const [project, assignments, tasks, expenses, allAttendance] = await Promise.all([
      storage.getProject(req.params.id),
      storage.getProjectAssignments(req.params.id),
      storage.getTasks(req.params.id),
      storage.getExpenses(req.params.id),
      storage.getAttendanceLogs(),
    ]);

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const assignedEmployeeIds = assignments.map(a => a.employeeId);
    const employees = await storage.getEmployees();
    const assignedEmployees = employees.filter(e => assignedEmployeeIds.includes(e.id));

    // Filter attendance logs by assigned employees and project date range
    // Use date strings (YYYY-MM-DD) for comparison to avoid timezone issues
    const projectStartDateStr = project.startDate || null;
    const projectEndDateStr = project.deadline || null;

    const projectAttendance = allAttendance.filter(log => {
      // Must be an assigned employee
      if (!assignedEmployeeIds.includes(log.employeeId)) {
        return false;
      }

      // Must have totalHours (completed attendance)
      if (!log.totalHours) {
        return false;
      }

      // Must have project date range defined
      if (!projectStartDateStr || !projectEndDateStr) {
        return false;
      }

      // Extract local date portion (YYYY-MM-DD) from timeIn timestamp
      const logTime = new Date(log.timeIn);
      const logDateStr = `${logTime.getFullYear()}-${String(logTime.getMonth() + 1).padStart(2, '0')}-${String(logTime.getDate()).padStart(2, '0')}`;
      return logDateStr >= projectStartDateStr && logDateStr <= projectEndDateStr;
    });

    // Calculate total hours: regular shift hours + approved OT hours
    const hoursUsed = projectAttendance.reduce((sum, log) => {
      const regularHours = (log.regularMinutes || 0) / 60;
      const approvedOtHours = log.otStatus === "Approved"
        ? parseFloat(log.overtimeHours || "0")
        : 0;
      return sum + regularHours + approvedOtHours;
    }, 0);
    const allocatedHours = parseFloat(project.allocatedHours || "0");
    const hoursPercentage = allocatedHours > 0
      ? Math.round((hoursUsed / allocatedHours) * 100)
      : 0;

    // Calculate total labor cost based on hours logged and employee rates
    let totalLaborCost = 0;
    for (const emp of assignedEmployees) {
      const dailyRate = parseFloat(String(emp.baseRate)) || 0;
      const hourlyRate = emp.rateType === "monthly" ? dailyRate / 22 / 8 : dailyRate / 8;

      const empLogs = projectAttendance.filter(log => log.employeeId === emp.id);
      for (const log of empLogs) {
        const regularHours = (log.regularMinutes || 0) / 60;
        totalLaborCost += hourlyRate * regularHours;

        if (log.otStatus === "Approved") {
          const otHours = parseFloat(log.overtimeHours || "0");
          totalLaborCost += hourlyRate * otHours * 1.25;
        }
      }
    }

    // Calculate estimated meal allowance for this project
    const mealAllowanceRate = parseFloat(project.mealAllowance || "0");
    let estimatedMealAllowance = 0;
    if (mealAllowanceRate > 0) {
      for (const emp of assignedEmployees) {
        const empLogs = projectAttendance.filter(log => log.employeeId === emp.id);
        estimatedMealAllowance += mealAllowanceRate * empLogs.length;
      }
    }

    res.json({
      project,
      assignments: assignments.map(a => ({
        ...a,
        employee: assignedEmployees.find(e => e.id === a.employeeId),
      })),
      tasks,
      expenses,
      taskStats: {
        total: tasks.length,
        todo: tasks.filter(t => t.status === "Todo").length,
        inProgress: tasks.filter(t => t.status === "In_Progress").length,
        blocked: tasks.filter(t => t.status === "Blocked").length,
        done: tasks.filter(t => t.status === "Done").length,
        progress: tasks.length > 0
          ? Math.round((tasks.filter(t => t.status === "Done").length / tasks.length) * 100)
          : 0,
      },
      hoursStats: {
        used: parseFloat(hoursUsed.toFixed(2)),
        allocated: allocatedHours,
        percentage: hoursPercentage,
      },
      totalLaborCost: parseFloat(totalLaborCost.toFixed(2)),
      estimatedMealAllowance: parseFloat(estimatedMealAllowance.toFixed(2)),
    });
  } catch (error) {
    logger.error("Error fetching project details:", error);
    res.status(500).json({ message: "Failed to fetch project details" });
  }
});

router.post("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR", "ENGINEER"], "projects.view", "projects.manage"), async (req, res) => {
  try {
    const sanitizedBody = sanitizeOptionalFields(req.body, OPTIONAL_PROJECT_FIELDS);
    const validatedData = insertProjectSchema.parse(sanitizedBody);
    
    if (validatedData.isOffice) {
      if (validatedData.deadline) {
        return res.status(400).json({ message: "Office locations cannot have a deadline" });
      }
      if (validatedData.status === "Completed" || validatedData.status === "Cancelled") {
        return res.status(400).json({ message: "Office locations cannot be marked as Completed or Cancelled" });
      }
      validatedData.deadline = null;
    }
    
    const project = await storage.createProject(validatedData);
    res.status(201).json(project);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error creating project:", error);
    res.status(500).json({ message: "Failed to create project" });
  }
});

router.patch("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR", "ENGINEER"], "projects.view", "projects.manage"), async (req, res) => {
  try {
    const sanitizedBody = sanitizeOptionalFields(req.body, OPTIONAL_PROJECT_FIELDS);
    const partialProjectSchema = insertProjectSchema.partial();
    const validatedData = partialProjectSchema.parse(sanitizedBody);
    
    const existingProject = await storage.getProject(req.params.id);
    if (!existingProject) {
      return res.status(404).json({ message: "Project not found" });
    }
    
    const isOffice = validatedData.isOffice ?? existingProject.isOffice;
    if (isOffice) {
      if (validatedData.deadline) {
        return res.status(400).json({ message: "Office locations cannot have a deadline" });
      }
      if (validatedData.status === "Completed" || validatedData.status === "Cancelled") {
        return res.status(400).json({ message: "Office locations cannot be marked as Completed or Cancelled" });
      }
      if (validatedData.isOffice && !existingProject.isOffice) {
        validatedData.deadline = null;
      }
    }
    
    const project = await storage.updateProject(req.params.id, validatedData);
    if (validatedData.status && validatedData.status !== existingProject.status) {
      (async () => {
        const assignments = await storage.getProjectAssignments(req.params.id);
        const assigneeIds = assignments.map(a => a.employeeId);
        await notifyProjectStatusChanged({
          projectId: req.params.id,
          projectName: existingProject.name,
          newStatus: validatedData.status!,
          changedBy: req.session.user?.employeeId || "",
          assigneeIds,
        });
      })().catch(() => {});
    }
    res.json(project);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error updating project:", error);
    res.status(500).json({ message: "Failed to update project" });
  }
});

router.delete("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "projects.manage"), async (req, res) => {
  try {
    await storage.deleteProject(req.params.id);
    res.status(204).send();
  } catch (error) {
    logger.error("Error deleting project:", error);
    res.status(500).json({ message: "Failed to delete project" });
  }
});

router.post("/:id/assignments", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR", "ENGINEER"], "projects.view", "projects.manage"), async (req, res) => {
  try {
    const validatedData = insertProjectAssignmentSchema.parse({
      ...req.body,
      projectId: req.params.id,
    });
    const assignment = await storage.createProjectAssignment(validatedData);
    (async () => {
      const proj = await storage.getProject(assignment.projectId);
      await notifyProjectAssignment({
        employeeId: assignment.employeeId,
        assignedBy: req.session.user?.employeeId || "",
        projectName: proj?.name || "Unknown Project",
        projectId: assignment.projectId,
      });
    })().catch(() => {});
    res.status(201).json(assignment);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error creating assignment:", error);
    res.status(500).json({ message: "Failed to create assignment" });
  }
});

router.delete("/:projectId/assignments/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "projects.manage"), async (req, res) => {
  try {
    await storage.deleteProjectAssignment(req.params.id);
    res.status(204).send();
  } catch (error) {
    logger.error("Error deleting assignment:", error);
    res.status(500).json({ message: "Failed to delete assignment" });
  }
});

// ==================== PROJECT COMMENTS ====================

// Get all comments for a project
router.get("/:id/comments", isAuthenticated, async (req, res) => {
  try {
    const project = await storage.getProject(req.params.id);
    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const comments = await storage.getProjectComments(req.params.id);
    res.json(comments);
  } catch (error) {
    logger.error("Error fetching project comments:", error);
    res.status(500).json({ message: "Failed to fetch comments" });
  }
});

// Add a comment to a project (only assigned employees or project manager can comment)
router.post("/:id/comments", isAuthenticated, async (req, res) => {
  try {
    const project = await storage.getProject(req.params.id);
    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const user = req.session.user as any;
    if (!user?.employeeId) {
      return res.status(401).json({ message: "User not authenticated" });
    }

    // Check if user is assigned to the project or is the project manager
    const isAssigned = await storage.isEmployeeAssignedToProject(req.params.id, user.employeeId);
    if (!isAssigned) {
      return res.status(403).json({ message: "Only assigned team members can comment on this project" });
    }

    // Note: Attachment uploads can be added later with proper storage support
    const attachments = req.body.attachments || null;

    const validatedData = insertProjectCommentSchema.parse({
      projectId: req.params.id,
      authorId: user.employeeId,
      content: req.body.content,
      attachments,
    });

    const comment = await storage.createProjectComment(validatedData);

    // Fire-and-forget: notify project members of new comment
    (async () => {
      const proj = await storage.getProject(req.params.id);
      const author = await storage.getEmployee(user.employeeId);
      const authorName = author ? `${author.firstName} ${author.lastName}` : "Unknown";
      const assignments = await storage.getProjectAssignments(req.params.id);
      const recipientIds = assignments.map(a => a.employeeId).filter(id => id !== user.employeeId);
      await notifyProjectComment({
        projectId: req.params.id,
        projectName: proj?.name || "Unknown Project",
        commentBy: user.employeeId,
        commentByName: authorName,
        recipientIds,
      });
    })().catch(() => {});
    res.status(201).json(comment);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error creating project comment:", error);
    res.status(500).json({ message: "Failed to create comment" });
  }
});

// Delete a project comment (only the author or admin can delete)
router.delete("/:projectId/comments/:commentId", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user as any;
    if (!user?.employeeId) {
      return res.status(401).json({ message: "User not authenticated" });
    }

    // Get the comment to verify ownership
    const comments = await storage.getProjectComments(req.params.projectId);
    const comment = comments.find(c => c.id === req.params.commentId);

    if (!comment) {
      return res.status(404).json({ message: "Comment not found" });
    }

    // Check if user is the author or has admin role
    const employee = await storage.getEmployee(user.employeeId);
    const isAdmin = employee?.role === "ADMIN" || employee?.role === "HR";
    const isAuthor = comment.authorId === user.employeeId;

    if (!isAuthor && !isAdmin) {
      return res.status(403).json({ message: "You can only delete your own comments" });
    }

    await storage.deleteProjectComment(req.params.commentId);
    res.status(204).send();
  } catch (error) {
    logger.error("Error deleting project comment:", error);
    res.status(500).json({ message: "Failed to delete comment" });
  }
});

// Get project stats (KPIs for project details modal)
router.get("/:id/stats", isAuthenticated, async (req, res) => {
  try {
    const project = await storage.getProject(req.params.id);
    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const stats = await storage.getProjectStats(req.params.id);
    res.json(stats);
  } catch (error) {
    logger.error("Error fetching project stats:", error);
    res.status(500).json({ message: "Failed to fetch project stats" });
  }
});

export default router;
