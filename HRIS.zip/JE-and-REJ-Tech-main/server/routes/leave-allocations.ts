import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { insertEmployeeLeaveAllocationSchema, type LeaveAccrualMode } from "@shared/schema";
import { z } from "zod";
import logger from "../utils/logger";

const router = Router();

// Helper to calculate prorated allocation based on hire date
function calculateProratedAllocation(annualAmount: number, hireDate: Date, year: number): number {
  const yearStart = new Date(year, 0, 1);
  const yearEnd = new Date(year, 11, 31);

  // If hired before this year, full allocation
  if (hireDate < yearStart) {
    return annualAmount;
  }

  // If hired after this year ends, no allocation
  if (hireDate > yearEnd) {
    return 0;
  }

  // Calculate remaining months in the year from hire date
  const hireMonth = hireDate.getMonth(); // 0-11
  const remainingMonths = 12 - hireMonth;
  const monthlyRate = annualAmount / 12;

  return Math.round(monthlyRate * remainingMonths * 10) / 10;
}

// Helper to calculate accrued amount for monthly accrual mode
function calculateAccruedAmount(annualAmount: number, throughMonth: number, hireDate: Date, year: number): number {
  const yearStart = new Date(year, 0, 1);

  // Determine start month for accrual
  let startMonth = 0; // January
  if (hireDate >= yearStart && hireDate.getFullYear() === year) {
    startMonth = hireDate.getMonth();
  }

  // Calculate accrued months (inclusive)
  const accruedMonths = Math.max(0, throughMonth - startMonth + 1);
  const monthlyRate = annualAmount / 12;

  return Math.round(monthlyRate * accruedMonths * 10) / 10;
}

// Get all leave allocations (filterable by employee and year)
router.get("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "leave.manage_allocations"), async (req, res) => {
  try {
    const { employeeId, year } = req.query;
    const allocations = await storage.getEmployeeLeaveAllocations(
      employeeId as string | undefined,
      year ? parseInt(year as string) : undefined
    );
    res.json(allocations);
  } catch (error) {
    logger.error("Error fetching leave allocations:", error);
    res.status(500).json({ message: "Failed to fetch leave allocations" });
  }
});

// Create leave allocation
router.post("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "leave.manage_allocations"), async (req, res) => {
  try {
    const validated = insertEmployeeLeaveAllocationSchema.parse(req.body);

    // Calculate remaining based on total and used
    const totalAllocated = parseFloat(String(validated.totalAllocated));
    const used = parseFloat(String(validated.used || 0));
    const remaining = totalAllocated - used;

    const allocation = await storage.createEmployeeLeaveAllocation({
      ...validated,
      remaining: remaining.toString(),
    });

    res.status(201).json(allocation);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error creating leave allocation:", error);
    res.status(500).json({ message: "Failed to create leave allocation" });
  }
});

// Update leave allocation
router.patch("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "leave.manage_allocations"), async (req, res) => {
  try {
    const updates = req.body;

    // Recalculate remaining if total or used changed
    if (updates.totalAllocated !== undefined || updates.used !== undefined) {
      const allAllocations = await storage.getEmployeeLeaveAllocations();
      const current = allAllocations.find(a => a.id === req.params.id);

      if (current) {
        const newTotal = updates.totalAllocated !== undefined
          ? parseFloat(String(updates.totalAllocated))
          : parseFloat(String(current.totalAllocated));
        const newUsed = updates.used !== undefined
          ? parseFloat(String(updates.used))
          : parseFloat(String(current.used));

        updates.remaining = (newTotal - newUsed).toString();
      }
    }

    const allocation = await storage.updateEmployeeLeaveAllocation(req.params.id, updates);
    if (!allocation) {
      return res.status(404).json({ message: "Leave allocation not found" });
    }
    res.json(allocation);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error updating leave allocation:", error);
    res.status(500).json({ message: "Failed to update leave allocation" });
  }
});

// Delete leave allocation
router.delete("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "leave.manage_allocations"), async (req, res) => {
  try {
    await storage.deleteEmployeeLeaveAllocation(req.params.id);
    res.status(204).send();
  } catch (error) {
    logger.error("Error deleting leave allocation:", error);
    res.status(500).json({ message: "Failed to delete leave allocation" });
  }
});

// Bulk allocate leave to all active employees for a year
router.post("/bulk-allocate", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "leave.manage_allocations"), async (req, res) => {
  try {
    const { year, leaveTypeIds, proRateNewHires } = req.body;

    if (!year) {
      return res.status(400).json({ message: "Year is required" });
    }

    const targetYear = parseInt(year);
    const employees = await storage.getEmployees();
    const activeEmployees = employees.filter(e => e.status === "Active");
    const leaveTypes = await storage.getLeaveTypes();
    const activeLeaveTypes = leaveTypes.filter(lt => lt.isActive);

    // Filter leave types if specific ones are requested
    const typesToAllocate = leaveTypeIds?.length
      ? activeLeaveTypes.filter(lt => leaveTypeIds.includes(lt.id))
      : activeLeaveTypes;

    const existingAllocations = await storage.getEmployeeLeaveAllocations(undefined, targetYear);
    const results = {
      created: 0,
      skipped: 0,
      errors: 0,
    };

    for (const employee of activeEmployees) {
      const hireDate = employee.startDate ? new Date(employee.startDate) : new Date(targetYear, 0, 1);

      for (const leaveType of typesToAllocate) {
        // Skip if allocation already exists
        const existing = existingAllocations.find(
          a => a.employeeId === employee.id && a.leaveTypeId === leaveType.id
        );

        if (existing) {
          results.skipped++;
          continue;
        }

        try {
          const annualAllocation = leaveType.annualAllocation || 0;
          const accrualMode = (leaveType.accrualMode || "annual") as LeaveAccrualMode;

          // Calculate total allocation (prorated if requested)
          let totalAllocated = annualAllocation;
          if (proRateNewHires && hireDate.getFullYear() === targetYear) {
            totalAllocated = calculateProratedAllocation(annualAllocation, hireDate, targetYear);
          }

          // Calculate accrued amount based on mode
          let accruedToDate: number;
          const currentMonth = new Date().getMonth(); // 0-11
          const isCurrentYear = targetYear === new Date().getFullYear();

          if (accrualMode === "annual") {
            // Annual mode: full amount available immediately
            accruedToDate = totalAllocated;
          } else if (accrualMode === "monthly") {
            // Monthly mode: calculate based on completed months
            const throughMonth = isCurrentYear ? currentMonth : 11;
            accruedToDate = calculateAccruedAmount(totalAllocated, throughMonth, hireDate, targetYear);
          } else {
            // None mode: manual allocation only (for special cases like Birthday leave)
            accruedToDate = 0;
          }

          await storage.createEmployeeLeaveAllocation({
            employeeId: employee.id,
            leaveTypeId: leaveType.id,
            year: targetYear,
            totalAllocated: totalAllocated.toString(),
            accruedToDate: accruedToDate.toString(),
            used: "0",
            remaining: accruedToDate.toString(),
            carriedOver: "0",
            lastAccrualMonth: accrualMode === "monthly" && isCurrentYear ? currentMonth : null,
          });

          results.created++;
        } catch (error) {
          logger.error(`Error creating allocation for employee ${employee.id}:`, error);
          results.errors++;
        }
      }
    }

    res.json({
      message: `Bulk allocation complete for ${targetYear}`,
      results,
    });
  } catch (error) {
    logger.error("Error in bulk allocation:", error);
    res.status(500).json({ message: "Failed to perform bulk allocation" });
  }
});

// Process monthly accruals for all employees
router.post("/process-accruals", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "leave.manage_allocations"), async (req, res) => {
  try {
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth(); // 0-11

    const allocations = await storage.getEmployeeLeaveAllocations(undefined, currentYear);
    const leaveTypes = await storage.getLeaveTypes();
    const employees = await storage.getEmployees();

    const results = {
      processed: 0,
      skipped: 0,
      errors: 0,
    };

    for (const allocation of allocations) {
      const leaveType = leaveTypes.find(lt => lt.id === allocation.leaveTypeId);

      // Only process monthly accrual types
      if (!leaveType || leaveType.accrualMode !== "monthly") {
        results.skipped++;
        continue;
      }

      // Skip if already processed this month
      const lastAccrualMonth = allocation.lastAccrualMonth || -1;
      if (lastAccrualMonth >= currentMonth) {
        results.skipped++;
        continue;
      }

      try {
        const employee = employees.find(e => e.id === allocation.employeeId);
        const hireDate = employee?.startDate ? new Date(employee.startDate) : new Date(currentYear, 0, 1);
        const totalAllocated = parseFloat(allocation.totalAllocated);

        // Calculate new accrued amount
        const newAccruedAmount = calculateAccruedAmount(totalAllocated, currentMonth, hireDate, currentYear);
        const used = parseFloat(allocation.used || "0");
        const carriedOver = parseFloat(allocation.carriedOver || "0");
        const remaining = Math.max(0, newAccruedAmount + carriedOver - used);

        await storage.updateEmployeeLeaveAllocation(allocation.id, {
          accruedToDate: newAccruedAmount.toString(),
          remaining: remaining.toString(),
          lastAccrualMonth: currentMonth,
        });

        results.processed++;
      } catch (error) {
        logger.error(`Error processing accrual for allocation ${allocation.id}:`, error);
        results.errors++;
      }
    }

    res.json({
      message: `Accrual processing complete for ${currentYear}-${String(currentMonth + 1).padStart(2, "0")}`,
      results,
    });
  } catch (error) {
    logger.error("Error processing accruals:", error);
    res.status(500).json({ message: "Failed to process accruals" });
  }
});

// Process year-end carryover
router.post("/process-carryover", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "leave.manage_allocations"), async (req, res) => {
  try {
    const { fromYear, maxCarryoverDays } = req.body;

    if (!fromYear) {
      return res.status(400).json({ message: "fromYear is required" });
    }

    const sourceYear = parseInt(fromYear);
    const targetYear = sourceYear + 1;
    const maxCarry = maxCarryoverDays ? parseFloat(maxCarryoverDays) : 5; // Default max 5 days carryover

    const sourceAllocations = await storage.getEmployeeLeaveAllocations(undefined, sourceYear);
    const targetAllocations = await storage.getEmployeeLeaveAllocations(undefined, targetYear);
    const leaveTypes = await storage.getLeaveTypes();

    const results = {
      processed: 0,
      skipped: 0,
      errors: 0,
    };

    for (const sourceAlloc of sourceAllocations) {
      const leaveType = leaveTypes.find(lt => lt.id === sourceAlloc.leaveTypeId);

      // Only carryover paid leave types
      if (!leaveType || !leaveType.isPaid) {
        results.skipped++;
        continue;
      }

      try {
        const remaining = parseFloat(sourceAlloc.remaining || "0");
        const carryoverAmount = Math.min(remaining, maxCarry);

        if (carryoverAmount <= 0) {
          results.skipped++;
          continue;
        }

        // Find or create target year allocation
        let targetAlloc = targetAllocations.find(
          a => a.employeeId === sourceAlloc.employeeId && a.leaveTypeId === sourceAlloc.leaveTypeId
        );

        if (targetAlloc) {
          // Update existing allocation with carryover
          const newCarriedOver = parseFloat(targetAlloc.carriedOver || "0") + carryoverAmount;
          const accruedToDate = parseFloat(targetAlloc.accruedToDate || targetAlloc.totalAllocated);
          const used = parseFloat(targetAlloc.used || "0");
          const newRemaining = Math.max(0, accruedToDate + newCarriedOver - used);

          await storage.updateEmployeeLeaveAllocation(targetAlloc.id, {
            carriedOver: newCarriedOver.toString(),
            remaining: newRemaining.toString(),
          });
        } else {
          // Create new allocation with carryover
          const totalAllocated = leaveType.annualAllocation || 0;
          const accrualMode = (leaveType.accrualMode || "annual") as LeaveAccrualMode;
          const accruedToDate = accrualMode === "annual" ? totalAllocated : 0;

          await storage.createEmployeeLeaveAllocation({
            employeeId: sourceAlloc.employeeId,
            leaveTypeId: sourceAlloc.leaveTypeId,
            year: targetYear,
            totalAllocated: totalAllocated.toString(),
            accruedToDate: accruedToDate.toString(),
            used: "0",
            remaining: (accruedToDate + carryoverAmount).toString(),
            carriedOver: carryoverAmount.toString(),
            lastAccrualMonth: accrualMode === "monthly" ? -1 : null,
          });
        }

        results.processed++;
      } catch (error) {
        logger.error(`Error processing carryover for allocation ${sourceAlloc.id}:`, error);
        results.errors++;
      }
    }

    res.json({
      message: `Carryover from ${sourceYear} to ${targetYear} complete (max ${maxCarry} days)`,
      results,
    });
  } catch (error) {
    logger.error("Error processing carryover:", error);
    res.status(500).json({ message: "Failed to process carryover" });
  }
});

export default router;
