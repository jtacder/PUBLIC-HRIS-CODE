/**
 * Tests for Expenses Route
 *
 * Tests all expense-related endpoints including:
 * - CRUD operations
 * - Approval/Rejection workflow
 * - Reimbursement process
 * - Role-based access control
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { Expense } from '@shared/schema';

// Mock storage
const mockStorage = {
  getExpenses: vi.fn(),
  getExpense: vi.fn(),
  createExpense: vi.fn(),
  updateExpense: vi.fn(),
};

vi.mock('../storage', () => ({
  storage: mockStorage,
}));

// Test fixtures
const mockExpense: Expense = {
  id: 'exp-001',
  projectId: 'proj-001',
  submittedById: 'emp-001',
  category: 'Materials',
  description: 'Electrical wires and conduits',
  amount: '5000',
  receiptUrl: 'https://storage.com/receipt001.jpg',
  expenseDate: '2025-01-15',
  status: 'Pending',
  approvedById: null,
  approvedAt: null,
  rejectionReason: null,
  reimbursedAt: null,
  reimbursementRef: null,
  createdAt: new Date(),
  updatedAt: new Date(),
};

describe('Expenses Route Logic', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('GET /expenses', () => {
    it('should return all expenses', async () => {
      const expenses = [mockExpense];
      mockStorage.getExpenses.mockResolvedValue(expenses);

      const result = await mockStorage.getExpenses();

      expect(result).toHaveLength(1);
    });

    it('should filter by projectId', async () => {
      mockStorage.getExpenses.mockResolvedValue([mockExpense]);

      await mockStorage.getExpenses('proj-001');

      expect(mockStorage.getExpenses).toHaveBeenCalledWith('proj-001');
    });

    it('should filter by status', async () => {
      const pendingExpenses = [mockExpense];
      mockStorage.getExpenses.mockResolvedValue(pendingExpenses);

      await mockStorage.getExpenses(undefined, 'Pending');

      expect(mockStorage.getExpenses).toHaveBeenCalledWith(undefined, 'Pending');
    });

    it('should filter by both projectId and status', async () => {
      mockStorage.getExpenses.mockResolvedValue([mockExpense]);

      await mockStorage.getExpenses('proj-001', 'Pending');

      expect(mockStorage.getExpenses).toHaveBeenCalledWith('proj-001', 'Pending');
    });
  });

  describe('GET /expenses/:id', () => {
    it('should return expense by ID', async () => {
      mockStorage.getExpense.mockResolvedValue(mockExpense);

      const result = await mockStorage.getExpense('exp-001');

      expect(result).toBeDefined();
      expect(result?.id).toBe('exp-001');
    });

    it('should return undefined for non-existent expense', async () => {
      mockStorage.getExpense.mockResolvedValue(undefined);

      const result = await mockStorage.getExpense('non-existent');

      expect(result).toBeUndefined();
    });
  });

  describe('POST /expenses', () => {
    it('should create a new expense (ADMIN/HR/ENGINEER only)', async () => {
      const newExpense = {
        projectId: 'proj-001',
        submittedById: 'emp-001',
        category: 'Tools',
        description: 'Power drill',
        amount: '3500',
        receiptUrl: 'https://storage.com/receipt.jpg',
        expenseDate: '2025-01-20',
      };

      mockStorage.createExpense.mockResolvedValue({
        ...mockExpense,
        ...newExpense,
        id: 'exp-new',
        status: 'Pending',
      });

      const result = await mockStorage.createExpense(newExpense as any);

      expect(result.id).toBe('exp-new');
      expect(result.status).toBe('Pending');
    });

    it('should default status to Pending', async () => {
      mockStorage.createExpense.mockResolvedValue({
        ...mockExpense,
        id: 'exp-new',
        status: 'Pending',
      });

      const result = await mockStorage.createExpense({} as any);

      expect(result.status).toBe('Pending');
    });
  });

  describe('PATCH /expenses/:id/approve', () => {
    it('should approve a pending expense', async () => {
      const approver = { employeeId: 'hr-001' };

      mockStorage.updateExpense.mockResolvedValue({
        ...mockExpense,
        status: 'Approved',
        approvedById: approver.employeeId,
        approvedAt: new Date(),
      });

      const result = await mockStorage.updateExpense('exp-001', {
        status: 'Approved',
        approvedById: approver.employeeId,
        approvedAt: new Date(),
      });

      expect(result?.status).toBe('Approved');
      expect(result?.approvedById).toBe('hr-001');
    });

    it('should set approvedAt timestamp', async () => {
      const approvedAt = new Date();

      mockStorage.updateExpense.mockResolvedValue({
        ...mockExpense,
        status: 'Approved',
        approvedAt,
      });

      const result = await mockStorage.updateExpense('exp-001', {
        status: 'Approved',
        approvedAt,
      });

      expect(result?.approvedAt).toBeDefined();
    });
  });

  describe('PATCH /expenses/:id/reject', () => {
    it('should reject a pending expense', async () => {
      const rejectionReason = 'Receipt not valid';

      mockStorage.updateExpense.mockResolvedValue({
        ...mockExpense,
        status: 'Rejected',
        rejectionReason,
      });

      const result = await mockStorage.updateExpense('exp-001', {
        status: 'Rejected',
        rejectionReason,
      });

      expect(result?.status).toBe('Rejected');
      expect(result?.rejectionReason).toBe(rejectionReason);
    });

    it('should include rejection reason', async () => {
      const rejectionReason = 'Amount exceeds budget';

      mockStorage.updateExpense.mockResolvedValue({
        ...mockExpense,
        status: 'Rejected',
        rejectionReason,
      });

      const result = await mockStorage.updateExpense('exp-001', {
        status: 'Rejected',
        rejectionReason,
      });

      expect(result?.rejectionReason).toBeDefined();
    });
  });

  describe('PATCH /expenses/:id/reimburse', () => {
    it('should reimburse an approved expense', async () => {
      const reimbursementRef = 'CHK-2025-001';

      mockStorage.updateExpense.mockResolvedValue({
        ...mockExpense,
        status: 'Reimbursed',
        reimbursedAt: new Date(),
        reimbursementRef,
      });

      const result = await mockStorage.updateExpense('exp-001', {
        status: 'Reimbursed',
        reimbursedAt: new Date(),
        reimbursementRef,
      });

      expect(result?.status).toBe('Reimbursed');
      expect(result?.reimbursementRef).toBe(reimbursementRef);
    });

    it('should set reimbursedAt timestamp', async () => {
      mockStorage.updateExpense.mockResolvedValue({
        ...mockExpense,
        status: 'Reimbursed',
        reimbursedAt: new Date(),
      });

      const result = await mockStorage.updateExpense('exp-001', {
        status: 'Reimbursed',
        reimbursedAt: new Date(),
      });

      expect(result?.reimbursedAt).toBeDefined();
    });

    it('should allow optional reimbursement reference', async () => {
      mockStorage.updateExpense.mockResolvedValue({
        ...mockExpense,
        status: 'Reimbursed',
        reimbursedAt: new Date(),
        reimbursementRef: null,
      });

      const result = await mockStorage.updateExpense('exp-001', {
        status: 'Reimbursed',
        reimbursedAt: new Date(),
      });

      expect(result?.status).toBe('Reimbursed');
    });
  });
});

describe('Expense Status Workflow', () => {
  it('should follow workflow: Pending -> Approved -> Reimbursed', () => {
    const workflow = ['Pending', 'Approved', 'Reimbursed'];

    expect(workflow[0]).toBe('Pending');
    expect(workflow[1]).toBe('Approved');
    expect(workflow[2]).toBe('Reimbursed');
  });

  it('should allow Pending -> Rejected', () => {
    const validStatuses = ['Pending', 'Approved', 'Rejected', 'Reimbursed'];
    expect(validStatuses).toContain('Rejected');
  });
});

describe('Expense Categories', () => {
  it('should support common expense categories', () => {
    const categories = [
      'Materials',
      'Tools',
      'Equipment',
      'Transportation',
      'Meals',
      'Accommodation',
      'Office Supplies',
      'Utilities',
      'Other',
    ];

    expect(categories).toContain(mockExpense.category);
  });
});

describe('Expense Data Validation', () => {
  it('should have required fields', () => {
    expect(mockExpense.projectId).toBeDefined();
    expect(mockExpense.submittedById).toBeDefined();
    expect(mockExpense.category).toBeDefined();
    expect(mockExpense.amount).toBeDefined();
    expect(mockExpense.expenseDate).toBeDefined();
  });

  it('should have valid status', () => {
    const validStatuses = ['Pending', 'Approved', 'Rejected', 'Reimbursed'];
    expect(validStatuses).toContain(mockExpense.status);
  });

  it('should have positive amount', () => {
    const amount = parseFloat(mockExpense.amount);
    expect(amount).toBeGreaterThan(0);
  });

  it('should have valid date format', () => {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    expect(mockExpense.expenseDate).toMatch(dateRegex);
  });
});

describe('Role-Based Access Control', () => {
  describe('Create access', () => {
    it('ADMIN can create expenses', () => {
      const role = 'ADMIN';
      const canCreate = role === 'ADMIN' || role === 'HR' || role === 'ENGINEER';
      expect(canCreate).toBe(true);
    });

    it('HR can create expenses', () => {
      const role = 'HR';
      const canCreate = role === 'ADMIN' || role === 'HR' || role === 'ENGINEER';
      expect(canCreate).toBe(true);
    });

    it('ENGINEER can create expenses', () => {
      const role = 'ENGINEER';
      const canCreate = role === 'ADMIN' || role === 'HR' || role === 'ENGINEER';
      expect(canCreate).toBe(true);
    });

    it('WORKER cannot create expenses', () => {
      const role = 'WORKER';
      const canCreate = role === 'ADMIN' || role === 'HR' || role === 'ENGINEER';
      expect(canCreate).toBe(false);
    });
  });

  describe('Approval access', () => {
    it('only HR/ADMIN can approve', () => {
      const hrRole = 'HR';
      const canApprove = hrRole === 'ADMIN' || hrRole === 'HR';
      expect(canApprove).toBe(true);
    });

    it('ENGINEER cannot approve', () => {
      const role = 'ENGINEER';
      const canApprove = role === 'ADMIN' || role === 'HR';
      expect(canApprove).toBe(false);
    });
  });

  describe('Reimbursement access', () => {
    it('only HR/ADMIN can mark as reimbursed', () => {
      const adminRole = 'ADMIN';
      const canReimburse = adminRole === 'ADMIN' || adminRole === 'HR';
      expect(canReimburse).toBe(true);
    });
  });
});

describe('Expense Amount Calculations', () => {
  it('should calculate total expenses for a project', () => {
    const expenses = [
      { amount: '5000', status: 'Approved' },
      { amount: '3000', status: 'Approved' },
      { amount: '2000', status: 'Pending' },
    ];

    const approvedTotal = expenses
      .filter(e => e.status === 'Approved')
      .reduce((sum, e) => sum + parseFloat(e.amount), 0);

    expect(approvedTotal).toBe(8000);
  });

  it('should calculate reimbursed total', () => {
    const expenses = [
      { amount: '5000', status: 'Reimbursed' },
      { amount: '3000', status: 'Approved' },
    ];

    const reimbursedTotal = expenses
      .filter(e => e.status === 'Reimbursed')
      .reduce((sum, e) => sum + parseFloat(e.amount), 0);

    expect(reimbursedTotal).toBe(5000);
  });

  it('should calculate pending approval amount', () => {
    const expenses = [
      { amount: '5000', status: 'Pending' },
      { amount: '3000', status: 'Pending' },
    ];

    const pendingTotal = expenses
      .filter(e => e.status === 'Pending')
      .reduce((sum, e) => sum + parseFloat(e.amount), 0);

    expect(pendingTotal).toBe(8000);
  });
});

describe('Receipt URL Handling', () => {
  it('should store receipt URL', () => {
    expect(mockExpense.receiptUrl).toBeDefined();
    expect(mockExpense.receiptUrl).toContain('https://');
  });

  it('should allow null receipt URL', () => {
    const expenseWithoutReceipt = { ...mockExpense, receiptUrl: null };
    expect(expenseWithoutReceipt.receiptUrl).toBeNull();
  });
});

describe('Expense Filtering', () => {
  it('should filter by project', () => {
    const expenses = [
      { ...mockExpense, projectId: 'proj-001' },
      { ...mockExpense, id: 'exp-002', projectId: 'proj-002' },
    ];

    const filtered = expenses.filter(e => e.projectId === 'proj-001');

    expect(filtered).toHaveLength(1);
  });

  it('should filter by status', () => {
    const expenses = [
      { ...mockExpense, status: 'Pending' as const },
      { ...mockExpense, id: 'exp-002', status: 'Approved' as const },
      { ...mockExpense, id: 'exp-003', status: 'Rejected' as const },
    ];

    const pending = expenses.filter(e => e.status === 'Pending');
    const approved = expenses.filter(e => e.status === 'Approved');

    expect(pending).toHaveLength(1);
    expect(approved).toHaveLength(1);
  });

  it('should filter by date range', () => {
    const expenses = [
      { ...mockExpense, expenseDate: '2025-01-10' },
      { ...mockExpense, id: 'exp-002', expenseDate: '2025-01-15' },
      { ...mockExpense, id: 'exp-003', expenseDate: '2025-01-20' },
    ];

    const startDate = new Date('2025-01-12');
    const endDate = new Date('2025-01-18');

    const filtered = expenses.filter(e => {
      const date = new Date(e.expenseDate);
      return date >= startDate && date <= endDate;
    });

    expect(filtered).toHaveLength(1);
    expect(filtered[0].id).toBe('exp-002');
  });

  it('should filter by submitter', () => {
    const expenses = [
      { ...mockExpense, submittedById: 'emp-001' },
      { ...mockExpense, id: 'exp-002', submittedById: 'emp-002' },
    ];

    const filtered = expenses.filter(e => e.submittedById === 'emp-001');

    expect(filtered).toHaveLength(1);
  });
});
