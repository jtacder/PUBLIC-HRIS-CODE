/**
 * Tests for Tasks Route
 *
 * Tests all task-related endpoints including:
 * - CRUD operations
 * - Task filtering by project and assignee
 * - Task comments
 * - Role-based access control
 * - Status transitions
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { Task, TaskComment } from '@shared/schema';

// Mock storage
const mockStorage = {
  getTasks: vi.fn(),
  getTask: vi.fn(),
  createTask: vi.fn(),
  updateTask: vi.fn(),
  deleteTask: vi.fn(),
  getEmployeeTasks: vi.fn(),
  getTaskComments: vi.fn(),
  createTaskComment: vi.fn(),
};

vi.mock('../storage', () => ({
  storage: mockStorage,
}));

// Test fixtures
const mockTask: Task = {
  id: 'task-001',
  projectId: 'proj-001',
  title: 'Install main electrical panel',
  description: 'Install 200A main electrical panel in utility room',
  status: 'Todo',
  priority: 'High',
  assignedToId: 'emp-001',
  dueDate: '2025-02-15',
  completedDate: null,
  estimatedHours: '16',
  actualHours: null,
  createdAt: new Date(),
  updatedAt: new Date(),
};

const mockComment: TaskComment = {
  id: 'comment-001',
  taskId: 'task-001',
  userId: 'user-001',
  content: 'Started working on this task',
  createdAt: new Date(),
};

describe('Tasks Route Logic', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('GET /tasks', () => {
    it('should return all tasks', async () => {
      const tasks = [mockTask];
      mockStorage.getTasks.mockResolvedValue(tasks);

      const result = await mockStorage.getTasks();

      expect(result).toHaveLength(1);
      expect(result[0].title).toBe('Install main electrical panel');
    });

    it('should filter tasks by projectId', async () => {
      const projectTasks = [mockTask];
      mockStorage.getTasks.mockResolvedValue(projectTasks);

      const result = await mockStorage.getTasks('proj-001');

      expect(mockStorage.getTasks).toHaveBeenCalledWith('proj-001');
    });

    it('should filter tasks by assignedToId', async () => {
      const employeeTasks = [mockTask, { ...mockTask, id: 'task-002', title: 'Second task' }];
      mockStorage.getEmployeeTasks.mockResolvedValue(employeeTasks);

      const result = await mockStorage.getEmployeeTasks('emp-001');

      expect(result).toHaveLength(2);
    });

    it('should return empty array when no tasks exist', async () => {
      mockStorage.getTasks.mockResolvedValue([]);

      const result = await mockStorage.getTasks();

      expect(result).toHaveLength(0);
    });
  });

  describe('GET /tasks/:id', () => {
    it('should return task with comments', async () => {
      const comments = [mockComment];
      mockStorage.getTask.mockResolvedValue(mockTask);
      mockStorage.getTaskComments.mockResolvedValue(comments);

      const [task, taskComments] = await Promise.all([
        mockStorage.getTask('task-001'),
        mockStorage.getTaskComments('task-001'),
      ]);

      expect(task).toBeDefined();
      expect(task?.id).toBe('task-001');
      expect(taskComments).toHaveLength(1);
    });

    it('should return undefined for non-existent task', async () => {
      mockStorage.getTask.mockResolvedValue(undefined);

      const result = await mockStorage.getTask('non-existent');

      expect(result).toBeUndefined();
    });
  });

  describe('POST /tasks', () => {
    it('should create a new task', async () => {
      const newTask = {
        projectId: 'proj-001',
        title: 'New Task',
        status: 'Todo',
        priority: 'Medium',
      };

      mockStorage.createTask.mockResolvedValue({
        ...mockTask,
        ...newTask,
        id: 'task-new',
      });

      const result = await mockStorage.createTask(newTask as any);

      expect(result.id).toBe('task-new');
      expect(result.title).toBe('New Task');
    });

    it('should set default status to Todo', async () => {
      const newTask = {
        projectId: 'proj-001',
        title: 'New Task',
        priority: 'Medium',
      };

      mockStorage.createTask.mockResolvedValue({
        ...mockTask,
        ...newTask,
        id: 'task-new',
        status: 'Todo',
      });

      const result = await mockStorage.createTask(newTask as any);

      expect(result.status).toBe('Todo');
    });
  });

  describe('PATCH /tasks/:id', () => {
    describe('Admin/HR/Engineer role', () => {
      it('should allow updating any task', async () => {
        const updates = { title: 'Updated Title' };
        mockStorage.updateTask.mockResolvedValue({ ...mockTask, ...updates });

        const result = await mockStorage.updateTask('task-001', updates);

        expect(result?.title).toBe('Updated Title');
      });

      it('should allow changing task assignment', async () => {
        const updates = { assignedToId: 'emp-002' };
        mockStorage.updateTask.mockResolvedValue({ ...mockTask, ...updates });

        const result = await mockStorage.updateTask('task-001', updates);

        expect(result?.assignedToId).toBe('emp-002');
      });
    });

    describe('Worker role', () => {
      it('should only allow updating tasks assigned to them', async () => {
        const mockSession = {
          user: {
            role: 'WORKER',
            employeeId: 'emp-001',
          },
        };

        // Task is assigned to emp-001
        const existingTask = { ...mockTask, assignedToId: 'emp-001' };

        // Worker can update their own task
        expect(existingTask.assignedToId).toBe(mockSession.user.employeeId);
      });

      it('should block updating tasks not assigned to them', async () => {
        const mockSession = {
          user: {
            role: 'WORKER',
            employeeId: 'emp-002',
          },
        };

        // Task is assigned to emp-001
        const existingTask = { ...mockTask, assignedToId: 'emp-001' };

        // Worker cannot update another worker's task
        expect(existingTask.assignedToId).not.toBe(mockSession.user.employeeId);
      });
    });

    it('should set completedDate when status changes to Done', async () => {
      const updates = { status: 'Done' as const };
      const today = new Date().toISOString().slice(0, 10);

      // When status is Done, completedDate should be set
      if (updates.status === 'Done') {
        const completedDate = today;
        expect(completedDate).toBe(today);
      }
    });

    it('should return undefined for non-existent task', async () => {
      mockStorage.updateTask.mockResolvedValue(undefined);

      const result = await mockStorage.updateTask('non-existent', { title: 'Test' });

      expect(result).toBeUndefined();
    });
  });

  describe('DELETE /tasks/:id', () => {
    it('should delete a task', async () => {
      mockStorage.deleteTask.mockResolvedValue(undefined);

      await mockStorage.deleteTask('task-001');

      expect(mockStorage.deleteTask).toHaveBeenCalledWith('task-001');
    });
  });

  describe('POST /tasks/:id/comments', () => {
    it('should create a new comment', async () => {
      const newComment = {
        taskId: 'task-001',
        userId: 'user-001',
        content: 'Progress update: 50% complete',
      };

      mockStorage.createTaskComment.mockResolvedValue({
        ...mockComment,
        ...newComment,
        id: 'comment-new',
      });

      const result = await mockStorage.createTaskComment(newComment as any);

      expect(result.id).toBe('comment-new');
      expect(result.content).toBe('Progress update: 50% complete');
    });

    it('should associate comment with correct task', async () => {
      const newComment = {
        taskId: 'task-001',
        userId: 'user-001',
        content: 'Test comment',
      };

      mockStorage.createTaskComment.mockResolvedValue({
        ...mockComment,
        ...newComment,
      });

      const result = await mockStorage.createTaskComment(newComment as any);

      expect(result.taskId).toBe('task-001');
    });
  });
});

describe('Task Data Validation', () => {
  it('should have required fields', () => {
    expect(mockTask.title).toBeDefined();
    expect(mockTask.projectId).toBeDefined();
    expect(mockTask.status).toBeDefined();
  });

  it('should have valid status', () => {
    const validStatuses = ['Todo', 'In_Progress', 'Blocked', 'Done'];
    expect(validStatuses).toContain(mockTask.status);
  });

  it('should have valid priority', () => {
    const validPriorities = ['Low', 'Medium', 'High', 'Urgent'];
    expect(validPriorities).toContain(mockTask.priority);
  });
});

describe('Task Status Transitions', () => {
  it('should allow Todo -> In_Progress', () => {
    const task = { ...mockTask, status: 'Todo' };
    const newStatus = 'In_Progress';

    // Valid transition
    expect(task.status).toBe('Todo');
    expect(newStatus).toBe('In_Progress');
  });

  it('should allow In_Progress -> Done', () => {
    const task = { ...mockTask, status: 'In_Progress' };
    const newStatus = 'Done';

    expect(task.status).toBe('In_Progress');
    expect(newStatus).toBe('Done');
  });

  it('should allow In_Progress -> Blocked', () => {
    const task = { ...mockTask, status: 'In_Progress' };
    const newStatus = 'Blocked';

    expect(task.status).toBe('In_Progress');
    expect(newStatus).toBe('Blocked');
  });

  it('should allow Blocked -> In_Progress', () => {
    const task = { ...mockTask, status: 'Blocked' };
    const newStatus = 'In_Progress';

    expect(task.status).toBe('Blocked');
    expect(newStatus).toBe('In_Progress');
  });

  it('should set completedDate when transitioning to Done', () => {
    const task = { ...mockTask, status: 'In_Progress', completedDate: null };
    const newStatus = 'Done';
    const today = new Date().toISOString().slice(0, 10);

    if (newStatus === 'Done') {
      const completedDate = today;
      expect(completedDate).toBeDefined();
      expect(completedDate).toBe(today);
    }
  });
});

describe('Task Filtering Logic', () => {
  it('should filter by project', () => {
    const tasks = [
      { ...mockTask, projectId: 'proj-001' },
      { ...mockTask, id: 'task-002', projectId: 'proj-002' },
      { ...mockTask, id: 'task-003', projectId: 'proj-001' },
    ];

    const filtered = tasks.filter(t => t.projectId === 'proj-001');

    expect(filtered).toHaveLength(2);
  });

  it('should filter by assignee', () => {
    const tasks = [
      { ...mockTask, assignedToId: 'emp-001' },
      { ...mockTask, id: 'task-002', assignedToId: 'emp-002' },
      { ...mockTask, id: 'task-003', assignedToId: 'emp-001' },
    ];

    const filtered = tasks.filter(t => t.assignedToId === 'emp-001');

    expect(filtered).toHaveLength(2);
  });

  it('should filter by status', () => {
    const tasks = [
      { ...mockTask, status: 'Todo' as const },
      { ...mockTask, id: 'task-002', status: 'Done' as const },
      { ...mockTask, id: 'task-003', status: 'In_Progress' as const },
    ];

    const todoTasks = tasks.filter(t => t.status === 'Todo');
    const doneTasks = tasks.filter(t => t.status === 'Done');

    expect(todoTasks).toHaveLength(1);
    expect(doneTasks).toHaveLength(1);
  });

  it('should filter by priority', () => {
    const tasks = [
      { ...mockTask, priority: 'High' as const },
      { ...mockTask, id: 'task-002', priority: 'Low' as const },
      { ...mockTask, id: 'task-003', priority: 'Urgent' as const },
    ];

    const urgentTasks = tasks.filter(t => t.priority === 'Urgent');
    const highTasks = tasks.filter(t => t.priority === 'High');

    expect(urgentTasks).toHaveLength(1);
    expect(highTasks).toHaveLength(1);
  });
});

describe('Task Assignment Security', () => {
  it('ADMIN can update any task', () => {
    const role = 'ADMIN';
    const isAdminOrHR = role === 'ADMIN' || role === 'HR' || role === 'ENGINEER';

    expect(isAdminOrHR).toBe(true);
  });

  it('HR can update any task', () => {
    const role = 'HR';
    const isAdminOrHR = role === 'ADMIN' || role === 'HR' || role === 'ENGINEER';

    expect(isAdminOrHR).toBe(true);
  });

  it('ENGINEER can update any task', () => {
    const role = 'ENGINEER';
    const isAdminOrHR = role === 'ADMIN' || role === 'HR' || role === 'ENGINEER';

    expect(isAdminOrHR).toBe(true);
  });

  it('WORKER can only update assigned tasks', () => {
    const role = 'WORKER';
    const isAdminOrHR = role === 'ADMIN' || role === 'HR' || role === 'ENGINEER';
    const taskAssignedToId = 'emp-001';
    const workerEmployeeId = 'emp-001';

    expect(isAdminOrHR).toBe(false);
    // Worker must be assigned to the task
    expect(taskAssignedToId).toBe(workerEmployeeId);
  });

  it('WORKER cannot update unassigned tasks', () => {
    const role = 'WORKER';
    const isAdminOrHR = role === 'ADMIN' || role === 'HR' || role === 'ENGINEER';
    const taskAssignedToId = 'emp-001';
    const workerEmployeeId = 'emp-002';

    expect(isAdminOrHR).toBe(false);
    expect(taskAssignedToId).not.toBe(workerEmployeeId);
  });
});

describe('Task Comments', () => {
  it('should get comments for a task', async () => {
    const comments = [
      mockComment,
      { ...mockComment, id: 'comment-002', content: 'Second comment' },
    ];
    mockStorage.getTaskComments.mockResolvedValue(comments);

    const result = await mockStorage.getTaskComments('task-001');

    expect(result).toHaveLength(2);
  });

  it('should return empty array when no comments exist', async () => {
    mockStorage.getTaskComments.mockResolvedValue([]);

    const result = await mockStorage.getTaskComments('task-001');

    expect(result).toHaveLength(0);
  });

  it('should associate comment with user', () => {
    expect(mockComment.userId).toBeDefined();
    expect(mockComment.userId).toBe('user-001');
  });

  it('should have content', () => {
    expect(mockComment.content).toBeDefined();
    expect(mockComment.content.length).toBeGreaterThan(0);
  });

  it('should have createdAt timestamp', () => {
    expect(mockComment.createdAt).toBeDefined();
    expect(mockComment.createdAt).toBeInstanceOf(Date);
  });
});

describe('Task Hours Tracking', () => {
  it('should have estimated hours', () => {
    expect(mockTask.estimatedHours).toBe('16');
  });

  it('should track actual hours', () => {
    const taskWithActual = { ...mockTask, actualHours: '18' };

    expect(taskWithActual.actualHours).toBe('18');
  });

  it('should handle null actual hours', () => {
    expect(mockTask.actualHours).toBeNull();
  });

  it('should calculate hours variance', () => {
    const estimated = parseFloat('16');
    const actual = parseFloat('18');
    const variance = actual - estimated;

    expect(variance).toBe(2); // 2 hours over estimate
  });
});
