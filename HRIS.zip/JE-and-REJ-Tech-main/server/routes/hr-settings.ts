import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import logger from "../utils/logger";
import {
  insertPayrollCutoffSchema,
  insertLeaveTypeSchema,
  insertLeaveRequestSchema,
  insertHolidaySchema,
  insertCashAdvanceSchema,
  insertCompanySettingSchema,
} from "@shared/schema";

const router = Router();

router.get("/payroll-cutoffs", isAuthenticated, async (req, res) => {
  try {
    const cutoffs = await storage.getPayrollCutoffs();
    res.json(cutoffs);
  } catch (error) {
    logger.error("Error fetching payroll cutoffs:", error);
    res.status(500).json({ message: "Failed to fetch payroll cutoffs" });
  }
});

router.post("/payroll-cutoffs", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "hr_settings.manage_cutoffs"), async (req, res) => {
  try {
    const validated = insertPayrollCutoffSchema.parse(req.body);
    const cutoff = await storage.createPayrollCutoff(validated);
    res.status(201).json(cutoff);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error creating payroll cutoff:", error);
    res.status(500).json({ message: "Failed to create payroll cutoff" });
  }
});

router.patch("/payroll-cutoffs/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "hr_settings.manage_cutoffs"), async (req, res) => {
  try {
    const validated = insertPayrollCutoffSchema.partial().parse(req.body);
    const cutoff = await storage.updatePayrollCutoff(req.params.id, validated);
    res.json(cutoff);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error updating payroll cutoff:", error);
    res.status(500).json({ message: "Failed to update payroll cutoff" });
  }
});

router.delete("/payroll-cutoffs/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "hr_settings.manage_cutoffs"), async (req, res) => {
  try {
    await storage.deletePayrollCutoff(req.params.id);
    res.status(204).send();
  } catch (error) {
    logger.error("Error deleting payroll cutoff:", error);
    res.status(500).json({ message: "Failed to delete payroll cutoff" });
  }
});

router.get("/leave-types", isAuthenticated, async (req, res) => {
  try {
    const leaveTypes = await storage.getLeaveTypes();
    res.json(leaveTypes);
  } catch (error) {
    logger.error("Error fetching leave types:", error);
    res.status(500).json({ message: "Failed to fetch leave types" });
  }
});

router.post("/leave-types", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "leave.manage_types"), async (req, res) => {
  try {
    const validated = insertLeaveTypeSchema.parse(req.body);
    const leaveType = await storage.createLeaveType(validated);
    res.status(201).json(leaveType);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error creating leave type:", error);
    res.status(500).json({ message: "Failed to create leave type" });
  }
});

router.patch("/leave-types/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "leave.manage_types"), async (req, res) => {
  try {
    const validated = insertLeaveTypeSchema.partial().parse(req.body);
    const leaveType = await storage.updateLeaveType(req.params.id, validated);
    res.json(leaveType);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error updating leave type:", error);
    res.status(500).json({ message: "Failed to update leave type" });
  }
});

router.delete("/leave-types/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "leave.manage_types"), async (req, res) => {
  try {
    await storage.deleteLeaveType(req.params.id);
    res.status(204).send();
  } catch (error) {
    logger.error("Error deleting leave type:", error);
    res.status(500).json({ message: "Failed to delete leave type" });
  }
});

router.get("/holidays", isAuthenticated, async (req, res) => {
  try {
    const { year } = req.query;
    const holidaysList = await storage.getHolidays(year ? parseInt(year as string) : undefined);
    res.json(holidaysList);
  } catch (error) {
    logger.error("Error fetching holidays:", error);
    res.status(500).json({ message: "Failed to fetch holidays" });
  }
});

router.post("/holidays", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "hr_settings.manage_holidays"), async (req, res) => {
  try {
    const validated = insertHolidaySchema.parse(req.body);
    const holiday = await storage.createHoliday(validated);
    res.status(201).json(holiday);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error creating holiday:", error);
    res.status(500).json({ message: "Failed to create holiday" });
  }
});

router.patch("/holidays/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "hr_settings.manage_holidays"), async (req, res) => {
  try {
    const validated = insertHolidaySchema.partial().parse(req.body);
    const holiday = await storage.updateHoliday(req.params.id, validated);
    res.json(holiday);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error updating holiday:", error);
    res.status(500).json({ message: "Failed to update holiday" });
  }
});

router.delete("/holidays/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "hr_settings.manage_holidays"), async (req, res) => {
  try {
    await storage.deleteHoliday(req.params.id);
    res.status(204).send();
  } catch (error) {
    logger.error("Error deleting holiday:", error);
    res.status(500).json({ message: "Failed to delete holiday" });
  }
});

router.get("/company", isAuthenticated, async (req, res) => {
  try {
    const { category } = req.query;
    const settings = await storage.getCompanySettings(category as string | undefined);
    res.json(settings);
  } catch (error) {
    logger.error("Error fetching company settings:", error);
    res.status(500).json({ message: "Failed to fetch company settings" });
  }
});

router.post("/company", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "hr_settings.edit"), async (req, res) => {
  try {
    const validated = insertCompanySettingSchema.parse(req.body);
    const setting = await storage.upsertCompanySetting(validated);
    res.json(setting);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error saving company setting:", error);
    res.status(500).json({ message: "Failed to save company setting" });
  }
});

export default router;
