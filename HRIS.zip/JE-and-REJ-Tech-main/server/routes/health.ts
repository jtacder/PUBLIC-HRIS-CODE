import { Router, Request, Response } from "express";
import { pool } from "../db";
import { logger } from "../utils/logger";
import { readFileSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const router = Router();

// Track server start time for uptime calculation
const serverStartTime = Date.now();

// Read version from package.json synchronously at module load
function getAppVersion(): string {
  try {
    // Try multiple paths to find package.json
    const paths = [
      join(process.cwd(), "package.json"),
      join(dirname(fileURLToPath(import.meta.url)), "../../package.json"),
    ];

    for (const pkgPath of paths) {
      try {
        const content = readFileSync(pkgPath, "utf-8");
        const pkg = JSON.parse(content);
        if (pkg.version) {
          return pkg.version;
        }
      } catch {
        // Try next path
      }
    }
  } catch (error) {
    logger.debug("Could not load package.json version, using default");
  }
  return "1.0.0";
}

const appVersion = getAppVersion();

interface HealthStatus {
  status: "healthy" | "unhealthy";
  timestamp: string;
  uptime: number;
  version: string;
  database: {
    status: "connected" | "disconnected";
    latency?: number;
  };
}

/**
 * Check database connection by executing a simple query
 */
async function checkDatabaseConnection(): Promise<{ connected: boolean; latency: number }> {
  const start = Date.now();
  try {
    const client = await pool.connect();
    await client.query("SELECT 1");
    client.release();
    return { connected: true, latency: Date.now() - start };
  } catch (error) {
    logger.error("Database health check failed", error);
    return { connected: false, latency: Date.now() - start };
  }
}

/**
 * GET /api/health
 * Main health check endpoint - returns overall system health
 * No authentication required
 */
router.get("/", async (_req: Request, res: Response) => {
  const dbCheck = await checkDatabaseConnection();
  const uptimeSeconds = Math.floor((Date.now() - serverStartTime) / 1000);

  const healthStatus: HealthStatus = {
    status: dbCheck.connected ? "healthy" : "unhealthy",
    timestamp: new Date().toISOString(),
    uptime: uptimeSeconds,
    version: appVersion,
    database: {
      status: dbCheck.connected ? "connected" : "disconnected",
      latency: dbCheck.latency,
    },
  };

  const httpStatus = healthStatus.status === "healthy" ? 200 : 503;

  logger.debug(`Health check: ${healthStatus.status}`, {
    uptime: uptimeSeconds,
    dbLatency: dbCheck.latency
  });

  res.status(httpStatus).json(healthStatus);
});

/**
 * GET /api/health/ready
 * Readiness check endpoint - indicates if the app is ready to receive traffic
 * Useful for Kubernetes/container orchestration
 * No authentication required
 */
router.get("/ready", async (_req: Request, res: Response) => {
  const dbCheck = await checkDatabaseConnection();

  if (dbCheck.connected) {
    res.status(200).json({
      ready: true,
      timestamp: new Date().toISOString(),
      checks: {
        database: "ok",
      },
    });
  } else {
    res.status(503).json({
      ready: false,
      timestamp: new Date().toISOString(),
      checks: {
        database: "failed",
      },
    });
  }
});

/**
 * GET /api/health/live
 * Liveness check endpoint - indicates if the app process is running
 * Useful for Kubernetes/container orchestration
 * No authentication required
 */
router.get("/live", (_req: Request, res: Response) => {
  res.status(200).json({
    alive: true,
    timestamp: new Date().toISOString(),
  });
});

export default router;
