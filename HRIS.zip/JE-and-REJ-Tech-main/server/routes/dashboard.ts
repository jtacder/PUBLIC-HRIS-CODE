import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { getPhilippineTime, getPhilippineDateString, getPhilippineDayName, extractDateString, parseShiftWorkDays, createPHTDateStart, createPHTDateEnd } from "../utils/datetime";
import type { PayrollCutoff } from "@shared/schema";
import logger from "../utils/logger";

const router = Router();

// Helper function to format year/month/day as YYYY-MM-DD string
function formatDateString(year: number, month: number, day: number): string {
  // Handle month overflow (e.g., month 12 becomes next year's month 0)
  const date = new Date(year, month, day);
  const actualYear = date.getFullYear();
  const actualMonth = String(date.getMonth() + 1).padStart(2, '0');
  const actualDay = String(date.getDate()).padStart(2, '0');
  return `${actualYear}-${actualMonth}-${actualDay}`;
}

// Helper function to calculate cutoff date range for a given month/year
// Uses PHT-aware date functions to ensure correct timezone display on frontend
function calculateCutoffDateRange(
  cutoff: PayrollCutoff,
  referenceMonth: number,
  referenceYear: number,
  isEndMonthPortion: boolean = false
): { start: Date; end: Date } {
  const spansMonth = cutoff.endDay < cutoff.startDay;

  if (spansMonth) {
    if (isEndMonthPortion) {
      // We're viewing from the "end month" perspective (e.g., Jan for Dec 27 - Jan 10)
      const startDateStr = formatDateString(referenceYear, referenceMonth - 1, cutoff.startDay);
      const endDateStr = formatDateString(referenceYear, referenceMonth, cutoff.endDay);
      return {
        start: createPHTDateStart(startDateStr),
        end: createPHTDateEnd(endDateStr),
      };
    } else {
      // We're viewing from the "start month" perspective (e.g., Dec for Dec 27 - Jan 10)
      const startDateStr = formatDateString(referenceYear, referenceMonth, cutoff.startDay);
      const endDateStr = formatDateString(referenceYear, referenceMonth + 1, cutoff.endDay);
      return {
        start: createPHTDateStart(startDateStr),
        end: createPHTDateEnd(endDateStr),
      };
    }
  } else {
    // Normal cutoff within same month
    const lastDayOfMonth = new Date(referenceYear, referenceMonth + 1, 0).getDate();
    const actualEndDay = cutoff.endDay >= 28
      ? Math.min(cutoff.endDay, lastDayOfMonth)
      : cutoff.endDay;
    const startDateStr = formatDateString(referenceYear, referenceMonth, cutoff.startDay);
    const endDateStr = formatDateString(referenceYear, referenceMonth, actualEndDay);
    return {
      start: createPHTDateStart(startDateStr),
      end: createPHTDateEnd(endDateStr),
    };
  }
}

// Helper function to find which cutoff the current day falls into
function findCurrentCutoff(
  cutoffs: PayrollCutoff[],
  currentDay: number,
  currentMonth: number,
  currentYear: number
): { cutoff: PayrollCutoff; isInEndMonthPortion: boolean } | null {
  const sortedCutoffs = [...cutoffs].sort((a, b) => a.startDay - b.startDay);

  for (const cutoff of sortedCutoffs) {
    const spansMonth = cutoff.endDay < cutoff.startDay;

    if (spansMonth) {
      if (currentDay >= cutoff.startDay) {
        return { cutoff, isInEndMonthPortion: false };
      } else if (currentDay <= cutoff.endDay) {
        return { cutoff, isInEndMonthPortion: true };
      }
    } else {
      if (currentDay >= cutoff.startDay && currentDay <= cutoff.endDay) {
        return { cutoff, isInEndMonthPortion: false };
      }
      if (cutoff.endDay >= 28 && currentDay >= cutoff.startDay) {
        const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        if (currentDay <= lastDayOfMonth) {
          return { cutoff, isInEndMonthPortion: false };
        }
      }
    }
  }

  return sortedCutoffs.length > 0 ? { cutoff: sortedCutoffs[0], isInEndMonthPortion: false } : null;
}

// Use permission-based check with legacy role fallback for backward compatibility
router.get("/stats", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "dashboard.view_admin"), async (req, res) => {
  try {
    // Parse query parameters for cutoff selection
    const selectedCutoffId = req.query.cutoffId as string | undefined;
    const selectedMonth = req.query.month ? parseInt(req.query.month as string) : undefined;
    const selectedYear = req.query.year ? parseInt(req.query.year as string) : undefined;

    // First batch: fetch data that doesn't depend on cutoff dates
    // Note: We fetch attendance logs AFTER determining cutoff dates for performance optimization
    const [employees, todayAttendanceAll, allProjects, allExpenses, disciplinaryActions, leaveRequests, configuredCutoffs] = await Promise.all([
      storage.getVisibleEmployees(),
      storage.getTodayAttendance(),
      storage.getProjects(),
      storage.getExpenses(),
      storage.getDisciplinaryActions(),
      storage.getLeaveRequests(),
      storage.getPayrollCutoffs(),
    ]);

    // Filter today's attendance to exclude hidden employees
    const visibleEmployeeIds = new Set(employees.map(e => e.id));
    const todayAttendance = todayAttendanceAll.filter(log => visibleEmployeeIds.has(log.employeeId));

    const activeEmployees = employees.filter(e => e.status === "Active" || e.status === "Probationary");
    // Exclude office locations from project counts (offices are permanent locations, not projects)
    const nonOfficeProjects = allProjects.filter(p => !p.isOffice);
    const activeProjects = nonOfficeProjects.filter(p => p.status === "Active");
    const pendingExpenses = allExpenses.filter(e => e.status === "Pending");
    const openNTEs = disciplinaryActions.filter(d => d.status === "Issued" || d.status === "Under_Review");

    const now = getPhilippineTime();
    const currentDay = now.getUTCDate();
    const currentMonth = now.getUTCMonth();
    const currentYear = now.getUTCFullYear();

    // Use selected month/year or default to current
    const refMonth = selectedMonth !== undefined ? selectedMonth : currentMonth;
    const refYear = selectedYear !== undefined ? selectedYear : currentYear;

    let cutoffStart: Date;
    let cutoffEnd: Date;
    let cutoffName = "";
    let cutoffId = "";

    // Build available cutoffs list with calculated date ranges for the reference month
    const availableCutoffs: Array<{
      id: string;
      name: string;
      startDay: number;
      endDay: number;
      startDate: string;
      endDate: string;
      isCurrent: boolean;
    }> = [];

    if (configuredCutoffs.length > 0) {
      const sortedCutoffs = [...configuredCutoffs].sort((a, b) => a.startDay - b.startDay);

      // Find which cutoff is "current" based on today's date
      const currentCutoffResult = findCurrentCutoff(sortedCutoffs, currentDay, currentMonth, currentYear);

      // Build the available cutoffs list
      for (const cutoff of sortedCutoffs) {
        const spansMonth = cutoff.endDay < cutoff.startDay;
        // For the dropdown, calculate date range assuming we're in the "start month" portion
        const dateRange = calculateCutoffDateRange(cutoff, refMonth, refYear, false);

        const isCurrent = currentCutoffResult?.cutoff.id === cutoff.id &&
          refMonth === currentMonth &&
          refYear === currentYear;

        availableCutoffs.push({
          id: cutoff.id,
          name: cutoff.name,
          startDay: cutoff.startDay,
          endDay: cutoff.endDay,
          startDate: dateRange.start.toISOString(),
          endDate: dateRange.end.toISOString(),
          isCurrent,
        });
      }

      // Determine which cutoff to use for stats
      let selectedCutoff: PayrollCutoff;
      let isInEndMonthPortion = false;

      if (selectedCutoffId) {
        // User explicitly selected a cutoff
        const found = sortedCutoffs.find(c => c.id === selectedCutoffId);
        selectedCutoff = found || sortedCutoffs[0];
        // When user selects, assume they want the "start month" view
        isInEndMonthPortion = false;
      } else if (currentCutoffResult) {
        // Auto-detect current cutoff
        selectedCutoff = currentCutoffResult.cutoff;
        isInEndMonthPortion = currentCutoffResult.isInEndMonthPortion;
      } else {
        selectedCutoff = sortedCutoffs[0];
      }

      cutoffId = selectedCutoff.id;
      cutoffName = selectedCutoff.name;

      // Calculate date range for the selected cutoff
      const dateRange = calculateCutoffDateRange(selectedCutoff, refMonth, refYear, isInEndMonthPortion);
      cutoffStart = dateRange.start;
      cutoffEnd = dateRange.end;
    } else {
      // Fallback: default cutoffs when none configured
      const lastDay = new Date(refYear, refMonth + 1, 0).getDate();
      const firstCutoffStart = createPHTDateStart(formatDateString(refYear, refMonth, 1));
      const firstCutoffEnd = createPHTDateEnd(formatDateString(refYear, refMonth, 15));
      const secondCutoffStart = createPHTDateStart(formatDateString(refYear, refMonth, 16));
      const secondCutoffEnd = createPHTDateEnd(formatDateString(refYear, refMonth, lastDay));

      if (currentDay <= 15) {
        cutoffName = "1st Cutoff";
        cutoffStart = firstCutoffStart;
        cutoffEnd = firstCutoffEnd;
        availableCutoffs.push({
          id: "default-1",
          name: "1st Cutoff",
          startDay: 1,
          endDay: 15,
          startDate: firstCutoffStart.toISOString(),
          endDate: firstCutoffEnd.toISOString(),
          isCurrent: currentDay <= 15,
        });
        availableCutoffs.push({
          id: "default-2",
          name: "2nd Cutoff",
          startDay: 16,
          endDay: 31,
          startDate: secondCutoffStart.toISOString(),
          endDate: secondCutoffEnd.toISOString(),
          isCurrent: currentDay > 15,
        });
      } else {
        cutoffName = "2nd Cutoff";
        cutoffStart = secondCutoffStart;
        cutoffEnd = secondCutoffEnd;
        availableCutoffs.push({
          id: "default-1",
          name: "1st Cutoff",
          startDay: 1,
          endDay: 15,
          startDate: firstCutoffStart.toISOString(),
          endDate: firstCutoffEnd.toISOString(),
          isCurrent: currentDay <= 15,
        });
        availableCutoffs.push({
          id: "default-2",
          name: "2nd Cutoff",
          startDay: 16,
          endDay: 31,
          startDate: secondCutoffStart.toISOString(),
          endDate: secondCutoffEnd.toISOString(),
          isCurrent: currentDay > 15,
        });
      }
      cutoffId = currentDay <= 15 ? "default-1" : "default-2";
    }

    // PERFORMANCE OPTIMIZATION: Fetch attendance logs with date filtering at database level
    // This avoids loading ALL attendance logs into memory
    const cutoffAttendanceAll = await storage.getAttendanceLogs(cutoffStart, cutoffEnd);
    const cutoffAttendance = cutoffAttendanceAll.filter(log => visibleEmployeeIds.has(log.employeeId));

    // PERFORMANCE OPTIMIZATION: Pre-group attendance by employeeId to avoid O(n×m) lookups
    // This changes complexity from O(employees × logs) to O(employees + logs)
    const attendanceByEmployee = new Map<string, typeof cutoffAttendance>();
    for (const log of cutoffAttendance) {
      const existing = attendanceByEmployee.get(log.employeeId);
      if (existing) {
        existing.push(log);
      } else {
        attendanceByEmployee.set(log.employeeId, [log]);
      }
    }

    let estimatedBasicPay = 0;
    let estimatedOTPay = 0;

    for (const emp of activeEmployees) {
      // O(1) lookup instead of O(n) filter
      const empAttendance = attendanceByEmployee.get(emp.id) || [];
      const dailyRate = parseFloat(String(emp.baseRate)) || 0;
      const hourlyRate = emp.rateType === "monthly" ? dailyRate / 22 / 8 : dailyRate / 8;

      let totalApprovedOTMinutes = 0;
      let totalRegularHours = 0;

      // Single pass: calculate both OT minutes and regular hours together
      for (const log of empAttendance) {
        // OT calculation
        if (log.otStatus === "Approved" && log.otMinutesApproved != null) {
          totalApprovedOTMinutes += Number(log.otMinutesApproved);
        }
        // Regular hours (capped at 8 per day)
        const hours = parseFloat(String(log.totalHours)) || 0;
        totalRegularHours += Math.min(hours, 8);
      }

      const approvedOTHours = totalApprovedOTMinutes / 60;

      // Basic pay is only for regular hours (not including OT)
      estimatedBasicPay += hourlyRate * totalRegularHours;

      // OT pay is separate with 1.25x multiplier
      estimatedOTPay += hourlyRate * approvedOTHours * 1.25;
    }

    const estimatedTotalPayroll = estimatedBasicPay + estimatedOTPay;

    // For pending OT count, we need all attendance (not just cutoff period)
    // Fetch only pending OT logs efficiently
    const pendingOTLogs = cutoffAttendance.filter(log =>
      log.otStatus === "Pending" &&
      ((log.overtimeMinutes && Number(log.overtimeMinutes) > 0) || log.isOvertimeSession)
    );
    
    const lateTodayLogs = todayAttendance.filter(log => log.isLate);

    const todayStr = getPhilippineDateString();
    const todayName = getPhilippineDayName();

    // Calculate employees on approved leave today
    const employeesOnLeaveToday = new Set(
      leaveRequests
        .filter(lr => {
          if (lr.status !== 'Approved') return false;
          const startDate = extractDateString(lr.startDate);
          const endDate = extractDateString(lr.endDate);
          return todayStr >= startDate && todayStr <= endDate;
        })
        .map(lr => lr.employeeId)
    );

    // Calculate employees whose day off is today (not in their shiftWorkDays)
    // Only count active employees who have a defined schedule
    const employeesOnDayOffToday = new Set(
      activeEmployees
        .filter(emp => {
          // Parse shiftWorkDays safely (handles both array and JSON string)
          const workDays = parseShiftWorkDays(emp.shiftWorkDays);
          if (workDays) {
            // Employee has a defined schedule - check if today is in their work days
            return !workDays.includes(todayName);
          }
          // If no schedule defined, assume they work all weekdays (Mon-Fri)
          // So only consider it a day off if today is Sat or Sun
          return todayName === 'Sat' || todayName === 'Sun';
        })
        .map(emp => emp.id)
    );

    // Filter out overlaps - if someone is on leave AND it's their day off, count only as day off
    // to avoid double counting. Actually, let's count them separately for clarity.
    const onLeaveCount = Array.from(employeesOnLeaveToday).filter(
      id => !employeesOnDayOffToday.has(id)
    ).length;
    const dayOffCount = employeesOnDayOffToday.size;

    // Expected present = active employees minus day offs minus on leave (no double counting)
    const expectedPresent = activeEmployees.length - dayOffCount - onLeaveCount;

    const clockedInEmployeeIds = new Set(todayAttendance.map(log => log.employeeId));
    const notClockedInEmployees = activeEmployees.filter(emp => {
      if (clockedInEmployeeIds.has(emp.id)) return false;
      if (employeesOnLeaveToday.has(emp.id)) return false;
      // Use consistent logic with employeesOnDayOffToday
      if (employeesOnDayOffToday.has(emp.id)) return false;
      return true;
    });

    res.json({
      totalEmployees: employees.length,
      activeEmployees: activeEmployees.length,
      todayAttendance: todayAttendance.length,
      // New fields for attendance tracking
      dayOffsToday: dayOffCount,
      onLeaveToday: onLeaveCount,
      expectedPresent: expectedPresent,
      estimatedBasicPay: estimatedBasicPay.toFixed(2),
      estimatedOTPay: estimatedOTPay.toFixed(2),
      estimatedTotalPayroll: estimatedTotalPayroll.toFixed(2),
      cutoffId: cutoffId,
      cutoffName: cutoffName,
      cutoffStart: cutoffStart.toISOString(),
      cutoffEnd: cutoffEnd.toISOString(),
      availableCutoffs: availableCutoffs,
      totalProjects: nonOfficeProjects.length,
      activeProjects: activeProjects.length,
      pendingExpenses: pendingExpenses.length,
      openNTEs: openNTEs.length,
      pendingOTCount: pendingOTLogs.length,
      lateTodayCount: lateTodayLogs.length,
      notClockedInCount: notClockedInEmployees.length,
      notClockedInEmployees: notClockedInEmployees.slice(0, 10).map(emp => ({
        id: emp.id,
        firstName: emp.firstName,
        lastName: emp.lastName,
        employeeNo: emp.employeeNo,
      })),
    });
  } catch (error) {
    logger.error("Error fetching dashboard stats:", error);
    res.status(500).json({ message: "Failed to fetch dashboard stats" });
  }
});

export default router;
