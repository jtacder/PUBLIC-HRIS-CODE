import { Router } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { insertProjectAssignmentSchema } from "@shared/schema";
import { logger } from "../utils/logger";

const router = Router();

/**
 * Schedule Management API Routes
 *
 * These endpoints provide a restricted view of employee schedule data
 * and project assignments. They are designed for users who only need
 * schedule management access without full employee data visibility.
 *
 * All dates/times follow Philippine Time (UTC+8) conventions.
 */

// GET /schedule-management/employees
// Returns employees with schedule-relevant fields only (no salary, SSS, personal data)
router.get(
  "/employees",
  isAuthenticated,
  hasRoleOrPermission(["ADMIN", "HR"], "schedules.view"),
  async (_req, res) => {
    try {
      const allEmployees = await storage.getEmployees();
      const allAssignments = await storage.getProjectAssignments();
      const allProjects = await storage.getProjects();

      // Build a project lookup for enrichment
      const projectMap = new Map(allProjects.map((p) => [p.id, p]));

      const scheduleEmployees = allEmployees
        .filter((e) => e.status === "Active" || e.status === "Probationary")
        .map((e) => {
          const employeeAssignments = allAssignments
            .filter((a) => a.employeeId === e.id && a.isActive)
            .map((a) => ({
              ...a,
              projectName: projectMap.get(a.projectId)?.name || "Unknown",
              projectCode: projectMap.get(a.projectId)?.code || null,
              projectStatus: projectMap.get(a.projectId)?.status || null,
            }));

          return {
            id: e.id,
            firstName: e.firstName,
            lastName: e.lastName,
            employeeNo: e.employeeNo,
            department: e.department,
            position: e.position,
            status: e.status,
            shiftStartTime: e.shiftStartTime,
            shiftEndTime: e.shiftEndTime,
            shiftWorkDays: e.shiftWorkDays,
            profilePhotoUrl: e.profilePhotoUrl,
            projectAssignments: employeeAssignments,
          };
        });

      res.json(scheduleEmployees);
    } catch (error) {
      logger.error("Error fetching schedule employees:", error);
      res.status(500).json({ message: "Failed to fetch schedule data" });
    }
  }
);

// PATCH /schedule-management/employees/:id/schedule
// Updates only schedule-related fields on the employee record
router.patch(
  "/employees/:id/schedule",
  isAuthenticated,
  hasRoleOrPermission(["ADMIN", "HR"], "schedules.edit"),
  async (req, res) => {
    try {
      const userId = req.session.user?.id;

      const scheduleSchema = z.object({
        shiftStartTime: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, "Invalid time format. Use HH:mm"),
        shiftEndTime: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, "Invalid time format. Use HH:mm"),
        shiftWorkDays: z.array(z.string()).min(1, "At least one work day is required"),
      });

      const validatedData = scheduleSchema.parse(req.body);

      const existingEmployee = await storage.getEmployee(req.params.id);
      if (!existingEmployee) {
        return res.status(404).json({ message: "Employee not found" });
      }

      const updated = await storage.updateEmployee(req.params.id, {
        shiftStartTime: validatedData.shiftStartTime,
        shiftEndTime: validatedData.shiftEndTime,
        shiftWorkDays: validatedData.shiftWorkDays,
      });

      // Create audit log for schedule change
      await storage.createAuditLog({
        userId,
        action: "UPDATE",
        entityType: "Employee Schedule",
        entityId: req.params.id,
        oldValues: {
          shiftStartTime: existingEmployee.shiftStartTime,
          shiftEndTime: existingEmployee.shiftEndTime,
          shiftWorkDays: existingEmployee.shiftWorkDays,
        },
        newValues: {
          shiftStartTime: validatedData.shiftStartTime,
          shiftEndTime: validatedData.shiftEndTime,
          shiftWorkDays: validatedData.shiftWorkDays,
        },
        ipAddress: req.ip,
        userAgent: req.get("user-agent"),
      });

      logger.info(
        `Schedule updated for employee ${req.params.id}: ${validatedData.shiftStartTime}-${validatedData.shiftEndTime} [${validatedData.shiftWorkDays.join(",")}]`
      );

      res.json({
        id: updated!.id,
        firstName: updated!.firstName,
        lastName: updated!.lastName,
        employeeNo: updated!.employeeNo,
        department: updated!.department,
        position: updated!.position,
        shiftStartTime: updated!.shiftStartTime,
        shiftEndTime: updated!.shiftEndTime,
        shiftWorkDays: updated!.shiftWorkDays,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      logger.error("Error updating employee schedule:", error);
      res.status(500).json({ message: "Failed to update schedule" });
    }
  }
);

// GET /schedule-management/projects
// Returns active projects with their current assignments
router.get(
  "/projects",
  isAuthenticated,
  hasRoleOrPermission(["ADMIN", "HR"], "schedules.view"),
  async (_req, res) => {
    try {
      const allProjects = await storage.getProjects();
      const allAssignments = await storage.getProjectAssignments();
      const allEmployees = await storage.getEmployees();

      const employeeMap = new Map(
        allEmployees.map((e) => [
          e.id,
          {
            id: e.id,
            firstName: e.firstName,
            lastName: e.lastName,
            employeeNo: e.employeeNo,
            department: e.department,
          },
        ])
      );

      // Only return active/planning projects
      const activeProjects = allProjects
        .filter((p) => p.status === "Active" || p.status === "Planning")
        .map((p) => {
          const projectAssignments = allAssignments
            .filter((a) => a.projectId === p.id)
            .map((a) => ({
              ...a,
              employee: employeeMap.get(a.employeeId) || null,
            }));

          return {
            id: p.id,
            name: p.name,
            code: p.code,
            status: p.status,
            isOffice: p.isOffice,
            startDate: p.startDate,
            deadline: p.deadline,
            locationName: p.locationName,
            assignments: projectAssignments,
          };
        });

      res.json(activeProjects);
    } catch (error) {
      logger.error("Error fetching schedule projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  }
);

// POST /schedule-management/projects/:id/assign
// Assign an employee to a project
router.post(
  "/projects/:id/assign",
  isAuthenticated,
  hasRoleOrPermission(["ADMIN", "HR"], "schedules.edit"),
  async (req, res) => {
    try {
      const userId = req.session.user?.id;

      const validatedData = insertProjectAssignmentSchema.parse({
        ...req.body,
        projectId: req.params.id,
      });

      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      const employee = await storage.getEmployee(validatedData.employeeId);
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }

      // Check for duplicate assignment
      const existingAssignments = await storage.getProjectAssignments(req.params.id);
      const alreadyAssigned = existingAssignments.some(
        (a) => a.employeeId === validatedData.employeeId && a.isActive
      );
      if (alreadyAssigned) {
        return res.status(409).json({ message: "Employee is already assigned to this project" });
      }

      const assignment = await storage.createProjectAssignment(validatedData);

      // Audit log
      await storage.createAuditLog({
        userId,
        action: "CREATE",
        entityType: "Project Assignment",
        entityId: assignment.id,
        newValues: {
          projectId: req.params.id,
          projectName: project.name,
          employeeId: validatedData.employeeId,
          employeeName: `${employee.firstName} ${employee.lastName}`,
          role: validatedData.role,
        },
        ipAddress: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.status(201).json(assignment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      logger.error("Error creating project assignment:", error);
      res.status(500).json({ message: "Failed to assign employee" });
    }
  }
);

// DELETE /schedule-management/projects/:projectId/assignments/:id
// Remove an employee from a project
router.delete(
  "/projects/:projectId/assignments/:id",
  isAuthenticated,
  hasRoleOrPermission(["ADMIN", "HR"], "schedules.edit"),
  async (req, res) => {
    try {
      const userId = req.session.user?.id;

      // Get assignment details for audit log before deletion
      const allAssignments = await storage.getProjectAssignments(req.params.projectId);
      const assignment = allAssignments.find((a) => a.id === req.params.id);

      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }

      const project = await storage.getProject(req.params.projectId);
      const employee = await storage.getEmployee(assignment.employeeId);

      await storage.deleteProjectAssignment(req.params.id);

      // Audit log
      await storage.createAuditLog({
        userId,
        action: "DELETE",
        entityType: "Project Assignment",
        entityId: req.params.id,
        oldValues: {
          projectId: req.params.projectId,
          projectName: project?.name || "Unknown",
          employeeId: assignment.employeeId,
          employeeName: employee ? `${employee.firstName} ${employee.lastName}` : "Unknown",
          role: assignment.role,
        },
        ipAddress: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.status(204).send();
    } catch (error) {
      logger.error("Error removing project assignment:", error);
      res.status(500).json({ message: "Failed to remove assignment" });
    }
  }
);

export default router;
