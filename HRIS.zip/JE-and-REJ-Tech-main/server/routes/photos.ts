/**
 * File serving endpoint for Replit Object Storage
 * Provides a proxy for serving photos and documents stored in object storage
 */
import { Router } from "express";
import { downloadPhoto, isLegacyBase64 } from "../utils/object-storage";
import { isAuthenticated } from "../email-auth";
import logger from "../utils/logger";

const router = Router();

/**
 * Get MIME type from file extension
 */
function getMimeType(key: string): string {
  const extension = key.split(".").pop()?.toLowerCase() || "";
  const mimeTypes: Record<string, string> = {
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    png: "image/png",
    webp: "image/webp",
    gif: "image/gif",
    pdf: "application/pdf",
  };
  return mimeTypes[extension] || "application/octet-stream";
}

/**
 * GET /api/photos/:key
 * Serve a file (photo or document) from object storage
 * The key is URL-encoded in the path
 */
router.get("/:key(*)", isAuthenticated, async (req, res) => {
  try {
    const key = decodeURIComponent(req.params.key);

    // Don't serve legacy base64 through this endpoint
    if (isLegacyBase64(key)) {
      return res.status(400).json({ message: "Invalid photo key" });
    }

    const fileBuffer = await downloadPhoto(key);

    if (!fileBuffer) {
      return res.status(404).json({ message: "File not found" });
    }

    // Determine content type from file extension
    const contentType = getMimeType(key);

    // Set appropriate headers for response
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "public, max-age=31536000"); // Cache for 1 year
    res.setHeader("Content-Length", fileBuffer.length);

    // For PDFs, allow inline viewing
    if (contentType === "application/pdf") {
      res.setHeader("Content-Disposition", "inline");
    }

    return res.send(fileBuffer);
  } catch (error) {
    logger.error("Error serving file:", error);
    return res.status(500).json({ message: "Failed to retrieve file" });
  }
});

export default router;
