/**
 * Tests for Attendance Route
 *
 * Tests all attendance-related endpoints including:
 * - Clock-in/Clock-out
 * - Attendance logs retrieval
 * - OT approval workflow
 * - Geo-fencing validation
 * - Late/undertime calculations
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { AttendanceLog, Employee, Project } from '@shared/schema';

// Mock dependencies
const mockStorage = {
  getEmployeeByQRToken: vi.fn(),
  getEmployee: vi.fn(),
  getEmployeeAssignments: vi.fn(),
  getProject: vi.fn(),
  getTodayAttendance: vi.fn(),
  getAttendanceLogs: vi.fn(),
  getAttendanceLog: vi.fn(),
  getEmployeeAttendance: vi.fn(),
  createAttendanceLog: vi.fn(),
  updateAttendanceLog: vi.fn(),
  deleteAttendanceLog: vi.fn(),
  createAuditLog: vi.fn(),
};

vi.mock('../storage', () => ({
  storage: mockStorage,
}));

// Test fixtures
const mockEmployee: Employee = {
  id: 'emp-001',
  firstName: 'Juan',
  lastName: 'Dela Cruz',
  middleName: null,
  email: 'juan@company.com',
  phone: '09171234567',
  address: null,
  birthDate: null,
  gender: null,
  civilStatus: null,
  nationality: 'Filipino',
  profilePhotoUrl: null,
  emergencyContactName: null,
  emergencyContactPhone: null,
  emergencyContactRelation: null,
  role: 'WORKER',
  position: 'Electrician',
  department: 'Operations',
  employeeNo: 'EMP-001',
  rateType: 'daily',
  baseRate: '700',
  sssNo: null,
  tinNo: null,
  philhealthNo: null,
  pagibigNo: null,
  bankName: null,
  bankAccountNo: null,
  status: 'Active',
  startDate: '2023-01-15',
  endDate: null,
  regularizationDate: null,
  shiftStartTime: '08:00',
  shiftEndTime: '17:00',
  shiftWorkDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
  qrToken: 'abc123token',
  enableSSSDeduction: true,
  enablePhilhealthDeduction: true,
  enablePagibigDeduction: true,
  enableTaxWithholding: false,
  userId: null,
  createdAt: new Date(),
  updatedAt: new Date(),
};

const mockProject: Project = {
  id: 'proj-001',
  name: 'Building A Installation',
  code: 'PROJ-001',
  description: null,
  client: null,
  isOffice: false,
  locationName: 'Building A',
  locationAddress: 'Makati City',
  locationLat: '14.5547',
  locationLng: '121.0244',
  geoRadius: 100,
  startDate: '2025-01-01',
  deadline: '2025-06-30',
  completedDate: null,
  budget: '1000000',
  actualCost: '0',
  allocatedHours: '5000',
  status: 'Active',
  projectManagerId: null,
  createdAt: new Date(),
  updatedAt: new Date(),
};

const mockAttendanceLog: AttendanceLog = {
  id: 'att-001',
  employeeId: 'emp-001',
  projectId: 'proj-001',
  timeIn: new Date('2025-01-15T08:00:00'),
  timeOut: null,
  totalHours: null,
  scheduledShiftStart: '08:00',
  scheduledShiftEnd: '17:00',
  scheduledShiftDate: '2025-01-15',
  actualShiftType: 'day',
  regularMinutes: 0,
  overtimeMinutes: 0,
  locationLat: '14.5547',
  locationLng: '121.0244',
  locationSource: 'GPS',
  distanceFromSite: '25',
  photoSnapshotUrl: 'https://storage.com/photo.jpg',
  faceVerified: true,
  verificationStatus: 'Verified',
  isLate: false,
  lateMinutes: 0,
  lateDeductible: false,
  undertimeMinutes: 0,
  lunchDeductionMinutes: 0,
  lunchPaid: false,
  overtimeHours: '0',
  overtimeType: null,
  overtimeApproved: false,
  otStatus: null,
  otMinutesApproved: 0,
  otApprovedById: null,
  otApprovedAt: null,
  otReason: null,
  isOvertimeSession: false,
  parentAttendanceId: null,
  justification: null,
  notes: null,
  createdAt: new Date(),
};

describe('Attendance Route Logic', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Clock-In', () => {
    it('should validate QR token and get employee', async () => {
      mockStorage.getEmployeeByQRToken.mockResolvedValue(mockEmployee);

      const employee = await mockStorage.getEmployeeByQRToken('abc123token');

      expect(employee).toBeDefined();
      expect(employee?.id).toBe('emp-001');
    });

    it('should reject invalid QR token', async () => {
      mockStorage.getEmployeeByQRToken.mockResolvedValue(undefined);

      const employee = await mockStorage.getEmployeeByQRToken('invalid-token');

      expect(employee).toBeUndefined();
    });

    it('should get employee project assignments', async () => {
      const assignments = [
        { projectId: 'proj-001', employeeId: 'emp-001', isActive: true },
      ];
      mockStorage.getEmployeeAssignments.mockResolvedValue(assignments);

      const result = await mockStorage.getEmployeeAssignments('emp-001');

      expect(result).toHaveLength(1);
      expect(result[0].projectId).toBe('proj-001');
    });

    it('should create attendance log on clock-in', async () => {
      mockStorage.createAttendanceLog.mockResolvedValue(mockAttendanceLog);

      const log = await mockStorage.createAttendanceLog({
        employeeId: 'emp-001',
        projectId: 'proj-001',
        timeIn: new Date(),
        locationLat: '14.5547',
        locationLng: '121.0244',
        photoSnapshotUrl: 'https://storage.com/photo.jpg',
      } as any);

      expect(log.id).toBe('att-001');
      expect(log.employeeId).toBe('emp-001');
    });

    it('should detect late clock-in', () => {
      const shiftStart = '08:00';
      const clockInTime = new Date('2025-01-15T08:30:00'); // 30 mins late
      const shiftStartParts = shiftStart.split(':').map(Number);
      const scheduledStart = new Date('2025-01-15');
      scheduledStart.setHours(shiftStartParts[0], shiftStartParts[1], 0, 0);

      const diffMinutes = Math.floor(
        (clockInTime.getTime() - scheduledStart.getTime()) / (1000 * 60)
      );

      expect(diffMinutes).toBe(30);
      expect(diffMinutes > 0).toBe(true); // Is late
      expect(diffMinutes > 15).toBe(true); // Deductible (past grace period)
    });

    it('should allow clock-in within grace period', () => {
      const shiftStart = '08:00';
      const clockInTime = new Date('2025-01-15T08:10:00'); // 10 mins late
      const shiftStartParts = shiftStart.split(':').map(Number);
      const scheduledStart = new Date('2025-01-15');
      scheduledStart.setHours(shiftStartParts[0], shiftStartParts[1], 0, 0);

      const diffMinutes = Math.floor(
        (clockInTime.getTime() - scheduledStart.getTime()) / (1000 * 60)
      );
      const graceMinutes = 15;

      expect(diffMinutes).toBe(10);
      expect(diffMinutes <= graceMinutes).toBe(true); // Within grace period
    });
  });

  describe('Clock-Out', () => {
    it('should update attendance log with clock-out time', async () => {
      const clockOutTime = new Date('2025-01-15T17:00:00');
      const updatedLog = {
        ...mockAttendanceLog,
        timeOut: clockOutTime,
        totalHours: '8',
        regularMinutes: 420, // 7 hours (8 hours - 1 hour lunch)
      };

      mockStorage.updateAttendanceLog.mockResolvedValue(updatedLog);

      const result = await mockStorage.updateAttendanceLog('att-001', {
        timeOut: clockOutTime,
      });

      expect(result?.timeOut).toBeDefined();
    });

    it('should calculate total hours worked', () => {
      const timeIn = new Date('2025-01-15T08:00:00');
      const timeOut = new Date('2025-01-15T17:00:00');
      const diffMs = timeOut.getTime() - timeIn.getTime();
      const diffHours = diffMs / (1000 * 60 * 60);

      expect(diffHours).toBe(9); // 9 hours including lunch
    });

    it('should calculate overtime', () => {
      const scheduledShiftMinutes = 9 * 60; // 9 hours = 540 minutes (with lunch)
      const actualWorkedMinutes = 10 * 60; // 10 hours = 600 minutes
      const lunchDeduction = 60;

      const regularMinutes = Math.min(
        actualWorkedMinutes - lunchDeduction,
        scheduledShiftMinutes - lunchDeduction
      );
      const overtimeMinutes = Math.max(0, actualWorkedMinutes - scheduledShiftMinutes);

      expect(regularMinutes).toBe(480); // 8 hours regular
      expect(overtimeMinutes).toBe(60); // 1 hour OT
    });

    it('should detect undertime', () => {
      const timeIn = new Date('2025-01-15T08:00:00');
      const timeOut = new Date('2025-01-15T16:00:00'); // Left 1 hour early
      const scheduledEnd = new Date('2025-01-15T17:00:00');

      const undertimeMs = scheduledEnd.getTime() - timeOut.getTime();
      const undertimeMinutes = Math.floor(undertimeMs / (1000 * 60));

      expect(undertimeMinutes).toBe(60);
    });
  });

  describe('Geo-fencing', () => {
    it('should calculate distance from project site', () => {
      // Haversine formula simulation
      const projectLat = 14.5547;
      const projectLng = 121.0244;
      const userLat = 14.5550;
      const userLng = 121.0244;

      // Simple approximation: 1 degree ≈ 111 km
      const latDiff = Math.abs(projectLat - userLat);
      const approximateDistanceKm = latDiff * 111;
      const approximateDistanceMeters = approximateDistanceKm * 1000;

      expect(approximateDistanceMeters).toBeLessThan(100); // Within 100m radius
    });

    it('should verify user is within project radius', () => {
      const geoRadius = 100; // meters
      const userDistance = 50; // meters from site

      const isWithinRadius = userDistance <= geoRadius;

      expect(isWithinRadius).toBe(true);
    });

    it('should flag user outside project radius', () => {
      const geoRadius = 100;
      const userDistance = 200;

      const isWithinRadius = userDistance <= geoRadius;
      const verificationStatus = isWithinRadius ? 'Verified' : 'Off-site';

      expect(isWithinRadius).toBe(false);
      expect(verificationStatus).toBe('Off-site');
    });
  });

  describe('Overtime Approval', () => {
    it('should set OT status to Pending on clock-out with OT', async () => {
      const logWithOT = {
        ...mockAttendanceLog,
        overtimeMinutes: 60,
        otStatus: 'Pending' as const,
      };

      mockStorage.updateAttendanceLog.mockResolvedValue(logWithOT);

      const result = await mockStorage.updateAttendanceLog('att-001', {
        overtimeMinutes: 60,
        otStatus: 'Pending',
      });

      expect(result?.otStatus).toBe('Pending');
    });

    it('should approve OT request', async () => {
      const approvedLog = {
        ...mockAttendanceLog,
        overtimeMinutes: 60,
        otStatus: 'Approved' as const,
        otMinutesApproved: 60,
        otApprovedById: 'hr-001',
        otApprovedAt: new Date(),
      };

      mockStorage.updateAttendanceLog.mockResolvedValue(approvedLog);

      const result = await mockStorage.updateAttendanceLog('att-001', {
        otStatus: 'Approved',
        otMinutesApproved: 60,
        otApprovedById: 'hr-001',
        otApprovedAt: new Date(),
      });

      expect(result?.otStatus).toBe('Approved');
      expect(result?.otMinutesApproved).toBe(60);
    });

    it('should reject OT request', async () => {
      const rejectedLog = {
        ...mockAttendanceLog,
        overtimeMinutes: 60,
        otStatus: 'Rejected' as const,
        otMinutesApproved: 0,
        otReason: 'Not pre-approved',
      };

      mockStorage.updateAttendanceLog.mockResolvedValue(rejectedLog);

      const result = await mockStorage.updateAttendanceLog('att-001', {
        otStatus: 'Rejected',
        otMinutesApproved: 0,
        otReason: 'Not pre-approved',
      });

      expect(result?.otStatus).toBe('Rejected');
      expect(result?.otMinutesApproved).toBe(0);
    });
  });

  describe('Attendance Logs Retrieval', () => {
    it('should get today\'s attendance', async () => {
      mockStorage.getTodayAttendance.mockResolvedValue([mockAttendanceLog]);

      const logs = await mockStorage.getTodayAttendance();

      expect(logs).toHaveLength(1);
    });

    it('should get attendance logs with date filter', async () => {
      mockStorage.getAttendanceLogs.mockResolvedValue([mockAttendanceLog]);

      const startDate = new Date('2025-01-01');
      const endDate = new Date('2025-01-31');
      const logs = await mockStorage.getAttendanceLogs(startDate, endDate);

      expect(mockStorage.getAttendanceLogs).toHaveBeenCalledWith(startDate, endDate);
    });

    it('should get employee-specific attendance', async () => {
      mockStorage.getEmployeeAttendance.mockResolvedValue([mockAttendanceLog]);

      const logs = await mockStorage.getEmployeeAttendance('emp-001');

      expect(logs).toHaveLength(1);
      expect(logs[0].employeeId).toBe('emp-001');
    });
  });

  describe('Night Shift Handling', () => {
    it('should detect night shift clock-in', () => {
      const clockInHour = 22; // 10 PM
      const isNightShift = clockInHour >= 22 || clockInHour < 4;

      expect(isNightShift).toBe(true);
    });

    it('should adjust scheduled date for overnight shift', () => {
      // Clock-in at 2 AM should be counted for previous day's shift
      const clockInTime = new Date('2025-01-15T02:00:00');
      const hour = clockInTime.getHours();
      const isNightShift = hour >= 22 || hour < 4;

      if (isNightShift && hour < 6) {
        const adjustedDate = new Date(clockInTime);
        adjustedDate.setDate(adjustedDate.getDate() - 1);
        expect(adjustedDate.getDate()).toBe(14);
      }
    });
  });

  describe('Lunch Break Deduction', () => {
    it('should apply 60-minute lunch deduction for shifts >= 5 hours', () => {
      const totalWorkedMinutes = 480; // 8 hours
      const minHoursForLunch = 5 * 60; // 300 minutes
      const lunchDeduction = totalWorkedMinutes >= minHoursForLunch ? 60 : 0;

      expect(lunchDeduction).toBe(60);
    });

    it('should not apply lunch deduction for short shifts', () => {
      const totalWorkedMinutes = 240; // 4 hours
      const minHoursForLunch = 5 * 60;
      const lunchDeduction = totalWorkedMinutes >= minHoursForLunch ? 60 : 0;

      expect(lunchDeduction).toBe(0);
    });

    it('should skip lunch deduction for paid lunch', () => {
      const lunchPaid = true;
      const lunchDeduction = lunchPaid ? 0 : 60;

      expect(lunchDeduction).toBe(0);
    });
  });

  describe('OT Session (Multiple Clock-ins)', () => {
    it('should mark secondary clock-in as OT session', () => {
      const mainShift = mockAttendanceLog;
      const otSession = {
        ...mockAttendanceLog,
        id: 'att-002',
        isOvertimeSession: true,
        parentAttendanceId: 'att-001',
        timeIn: new Date('2025-01-15T18:00:00'),
      };

      expect(otSession.isOvertimeSession).toBe(true);
      expect(otSession.parentAttendanceId).toBe(mainShift.id);
    });
  });
});

describe('Attendance Validation', () => {
  it('should have valid verification status', () => {
    const validStatuses = ['Verified', 'Pending', 'Flagged', 'Off-site'];
    expect(validStatuses).toContain(mockAttendanceLog.verificationStatus);
  });

  it('should have valid OT status', () => {
    const validStatuses = ['Pending', 'Approved', 'Rejected', null];
    expect(validStatuses).toContain(mockAttendanceLog.otStatus);
  });

  it('should have non-negative late minutes', () => {
    expect(mockAttendanceLog.lateMinutes).toBeGreaterThanOrEqual(0);
  });

  it('should have non-negative overtime minutes', () => {
    expect(mockAttendanceLog.overtimeMinutes).toBeGreaterThanOrEqual(0);
  });
});
