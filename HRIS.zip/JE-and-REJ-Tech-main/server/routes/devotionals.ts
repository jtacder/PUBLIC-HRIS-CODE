import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { insertDevotionalSchema, insertDevotionalReadingLogSchema } from "@shared/schema";
import { z } from "zod";
import { devotionalNoteSchema, validateBody } from "../validation/schemas";
import logger from "../utils/logger";

const router = Router();

// Helper: Calculate day of year (1-365)
function getDayOfYear(date: Date = new Date()): number {
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = date.getTime() - start.getTime();
  const oneDay = 1000 * 60 * 60 * 24;
  return Math.floor(diff / oneDay);
}

// Helper: Get current date in YYYY-MM-DD format
function getTodayString(): string {
  const now = new Date();
  return now.toISOString().split("T")[0];
}

// ========================================
// EMPLOYEE ENDPOINTS
// ========================================

// GET /api/devotionals/today - Get today's devotional for the current employee
router.get("/today", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user as any;
    const employeeId = user.employeeId;
    const todayString = getTodayString();
    const dayOfYear = getDayOfYear();

    // Get or create employee's devotional progress
    let progress = await storage.getEmployeeDevotionalProgress(employeeId);

    if (!progress) {
      // Create new progress record for the employee (starts today)
      progress = await storage.createEmployeeDevotionalProgress({
        employeeId,
        startDate: todayString,
        currentYear: 1,
        lastReadDay: 0,
        totalDaysRead: 0,
        currentStreak: 0,
        longestStreak: 0,
        todayRead: false,
      });
    }

    // Check if already read today
    const todayLog = await storage.getDevotionalReadingLogByDate(employeeId, todayString);
    const todayRead = !!todayLog;

    // Get today's devotional content
    const devotional = await storage.getDevotionalByDay(dayOfYear);

    if (!devotional) {
      // No devotional for this day yet - return placeholder
      return res.json({
        day: dayOfYear,
        totalDays: 365,
        todayRead,
        progress: {
          totalDaysRead: progress.totalDaysRead,
          currentStreak: progress.currentStreak,
          longestStreak: progress.longestStreak,
        },
        content: null, // No content available
        message: "Devotional content not yet available for today",
      });
    }

    res.json({
      day: dayOfYear,
      totalDays: 365,
      todayRead,
      progress: {
        totalDaysRead: progress.totalDaysRead,
        currentStreak: progress.currentStreak,
        longestStreak: progress.longestStreak,
      },
      content: {
        id: devotional.id,
        verse: devotional.verse,
        reference: devotional.reference,
        excerpt: devotional.baseExcerpt,
        theme: devotional.theme,
      },
    });
  } catch (error) {
    logger.error("Error fetching today's devotional:", error);
    res.status(500).json({ message: "Failed to fetch today's devotional" });
  }
});

// POST /api/devotionals/mark-read - Mark today's devotional as read
router.post("/mark-read", isAuthenticated, async (req, res) => {
  try {
    // Validate personal note if provided
    const validation = validateBody(devotionalNoteSchema, { personalNote: req.body.personalNote });
    if (!validation.success) {
      return res.status(400).json({ message: "Validation failed", errors: validation.errors });
    }

    const user = req.session.user as any;
    const employeeId = user.employeeId;
    const { personalNote } = validation.data;
    const todayString = getTodayString();
    const dayOfYear = getDayOfYear();

    // Get employee's progress
    let progress = await storage.getEmployeeDevotionalProgress(employeeId);

    if (!progress) {
      // Create new progress record
      progress = await storage.createEmployeeDevotionalProgress({
        employeeId,
        startDate: todayString,
        currentYear: 1,
        lastReadDay: 0,
        totalDaysRead: 0,
        currentStreak: 0,
        longestStreak: 0,
        todayRead: false,
      });
    }

    // Check if already read today
    const existingLog = await storage.getDevotionalReadingLogByDate(employeeId, todayString);
    if (existingLog) {
      return res.status(400).json({ message: "Already marked as read today" });
    }

    // Get the devotional for today
    const devotional = await storage.getDevotionalByDay(dayOfYear);
    if (!devotional) {
      return res.status(404).json({ message: "No devotional available for today" });
    }

    // Create reading log
    await storage.createDevotionalReadingLog({
      employeeId,
      devotionalId: devotional.id,
      readDate: todayString,
      dayNumber: dayOfYear,
      yearNumber: progress.currentYear,
      personalNote: personalNote || null,
      isFavorite: false,
    });

    // Calculate new streak
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayString = yesterday.toISOString().split("T")[0];
    const yesterdayLog = await storage.getDevotionalReadingLogByDate(employeeId, yesterdayString);

    const newStreak = yesterdayLog ? progress.currentStreak + 1 : 1;
    const newLongestStreak = Math.max(progress.longestStreak, newStreak);

    // Update progress
    await storage.updateEmployeeDevotionalProgress(progress.id, {
      lastReadDay: dayOfYear,
      lastReadDate: todayString,
      totalDaysRead: progress.totalDaysRead + 1,
      currentStreak: newStreak,
      longestStreak: newLongestStreak,
      todayRead: true,
    });

    res.json({
      success: true,
      message: "Devotional marked as read",
      newStreak,
      totalDaysRead: progress.totalDaysRead + 1,
    });
  } catch (error) {
    logger.error("Error marking devotional as read:", error);
    res.status(500).json({ message: "Failed to mark devotional as read" });
  }
});

// GET /api/devotionals/progress - Get employee's reading progress
router.get("/progress", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user as any;
    const employeeId = user.employeeId;

    const progress = await storage.getEmployeeDevotionalProgress(employeeId);

    if (!progress) {
      return res.json({
        started: false,
        message: "Devotional journey not started yet",
      });
    }

    const recentLogs = await storage.getDevotionalReadingLogs(employeeId, 7);

    res.json({
      started: true,
      startDate: progress.startDate,
      lastReadDay: progress.lastReadDay,
      lastReadDate: progress.lastReadDate,
      totalDaysRead: progress.totalDaysRead,
      currentStreak: progress.currentStreak,
      longestStreak: progress.longestStreak,
      todayRead: progress.todayRead,
      percentComplete: Math.round((progress.totalDaysRead / 365) * 100),
      recentReadings: recentLogs.map(log => ({
        date: log.readDate,
        dayNumber: log.dayNumber,
        isFavorite: log.isFavorite,
      })),
    });
  } catch (error) {
    logger.error("Error fetching devotional progress:", error);
    res.status(500).json({ message: "Failed to fetch devotional progress" });
  }
});

// POST /api/devotionals/favorite/:logId - Toggle favorite status
router.post("/favorite/:logId", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user as any;
    const { logId } = req.params;
    const { isFavorite } = req.body;

    const logs = await storage.getDevotionalReadingLogs(user.employeeId);
    const log = logs.find(l => l.id === logId);

    if (!log) {
      return res.status(404).json({ message: "Reading log not found" });
    }

    await storage.updateDevotionalReadingLog(logId, { isFavorite });

    res.json({ success: true, isFavorite });
  } catch (error) {
    logger.error("Error toggling favorite:", error);
    res.status(500).json({ message: "Failed to update favorite status" });
  }
});

// GET /api/devotionals/favorites - Get all favorite devotionals
router.get("/favorites", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user as any;
    const favorites = await storage.getFavoriteDevotionals(user.employeeId);

    res.json(favorites);
  } catch (error) {
    logger.error("Error fetching favorites:", error);
    res.status(500).json({ message: "Failed to fetch favorites" });
  }
});

// GET /api/devotionals/:day - Get specific day's devotional
router.get("/:day", isAuthenticated, async (req, res) => {
  try {
    const day = parseInt(req.params.day);

    if (isNaN(day) || day < 1 || day > 365) {
      return res.status(400).json({ message: "Invalid day number (must be 1-365)" });
    }

    const devotional = await storage.getDevotionalByDay(day);

    if (!devotional) {
      return res.status(404).json({ message: "Devotional not found for this day" });
    }

    res.json(devotional);
  } catch (error) {
    logger.error("Error fetching devotional:", error);
    res.status(500).json({ message: "Failed to fetch devotional" });
  }
});

// ========================================
// ADMIN ENDPOINTS (for content management)
// ========================================

// GET /api/devotionals/admin/all - Get all devotionals (Admin/HR only)
router.get("/admin/all", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "devotionals.view_all", "devotionals.manage"), async (req, res) => {
  try {
    const allDevotionals = await storage.getDevotionals();
    res.json(allDevotionals);
  } catch (error) {
    logger.error("Error fetching all devotionals:", error);
    res.status(500).json({ message: "Failed to fetch devotionals" });
  }
});

// POST /api/devotionals/admin/create - Create a new devotional (Admin/HR only)
router.post("/admin/create", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "devotionals.manage"), async (req, res) => {
  try {
    const validated = insertDevotionalSchema.parse(req.body);

    // Check if day number already exists
    const existing = await storage.getDevotionalByDay(validated.dayNumber);
    if (existing) {
      return res.status(400).json({ message: `Devotional for day ${validated.dayNumber} already exists` });
    }

    const devotional = await storage.createDevotional(validated);
    res.status(201).json(devotional);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error creating devotional:", error);
    res.status(500).json({ message: "Failed to create devotional" });
  }
});

// PUT /api/devotionals/admin/:id - Update a devotional (Admin/HR only)
router.put("/admin/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "devotionals.manage"), async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    const existing = await storage.getDevotional(id);
    if (!existing) {
      return res.status(404).json({ message: "Devotional not found" });
    }

    const updated = await storage.updateDevotional(id, updates);
    res.json(updated);
  } catch (error) {
    logger.error("Error updating devotional:", error);
    res.status(500).json({ message: "Failed to update devotional" });
  }
});

// DELETE /api/devotionals/admin/:id - Delete a devotional (Admin only)
router.delete("/admin/:id", isAuthenticated, hasRoleOrPermission(["ADMIN"], "devotionals.manage"), async (req, res) => {
  try {
    const { id } = req.params;

    const existing = await storage.getDevotional(id);
    if (!existing) {
      return res.status(404).json({ message: "Devotional not found" });
    }

    await storage.deleteDevotional(id);
    res.json({ success: true, message: "Devotional deleted" });
  } catch (error) {
    logger.error("Error deleting devotional:", error);
    res.status(500).json({ message: "Failed to delete devotional" });
  }
});

// POST /api/devotionals/admin/bulk - Bulk create devotionals (Admin/HR only)
router.post("/admin/bulk", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "devotionals.manage"), async (req, res) => {
  try {
    const { devotionals: devotionalList } = req.body;

    if (!Array.isArray(devotionalList) || devotionalList.length === 0) {
      return res.status(400).json({ message: "devotionals array is required" });
    }

    const results = {
      created: 0,
      skipped: 0,
      errors: [] as string[],
    };

    for (const item of devotionalList) {
      try {
        const validated = insertDevotionalSchema.parse(item);
        const existing = await storage.getDevotionalByDay(validated.dayNumber);

        if (existing) {
          results.skipped++;
          continue;
        }

        await storage.createDevotional(validated);
        results.created++;
      } catch (e: any) {
        results.errors.push(`Day ${item.dayNumber}: ${e.message}`);
      }
    }

    res.json(results);
  } catch (error) {
    logger.error("Error bulk creating devotionals:", error);
    res.status(500).json({ message: "Failed to bulk create devotionals" });
  }
});

export default router;
