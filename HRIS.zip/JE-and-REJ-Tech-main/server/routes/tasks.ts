import { Router } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { insertTaskSchema, insertTaskCommentSchema } from "@shared/schema";
import { uploadPhoto, uploadFile } from "../utils/object-storage";
import logger from "../utils/logger";
import { notifyTaskAssigned, notifyTaskStatusChanged, notifyTaskComment, notifyTaskBlocked } from "../services/notification-triggers";

/**
 * Process photos for tasks - handles single photos, multiple photos (arrays), and base64 uploads
 * Returns a JSON string array of object storage keys, or a single key for backwards compatibility
 */
async function processTaskPhotos(photosInput: string | string[] | undefined, entityId: string): Promise<string | undefined> {
  if (!photosInput) return undefined;

  // Handle array of photos (multiple uploads)
  const photos = Array.isArray(photosInput) ? photosInput : [photosInput];
  const uploadedKeys: string[] = [];

  for (const photo of photos) {
    if (!photo) continue;

    // If it's a base64 data URI, upload it
    if (photo.startsWith("data:")) {
      const uploadResult = await uploadFile(photo, "task", entityId);
      if (uploadResult) {
        uploadedKeys.push(uploadResult.key);
      }
    } else {
      // Already an object storage key, keep it
      uploadedKeys.push(photo);
    }
  }

  if (uploadedKeys.length === 0) return undefined;
  if (uploadedKeys.length === 1) return uploadedKeys[0];
  return JSON.stringify(uploadedKeys);
}

const router = Router();

router.get("/", isAuthenticated, async (req, res) => {
  try {
    const { projectId, assignedToId } = req.query;
    let tasks;
    
    if (assignedToId) {
      tasks = await storage.getEmployeeTasks(assignedToId as string);
    } else {
      tasks = await storage.getTasks(projectId as string | undefined);
    }
    
    res.json(tasks);
  } catch (error) {
    logger.error("Error fetching tasks:", error);
    res.status(500).json({ message: "Failed to fetch tasks" });
  }
});

router.get("/:id", isAuthenticated, async (req, res) => {
  try {
    const [task, comments] = await Promise.all([
      storage.getTask(req.params.id),
      storage.getTaskComments(req.params.id),
    ]);
    
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }
    
    res.json({ ...task, comments });
  } catch (error) {
    logger.error("Error fetching task:", error);
    res.status(500).json({ message: "Failed to fetch task" });
  }
});

router.post("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR", "ENGINEER"], "projects.view", "projects.manage"), async (req, res) => {
  try {
    const validatedData = insertTaskSchema.parse(req.body);
    const tempId = `task-${Date.now()}`;

    // Process task photos (supports multiple photos)
    const processedPhotos = await processTaskPhotos(
      (req.body.completionPhotoUrl || req.body.completionPhotos) as string | string[] | undefined,
      tempId
    );
    if (processedPhotos) {
      validatedData.completionPhotoUrl = processedPhotos;
    }

    const task = await storage.createTask(validatedData);

    // Fire-and-forget: notify assigned employee
    if (task.assignedToId) {
      notifyTaskAssigned({
        assigneeId: task.assignedToId,
        assignedBy: req.session.user?.employeeId || "",
        taskTitle: task.title,
        taskId: task.id,
      }).catch(() => {});
    }

    res.status(201).json(task);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error creating task:", error);
    res.status(500).json({ message: "Failed to create task" });
  }
});

router.patch("/:id", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user;
    const isAdminOrHR = user?.role === "ADMIN" || user?.role === "HR" || user?.role === "ENGINEER";

    // SECURITY FIX: Non-admin/HR/Engineer users can only update tasks assigned to them
    if (!isAdminOrHR) {
      const existingTask = await storage.getTask(req.params.id);
      if (!existingTask) {
        return res.status(404).json({ message: "Task not found" });
      }
      if (existingTask.assignedToId !== user?.employeeId) {
        return res.status(403).json({ message: "You can only update tasks assigned to you" });
      }
    }

    const partialTaskSchema = insertTaskSchema.partial();
    const validatedData = partialTaskSchema.parse(req.body);

    if (validatedData.status === "Done") {
      validatedData.completedDate = new Date().toISOString().slice(0, 10);
    }

    // Process task photos (supports multiple photos)
    const processedPhotos = await processTaskPhotos(
      (req.body.completionPhotoUrl || req.body.completionPhotos) as string | string[] | undefined,
      req.params.id
    );
    if (processedPhotos) {
      validatedData.completionPhotoUrl = processedPhotos;
    }

    const task = await storage.updateTask(req.params.id, validatedData);
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    // Fire-and-forget: notify relevant people of status change
    if (validatedData.status && task) {
      (async () => {
        const changer = await storage.getEmployee(user?.employeeId || "");
        const changerName = changer ? `${changer.firstName} ${changer.lastName}` : "Unknown";
        const recipientIds: string[] = [];
        if (task.assignedToId && task.assignedToId !== user?.employeeId) recipientIds.push(task.assignedToId);
        if (recipientIds.length > 0) {
          await notifyTaskStatusChanged({
            taskId: task.id,
            taskTitle: task.title,
            newStatus: validatedData.status!,
            changedBy: user?.employeeId || "",
            changedByName: changerName,
            recipientIds,
          });
        }
        if (validatedData.status === "Blocked") {
          await notifyTaskBlocked({
            assigneeId: task.assignedToId || "",
            taskTitle: task.title,
            taskId: task.id,
            blockedBy: changerName,
          });
        }
      })().catch(() => {});
    }

    res.json(task);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error updating task:", error);
    res.status(500).json({ message: "Failed to update task" });
  }
});

router.delete("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR", "ENGINEER"], "projects.view", "projects.manage"), async (req, res) => {
  try {
    await storage.deleteTask(req.params.id);
    res.status(204).send();
  } catch (error) {
    logger.error("Error deleting task:", error);
    res.status(500).json({ message: "Failed to delete task" });
  }
});

router.post("/:id/comments", isAuthenticated, async (req, res) => {
  try {
    const validatedData = insertTaskCommentSchema.parse({
      ...req.body,
      taskId: req.params.id,
    });

    // Process comment attachment if provided (supports single or multiple photos)
    if (req.body.attachmentUrl) {
      const processedAttachment = await processTaskPhotos(
        req.body.attachmentUrl as string | string[],
        `comment-${req.params.id}-${Date.now()}`
      );
      if (processedAttachment) {
        validatedData.attachmentUrl = processedAttachment;
      }
    }

    const comment = await storage.createTaskComment(validatedData);

    // Fire-and-forget: notify task assignee of new comment
    (async () => {
      const task = await storage.getTask(req.params.id);
      if (!task) return;
      const author = await storage.getEmployee(comment.authorId);
      const authorName = author ? `${author.firstName} ${author.lastName}` : "Unknown";
      const recipientIds: string[] = [];
      if (task.assignedToId && task.assignedToId !== comment.authorId) recipientIds.push(task.assignedToId);
      if (recipientIds.length > 0) {
        await notifyTaskComment({
          taskId: task.id,
          taskTitle: task.title,
          commentBy: comment.authorId,
          commentByName: authorName,
          recipientIds,
        });
      }
    })().catch(() => {});

    res.status(201).json(comment);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error creating comment:", error);
    res.status(500).json({ message: "Failed to create comment" });
  }
});

export default router;
