import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { insertLoanSchema, loanTypeEnum } from "@shared/schema";
import { z } from "zod";
import { loanSchema, validateBody } from "../validation/schemas";
import logger from "../utils/logger";
import { notifyLoanUpdate, notifyNewRequestPending, notifyLoanSubmittedOnBehalf } from "../services/notification-triggers";

const router = Router();

// Get all loans (filtered by role)
router.get("/", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user as any;
    const { employeeId, status, loanType } = req.query;

    let allLoans;
    // Role-based filtering: HR/Admin see all, employees see only their own
    if (user.role === "ADMIN" || user.role === "HR") {
      allLoans = await storage.getLoans(employeeId as string | undefined);
    } else {
      // Regular employees only see their own loans
      allLoans = await storage.getLoans(user.employeeId);
    }

    // Apply additional filters
    let filteredLoans = allLoans;
    if (status) {
      filteredLoans = filteredLoans.filter(l => l.status === status);
    }
    if (loanType) {
      filteredLoans = filteredLoans.filter(l => l.loanType === loanType);
    }

    res.json(filteredLoans);
  } catch (error) {
    logger.error("Error fetching loans:", error);
    res.status(500).json({ message: "Failed to fetch loans" });
  }
});

// Get single loan
router.get("/:id", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user as any;
    const loan = await storage.getLoan(req.params.id);

    if (!loan) {
      return res.status(404).json({ message: "Loan not found" });
    }

    // Check access rights
    if (user.role !== "ADMIN" && user.role !== "HR" && loan.employeeId !== user.employeeId) {
      return res.status(403).json({ message: "Access denied" });
    }

    res.json(loan);
  } catch (error) {
    logger.error("Error fetching loan:", error);
    res.status(500).json({ message: "Failed to fetch loan" });
  }
});

// Create loan (HR/Admin only - for creating on behalf of employee)
router.post("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve", "cash_advances.disburse"), async (req, res) => {
  try {
    const user = req.session.user as any;
    const { amount, interest = "0", ...rest } = req.body;
    const amountNum = parseFloat(amount);
    const interestNum = parseFloat(interest);
    const totalAmount = amountNum + interestNum;

    // Verify the target employee exists
    const targetEmployeeId = rest.employeeId;
    if (targetEmployeeId) {
      const targetEmployee = await storage.getEmployee(targetEmployeeId);
      if (!targetEmployee) {
        return res.status(400).json({ message: "Target employee not found" });
      }
    }

    // Determine if this is an on-behalf submission
    const isOnBehalf = targetEmployeeId && targetEmployeeId !== user.employeeId;

    const validated = insertLoanSchema.parse({
      ...rest,
      amount,
      interest: interest.toString(),
      totalAmount: totalAmount.toString(),
      remainingBalance: totalAmount.toString(),
      status: "Pending",
      submittedById: user.employeeId, // Track who submitted
    });

    const loan = await storage.createLoan(validated);

    // Notify admins of new loan request
    const employee = await storage.getEmployee(loan.employeeId);
    const employeeName = employee ? `${employee.firstName} ${employee.lastName}` : "Unknown";
    notifyNewRequestPending({
      employeeId: loan.employeeId,
      employeeName,
      requestType: "loan",
      amount: loan.amount as string,
      requestId: loan.id,
    }).catch(() => {});

    // If on-behalf submission, notify the employee
    if (isOnBehalf) {
      notifyLoanSubmittedOnBehalf({
        employeeId: loan.employeeId,
        submittedById: user.employeeId,
        submitterName: `${user.firstName} ${user.lastName}`,
        amount: loan.amount as string,
        loanType: loan.loanType,
        loanId: loan.id,
      }).catch(() => {});
    }

    res.status(201).json(loan);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error creating loan:", error);
    res.status(500).json({ message: "Failed to create loan" });
  }
});

// Approve loan (HR/Admin only)
router.post("/:id/approve", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve", "cash_advances.disburse"), async (req, res) => {
  try {
    const user = req.session.user as any;

    // Validate loan parameters
    const validation = validateBody(loanSchema, {
      deductionPerCutoff: parseFloat(req.body.deductionPerCutoff),
      interest: req.body.interest !== undefined ? parseFloat(req.body.interest) : 0
    });
    if (!validation.success) {
      return res.status(400).json({ message: "Validation failed", errors: validation.errors });
    }

    const { deductionPerCutoff, interest } = validation.data;
    const { remarks, startDeductionDate } = req.body;

    const existingLoan = await storage.getLoan(req.params.id);
    if (!existingLoan) {
      return res.status(404).json({ message: "Loan not found" });
    }

    if (existingLoan.status !== "Pending") {
      return res.status(400).json({
        message: `Cannot approve loan with status: ${existingLoan.status}`
      });
    }

    // Calculate total amount with interest if interest is updated at approval
    let totalAmount = parseFloat(existingLoan.totalAmount as any);
    let newInterest = existingLoan.interest;

    if (interest !== undefined && interest !== null) {
      const interestNum = typeof interest === "number" ? interest : parseFloat(interest);
      const amountNum = parseFloat(existingLoan.amount as any);
      totalAmount = amountNum + interestNum;
      newInterest = interest.toString();
    }

    const deduction = typeof deductionPerCutoff === "number" ? deductionPerCutoff : parseFloat(deductionPerCutoff);
    if (deduction > totalAmount) {
      return res.status(400).json({
        message: "Deduction per cutoff cannot be greater than the total amount"
      });
    }

    const loan = await storage.updateLoan(req.params.id, {
      status: "Approved",
      approvedById: user.employeeId,
      deductionPerCutoff: deductionPerCutoff.toString(),
      interest: newInterest,
      totalAmount: totalAmount.toString(),
      remainingBalance: totalAmount.toString(),
      remarks: remarks || null,
      startDeductionDate: startDeductionDate || null,
    } as any);

    // Create audit log
    await storage.createAuditLog({
      userId: user.employeeId,
      action: "APPROVE",
      entityType: "Loan",
      entityId: req.params.id,
      newValues: { status: "Approved", deductionPerCutoff, interest: newInterest, totalAmount },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    // Notify employee of approval
    notifyLoanUpdate({
      employeeId: existingLoan.employeeId,
      processedBy: user.employeeId,
      status: "Approved",
      amount: existingLoan.amount as string,
      loanId: req.params.id,
    }).catch(() => {});

    res.json(loan);
  } catch (error) {
    logger.error("Error approving loan:", error);
    res.status(500).json({ message: "Failed to approve loan" });
  }
});

// Reject loan (HR/Admin only)
router.post("/:id/reject", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve", "cash_advances.disburse"), async (req, res) => {
  try {
    const user = req.session.user as any;
    const { remarks } = req.body;

    const existingLoan = await storage.getLoan(req.params.id);
    if (!existingLoan) {
      return res.status(404).json({ message: "Loan not found" });
    }

    if (existingLoan.status !== "Pending") {
      return res.status(400).json({
        message: `Cannot reject loan with status: ${existingLoan.status}`
      });
    }

    const loan = await storage.updateLoan(req.params.id, {
      status: "Rejected",
      approvedById: user.employeeId,
      remarks: remarks || null,
    } as any);

    // Create audit log
    await storage.createAuditLog({
      userId: user.employeeId,
      action: "REJECT",
      entityType: "Loan",
      entityId: req.params.id,
      newValues: { status: "Rejected", remarks },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    // Notify employee of rejection
    notifyLoanUpdate({
      employeeId: existingLoan.employeeId,
      processedBy: user.employeeId,
      status: "Rejected",
      amount: existingLoan.amount as string,
      loanId: req.params.id,
    }).catch(() => {});

    res.json(loan);
  } catch (error) {
    logger.error("Error rejecting loan:", error);
    res.status(500).json({ message: "Failed to reject loan" });
  }
});

// Disburse loan (HR/Admin only - mark as disbursed)
router.post("/:id/disburse", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve", "cash_advances.disburse"), async (req, res) => {
  try {
    const user = req.session.user as any;
    const existingLoan = await storage.getLoan(req.params.id);

    if (!existingLoan) {
      return res.status(404).json({ message: "Loan not found" });
    }

    if (existingLoan.status !== "Approved") {
      return res.status(400).json({
        message: `Cannot disburse loan with status: ${existingLoan.status}. Must be Approved first.`
      });
    }

    const loan = await storage.updateLoan(req.params.id, {
      status: "Disbursed",
      remainingBalance: existingLoan.totalAmount, // Start with full total amount
    } as any);

    // Create audit log
    await storage.createAuditLog({
      userId: user.employeeId,
      action: "DISBURSE",
      entityType: "Loan",
      entityId: req.params.id,
      newValues: { status: "Disbursed", remainingBalance: existingLoan.totalAmount },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    // Notify employee of disbursement
    notifyLoanUpdate({
      employeeId: existingLoan.employeeId,
      processedBy: user.employeeId,
      status: "Disbursed",
      amount: existingLoan.amount as string,
      loanId: req.params.id,
    }).catch(() => {});

    res.json(loan);
  } catch (error) {
    logger.error("Error disbursing loan:", error);
    res.status(500).json({ message: "Failed to disburse loan" });
  }
});

// Update loan schema with explicit field whitelist
const loanUpdateSchema = z.object({
  amount: z.string().optional(),
  interest: z.string().optional(),
  reason: z.string().optional(),
  deductionPerCutoff: z.string().optional(),
  startDeductionDate: z.string().nullable().optional(),
  remarks: z.string().nullable().optional(),
}).strict();

// Update loan (HR/Admin only - for general edits)
router.patch("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "cash_advances.view_all", "cash_advances.approve", "cash_advances.disburse"), async (req, res) => {
  try {
    // Validate and whitelist allowed fields
    const validationResult = loanUpdateSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: "Validation failed",
        errors: validationResult.error.errors
      });
    }

    const updates = validationResult.data;

    // Prevent direct status changes via PATCH - use dedicated endpoints
    if ((req.body as any).status) {
      return res.status(400).json({
        message: "Use dedicated endpoints: /approve, /reject, or /disburse to change status"
      });
    }

    // Recalculate total if amount or interest changes
    const existingLoan = await storage.getLoan(req.params.id);
    if (!existingLoan) {
      return res.status(404).json({ message: "Loan not found" });
    }

    let finalUpdates: any = { ...updates };
    if (updates.amount || updates.interest) {
      const amount = parseFloat(updates.amount || (existingLoan.amount as any));
      const interest = parseFloat(updates.interest || (existingLoan.interest as any) || "0");
      finalUpdates.totalAmount = (amount + interest).toString();

      // If not yet disbursed, also update remaining balance
      if (existingLoan.status === "Pending" || existingLoan.status === "Approved") {
        finalUpdates.remainingBalance = finalUpdates.totalAmount;
      }
    }

    const loan = await storage.updateLoan(req.params.id, finalUpdates);
    res.json(loan);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error updating loan:", error);
    res.status(500).json({ message: "Failed to update loan" });
  }
});

// Get payment history for a loan
router.get("/:id/payments", isAuthenticated, async (req, res) => {
  try {
    const payments = await storage.getLoanPayments(req.params.id);
    res.json(payments);
  } catch (error) {
    logger.error("Error fetching loan payments:", error);
    res.status(500).json({ message: "Failed to fetch payment history" });
  }
});

// Get loan types (static list)
router.get("/types/list", isAuthenticated, async (req, res) => {
  try {
    const types = loanTypeEnum.map(type => ({
      value: type,
      label: type.replace(/_/g, " "),
    }));
    res.json(types);
  } catch (error) {
    logger.error("Error fetching loan types:", error);
    res.status(500).json({ message: "Failed to fetch loan types" });
  }
});

export default router;
