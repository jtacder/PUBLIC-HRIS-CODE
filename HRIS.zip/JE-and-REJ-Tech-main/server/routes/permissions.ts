import { Router } from "express";
import { db } from "../db";
import {
  permissions,
  roles,
  rolePermissions,
  userPermissions,
  employees,
  type InsertRole,
  type InsertPermission,
} from "@shared/schema";
import { eq, and, desc, count } from "drizzle-orm";
import { isAuthenticated } from "../email-auth";
import { hasPermission, isSuperadmin } from "../middleware/permissions";
import { permissionService } from "../services/permission-service";
import { notifyPermissionChange, notifyRoleChanged } from "../services/notification-triggers";
import { logger } from "../utils/logger";
import { z } from "zod";

const router = Router();

// ============================================
// PERMISSIONS ENDPOINTS
// ============================================

/**
 * GET /api/permissions
 * Get all available permissions
 */
router.get("/", isAuthenticated, hasPermission("permissions.view"), async (req, res) => {
  try {
    const allPermissions = await permissionService.getAllPermissions();
    res.json(allPermissions);
  } catch (error) {
    logger.error("Error fetching permissions", error);
    res.status(500).json({ message: "Failed to fetch permissions" });
  }
});

/**
 * GET /api/permissions/grouped
 * Get permissions grouped by category and feature
 */
router.get("/grouped", isAuthenticated, hasPermission("permissions.view"), async (req, res) => {
  try {
    const grouped = await permissionService.getPermissionsGrouped();
    res.json(grouped);
  } catch (error) {
    logger.error("Error fetching grouped permissions", error);
    res.status(500).json({ message: "Failed to fetch grouped permissions" });
  }
});

/**
 * GET /api/permissions/my
 * Get current user's effective permissions
 */
router.get("/my", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user!;
    const userPerms = await permissionService.getUserPermissions(user.employeeId);

    res.json({
      permissions: userPerms.permissions,
      isSuperadmin: userPerms.isSuperadmin,
      roleId: userPerms.roleId,
    });
  } catch (error) {
    logger.error("Error fetching user permissions", error);
    res.status(500).json({ message: "Failed to fetch permissions" });
  }
});

// ============================================
// ROLES ENDPOINTS
// ============================================

/**
 * GET /api/permissions/roles
 * Get all roles
 */
router.get("/roles", isAuthenticated, hasPermission("permissions.view"), async (req, res) => {
  try {
    const allRoles = await permissionService.getAllRoles();

    // Get employee count for each role
    const rolesWithCount = await Promise.all(
      allRoles.map(async (role) => {
        const [result] = await db
          .select({ count: count() })
          .from(employees)
          .where(eq(employees.roleId, role.id));

        return {
          ...role,
          employeeCount: result?.count ?? 0,
        };
      })
    );

    res.json(rolesWithCount);
  } catch (error) {
    logger.error("Error fetching roles", error);
    res.status(500).json({ message: "Failed to fetch roles" });
  }
});

/**
 * GET /api/permissions/roles/:id
 * Get role with its permissions
 */
router.get("/roles/:id", isAuthenticated, hasPermission("permissions.view"), async (req, res) => {
  try {
    const { id } = req.params;
    const roleData = await permissionService.getRoleWithPermissions(id);

    if (!roleData) {
      return res.status(404).json({ message: "Role not found" });
    }

    res.json(roleData);
  } catch (error) {
    logger.error("Error fetching role", error);
    res.status(500).json({ message: "Failed to fetch role" });
  }
});

/**
 * POST /api/permissions/roles
 * Create a new role (Superadmin only)
 */
router.post("/roles", isAuthenticated, isSuperadmin, async (req, res) => {
  try {
    const schema = z.object({
      name: z.string().min(1).max(50).regex(/^[A-Z_]+$/, "Name must be uppercase with underscores only"),
      displayName: z.string().min(1).max(100),
      description: z.string().optional(),
      isSuperadmin: z.boolean().optional().default(false),
      permissionIds: z.array(z.string()).optional().default([]),
    });

    const data = schema.parse(req.body);

    // Check if role name already exists
    const [existing] = await db
      .select()
      .from(roles)
      .where(eq(roles.name, data.name))
      .limit(1);

    if (existing) {
      return res.status(400).json({ message: "Role name already exists" });
    }

    // Create role
    const [newRole] = await db
      .insert(roles)
      .values({
        name: data.name,
        displayName: data.displayName,
        description: data.description,
        isSuperadmin: data.isSuperadmin,
        isSystemRole: false,
      })
      .returning();

    // Add permissions if provided (updateRolePermissions handles insert + audit logging)
    // Wrapped in try-catch so permission failures don't block role creation response
    const user = req.session.user!;
    if (data.permissionIds.length > 0) {
      try {
        await permissionService.updateRolePermissions(
          newRole.id,
          data.permissionIds,
          user.employeeId,
          req.ip,
          req.get("user-agent")
        );
      } catch (permError) {
        // Log error but don't fail the request - role was created successfully
        logger.error("Error adding permissions to new role", { roleId: newRole.id, error: permError });
      }
    }

    res.status(201).json(newRole);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error creating role", error);
    res.status(500).json({ message: "Failed to create role" });
  }
});

/**
 * PUT /api/permissions/roles/:id
 * Update a role
 */
router.put("/roles/:id", isAuthenticated, isSuperadmin, async (req, res) => {
  try {
    const { id } = req.params;

    const schema = z.object({
      displayName: z.string().min(1).max(100).optional(),
      description: z.string().optional(),
    });

    const data = schema.parse(req.body);

    // Check if role exists and is not a system role
    const [role] = await db
      .select()
      .from(roles)
      .where(eq(roles.id, id))
      .limit(1);

    if (!role) {
      return res.status(404).json({ message: "Role not found" });
    }

    // Update role
    const [updated] = await db
      .update(roles)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(roles.id, id))
      .returning();

    res.json(updated);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error updating role", error);
    res.status(500).json({ message: "Failed to update role" });
  }
});

/**
 * DELETE /api/permissions/roles/:id
 * Delete a role (Superadmin only, cannot delete system roles)
 */
router.delete("/roles/:id", isAuthenticated, isSuperadmin, async (req, res) => {
  try {
    const { id } = req.params;

    // Check if role exists
    const [role] = await db
      .select()
      .from(roles)
      .where(eq(roles.id, id))
      .limit(1);

    if (!role) {
      return res.status(404).json({ message: "Role not found" });
    }

    if (role.isSystemRole) {
      return res.status(400).json({ message: "Cannot delete system roles" });
    }

    // Check if role has any users
    const [result] = await db
      .select({ count: count() })
      .from(employees)
      .where(eq(employees.roleId, id));

    const employeeCount = result?.count ?? 0;
    if (employeeCount > 0) {
      return res.status(400).json({
        message: `Cannot delete role. ${employeeCount} employee(s) are assigned to this role.`,
      });
    }

    // Delete role (cascade will handle rolePermissions)
    await db.delete(roles).where(eq(roles.id, id));

    res.json({ message: "Role deleted successfully" });
  } catch (error) {
    logger.error("Error deleting role", error);
    res.status(500).json({ message: "Failed to delete role" });
  }
});

/**
 * PUT /api/permissions/roles/:id/permissions
 * Update role's permissions
 */
router.put("/roles/:id/permissions", isAuthenticated, isSuperadmin, async (req, res) => {
  try {
    const { id } = req.params;

    const schema = z.object({
      permissionIds: z.array(z.string()),
    });

    const { permissionIds } = schema.parse(req.body);

    // Check if role exists
    const [role] = await db
      .select()
      .from(roles)
      .where(eq(roles.id, id))
      .limit(1);

    if (!role) {
      return res.status(404).json({ message: "Role not found" });
    }

    const user = req.session.user!;

    await permissionService.updateRolePermissions(
      id,
      permissionIds,
      user.employeeId,
      req.ip,
      req.get("user-agent")
    );

    res.json({ message: "Role permissions updated successfully" });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error updating role permissions", error);
    res.status(500).json({ message: "Failed to update role permissions" });
  }
});

// ============================================
// USER PERMISSIONS ENDPOINTS
// ============================================

/**
 * GET /api/permissions/employees/:id
 * Get employee's permission details
 */
router.get(
  "/employees/:id",
  isAuthenticated,
  hasPermission("permissions.view"),
  async (req, res) => {
    try {
      const { id } = req.params;

      const details = await permissionService.getEmployeePermissionDetails(id);

      res.json(details);
    } catch (error) {
      logger.error("Error fetching employee permissions", error);
      res.status(500).json({ message: "Failed to fetch employee permissions" });
    }
  }
);

/**
 * PUT /api/permissions/employees/:id/role
 * Change employee's role
 */
router.put(
  "/employees/:id/role",
  isAuthenticated,
  hasPermission("permissions.manage"),
  async (req, res) => {
    try {
      const { id } = req.params;

      const schema = z.object({
        roleId: z.string().nullable(),
      });

      const { roleId } = schema.parse(req.body);

      // If setting a superadmin role, require superadmin privileges
      if (roleId) {
        const [role] = await db
          .select()
          .from(roles)
          .where(eq(roles.id, roleId))
          .limit(1);

        if (role?.isSuperadmin) {
          const isSuperAdmin = await permissionService.isSuperadmin(
            req.session.user!.employeeId
          );
          if (!isSuperAdmin) {
            return res.status(403).json({
              message: "Only superadmins can assign superadmin roles",
            });
          }
        }
      }

      const user = req.session.user!;

      await permissionService.changeUserRole(
        id,
        roleId,
        user.employeeId,
        req.ip,
        req.get("user-agent")
      );

      // Fire-and-forget notification
      (async () => {
        let newRoleName = "No Role";
        if (roleId) {
          const [r] = await db
            .select({ displayName: roles.displayName })
            .from(roles)
            .where(eq(roles.id, roleId))
            .limit(1);
          newRoleName = r?.displayName ?? "Unknown";
        }
        await notifyRoleChanged({
          employeeId: id,
          changedBy: user.employeeId,
          newRole: newRoleName,
        });
      })().catch(() => {});

      res.json({ message: "Employee role updated successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      logger.error("Error updating employee role", error);
      res.status(500).json({ message: "Failed to update employee role" });
    }
  }
);

/**
 * PUT /api/permissions/employees/:id/permissions
 * Update employee's individual permissions
 */
router.put(
  "/employees/:id/permissions",
  isAuthenticated,
  hasPermission("permissions.manage"),
  async (req, res) => {
    try {
      const { id } = req.params;

      const schema = z.object({
        permissionIds: z.array(z.string()),
      });

      const { permissionIds } = schema.parse(req.body);

      const user = req.session.user!;

      await permissionService.updateUserPermissions(
        id,
        permissionIds,
        user.employeeId,
        req.ip,
        req.get("user-agent")
      );

      res.json({ message: "Employee permissions updated successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      logger.error("Error updating employee permissions", error);
      res.status(500).json({ message: "Failed to update employee permissions" });
    }
  }
);

/**
 * POST /api/permissions/employees/:id/grant
 * Grant a specific permission to an employee
 */
router.post(
  "/employees/:id/grant",
  isAuthenticated,
  hasPermission("permissions.manage"),
  async (req, res) => {
    try {
      const { id } = req.params;

      const schema = z.object({
        permissionId: z.string(),
        expiresAt: z.string().datetime().optional(),
      });

      const data = schema.parse(req.body);

      const user = req.session.user!;

      await permissionService.grantPermission(
        id,
        data.permissionId,
        user.employeeId,
        data.expiresAt ? new Date(data.expiresAt) : undefined,
        req.ip,
        req.get("user-agent")
      );

      // Fire-and-forget notification
      (async () => {
        const [perm] = await db
          .select({ name: permissions.name })
          .from(permissions)
          .where(eq(permissions.id, data.permissionId))
          .limit(1);
        await notifyPermissionChange({
          employeeId: id,
          changedBy: user.employeeId,
          action: "granted",
          permissionName: perm?.name ?? data.permissionId,
        });
      })().catch(() => {});

      res.json({ message: "Permission granted successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      logger.error("Error granting permission", error);
      res.status(500).json({ message: "Failed to grant permission" });
    }
  }
);

/**
 * POST /api/permissions/employees/:id/revoke
 * Revoke a specific permission from an employee
 */
router.post(
  "/employees/:id/revoke",
  isAuthenticated,
  hasPermission("permissions.manage"),
  async (req, res) => {
    try {
      const { id } = req.params;

      const schema = z.object({
        permissionId: z.string(),
      });

      const { permissionId } = schema.parse(req.body);

      const user = req.session.user!;

      await permissionService.revokePermission(
        id,
        permissionId,
        user.employeeId,
        req.ip,
        req.get("user-agent")
      );

      // Fire-and-forget notification
      (async () => {
        const [perm] = await db
          .select({ name: permissions.name })
          .from(permissions)
          .where(eq(permissions.id, permissionId))
          .limit(1);
        await notifyPermissionChange({
          employeeId: id,
          changedBy: user.employeeId,
          action: "revoked",
          permissionName: perm?.name ?? permissionId,
        });
      })().catch(() => {});

      res.json({ message: "Permission revoked successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      logger.error("Error revoking permission", error);
      res.status(500).json({ message: "Failed to revoke permission" });
    }
  }
);

/**
 * GET /api/permissions/employees-with-roles
 * Get all employees with their roles for the permission management UI
 */
router.get(
  "/employees-with-roles",
  isAuthenticated,
  hasPermission("permissions.view"),
  async (req, res) => {
    try {
      const employeesWithRoles = await db
        .select({
          id: employees.id,
          firstName: employees.firstName,
          lastName: employees.lastName,
          email: employees.email,
          position: employees.position,
          department: employees.department,
          role: employees.role, // Legacy role
          roleId: employees.roleId,
          status: employees.status,
        })
        .from(employees)
        .where(eq(employees.status, "Active"))
        .orderBy(employees.lastName, employees.firstName);

      // Get role details for each employee
      const result = await Promise.all(
        employeesWithRoles.map(async (emp) => {
          let assignedRole = null;
          let individualPermissionCount = 0;

          if (emp.roleId) {
            const [role] = await db
              .select()
              .from(roles)
              .where(eq(roles.id, emp.roleId))
              .limit(1);
            assignedRole = role || null;
          }

          // Count individual permissions
          const [permResult] = await db
            .select({ count: count() })
            .from(userPermissions)
            .where(eq(userPermissions.employeeId, emp.id));

          individualPermissionCount = permResult?.count ?? 0;

          return {
            ...emp,
            assignedRole,
            individualPermissionCount,
          };
        })
      );

      res.json(result);
    } catch (error) {
      logger.error("Error fetching employees with roles", error);
      res.status(500).json({ message: "Failed to fetch employees" });
    }
  }
);

/**
 * GET /api/permissions/audit-logs
 * Get permission audit logs
 */
router.get(
  "/audit-logs",
  isAuthenticated,
  hasPermission("permissions.view", "audit.view"),
  async (req, res) => {
    try {
      const logs = await permissionService.getPermissionAuditLogs({
        limit: 100,
      });

      res.json(logs);
    } catch (error) {
      logger.error("Error fetching permission audit logs", error);
      res.status(500).json({ message: "Failed to fetch audit logs" });
    }
  }
);

/**
 * GET /api/permissions/roles/:id/diagnostics
 * Get diagnostic information about a role's permissions
 */
router.get(
  "/roles/:id/diagnostics",
  isAuthenticated,
  hasPermission("permissions.view"),
  async (req, res) => {
    try {
      const { id } = req.params;

      // Get role
      const [role] = await db
        .select()
        .from(roles)
        .where(eq(roles.id, id))
        .limit(1);

      if (!role) {
        return res.status(404).json({ message: "Role not found" });
      }

      // Get role permissions count
      const rolePerms = await db
        .select({ permissionId: rolePermissions.permissionId })
        .from(rolePermissions)
        .where(eq(rolePermissions.roleId, id));

      // Get employees with this role
      const employeesWithRole = await db
        .select({
          id: employees.id,
          firstName: employees.firstName,
          lastName: employees.lastName,
          email: employees.email,
        })
        .from(employees)
        .where(eq(employees.roleId, id));

      res.json({
        role,
        permissionCount: rolePerms.length,
        hasPermissions: rolePerms.length > 0,
        employeeCount: employeesWithRole.length,
        employees: employeesWithRole,
        warning: rolePerms.length === 0
          ? "This role has NO permissions assigned! Users with this role will have no access."
          : null,
      });
    } catch (error) {
      logger.error("Error fetching role diagnostics", error);
      res.status(500).json({ message: "Failed to fetch role diagnostics" });
    }
  }
);

/**
 * POST /api/permissions/roles/:id/sync
 * Sync role permissions with predefined permission set
 * This fixes cases where a role exists but has no permissions
 */
router.post(
  "/roles/:id/sync",
  isAuthenticated,
  isSuperadmin,
  async (req, res) => {
    try {
      const { id } = req.params;

      const schema = z.object({
        permissionCodes: z.array(z.string()),
      });

      const { permissionCodes } = schema.parse(req.body);

      // Check if role exists
      const [role] = await db
        .select()
        .from(roles)
        .where(eq(roles.id, id))
        .limit(1);

      if (!role) {
        return res.status(404).json({ message: "Role not found" });
      }

      const user = req.session.user!;

      const result = await permissionService.syncRolePermissions(
        id,
        permissionCodes,
        user.employeeId,
        req.ip,
        req.get("user-agent")
      );

      res.json({
        message: `Synced permissions for role ${role.displayName}`,
        added: result.added,
        existing: result.existing,
        total: result.added + result.existing,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      logger.error("Error syncing role permissions", error);
      res.status(500).json({ message: "Failed to sync role permissions" });
    }
  }
);

/**
 * POST /api/permissions/clear-cache
 * Clear permission cache for current user or all users
 */
router.post(
  "/clear-cache",
  isAuthenticated,
  async (req, res) => {
    try {
      const { all } = req.body;
      const user = req.session.user!;

      if (all) {
        // Only superadmins can clear all cache
        const isSuperAdmin = await permissionService.isSuperadmin(user.employeeId);
        if (!isSuperAdmin) {
          return res.status(403).json({ message: "Only superadmins can clear all cache" });
        }
        permissionService.clearCache();
        res.json({ message: "All permission caches cleared" });
      } else {
        // Clear only current user's cache
        permissionService.invalidateCache(user.employeeId);
        res.json({ message: "Your permission cache cleared" });
      }
    } catch (error) {
      logger.error("Error clearing permission cache", error);
      res.status(500).json({ message: "Failed to clear cache" });
    }
  }
);

/**
 * GET /api/permissions/my/refresh
 * Refresh and return current user's permissions (bypasses cache)
 */
router.get("/my/refresh", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user!;

    // Clear cache first
    permissionService.invalidateCache(user.employeeId);

    // Get fresh permissions
    const userPerms = await permissionService.getUserPermissions(user.employeeId);

    res.json({
      permissions: userPerms.permissions,
      isSuperadmin: userPerms.isSuperadmin,
      roleId: userPerms.roleId,
      message: "Permissions refreshed from database",
    });
  } catch (error) {
    logger.error("Error refreshing user permissions", error);
    res.status(500).json({ message: "Failed to refresh permissions" });
  }
});

export default router;
