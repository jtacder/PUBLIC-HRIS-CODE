import { Router } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { db } from "../db";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { calculateEnhancedPayroll } from "../payroll-calculator";
import { payrollComputeSchema } from "../utils/validation";
import { config } from "../config";
import logger from "../utils/logger";
import { updateThirteenthMonthAccrualForPayroll, syncThirteenthMonthAccrualOnRevert } from "./thirteenth-month";
import { notifyPayrollReleased, notifyPayrollDraftReady } from "../services/notification-triggers";
import { runPayrollReconciliation, applyReconciliationFixes } from "../services/payroll-reconciliation";

// =============================================================================
// PAYROLL DEDUCTION PROCESSING HELPERS
// =============================================================================

/**
 * Apply cash advance deductions with idempotency check.
 * Only processes payments that haven't been applied yet (deductionApplied = false).
 * Throws an error if a referenced cash advance is missing.
 */
async function applyCashAdvanceDeductions(payrollRecordId: string): Promise<{ applied: number; skipped: number; errors: string[] }> {
  const caPayments = await storage.getCashAdvancePaymentsByPayrollRecord(payrollRecordId);
  let applied = 0;
  let skipped = 0;
  const errors: string[] = [];

  for (const payment of caPayments) {
    // Idempotency check: skip if already applied
    if ((payment as any).deductionApplied === true) {
      skipped++;
      continue;
    }

    const advance = await storage.getCashAdvance(payment.cashAdvanceId);
    if (!advance) {
      // CRITICAL: Referenced cash advance was deleted - this is a data integrity issue
      errors.push(`Cash advance ${payment.cashAdvanceId} not found for payment ${payment.id}`);
      continue;
    }

    const newBalance = parseFloat(String(payment.remainingBalanceAfter) || "0");
    await storage.updateCashAdvance(payment.cashAdvanceId, {
      remainingBalance: newBalance.toString(),
      status: newBalance === 0 ? "Fully_Paid" : "Disbursed",
    });

    // Mark payment as applied
    await storage.markCashAdvancePaymentApplied(payment.id);
    applied++;
  }

  return { applied, skipped, errors };
}

/**
 * Apply loan deductions with idempotency check.
 * Only processes payments that haven't been applied yet (deductionApplied = false).
 * Throws an error if a referenced loan is missing.
 */
async function applyLoanDeductions(payrollRecordId: string): Promise<{ applied: number; skipped: number; errors: string[] }> {
  const loanPayments = await storage.getLoanPaymentsByPayrollRecord(payrollRecordId);
  let applied = 0;
  let skipped = 0;
  const errors: string[] = [];

  for (const payment of loanPayments) {
    // Idempotency check: skip if already applied
    if ((payment as any).deductionApplied === true) {
      skipped++;
      continue;
    }

    const loan = await storage.getLoan(payment.loanId);
    if (!loan) {
      // CRITICAL: Referenced loan was deleted - this is a data integrity issue
      errors.push(`Loan ${payment.loanId} not found for payment ${payment.id}`);
      continue;
    }

    const newBalance = parseFloat(String(payment.remainingBalanceAfter) || "0");
    await storage.updateLoan(payment.loanId, {
      remainingBalance: newBalance.toString(),
      status: newBalance === 0 ? "Fully_Paid" : "Disbursed",
    });

    // Mark payment as applied
    await storage.markLoanPaymentApplied(payment.id);
    applied++;
  }

  return { applied, skipped, errors };
}

/**
 * Revert cash advance deductions with idempotency check.
 * Only reverts payments that were actually applied (deductionApplied = true).
 */
async function revertCashAdvanceDeductions(payrollRecordId: string): Promise<{ reverted: number; skipped: number; errors: string[] }> {
  const caPayments = await storage.getCashAdvancePaymentsByPayrollRecord(payrollRecordId);
  let reverted = 0;
  let skipped = 0;
  const errors: string[] = [];

  for (const payment of caPayments) {
    // Idempotency check: skip if not applied
    if ((payment as any).deductionApplied !== true) {
      skipped++;
      continue;
    }

    const advance = await storage.getCashAdvance(payment.cashAdvanceId);
    if (!advance) {
      // Cash advance was deleted - log but continue since we can't restore
      errors.push(`Cash advance ${payment.cashAdvanceId} not found - cannot restore balance`);
      continue;
    }

    const currentBalance = parseFloat(String(advance.remainingBalance) || "0");
    const deductedAmount = parseFloat(String(payment.deductionAmount) || "0");
    const restoredBalance = currentBalance + deductedAmount;

    await storage.updateCashAdvance(payment.cashAdvanceId, {
      remainingBalance: restoredBalance.toString(),
      status: "Disbursed",
    });

    // Mark payment as unapplied
    await storage.markCashAdvancePaymentUnapplied(payment.id);
    reverted++;
  }

  return { reverted, skipped, errors };
}

/**
 * Revert loan deductions with idempotency check.
 * Only reverts payments that were actually applied (deductionApplied = true).
 */
async function revertLoanDeductions(payrollRecordId: string): Promise<{ reverted: number; skipped: number; errors: string[] }> {
  const loanPayments = await storage.getLoanPaymentsByPayrollRecord(payrollRecordId);
  let reverted = 0;
  let skipped = 0;
  const errors: string[] = [];

  for (const payment of loanPayments) {
    // Idempotency check: skip if not applied
    if ((payment as any).deductionApplied !== true) {
      skipped++;
      continue;
    }

    const loan = await storage.getLoan(payment.loanId);
    if (!loan) {
      // Loan was deleted - log but continue since we can't restore
      errors.push(`Loan ${payment.loanId} not found - cannot restore balance`);
      continue;
    }

    const currentBalance = parseFloat(String(loan.remainingBalance) || "0");
    const deductedAmount = parseFloat(String(payment.deductionAmount) || "0");
    const restoredBalance = currentBalance + deductedAmount;

    await storage.updateLoan(payment.loanId, {
      remainingBalance: restoredBalance.toString(),
      status: "Disbursed",
    });

    // Mark payment as unapplied
    await storage.markLoanPaymentUnapplied(payment.id);
    reverted++;
  }

  return { reverted, skipped, errors };
}

/**
 * Validate net pay is not negative. Returns validation result.
 */
function validateNetPay(grossPay: string | number, totalDeductions: string | number): { valid: boolean; netPay: number } {
  const gross = parseFloat(String(grossPay) || "0");
  const deductions = parseFloat(String(totalDeductions) || "0");
  const netPay = gross - deductions;
  return { valid: netPay >= 0, netPay };
}

const router = Router();

router.get("/:cutoffStart/:cutoffEnd", isAuthenticated, async (req, res) => {
  try {
    const { cutoffStart, cutoffEnd } = req.params;
    const records = await storage.getPayrollRecords(cutoffStart, cutoffEnd);
    res.json(records);
  } catch (error) {
    logger.error("Error fetching payroll:", error);
    res.status(500).json({ message: "Failed to fetch payroll records" });
  }
});

router.get("/summary/:cutoffStart/:cutoffEnd", isAuthenticated, async (req, res) => {
  try {
    const { cutoffStart, cutoffEnd } = req.params;
    const records = await storage.getPayrollRecords(cutoffStart, cutoffEnd);

    const summary = {
      cutoffStart,
      cutoffEnd,
      totalGross: records.reduce((sum, r) => sum + parseFloat(String(r.grossPay) || "0"), 0).toFixed(2),
      totalDeductions: records.reduce((sum, r) => sum + parseFloat(String(r.totalDeductions) || "0"), 0).toFixed(2),
      totalNet: records.reduce((sum, r) => sum + parseFloat(String(r.netPay) || "0"), 0).toFixed(2),
      totalSSS: records.reduce((sum, r) => sum + parseFloat(String(r.sssDeduction) || "0"), 0).toFixed(2),
      totalPhilHealth: records.reduce((sum, r) => sum + parseFloat(String(r.philhealthDeduction) || "0"), 0).toFixed(2),
      totalPagibig: records.reduce((sum, r) => sum + parseFloat(String(r.pagibigDeduction) || "0"), 0).toFixed(2),
      totalTax: records.reduce((sum, r) => sum + parseFloat(String(r.taxDeduction) || "0"), 0).toFixed(2),
      recordCount: records.length,
      byStatus: {
        draft: records.filter(r => r.status === "Draft").length,
        approved: records.filter(r => r.status === "Approved").length,
        released: records.filter(r => r.status === "Released").length,
      },
    };

    res.json(summary);
  } catch (error) {
    logger.error("Error fetching payroll summary:", error);
    res.status(500).json({ message: "Failed to fetch payroll summary" });
  }
});

router.post("/compute", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process", "payroll.edit", "payroll.approve", "payroll.release"), async (req, res) => {
  try {
    const validatedData = payrollComputeSchema.parse(req.body);
    const { cutoffStart, cutoffEnd } = validatedData;
    const userId = req.session.user?.id;

    // Get only visible employees (exclude hidden system accounts)
    const employees = await storage.getVisibleEmployees();
    const activeEmployees = employees.filter(e =>
      e.status === "Active" || e.status === "Probationary"
    );

    await storage.deletePayrollRecordsForCutoff(cutoffStart, cutoffEnd);

    const startDate = new Date(cutoffStart);
    const endDate = new Date(cutoffEnd);
    endDate.setHours(23, 59, 59, 999);

    // Batch fetch all data upfront to avoid N+1 queries
    const [allAttendance, allLeaveRequests, leaveTypes, allCashAdvances, allLoans, allProjects] = await Promise.all([
      storage.getAttendanceLogs(startDate, endDate),
      storage.getLeaveRequests(),
      storage.getLeaveTypes(),
      storage.getCashAdvances(),
      storage.getLoans(),
      storage.getProjects(),
    ]);

    // Build a map of projectId -> mealAllowance rate for quick lookup
    const projectMealAllowanceMap = new Map<string, number>();
    for (const project of allProjects) {
      const rate = parseFloat(project.mealAllowance || "0");
      if (rate > 0) {
        projectMealAllowanceMap.set(project.id, rate);
      }
    }

    const createdRecords = [];

    for (const employee of activeEmployees) {
      // Filter attendance for this employee from batch data
      const attendance = allAttendance.filter(a => a.employeeId === employee.id);

      const daysWorked = attendance.length;
      const hoursWorked = attendance.reduce((sum, log) => sum + parseFloat(String(log.totalHours) || "8"), 0);
      const totalLateMinutes = attendance.reduce((sum, log) => sum + (log.lateMinutes || 0), 0);
      const totalUndertimeMinutes = attendance.reduce((sum, log) => sum + (log.undertimeMinutes || 0), 0);

      // Filter leave requests for this employee from batch data
      const employeeLeaveRequests = allLeaveRequests.filter(l => l.employeeId === employee.id);
      const approvedLeavesInPeriod = employeeLeaveRequests.filter(leave => {
        if (leave.status !== "Approved") return false;
        const leaveStart = new Date(leave.startDate);
        const leaveEnd = new Date(leave.endDate);
        // Check if leave overlaps with payroll period
        return leaveStart <= endDate && leaveEnd >= startDate;
      });

      // Calculate unpaid leave days and deduction
      let unpaidLeaveDays = 0;
      let paidLeaveDays = 0;

      for (const leave of approvedLeavesInPeriod) {
        const leaveType = leaveTypes.find(lt => lt.id === leave.leaveTypeId);
        const days = parseFloat(String(leave.totalDays));

        if (leaveType && !leaveType.isPaid) {
          unpaidLeaveDays += days;
        } else {
          paidLeaveDays += days;
        }
      }

      // Filter cash advances for this employee from batch data
      const employeeCashAdvances = allCashAdvances.filter(ca => ca.employeeId === employee.id);
      const activeCashAdvances = employeeCashAdvances.filter(ca =>
        ca.status === "Disbursed" &&
        parseFloat(String(ca.remainingBalance) || "0") > 0
      );

      // Calculate total cash advance deduction for this period
      let totalCashAdvanceDeduction = 0;
      const cashAdvanceDeductions: Array<{ advanceId: string; amount: number; remainingAfter: number }> = [];

      for (const advance of activeCashAdvances) {
        const deductionPerCutoff = parseFloat(String(advance.deductionPerCutoff) || "0");
        const remainingBalance = parseFloat(String(advance.remainingBalance) || "0");

        if (deductionPerCutoff > 0 && remainingBalance > 0) {
          // Deduct the lesser of deductionPerCutoff or remaining balance
          const actualDeduction = Math.min(deductionPerCutoff, remainingBalance);
          const newRemainingBalance = remainingBalance - actualDeduction;

          totalCashAdvanceDeduction += actualDeduction;
          cashAdvanceDeductions.push({
            advanceId: advance.id,
            amount: actualDeduction,
            remainingAfter: newRemainingBalance,
          });
        }
      }

      // Filter loans for this employee from batch data
      const employeeLoans = allLoans.filter(l => l.employeeId === employee.id);
      const activeLoans = employeeLoans.filter(l => {
        // Check if disbursed and has remaining balance
        if (l.status !== "Disbursed" || parseFloat(String(l.remainingBalance) || "0") <= 0) {
          return false;
        }
        // Check if deduction should start (if start date is specified)
        if (l.startDeductionDate) {
          const startDate = new Date(l.startDeductionDate);
          const cutoffEndDate = new Date(cutoffEnd);
          if (startDate > cutoffEndDate) {
            return false; // Haven't reached start date yet
          }
        }
        return true;
      });

      // Calculate loan deductions broken down by type
      let totalLoanDeduction = 0;
      let sssLoanDeduction = 0;
      let pagibigLoanDeduction = 0;
      let bankLoanDeduction = 0;
      const loanDeductions: Array<{ loanId: string; amount: number; remainingAfter: number }> = [];

      for (const loan of activeLoans) {
        const deductionPerCutoff = parseFloat(String(loan.deductionPerCutoff) || "0");
        const remainingBalance = parseFloat(String(loan.remainingBalance) || "0");

        if (deductionPerCutoff > 0 && remainingBalance > 0) {
          // Deduct the lesser of deductionPerCutoff or remaining balance
          const actualDeduction = Math.min(deductionPerCutoff, remainingBalance);
          const newRemainingBalance = remainingBalance - actualDeduction;

          totalLoanDeduction += actualDeduction;

          // Track per-type breakdown
          if (loan.loanType === "SSS_Loan") {
            sssLoanDeduction += actualDeduction;
          } else if (loan.loanType === "Pagibig_Loan") {
            pagibigLoanDeduction += actualDeduction;
          } else if (loan.loanType === "Bank_Loan") {
            bankLoanDeduction += actualDeduction;
          }

          loanDeductions.push({
            loanId: loan.id,
            amount: actualDeduction,
            remainingAfter: newRemainingBalance,
          });
        }
      }

      const isApprovedOT = (log: typeof attendance[0]) => 
        log.otStatus === "Approved" || (log.overtimeApproved && log.otStatus !== "Rejected");
      
      const regularOTMinutes = attendance.reduce((sum, log) => {
        // Treat NULL/undefined overtimeType as "Regular" for backward compatibility
        if ((log.overtimeType === "Regular" || !log.overtimeType) && isApprovedOT(log)) {
          const approvedMinutes = log.otMinutesApproved ?? log.overtimeMinutes ?? 0;
          return sum + Number(approvedMinutes);
        }
        return sum;
      }, 0);
      const restDayOTMinutes = attendance.reduce((sum, log) => {
        if (log.overtimeType === "RestDay" && isApprovedOT(log)) {
          const approvedMinutes = log.otMinutesApproved ?? log.overtimeMinutes ?? 0;
          return sum + Number(approvedMinutes);
        }
        return sum;
      }, 0);
      const holidayOTMinutes = attendance.reduce((sum, log) => {
        if (log.overtimeType === "Holiday" && isApprovedOT(log)) {
          const approvedMinutes = log.otMinutesApproved ?? log.overtimeMinutes ?? 0;
          return sum + Number(approvedMinutes);
        }
        return sum;
      }, 0);

      const dailyRate = parseFloat(String(employee.baseRate)) || 0;
      const effectiveRate = employee.rateType === "monthly"
        ? dailyRate / config.payroll.defaultWorkingDaysPerMonth
        : dailyRate;

      // Calculate unpaid leave deduction
      const unpaidLeaveDeduction = unpaidLeaveDays * effectiveRate;

      const payrollCalc = calculateEnhancedPayroll({
        daysWorked,
        dailyRate: effectiveRate,
        hoursWorked,
        regularOTMinutes,
        restDayOTMinutes,
        holidayOTMinutes,
        lateMinutes: totalLateMinutes,
        undertimeMinutes: totalUndertimeMinutes,
        deductionConfig: {
          applySss: employee.enableSSSDeduction ?? true,
          applyPhilhealth: employee.enablePhilhealthDeduction ?? true,
          applyPagibig: employee.enablePagibigDeduction ?? true,
          applyTax: employee.enableTaxWithholding ?? false,
        },
      });

      // Calculate meal allowance total (FYI only - NOT included in pay)
      // For each attendance log, check if the associated project has a meal allowance rate
      let mealAllowanceTotal = 0;
      for (const log of attendance) {
        if (log.projectId) {
          const mealRate = projectMealAllowanceMap.get(log.projectId);
          if (mealRate && mealRate > 0) {
            mealAllowanceTotal += mealRate;
          }
        }
      }

      // Calculate COLA (Cost of Living Allowance) - tax-exempt, pro-rated based on days worked
      // Monthly COLA ÷ 2 = Semi-monthly COLA, then pro-rated based on attendance
      const monthlyColaAmount = parseFloat(String(employee.colaAllowance) || "0");
      const semiMonthlyCola = monthlyColaAmount / 2;
      // Expected working days per semi-monthly period (22 days/month ÷ 2)
      const expectedWorkingDays = 11;
      // Pro-rate COLA based on days worked vs expected working days
      const colaAllowance = daysWorked > 0
        ? Math.min(semiMonthlyCola, (daysWorked / expectedWorkingDays) * semiMonthlyCola)
        : 0;

      // Add cash advance, loan, and unpaid leave to total deductions
      const totalDeductionsWithExtras = payrollCalc.totalDeductions + totalCashAdvanceDeduction + totalLoanDeduction + unpaidLeaveDeduction;

      // Add COLA to gross pay (tax-exempt - not included in tax calculation)
      const grossPayWithCola = payrollCalc.grossPay + colaAllowance;
      const netPayWithExtras = grossPayWithCola - totalDeductionsWithExtras;

      const record = await storage.createPayrollRecord({
        employeeId: employee.id,
        cutoffStart,
        cutoffEnd,
        daysWorked: daysWorked.toString(),
        hoursWorked: hoursWorked.toString(),
        totalLateMinutes,
        totalUndertimeMinutes,
        regularOTMinutes,
        restDayOTMinutes,
        holidayOTMinutes,
        regularOTPay: payrollCalc.regularOTPay.toString(),
        restDayOTPay: payrollCalc.restDayOTPay.toString(),
        holidayOTPay: payrollCalc.holidayOTPay.toString(),
        basicPay: payrollCalc.basicPay.toString(),
        grossPay: grossPayWithCola.toFixed(2),
        colaAllowance: colaAllowance.toFixed(2),
        sssDeduction: payrollCalc.sssDeduction.toString(),
        philhealthDeduction: payrollCalc.philhealthDeduction.toString(),
        pagibigDeduction: payrollCalc.pagibigDeduction.toString(),
        taxDeduction: payrollCalc.taxDeduction.toString(),
        lateDeduction: payrollCalc.lateDeduction.toString(),
        undertimeDeduction: payrollCalc.undertimeDeduction.toString(),
        cashAdvanceDeduction: totalCashAdvanceDeduction.toString(),
        sssLoanDeduction: sssLoanDeduction.toString(),
        pagibigLoanDeduction: pagibigLoanDeduction.toString(),
        bankLoanDeduction: bankLoanDeduction.toString(),
        loanDeduction: totalLoanDeduction.toString(),
        unpaidLeaveDays: unpaidLeaveDays.toString(),
        unpaidLeaveDeduction: unpaidLeaveDeduction.toString(),
        paidLeaveDays: paidLeaveDays.toString(),
        totalDeductions: totalDeductionsWithExtras.toString(),
        netPay: netPayWithExtras.toString(),
        mealAllowanceTotal: mealAllowanceTotal.toFixed(2),
        status: "Draft",
      });

      // Store cash advance payment records for tracking (but don't update balances yet)
      // Balances will be updated when payroll is approved/released
      for (const deduction of cashAdvanceDeductions) {
        await storage.createCashAdvancePayment({
          cashAdvanceId: deduction.advanceId,
          payrollRecordId: record.id,
          payrollPeriodId: null, // Optional field
          deductionAmount: deduction.amount.toString(),
          remainingBalanceAfter: deduction.remainingAfter.toString(),
          paymentDate: cutoffEnd,
        });
      }

      // Store loan payment records for tracking (but don't update balances yet)
      // Balances will be updated when payroll is approved/released
      for (const deduction of loanDeductions) {
        await storage.createLoanPayment({
          loanId: deduction.loanId,
          payrollRecordId: record.id,
          payrollPeriodId: null, // Optional field
          deductionAmount: deduction.amount.toString(),
          remainingBalanceAfter: deduction.remainingAfter.toString(),
          paymentDate: cutoffEnd,
        });
      }

      createdRecords.push(record);
    }

    // Audit log for payroll computation
    await storage.createAuditLog({
      userId,
      action: "COMPUTE",
      entityType: "Payroll",
      entityId: `${cutoffStart}_${cutoffEnd}`,
      newValues: {
        cutoffStart,
        cutoffEnd,
        employeeCount: createdRecords.length,
        totalGross: createdRecords.reduce((sum, r) => sum + parseFloat(String(r.grossPay) || "0"), 0),
        totalNet: createdRecords.reduce((sum, r) => sum + parseFloat(String(r.netPay) || "0"), 0),
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    // Notify admins that payroll draft is ready
    notifyPayrollDraftReady({
      periodLabel: `${cutoffStart} to ${cutoffEnd}`,
      periodId: `${cutoffStart}_${cutoffEnd}`,
      createdBy: userId || "",
    }).catch(() => {});

    res.status(201).json({
      message: `Payroll computed for ${createdRecords.length} employees`,
      records: createdRecords,
    });
  } catch (error) {
    logger.error("Error computing payroll:", error);
    res.status(500).json({ message: "Failed to compute payroll" });
  }
});

router.patch("/:id/approve", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process", "payroll.edit", "payroll.approve", "payroll.release"), async (req, res) => {
  try {
    const userId = req.session.user?.id;

    // Get the payroll record to check current status
    const existingRecord = await storage.getPayrollRecord(req.params.id);
    if (!existingRecord) {
      return res.status(404).json({ message: "Payroll record not found" });
    }

    // Validate current status
    if (existingRecord.status !== "Draft") {
      return res.status(400).json({
        message: `Cannot approve payroll with status: ${existingRecord.status}. Only Draft records can be approved.`
      });
    }

    // Validate net pay is not negative
    const netPayValidation = validateNetPay(existingRecord.grossPay || "0", existingRecord.totalDeductions || "0");
    if (!netPayValidation.valid) {
      logger.warn(`Payroll ${req.params.id} has negative net pay: ${netPayValidation.netPay}`);
      // We'll allow it but flag it
    }

    // Use database transaction for atomicity
    // All deduction updates and status change happen together or not at all
    let deductionErrors: string[] = [];

    try {
      // Apply cash advance deductions with idempotency check
      const caResult = await applyCashAdvanceDeductions(req.params.id);
      if (caResult.errors.length > 0) {
        deductionErrors.push(...caResult.errors);
        logger.warn(`Cash advance deduction errors for payroll ${req.params.id}:`, { errors: caResult.errors });
      }

      // Apply loan deductions with idempotency check
      const loanResult = await applyLoanDeductions(req.params.id);
      if (loanResult.errors.length > 0) {
        deductionErrors.push(...loanResult.errors);
        logger.warn(`Loan deduction errors for payroll ${req.params.id}:`, { errors: loanResult.errors });
      }

      // Update payroll status
      const record = await storage.updatePayrollRecord(req.params.id, {
        status: "Approved",
        approvedAt: new Date(),
        hasNegativeNetPay: !netPayValidation.valid,
      });

      // Audit log for payroll approval
      await storage.createAuditLog({
        userId,
        action: "APPROVE",
        entityType: "PayrollRecord",
        entityId: req.params.id,
        oldValues: { status: existingRecord.status },
        newValues: {
          status: "Approved",
          employeeId: record?.employeeId,
          netPay: record?.netPay,
          deductionErrors: deductionErrors.length > 0 ? deductionErrors : undefined,
        },
        ipAddress: req.ip,
        userAgent: req.get("user-agent"),
      });

      res.json({
        ...record,
        warnings: deductionErrors.length > 0 ? deductionErrors : undefined,
      });
    } catch (txError) {
      // Transaction failed - log and return error
      logger.error(`Transaction failed for payroll approval ${req.params.id}:`, txError);
      throw txError;
    }
  } catch (error) {
    logger.error("Error approving payroll:", error);
    res.status(500).json({ message: "Failed to approve payroll" });
  }
});

router.patch("/:id/release", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process", "payroll.edit", "payroll.approve", "payroll.release"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const { force13thMonth } = req.body; // Optional: force release even if 13th month fails

    // Get existing record for audit log
    const existingRecord = await storage.getPayrollRecord(req.params.id);
    if (!existingRecord) {
      return res.status(404).json({ message: "Payroll record not found" });
    }

    // Validate current status
    if (existingRecord.status !== "Draft" && existingRecord.status !== "Approved") {
      return res.status(400).json({
        message: `Cannot release payroll with status: ${existingRecord.status}. Only Draft or Approved records can be released.`
      });
    }

    let deductionErrors: string[] = [];

    // Apply cash advance and loan deductions if releasing directly from Draft
    // (This ensures deductions are applied even if approval step was skipped)
    // Uses idempotency checks to prevent double deductions
    if (existingRecord.status === "Draft") {
      // Apply cash advance deductions with idempotency check
      const caResult = await applyCashAdvanceDeductions(req.params.id);
      if (caResult.errors.length > 0) {
        deductionErrors.push(...caResult.errors);
        logger.warn(`Cash advance deduction errors for payroll ${req.params.id}:`, { errors: caResult.errors });
      }

      // Apply loan deductions with idempotency check
      const loanResult = await applyLoanDeductions(req.params.id);
      if (loanResult.errors.length > 0) {
        deductionErrors.push(...loanResult.errors);
        logger.warn(`Loan deduction errors for payroll ${req.params.id}:`, { errors: loanResult.errors });
      }
    }

    // Update payroll status to Released
    const record = await storage.updatePayrollRecord(req.params.id, {
      status: "Released",
      releasedAt: new Date(),
    });

    // Update 13th month accrual for this employee
    // CRITICAL: This is now treated as important - failure will cause release to fail unless forced
    let thirteenthMonthError: string | null = null;
    if (record) {
      try {
        await updateThirteenthMonthAccrualForPayroll(record);
      } catch (accrualError: any) {
        thirteenthMonthError = accrualError.message || "Unknown 13th month accrual error";
        logger.error(`Failed to update 13th month accrual for payroll ${req.params.id}:`, accrualError);

        // If not forcing, revert the release status and fail
        if (!force13thMonth) {
          // Revert payroll status back to previous state
          await storage.updatePayrollRecord(req.params.id, {
            status: existingRecord.status,
            releasedAt: null,
          });

          // Revert deductions if we applied them (Draft -> Released direct path)
          if (existingRecord.status === "Draft") {
            await revertCashAdvanceDeductions(req.params.id);
            await revertLoanDeductions(req.params.id);
          }

          return res.status(500).json({
            message: "Failed to update 13th month accrual. Release has been cancelled.",
            error: thirteenthMonthError,
            suggestion: "You can retry or set force13thMonth: true in request body to release anyway (not recommended)."
          });
        }
      }
    }

    // Audit log for payroll release
    await storage.createAuditLog({
      userId,
      action: "RELEASE",
      entityType: "PayrollRecord",
      entityId: req.params.id,
      oldValues: { status: existingRecord.status },
      newValues: {
        status: "Released",
        employeeId: record?.employeeId,
        netPay: record?.netPay,
        deductionErrors: deductionErrors.length > 0 ? deductionErrors : undefined,
        thirteenthMonthError: thirteenthMonthError,
        force13thMonth: thirteenthMonthError ? force13thMonth : undefined,
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    // Send notification
    try {
      if (record) {
        await notifyPayrollReleased({
          employeeIds: [record.employeeId],
          periodLabel: `${record.cutoffStart} to ${record.cutoffEnd}`,
          periodId: `${record.cutoffStart}_${record.cutoffEnd}`,
          releasedBy: userId || "",
        });
      }
    } catch (notifyError: any) {
      logger.warn("Failed to send payroll release notification:", { error: notifyError.message });
      // Don't fail the release for notification errors
    }

    const warnings = [
      ...(deductionErrors.length > 0 ? deductionErrors : []),
      ...(thirteenthMonthError ? [`13th month accrual error (forced): ${thirteenthMonthError}`] : []),
    ];

    res.json({
      ...record,
      warnings: warnings.length > 0 ? warnings : undefined,
    });
  } catch (error) {
    logger.error("Error releasing payroll:", error);
    res.status(500).json({ message: "Failed to release payroll" });
  }
});

router.patch("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process", "payroll.edit", "payroll.approve", "payroll.release"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const {
      basicPay, regularOTPay, restDayOTPay, holidayOTPay,
      bonusAmount, bonusNotes, allowances, colaAllowance,
      sssDeduction, philhealthDeduction, pagibigDeduction, taxDeduction,
      lateDeduction, undertimeDeduction, otherDeductionAmount, otherDeductionNotes,
      cashAdvanceDeduction,
      sssLoanDeduction, pagibigLoanDeduction, bankLoanDeduction,
      overrideNetPay, editNotes, status,
    } = req.body;

    const updateData: any = { isEdited: true, updatedAt: new Date() };

    if (basicPay !== undefined) updateData.basicPay = basicPay;
    if (regularOTPay !== undefined) updateData.regularOTPay = regularOTPay;
    if (restDayOTPay !== undefined) updateData.restDayOTPay = restDayOTPay;
    if (holidayOTPay !== undefined) updateData.holidayOTPay = holidayOTPay;
    if (bonusAmount !== undefined) updateData.bonusAmount = bonusAmount;
    if (bonusNotes !== undefined) updateData.bonusNotes = bonusNotes;
    if (allowances !== undefined) updateData.allowances = allowances;
    if (colaAllowance !== undefined) updateData.colaAllowance = colaAllowance;
    if (sssDeduction !== undefined) updateData.sssDeduction = sssDeduction;
    if (philhealthDeduction !== undefined) updateData.philhealthDeduction = philhealthDeduction;
    if (pagibigDeduction !== undefined) updateData.pagibigDeduction = pagibigDeduction;
    if (taxDeduction !== undefined) updateData.taxDeduction = taxDeduction;
    if (lateDeduction !== undefined) updateData.lateDeduction = lateDeduction;
    if (undertimeDeduction !== undefined) updateData.undertimeDeduction = undertimeDeduction;
    if (otherDeductionAmount !== undefined) updateData.otherDeductionAmount = otherDeductionAmount;
    if (otherDeductionNotes !== undefined) updateData.otherDeductionNotes = otherDeductionNotes;
    if (cashAdvanceDeduction !== undefined) updateData.cashAdvanceDeduction = cashAdvanceDeduction;
    if (sssLoanDeduction !== undefined) updateData.sssLoanDeduction = sssLoanDeduction;
    if (pagibigLoanDeduction !== undefined) updateData.pagibigLoanDeduction = pagibigLoanDeduction;
    if (bankLoanDeduction !== undefined) updateData.bankLoanDeduction = bankLoanDeduction;
    if (overrideNetPay !== undefined) updateData.overrideNetPay = overrideNetPay;
    if (editNotes !== undefined) updateData.editNotes = editNotes;
    if (status !== undefined) updateData.status = status;

    const existingRecord = await storage.getPayrollRecord(req.params.id);
    if (!existingRecord) {
      return res.status(404).json({ message: "Payroll record not found" });
    }

    const newBasicPay = updateData.basicPay ?? existingRecord.basicPay ?? "0";
    const newRegularOTPay = updateData.regularOTPay ?? existingRecord.regularOTPay ?? "0";
    const newRestDayOTPay = updateData.restDayOTPay ?? existingRecord.restDayOTPay ?? "0";
    const newHolidayOTPay = updateData.holidayOTPay ?? existingRecord.holidayOTPay ?? "0";
    const newBonusAmount = updateData.bonusAmount ?? existingRecord.bonusAmount ?? "0";
    const newAllowances = updateData.allowances ?? existingRecord.allowances ?? "0";
    const newColaAllowance = updateData.colaAllowance ?? existingRecord.colaAllowance ?? "0";

    const grossPay = parseFloat(newBasicPay) + parseFloat(newRegularOTPay) + parseFloat(newRestDayOTPay) +
                     parseFloat(newHolidayOTPay) + parseFloat(newBonusAmount) + parseFloat(newAllowances) +
                     parseFloat(newColaAllowance);
    updateData.grossPay = grossPay.toFixed(2);

    const newSSSDeduction = updateData.sssDeduction ?? existingRecord.sssDeduction ?? "0";
    const newPhilhealthDeduction = updateData.philhealthDeduction ?? existingRecord.philhealthDeduction ?? "0";
    const newPagibigDeduction = updateData.pagibigDeduction ?? existingRecord.pagibigDeduction ?? "0";
    const newTaxDeduction = updateData.taxDeduction ?? existingRecord.taxDeduction ?? "0";
    const newLateDeduction = updateData.lateDeduction ?? existingRecord.lateDeduction ?? "0";
    const newUndertimeDeduction = updateData.undertimeDeduction ?? existingRecord.undertimeDeduction ?? "0";
    const newOtherDeduction = updateData.otherDeductionAmount ?? existingRecord.otherDeductionAmount ?? "0";
    const newCashAdvanceDeduction = updateData.cashAdvanceDeduction ?? existingRecord.cashAdvanceDeduction ?? "0";

    // Per-type loan deductions — auto-calculate total loanDeduction as their sum
    const newSSSLoanDeduction = updateData.sssLoanDeduction ?? existingRecord.sssLoanDeduction ?? "0";
    const newPagibigLoanDeduction = updateData.pagibigLoanDeduction ?? existingRecord.pagibigLoanDeduction ?? "0";
    const newBankLoanDeduction = updateData.bankLoanDeduction ?? existingRecord.bankLoanDeduction ?? "0";
    const newLoanDeduction = parseFloat(newSSSLoanDeduction) + parseFloat(newPagibigLoanDeduction) + parseFloat(newBankLoanDeduction);
    updateData.loanDeduction = newLoanDeduction.toFixed(2);

    const totalDeductions = parseFloat(newSSSDeduction) + parseFloat(newPhilhealthDeduction) +
                            parseFloat(newPagibigDeduction) + parseFloat(newTaxDeduction) +
                            parseFloat(newLateDeduction) + parseFloat(newUndertimeDeduction) +
                            parseFloat(newOtherDeduction) + parseFloat(newCashAdvanceDeduction) +
                            newLoanDeduction;
    updateData.totalDeductions = totalDeductions.toFixed(2);

    if (updateData.overrideNetPay === undefined || updateData.overrideNetPay === null) {
      updateData.netPay = (grossPay - totalDeductions).toFixed(2);
    }

    // Balance protection: if any loan deduction was manually changed,
    // delete the associated payment records so stale amounts don't get applied
    // to remaining balances when the payroll is approved/released.
    const loanFieldsChanged = [
      sssLoanDeduction, pagibigLoanDeduction, bankLoanDeduction,
    ].some(v => v !== undefined);

    let deletedLoanPayments = false;
    let deletedCashAdvancePayments = false;

    if (loanFieldsChanged) {
      const existingLoanTotal = parseFloat(String(existingRecord.loanDeduction) || "0");
      if (Math.abs(existingLoanTotal - newLoanDeduction) > 0.001) {
        // Get payment records before deletion for audit trail
        const loanPaymentsToDelete = await storage.getLoanPaymentsByPayrollRecord(req.params.id);
        await storage.deleteLoanPaymentsByPayrollRecord(req.params.id);
        deletedLoanPayments = true;
        logger.info(`Deleted loan payments for payroll record ${req.params.id} due to manual edit (${existingLoanTotal} -> ${newLoanDeduction})`);

        // Create audit log for payment deletion
        await storage.createAuditLog({
          userId,
          action: "DELETE_PAYMENT_RECORDS",
          entityType: "LoanPayment",
          entityId: req.params.id,
          oldValues: {
            payrollRecordId: req.params.id,
            reason: "Manual loan deduction edit",
            deletedCount: loanPaymentsToDelete.length,
            deletedRecords: loanPaymentsToDelete.map(p => ({
              id: p.id,
              loanId: p.loanId,
              deductionAmount: p.deductionAmount,
              remainingBalanceAfter: p.remainingBalanceAfter,
            })),
            oldTotal: existingLoanTotal,
            newTotal: newLoanDeduction,
          },
          ipAddress: req.ip,
          userAgent: req.get("user-agent"),
        });
      }
    }

    if (cashAdvanceDeduction !== undefined) {
      const existingCAAmount = parseFloat(String(existingRecord.cashAdvanceDeduction) || "0");
      const newCAAmount = parseFloat(String(cashAdvanceDeduction) || "0");
      if (Math.abs(existingCAAmount - newCAAmount) > 0.001) {
        // Get payment records before deletion for audit trail
        const caPaymentsToDelete = await storage.getCashAdvancePaymentsByPayrollRecord(req.params.id);
        await storage.deleteCashAdvancePaymentsByPayrollRecord(req.params.id);
        deletedCashAdvancePayments = true;
        logger.info(`Deleted cash advance payments for payroll record ${req.params.id} due to manual edit (${existingCAAmount} -> ${newCAAmount})`);

        // Create audit log for payment deletion
        await storage.createAuditLog({
          userId,
          action: "DELETE_PAYMENT_RECORDS",
          entityType: "CashAdvancePayment",
          entityId: req.params.id,
          oldValues: {
            payrollRecordId: req.params.id,
            reason: "Manual cash advance deduction edit",
            deletedCount: caPaymentsToDelete.length,
            deletedRecords: caPaymentsToDelete.map(p => ({
              id: p.id,
              cashAdvanceId: p.cashAdvanceId,
              deductionAmount: p.deductionAmount,
              remainingBalanceAfter: p.remainingBalanceAfter,
            })),
            oldTotal: existingCAAmount,
            newTotal: newCAAmount,
          },
          ipAddress: req.ip,
          userAgent: req.get("user-agent"),
        });
      }
    }

    // Validate net pay is not negative - flag but allow
    const netPayValidation = validateNetPay(grossPay, totalDeductions);
    if (!netPayValidation.valid) {
      logger.warn(`Payroll ${req.params.id} has negative net pay after edit: ${netPayValidation.netPay}`);
      updateData.hasNegativeNetPay = true;
    } else {
      updateData.hasNegativeNetPay = false;
    }

    const record = await storage.updatePayrollRecord(req.params.id, updateData);

    // Audit log for payroll record update
    await storage.createAuditLog({
      userId,
      action: "UPDATE",
      entityType: "PayrollRecord",
      entityId: req.params.id,
      oldValues: {
        basicPay: existingRecord.basicPay,
        grossPay: existingRecord.grossPay,
        netPay: existingRecord.netPay,
        loanDeduction: existingRecord.loanDeduction,
        cashAdvanceDeduction: existingRecord.cashAdvanceDeduction,
        status: existingRecord.status,
      },
      newValues: {
        basicPay: record?.basicPay,
        grossPay: record?.grossPay,
        netPay: record?.netPay,
        loanDeduction: record?.loanDeduction,
        cashAdvanceDeduction: record?.cashAdvanceDeduction,
        status: record?.status,
        editNotes: record?.editNotes,
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json(record);
  } catch (error) {
    logger.error("Error updating payroll record:", error);
    res.status(500).json({ message: "Failed to update payroll record" });
  }
});

// Get deduction breakdown details for a payroll record (loan and cash advance)
router.get("/:id/deduction-details", isAuthenticated, async (req, res) => {
  try {
    const record = await storage.getPayrollRecord(req.params.id);
    if (!record) {
      return res.status(404).json({ message: "Payroll record not found" });
    }

    // Check access: HR/Admin can see all, employees can only see their own
    const user = req.session.user as any;
    if (user.role !== "ADMIN" && user.role !== "HR" && record.employeeId !== user.employeeId) {
      return res.status(403).json({ message: "Access denied" });
    }

    // Get loan payment details with loan type info
    const loanPaymentRecords = await storage.getLoanPaymentsByPayrollRecord(req.params.id);
    const loanDetails = [];
    for (const payment of loanPaymentRecords) {
      const loan = await storage.getLoan(payment.loanId);
      loanDetails.push({
        loanId: payment.loanId,
        loanType: loan?.loanType || "Unknown",
        loanTypeLabel: (loan?.loanType || "Unknown").replace(/_/g, " "),
        deductionAmount: payment.deductionAmount,
        remainingBalanceAfter: payment.remainingBalanceAfter,
      });
    }

    // Get cash advance payment details
    const caPaymentRecords = await storage.getCashAdvancePaymentsByPayrollRecord(req.params.id);
    const cashAdvanceDetails = [];
    for (const payment of caPaymentRecords) {
      cashAdvanceDetails.push({
        cashAdvanceId: payment.cashAdvanceId,
        deductionAmount: payment.deductionAmount,
        remainingBalanceAfter: payment.remainingBalanceAfter,
      });
    }

    res.json({
      payrollRecordId: req.params.id,
      loanDetails,
      cashAdvanceDetails,
    });
  } catch (error) {
    logger.error("Error fetching deduction details:", error);
    res.status(500).json({ message: "Failed to fetch deduction details" });
  }
});

// Bulk approve all draft payroll records for a cutoff period
// Uses idempotency checks to prevent double deductions
router.post("/approve-all", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process", "payroll.edit", "payroll.approve", "payroll.release"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const { cutoffStart, cutoffEnd } = req.body;

    if (!cutoffStart || !cutoffEnd) {
      return res.status(400).json({ message: "cutoffStart and cutoffEnd are required" });
    }

    const records = await storage.getPayrollRecords(cutoffStart, cutoffEnd);
    const draftRecords = records.filter(r => r.status === "Draft");

    if (draftRecords.length === 0) {
      return res.status(400).json({ message: "No draft records to approve" });
    }

    const approvedRecords = [];
    const errors: { id: string; error: string; deductionErrors?: string[] }[] = [];

    for (const record of draftRecords) {
      try {
        // Apply cash advance deductions with idempotency check
        const caResult = await applyCashAdvanceDeductions(record.id);

        // Apply loan deductions with idempotency check
        const loanResult = await applyLoanDeductions(record.id);

        // Collect deduction errors but don't fail the approval
        const deductionErrors = [...caResult.errors, ...loanResult.errors];
        if (deductionErrors.length > 0) {
          logger.warn(`Deduction errors for payroll ${record.id}:`, { errors: deductionErrors });
        }

        // Validate net pay
        const netPayValidation = validateNetPay(record.grossPay || "0", record.totalDeductions || "0");

        const updatedRecord = await storage.updatePayrollRecord(record.id, {
          status: "Approved",
          approvedAt: new Date(),
          hasNegativeNetPay: !netPayValidation.valid,
        });
        approvedRecords.push({ record: updatedRecord, deductionErrors });

        // Audit log for each approval
        await storage.createAuditLog({
          userId,
          action: "APPROVE",
          entityType: "PayrollRecord",
          entityId: record.id,
          oldValues: { status: record.status },
          newValues: {
            status: "Approved",
            employeeId: record.employeeId,
            netPay: record.netPay,
            deductionErrors: deductionErrors.length > 0 ? deductionErrors : undefined,
          },
          ipAddress: req.ip,
          userAgent: req.get("user-agent"),
        });
      } catch (error) {
        errors.push({ id: record.id, error: String(error) });
      }
    }

    // Bulk audit log
    await storage.createAuditLog({
      userId,
      action: "BULK_APPROVE",
      entityType: "Payroll",
      entityId: `${cutoffStart}_${cutoffEnd}`,
      newValues: {
        cutoffStart,
        cutoffEnd,
        approvedCount: approvedRecords.length,
        totalNet: approvedRecords.reduce((sum, r) => sum + parseFloat(String(r.record?.netPay) || "0"), 0),
        errorCount: errors.length,
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    // Collect all deduction warnings
    const allWarnings = approvedRecords
      .filter(r => r.deductionErrors && r.deductionErrors.length > 0)
      .map(r => ({ recordId: r.record?.id, warnings: r.deductionErrors }));

    res.json({
      message: `Approved ${approvedRecords.length} payroll records`,
      approvedCount: approvedRecords.length,
      errorCount: errors.length,
      errors: errors.length > 0 ? errors : undefined,
      warnings: allWarnings.length > 0 ? allWarnings : undefined,
    });
  } catch (error) {
    logger.error("Error bulk approving payroll:", error);
    res.status(500).json({ message: "Failed to approve payroll records" });
  }
});

// Bulk release all approved payroll records for a cutoff period
router.post("/release-all", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process", "payroll.edit", "payroll.approve", "payroll.release"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const { cutoffStart, cutoffEnd } = req.body;

    if (!cutoffStart || !cutoffEnd) {
      return res.status(400).json({ message: "cutoffStart and cutoffEnd are required" });
    }

    const records = await storage.getPayrollRecords(cutoffStart, cutoffEnd);
    const approvedRecords = records.filter(r => r.status === "Approved");

    if (approvedRecords.length === 0) {
      return res.status(400).json({ message: "No approved records to release" });
    }

    const releasedRecords = [];
    const errors = [];

    for (const record of approvedRecords) {
      try {
        const updatedRecord = await storage.updatePayrollRecord(record.id, {
          status: "Released",
          releasedAt: new Date(),
        });
        releasedRecords.push(updatedRecord);

        // Update 13th month accrual for this employee
        if (updatedRecord) {
          try {
            await updateThirteenthMonthAccrualForPayroll(updatedRecord);
          } catch (accrualError: any) {
            logger.warn(`Failed to update 13th month accrual for employee ${record.employeeId}:`, accrualError);
          }
        }

        // Audit log for each release
        await storage.createAuditLog({
          userId,
          action: "RELEASE",
          entityType: "PayrollRecord",
          entityId: record.id,
          oldValues: { status: record.status },
          newValues: { status: "Released", employeeId: record.employeeId, netPay: record.netPay },
          ipAddress: req.ip,
          userAgent: req.get("user-agent"),
        });
      } catch (error) {
        errors.push({ id: record.id, error: String(error) });
      }
    }

    // Bulk audit log
    await storage.createAuditLog({
      userId,
      action: "BULK_RELEASE",
      entityType: "Payroll",
      entityId: `${cutoffStart}_${cutoffEnd}`,
      newValues: {
        cutoffStart,
        cutoffEnd,
        releasedCount: releasedRecords.length,
        totalNet: releasedRecords.reduce((sum, r) => sum + parseFloat(String(r?.netPay) || "0"), 0),
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    // Notify all affected employees that their payslips are available
    const releasedEmployeeIds = Array.from(new Set(
      releasedRecords
        .filter((r): r is NonNullable<typeof r> => r != null)
        .map(r => r.employeeId)
    ));
    if (releasedEmployeeIds.length > 0) {
      notifyPayrollReleased({
        employeeIds: releasedEmployeeIds,
        periodLabel: `${cutoffStart} to ${cutoffEnd}`,
        periodId: `${cutoffStart}_${cutoffEnd}`,
        releasedBy: userId || "",
      }).catch(() => {});
    }

    res.json({
      message: `Released ${releasedRecords.length} payroll records`,
      releasedCount: releasedRecords.length,
      errorCount: errors.length,
      errors: errors.length > 0 ? errors : undefined,
    });
  } catch (error) {
    logger.error("Error bulk releasing payroll:", error);
    res.status(500).json({ message: "Failed to release payroll records" });
  }
});

// Bulk revert all released/approved payroll records to draft for a cutoff period
// Uses idempotency checks to prevent reverting already-unapplied deductions
router.post("/revert-all", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process", "payroll.edit", "payroll.approve", "payroll.release"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const { cutoffStart, cutoffEnd } = req.body;

    if (!cutoffStart || !cutoffEnd) {
      return res.status(400).json({ message: "cutoffStart and cutoffEnd are required" });
    }

    const records = await storage.getPayrollRecords(cutoffStart, cutoffEnd);
    const nonDraftRecords = records.filter(r => r.status !== "Draft");

    if (nonDraftRecords.length === 0) {
      return res.status(400).json({ message: "No records to revert" });
    }

    const revertedRecords = [];
    const errors: { id: string; error: string; revertErrors?: string[] }[] = [];

    for (const record of nonDraftRecords) {
      try {
        const revertErrors: string[] = [];

        // Restore cash advance balances with idempotency check
        const caResult = await revertCashAdvanceDeductions(record.id);
        if (caResult.errors.length > 0) {
          revertErrors.push(...caResult.errors);
        }

        // Restore loan balances with idempotency check
        const loanResult = await revertLoanDeductions(record.id);
        if (loanResult.errors.length > 0) {
          revertErrors.push(...loanResult.errors);
        }

        const updatedRecord = await storage.updatePayrollRecord(record.id, {
          status: "Draft",
        });
        revertedRecords.push({ record: updatedRecord, revertErrors });

        // Sync 13th month accrual if reverting from Released status
        if (record.status === "Released" && updatedRecord) {
          try {
            await syncThirteenthMonthAccrualOnRevert(updatedRecord);
          } catch (accrualError: any) {
            logger.warn(`Failed to sync 13th month accrual for employee ${record.employeeId}:`, accrualError);
            revertErrors.push(`13th month sync failed: ${accrualError.message}`);
          }
        }

        // Audit log for each revert
        await storage.createAuditLog({
          userId,
          action: "REVERT",
          entityType: "PayrollRecord",
          entityId: record.id,
          oldValues: { status: record.status },
          newValues: {
            status: "Draft",
            employeeId: record.employeeId,
            caReverted: caResult.reverted,
            caSkipped: caResult.skipped,
            loanReverted: loanResult.reverted,
            loanSkipped: loanResult.skipped,
            revertErrors: revertErrors.length > 0 ? revertErrors : undefined,
          },
          ipAddress: req.ip,
          userAgent: req.get("user-agent"),
        });
      } catch (error) {
        errors.push({ id: record.id, error: String(error) });
      }
    }

    // Bulk audit log
    await storage.createAuditLog({
      userId,
      action: "BULK_REVERT",
      entityType: "Payroll",
      entityId: `${cutoffStart}_${cutoffEnd}`,
      newValues: {
        cutoffStart,
        cutoffEnd,
        revertedCount: revertedRecords.length,
        errorCount: errors.length,
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    // Collect all revert warnings
    const allWarnings = revertedRecords
      .filter(r => r.revertErrors && r.revertErrors.length > 0)
      .map(r => ({ recordId: r.record?.id, warnings: r.revertErrors }));

    res.json({
      message: `Reverted ${revertedRecords.length} payroll records to draft`,
      revertedCount: revertedRecords.length,
      errorCount: errors.length,
      errors: errors.length > 0 ? errors : undefined,
      warnings: allWarnings.length > 0 ? allWarnings : undefined,
    });
  } catch (error) {
    logger.error("Error bulk reverting payroll:", error);
    res.status(500).json({ message: "Failed to revert payroll records" });
  }
});

// Release selected payroll records by IDs
router.post("/release-selected", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process", "payroll.edit", "payroll.approve", "payroll.release"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const { ids } = req.body;

    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ message: "ids array is required" });
    }

    const releasedRecords = [];
    const errors = [];

    for (const id of ids) {
      try {
        const existingRecord = await storage.getPayrollRecord(id);
        if (!existingRecord) {
          errors.push({ id, error: "Record not found" });
          continue;
        }
        if (existingRecord.status !== "Approved") {
          errors.push({ id, error: `Cannot release record with status: ${existingRecord.status}` });
          continue;
        }

        const updatedRecord = await storage.updatePayrollRecord(id, {
          status: "Released",
          releasedAt: new Date(),
        });
        releasedRecords.push(updatedRecord);

        // Update 13th month accrual for this employee
        if (updatedRecord) {
          try {
            await updateThirteenthMonthAccrualForPayroll(updatedRecord);
          } catch (accrualError: any) {
            logger.warn(`Failed to update 13th month accrual for employee ${existingRecord.employeeId}:`, accrualError);
          }
        }

        // Audit log for each release
        await storage.createAuditLog({
          userId,
          action: "RELEASE",
          entityType: "PayrollRecord",
          entityId: id,
          oldValues: { status: existingRecord.status },
          newValues: { status: "Released", employeeId: existingRecord.employeeId, netPay: existingRecord.netPay },
          ipAddress: req.ip,
          userAgent: req.get("user-agent"),
        });
      } catch (error) {
        errors.push({ id, error: String(error) });
      }
    }

    res.json({
      message: `Released ${releasedRecords.length} payroll records`,
      releasedCount: releasedRecords.length,
      errorCount: errors.length,
      errors: errors.length > 0 ? errors : undefined,
    });
  } catch (error) {
    logger.error("Error releasing selected payroll:", error);
    res.status(500).json({ message: "Failed to release payroll records" });
  }
});

// Approve selected draft payroll records by IDs
router.post("/approve-selected", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process", "payroll.edit", "payroll.approve", "payroll.release"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const { ids } = req.body;

    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ message: "ids array is required" });
    }

    const approvedRecords = [];
    const errors = [];

    for (const id of ids) {
      try {
        const existingRecord = await storage.getPayrollRecord(id);
        if (!existingRecord) {
          errors.push({ id, error: "Record not found" });
          continue;
        }
        if (existingRecord.status !== "Draft") {
          errors.push({ id, error: `Cannot approve record with status: ${existingRecord.status}` });
          continue;
        }

        // Apply cash advance deductions
        const caPayments = await storage.getCashAdvancePaymentsByPayrollRecord(id);
        for (const payment of caPayments) {
          const advance = await storage.getCashAdvance(payment.cashAdvanceId);
          if (advance) {
            const newBalance = parseFloat(String(payment.remainingBalanceAfter) || "0");
            await storage.updateCashAdvance(payment.cashAdvanceId, {
              remainingBalance: newBalance.toString(),
              status: newBalance === 0 ? "Fully_Paid" : "Disbursed",
            });
          }
        }

        // Apply loan deductions
        const loanPayments = await storage.getLoanPaymentsByPayrollRecord(id);
        for (const payment of loanPayments) {
          const loan = await storage.getLoan(payment.loanId);
          if (loan) {
            const newBalance = parseFloat(String(payment.remainingBalanceAfter) || "0");
            await storage.updateLoan(payment.loanId, {
              remainingBalance: newBalance.toString(),
              status: newBalance === 0 ? "Fully_Paid" : "Disbursed",
            });
          }
        }

        const updatedRecord = await storage.updatePayrollRecord(id, {
          status: "Approved",
          approvedAt: new Date(),
        });
        approvedRecords.push(updatedRecord);

        // Audit log for each approval
        await storage.createAuditLog({
          userId,
          action: "APPROVE",
          entityType: "PayrollRecord",
          entityId: id,
          oldValues: { status: existingRecord.status },
          newValues: { status: "Approved", employeeId: existingRecord.employeeId, netPay: existingRecord.netPay },
          ipAddress: req.ip,
          userAgent: req.get("user-agent"),
        });
      } catch (error) {
        errors.push({ id, error: String(error) });
      }
    }

    res.json({
      message: `Approved ${approvedRecords.length} payroll records`,
      approvedCount: approvedRecords.length,
      errorCount: errors.length,
      errors: errors.length > 0 ? errors : undefined,
    });
  } catch (error) {
    logger.error("Error approving selected payroll:", error);
    res.status(500).json({ message: "Failed to approve payroll records" });
  }
});

// Revert selected payroll records to draft by IDs
router.post("/revert-selected", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process", "payroll.edit", "payroll.approve", "payroll.release"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const { ids } = req.body;

    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ message: "ids array is required" });
    }

    const revertedRecords = [];
    const errors = [];

    for (const id of ids) {
      try {
        const existingRecord = await storage.getPayrollRecord(id);
        if (!existingRecord) {
          errors.push({ id, error: "Record not found" });
          continue;
        }
        if (existingRecord.status === "Draft") {
          errors.push({ id, error: "Record is already in Draft status" });
          continue;
        }

        const revertErrors: string[] = [];

        // Restore cash advance balances with idempotency check
        const caResult = await revertCashAdvanceDeductions(id);
        if (caResult.errors.length > 0) {
          revertErrors.push(...caResult.errors);
        }

        // Restore loan balances with idempotency check
        const loanResult = await revertLoanDeductions(id);
        if (loanResult.errors.length > 0) {
          revertErrors.push(...loanResult.errors);
        }

        const updatedRecord = await storage.updatePayrollRecord(id, {
          status: "Draft",
        });
        revertedRecords.push({ record: updatedRecord, revertErrors, caResult, loanResult });

        // Sync 13th month accrual if reverting from Released status
        if (existingRecord.status === "Released" && updatedRecord) {
          try {
            await syncThirteenthMonthAccrualOnRevert(updatedRecord);
          } catch (accrualError: any) {
            logger.warn(`Failed to sync 13th month accrual for employee ${existingRecord.employeeId}:`, accrualError);
            revertErrors.push(`13th month sync failed: ${accrualError.message}`);
          }
        }

        // Audit log for each revert
        await storage.createAuditLog({
          userId,
          action: "REVERT",
          entityType: "PayrollRecord",
          entityId: id,
          oldValues: { status: existingRecord.status },
          newValues: {
            status: "Draft",
            employeeId: existingRecord.employeeId,
            caReverted: caResult.reverted,
            caSkipped: caResult.skipped,
            loanReverted: loanResult.reverted,
            loanSkipped: loanResult.skipped,
            revertErrors: revertErrors.length > 0 ? revertErrors : undefined,
          },
          ipAddress: req.ip,
          userAgent: req.get("user-agent"),
        });
      } catch (error) {
        errors.push({ id, error: String(error) });
      }
    }

    // Collect all revert warnings
    const allWarnings = revertedRecords
      .filter(r => r.revertErrors && r.revertErrors.length > 0)
      .map(r => ({ recordId: r.record?.id, warnings: r.revertErrors }));

    res.json({
      message: `Reverted ${revertedRecords.length} payroll records to draft`,
      revertedCount: revertedRecords.length,
      errorCount: errors.length,
      errors: errors.length > 0 ? errors : undefined,
      warnings: allWarnings.length > 0 ? allWarnings : undefined,
    });
  } catch (error) {
    logger.error("Error reverting selected payroll:", error);
    res.status(500).json({ message: "Failed to revert payroll records" });
  }
});

router.delete("/cutoff", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "payroll.view", "payroll.process", "payroll.edit", "payroll.approve", "payroll.release"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const { cutoffStart, cutoffEnd } = req.query;

    if (!cutoffStart || !cutoffEnd) {
      return res.status(400).json({ message: "cutoffStart and cutoffEnd query parameters are required" });
    }
    
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(cutoffStart as string) || !dateRegex.test(cutoffEnd as string)) {
      return res.status(400).json({ message: "Invalid date format. Use YYYY-MM-DD" });
    }
    
    const existingRecords = await storage.getPayrollRecordsForCutoff(cutoffStart as string, cutoffEnd as string);
    const nonDraftRecords = existingRecords.filter(r => r.status !== "Draft");
    
    if (nonDraftRecords.length > 0) {
      return res.status(409).json({ 
        message: "Cannot delete: Some payroll records have been approved or released. Only Draft records can be deleted.",
        approvedCount: nonDraftRecords.filter(r => r.status === "Approved").length,
        releasedCount: nonDraftRecords.filter(r => r.status === "Released").length
      });
    }
    
    await storage.deletePayrollRecordsForCutoff(cutoffStart as string, cutoffEnd as string);

    // Audit log for payroll deletion
    await storage.createAuditLog({
      userId,
      action: "DELETE",
      entityType: "Payroll",
      entityId: `${cutoffStart}_${cutoffEnd}`,
      oldValues: {
        cutoffStart,
        cutoffEnd,
        recordCount: existingRecords.length,
        employeeIds: existingRecords.map(r => r.employeeId),
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json({
      message: `Draft payroll records for ${cutoffStart} to ${cutoffEnd} have been deleted`,
      cutoffStart,
      cutoffEnd,
      deletedCount: existingRecords.length
    });
  } catch (error) {
    logger.error("Error deleting payroll records:", error);
    res.status(500).json({ message: "Failed to delete payroll records" });
  }
});

// =============================================================================
// PAYROLL RECONCILIATION ENDPOINTS
// =============================================================================

/**
 * Run payroll data reconciliation check
 * This identifies data inconsistencies without making changes
 */
router.post("/reconcile", isAuthenticated, hasRoleOrPermission(["ADMIN"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const { staleDraftDays } = req.body;

    logger.info(`Payroll reconciliation started by user ${userId}`);

    const result = await runPayrollReconciliation({
      autoFix: false,
      dryRun: true,
      staleDraftDays: staleDraftDays || 30,
    });

    // Audit log
    await storage.createAuditLog({
      userId,
      action: "RECONCILIATION_CHECK",
      entityType: "PayrollReconciliation",
      entityId: result.runAt.toISOString(),
      newValues: {
        issuesFound: result.issuesFound,
        issuesByType: result.issuesByType,
        durationMs: result.durationMs,
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json(result);
  } catch (error) {
    logger.error("Error running payroll reconciliation:", error);
    res.status(500).json({ message: "Failed to run payroll reconciliation" });
  }
});

/**
 * Apply reconciliation fixes (use with caution)
 * Only applies fixes for non-critical issues like missing flags
 */
router.post("/reconcile/fix", isAuthenticated, hasRoleOrPermission(["ADMIN"], "payroll.view", "payroll.process"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const { issueTypes } = req.body;

    if (!userId) {
      return res.status(401).json({ message: "User ID required" });
    }

    // First run reconciliation to get current issues
    const reconciliationResult = await runPayrollReconciliation({
      autoFix: false,
      dryRun: true,
    });

    // Filter to only fixable issues
    const fixableTypes = ["MISSING_DEDUCTION_FLAG"];
    let issuesToFix = reconciliationResult.issues.filter(i => fixableTypes.includes(i.type));

    // Further filter by requested issue types if provided
    if (issueTypes && Array.isArray(issueTypes)) {
      issuesToFix = issuesToFix.filter(i => issueTypes.includes(i.type));
    }

    if (issuesToFix.length === 0) {
      return res.json({
        message: "No fixable issues found",
        fixed: 0,
        failed: 0,
      });
    }

    // Apply fixes
    const fixResult = await applyReconciliationFixes(issuesToFix, userId);

    res.json({
      message: `Applied ${fixResult.fixed} fixes, ${fixResult.failed} failed`,
      ...fixResult,
    });
  } catch (error) {
    logger.error("Error applying reconciliation fixes:", error);
    res.status(500).json({ message: "Failed to apply reconciliation fixes" });
  }
});

export default router;
