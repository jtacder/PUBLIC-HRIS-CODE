import { Router } from "express";
import { z } from "zod";
import QRCode from "qrcode";
import multer from "multer";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { isSuperadmin } from "../middleware/permissions";
import { insertEmployeeSchema, insertEmployeeDocumentSchema } from "@shared/schema";
import { generateEmployeeTemplate } from "../utils/employee-template";
import { parseEmployeeFile, validateEmployeeData, type ImportError } from "../utils/employee-import";
import { uploadPhoto } from "../utils/object-storage";
import logger from "../utils/logger";

const router = Router();

// Configure multer for file uploads (memory storage for processing)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedMimes = [
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
      "application/vnd.ms-excel", // .xls
      "text/csv", // .csv
      "application/csv",
    ];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Only Excel (.xlsx, .xls) and CSV files are allowed"));
    }
  },
});

router.get("/", isAuthenticated, async (req, res) => {
  try {
    const { status, department, search, includeHidden } = req.query;

    // Only superadmins can see hidden employees
    const canSeeHidden = req.session.user?.isSuperadmin === true;
    const shouldIncludeHidden = includeHidden === 'true' && canSeeHidden;

    let employees = await storage.getEmployees(shouldIncludeHidden);

    if (status) {
      employees = employees.filter(e => e.status === status);
    }
    if (department) {
      employees = employees.filter(e => e.department === department);
    }
    if (search) {
      const searchLower = (search as string).toLowerCase();
      employees = employees.filter(e =>
        e.firstName.toLowerCase().includes(searchLower) ||
        e.lastName.toLowerCase().includes(searchLower) ||
        (e.employeeNo && e.employeeNo.toLowerCase().includes(searchLower))
      );
    }

    res.json(employees);
  } catch (error) {
    logger.error("Error fetching employees:", error);
    res.status(500).json({ message: "Failed to fetch employees" });
  }
});

// ============================================
// SYSTEM ACCOUNTS MANAGEMENT (superadmin only)
// ============================================

// Get hidden/system accounts (superadmin only)
router.get("/system-accounts", isAuthenticated, isSuperadmin, async (req, res) => {
  try {
    const hiddenEmployees = await storage.getHiddenEmployees();
    res.json(hiddenEmployees);
  } catch (error) {
    logger.error("Error fetching system accounts:", error);
    res.status(500).json({ message: "Failed to fetch system accounts" });
  }
});

// Toggle employee hidden status (superadmin only)
router.patch("/toggle-hidden/:id", isAuthenticated, isSuperadmin, async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const { isHidden } = req.body;

    const existingEmployee = await storage.getEmployee(req.params.id);
    if (!existingEmployee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    const employee = await storage.updateEmployee(req.params.id, { isHidden: Boolean(isHidden) });

    // Audit log for toggle hidden status
    await storage.createAuditLog({
      userId,
      action: "UPDATE",
      entityType: "Employee",
      entityId: req.params.id,
      oldValues: { isHidden: existingEmployee.isHidden },
      newValues: { isHidden: Boolean(isHidden) },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json(employee);
  } catch (error) {
    logger.error("Error toggling employee hidden status:", error);
    res.status(500).json({ message: "Failed to update employee visibility" });
  }
});

// ============================================
// BULK UPLOAD ENDPOINTS (must be before /:id routes)
// ============================================

// Download employee template
router.get("/template/download", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "employees.view", "employees.create", "employees.edit", "employees.delete"), async (req, res) => {
  try {
    const buffer = generateEmployeeTemplate();

    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", "attachment; filename=employee_upload_template.xlsx");
    res.send(buffer);
  } catch (error) {
    logger.error("Error generating template:", error);
    res.status(500).json({ message: "Failed to generate template" });
  }
});

// Bulk upload employees
router.post("/bulk-upload", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "employees.view", "employees.create", "employees.edit", "employees.delete"), upload.single("file"), async (req, res) => {
  try {
    const userId = req.session.user?.id;

    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    // Determine file type
    const fileType = req.file.originalname.endsWith(".csv") ? "csv" : "xlsx";

    // Parse the file
    const parseResult = parseEmployeeFile(req.file.buffer, fileType);

    if (!parseResult.success && parseResult.data.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Failed to parse file",
        errors: parseResult.errors,
        summary: {
          total: parseResult.totalRows,
          created: 0,
          failed: parseResult.totalRows,
        },
      });
    }

    // Validate the parsed data
    const { valid: validatedData, errors: validationErrors } = validateEmployeeData(parseResult.data);

    // Combine all errors
    const allErrors: ImportError[] = [...parseResult.errors, ...validationErrors];

    // Check for duplicate emails within the uploaded file
    const emailMap = new Map<string, number[]>();
    for (let i = 0; i < validatedData.length; i++) {
      const email = validatedData[i].email?.toLowerCase();
      if (email) {
        const rows = emailMap.get(email) || [];
        rows.push(i + 2); // +2 for header row offset
        emailMap.set(email, rows);
      }
    }

    // Add errors for duplicate emails within file
    Array.from(emailMap.entries()).forEach(([email, rows]) => {
      if (rows.length > 1) {
        rows.forEach((row) => {
          allErrors.push({
            row,
            field: "email",
            message: `Duplicate email "${email}" found in rows: ${rows.join(", ")}`,
            value: email,
          });
        });
      }
    });

    // Check for existing emails in database
    const existingEmployees = await storage.getEmployees();
    const existingEmails = new Set(
      existingEmployees
        .filter((e) => e.email)
        .map((e) => e.email!.toLowerCase())
    );

    // Filter out employees with duplicate emails and track which ones to create
    const toCreate: any[] = [];
    for (let i = 0; i < validatedData.length; i++) {
      const employee = validatedData[i];
      if (employee.email && existingEmails.has(employee.email.toLowerCase())) {
        allErrors.push({
          row: i + 2,
          field: "email",
          message: `Email "${employee.email}" already exists in the system`,
          value: employee.email,
        });
      } else {
        // Check if we already have an error for this row
        const hasError = allErrors.some((e) => e.row === i + 2);
        if (!hasError) {
          toCreate.push(employee);
        }
      }
    }

    // Create employees
    const createdEmployees: any[] = [];
    const createErrors: ImportError[] = [];

    for (let i = 0; i < toCreate.length; i++) {
      try {
        const employee = await storage.createEmployee(toCreate[i]);
        createdEmployees.push(employee);

        // Create audit log for each created employee
        await storage.createAuditLog({
          userId,
          action: "CREATE",
          entityType: "Employee",
          entityId: employee.id,
          newValues: {
            firstName: employee.firstName,
            lastName: employee.lastName,
            email: employee.email,
            department: employee.department,
            position: employee.position,
            role: employee.role,
            status: employee.status,
            source: "bulk_upload",
          },
          ipAddress: req.ip,
          userAgent: req.get("user-agent"),
        });
      } catch (error: any) {
        createErrors.push({
          row: i + 2,
          field: "database",
          message: error.message || "Failed to create employee",
        });
      }
    }

    // Combine all errors
    const finalErrors = [...allErrors, ...createErrors];

    // Create single audit log for the bulk upload operation
    await storage.createAuditLog({
      userId,
      action: "BULK_UPLOAD",
      entityType: "Employee",
      entityId: null,
      newValues: {
        fileName: req.file.originalname,
        totalRows: parseResult.totalRows,
        created: createdEmployees.length,
        failed: finalErrors.length,
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.status(createdEmployees.length > 0 ? 201 : 400).json({
      success: createdEmployees.length > 0,
      message:
        createdEmployees.length > 0
          ? `Successfully created ${createdEmployees.length} employee(s)`
          : "No employees were created",
      summary: {
        total: parseResult.totalRows,
        created: createdEmployees.length,
        failed: finalErrors.length,
      },
      errors: finalErrors,
      createdEmployees: createdEmployees.map((e) => ({
        id: e.id,
        firstName: e.firstName,
        lastName: e.lastName,
        email: e.email,
        role: e.role,
      })),
    });
  } catch (error: any) {
    logger.error("Error in bulk upload:", error);

    // Handle multer errors
    if (error.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({
        success: false,
        message: "File size exceeds 5MB limit"
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || "Failed to process bulk upload"
    });
  }
});

// ============================================
// EMPLOYEE ROUTES WITH :id PARAMETER
// ============================================

// Deactivate employee - sets status to "Inactive"
router.patch("/:id/deactivate", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "employees.view", "employees.create", "employees.edit", "employees.delete"), async (req, res) => {
  try {
    const userId = req.session.user?.id;

    const existingEmployee = await storage.getEmployee(req.params.id);
    if (!existingEmployee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    if (existingEmployee.status === "Inactive") {
      return res.status(400).json({ message: "Employee is already inactive" });
    }

    const employee = await storage.updateEmployee(req.params.id, { status: "Inactive" });

    // Audit log for employee deactivation
    await storage.createAuditLog({
      userId,
      action: "UPDATE",
      entityType: "Employee",
      entityId: req.params.id,
      oldValues: { status: existingEmployee.status },
      newValues: { status: "Inactive", action: "deactivate" },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json(employee);
  } catch (error) {
    logger.error("Error deactivating employee:", error);
    res.status(500).json({ message: "Failed to deactivate employee" });
  }
});

// Reactivate employee - sets status to "Active"
router.patch("/:id/reactivate", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "employees.view", "employees.create", "employees.edit", "employees.delete"), async (req, res) => {
  try {
    const userId = req.session.user?.id;

    const existingEmployee = await storage.getEmployee(req.params.id);
    if (!existingEmployee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    if (existingEmployee.status !== "Inactive" && existingEmployee.status !== "Terminated") {
      return res.status(400).json({ message: "Employee is not inactive or terminated" });
    }

    const employee = await storage.updateEmployee(req.params.id, { status: "Active" });

    // Audit log for employee reactivation
    await storage.createAuditLog({
      userId,
      action: "UPDATE",
      entityType: "Employee",
      entityId: req.params.id,
      oldValues: { status: existingEmployee.status },
      newValues: { status: "Active", action: "reactivate" },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json(employee);
  } catch (error) {
    logger.error("Error reactivating employee:", error);
    res.status(500).json({ message: "Failed to reactivate employee" });
  }
});

router.get("/:id/complete-file", isAuthenticated, async (req, res) => {
  try {
    const employee = await storage.getEmployee(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    const [documents, disciplinaryHistory, payrollHistory, cashAdvances, loans] = await Promise.all([
      storage.getEmployeeDocuments(req.params.id),
      storage.getDisciplinaryActions(req.params.id),
      storage.getEmployeePayroll(req.params.id),
      storage.getCashAdvances(req.params.id),
      storage.getLoans(req.params.id),
    ]);

    res.json({
      employee,
      documents,
      disciplinaryHistory,
      payrollHistory,
      cashAdvances,
      loans,
    });
  } catch (error) {
    logger.error("Error fetching employee file:", error);
    res.status(500).json({ message: "Failed to fetch employee file" });
  }
});

// Complete 201 File with all related data (must come before /:id route)
router.get("/:id/201-file", isAuthenticated, async (req, res) => {
  try {
    const employee = await storage.getEmployee(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    const [documents, disciplinaryHistory, payrollHistory, cashAdvances, loans] = await Promise.all([
      storage.getEmployeeDocuments(req.params.id),
      storage.getDisciplinaryActions(req.params.id),
      storage.getEmployeePayroll(req.params.id),
      storage.getCashAdvances(req.params.id),
      storage.getLoans(req.params.id),
    ]);

    res.json({
      employee,
      documents,
      disciplinaryHistory,
      payrollHistory,
      cashAdvances,
      loans,
    });
  } catch (error) {
    logger.error("Error fetching 201 file:", error);
    res.status(500).json({ message: "Failed to fetch employee file" });
  }
});

router.get("/:id", isAuthenticated, async (req, res) => {
  try {
    const employee = await storage.getEmployee(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }
    res.json(employee);
  } catch (error) {
    logger.error("Error fetching employee:", error);
    res.status(500).json({ message: "Failed to fetch employee" });
  }
});

router.post("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "employees.view", "employees.create", "employees.edit", "employees.delete"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const validatedData = insertEmployeeSchema.parse(req.body);

    // Upload profile photo to Object Storage if provided as base64
    if (validatedData.profilePhotoUrl?.startsWith("data:image/")) {
      // Generate a temporary ID for new employees (will be replaced with actual ID)
      const tempId = `new-${Date.now()}`;
      const uploadResult = await uploadPhoto(validatedData.profilePhotoUrl, "profile", tempId);
      if (uploadResult) {
        validatedData.profilePhotoUrl = uploadResult.key;
      }
    }

    const employee = await storage.createEmployee(validatedData);

    // Audit log for employee creation
    await storage.createAuditLog({
      userId,
      action: "CREATE",
      entityType: "Employee",
      entityId: employee.id,
      newValues: {
        firstName: employee.firstName,
        lastName: employee.lastName,
        email: employee.email,
        department: employee.department,
        position: employee.position,
        role: employee.role,
        status: employee.status,
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.status(201).json(employee);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error creating employee:", error);
    res.status(500).json({ message: "Failed to create employee" });
  }
});

router.patch("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "employees.view", "employees.create", "employees.edit", "employees.delete"), async (req, res) => {
  try {
    const userId = req.session.user?.id;

    // Get existing employee for audit log
    const existingEmployee = await storage.getEmployee(req.params.id);
    if (!existingEmployee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    const partialSchema = insertEmployeeSchema.partial();
    const validatedData = partialSchema.parse(req.body);

    // Upload profile photo to Object Storage if provided as base64
    if (validatedData.profilePhotoUrl?.startsWith("data:image/")) {
      const uploadResult = await uploadPhoto(validatedData.profilePhotoUrl, "profile", req.params.id);
      if (uploadResult) {
        validatedData.profilePhotoUrl = uploadResult.key;
      }
    }

    const employee = await storage.updateEmployee(req.params.id, validatedData);

    // Audit log for employee update
    await storage.createAuditLog({
      userId,
      action: "UPDATE",
      entityType: "Employee",
      entityId: req.params.id,
      oldValues: {
        firstName: existingEmployee.firstName,
        lastName: existingEmployee.lastName,
        email: existingEmployee.email,
        department: existingEmployee.department,
        position: existingEmployee.position,
        role: existingEmployee.role,
        status: existingEmployee.status,
        baseRate: existingEmployee.baseRate,
      },
      newValues: validatedData,
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.json(employee);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error updating employee:", error);
    res.status(500).json({ message: "Failed to update employee" });
  }
});

router.delete("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "employees.view", "employees.create", "employees.edit", "employees.delete"), async (req, res) => {
  try {
    const userId = req.session.user?.id;

    // Get existing employee for audit log
    const existingEmployee = await storage.getEmployee(req.params.id);
    if (!existingEmployee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    await storage.deleteEmployee(req.params.id);

    // Audit log for employee deletion
    await storage.createAuditLog({
      userId,
      action: "DELETE",
      entityType: "Employee",
      entityId: req.params.id,
      oldValues: {
        firstName: existingEmployee.firstName,
        lastName: existingEmployee.lastName,
        email: existingEmployee.email,
        department: existingEmployee.department,
        position: existingEmployee.position,
        employeeNo: existingEmployee.employeeNo,
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.status(204).send();
  } catch (error) {
    logger.error("Error deleting employee:", error);
    res.status(500).json({ message: "Failed to delete employee" });
  }
});

router.get("/:id/qr-code", isAuthenticated, async (req, res) => {
  try {
    const employee = await storage.getEmployee(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    if (!employee.qrToken) {
      const crypto = await import("crypto");
      const qrToken = crypto.randomBytes(16).toString('hex');
      await storage.updateEmployee(employee.id, { qrToken } as any);
      employee.qrToken = qrToken;
    }

    const qrData = JSON.stringify({
      token: employee.qrToken,
      name: `${employee.firstName} ${employee.lastName}`,
      employeeNo: employee.employeeNo || "",
    });

    QRCode.toDataURL(qrData, {
      width: 300,
      margin: 2,
    }, (err, url) => {
      if (err) {
        logger.error("QR Code generation error:", err);
        return res.status(500).json({ message: "Failed to generate QR code" });
      }
      res.json({ qrCode: url, qrToken: employee.qrToken });
    });
  } catch (error) {
    logger.error("Error generating QR code:", error);
    res.status(500).json({ message: "Failed to generate QR code" });
  }
});

router.get("/:id/qr-code/download", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "employees.view", "employees.create", "employees.edit", "employees.delete"), async (req, res) => {
  try {
    const employee = await storage.getEmployee(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    if (!employee.qrToken) {
      const crypto = await import("crypto");
      const qrToken = crypto.randomBytes(16).toString('hex');
      await storage.updateEmployee(employee.id, { qrToken } as any);
      employee.qrToken = qrToken;
    }

    const qrData = JSON.stringify({
      token: employee.qrToken,
      name: `${employee.firstName} ${employee.lastName}`,
      employeeNo: employee.employeeNo || "",
    });

    const qrCodeBuffer = await QRCode.toBuffer(qrData, {
      width: 400,
      margin: 2,
      type: 'png',
    });

    const filename = `${employee.lastName}_${employee.firstName}_QR.png`;
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(qrCodeBuffer);
  } catch (error) {
    logger.error("Error downloading QR code:", error);
    res.status(500).json({ message: "Failed to download QR code" });
  }
});

router.get("/:id/payroll", isAuthenticated, async (req, res) => {
  try {
    const payrollRecords = await storage.getEmployeePayroll(req.params.id);
    res.json(payrollRecords);
  } catch (error) {
    logger.error("Error fetching employee payroll:", error);
    res.status(500).json({ message: "Failed to fetch employee payroll" });
  }
});

router.get("/:id/assignments", isAuthenticated, async (req, res) => {
  try {
    const assignments = await storage.getEmployeeAssignments(req.params.id);
    res.json(assignments);
  } catch (error) {
    logger.error("Error fetching employee assignments:", error);
    res.status(500).json({ message: "Failed to fetch employee assignments" });
  }
});

router.get("/:id/documents", isAuthenticated, async (req, res) => {
  try {
    const documents = await storage.getEmployeeDocuments(req.params.id);
    res.json(documents);
  } catch (error) {
    logger.error("Error fetching documents:", error);
    res.status(500).json({ message: "Failed to fetch documents" });
  }
});

router.post("/:id/documents", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "employees.view", "employees.create", "employees.edit", "employees.delete"), async (req, res) => {
  try {
    const userId = req.session.user?.id;
    const validatedData = insertEmployeeDocumentSchema.parse({
      ...req.body,
      employeeId: req.params.id,
    });
    const document = await storage.createEmployeeDocument(validatedData);

    // Audit log for document upload
    await storage.createAuditLog({
      userId,
      action: "CREATE",
      entityType: "EmployeeDocument",
      entityId: document.id,
      newValues: {
        employeeId: req.params.id,
        documentType: document.documentType,
        documentName: document.documentName,
      },
      ipAddress: req.ip,
      userAgent: req.get("user-agent"),
    });

    res.status(201).json(document);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error creating document:", error);
    res.status(500).json({ message: "Failed to create document" });
  }
});

export default router;
