import { Router } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { insertDisciplinaryActionSchema } from "@shared/schema";
import logger from "../utils/logger";
import { notifyNTEIssued, notifyNTEResolution, notifyNTEExplanationReceived } from "../services/notification-triggers";

const router = Router();

router.get("/", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user!;
    const { employeeId } = req.query;

    // Role-based filtering: HR/Admin see all, employees see only their own
    if (user.role === "ADMIN" || user.role === "HR") {
      const actions = await storage.getDisciplinaryActions(employeeId as string | undefined);
      res.json(actions);
    } else {
      // Regular employees only see their own records
      const actions = await storage.getDisciplinaryActions(user.employeeId);
      res.json(actions);
    }
  } catch (error) {
    logger.error("Error fetching disciplinary actions:", error);
    res.status(500).json({ message: "Failed to fetch disciplinary actions" });
  }
});

router.get("/:id", isAuthenticated, async (req, res) => {
  try {
    const action = await storage.getDisciplinaryAction(req.params.id);
    if (!action) {
      return res.status(404).json({ message: "Disciplinary action not found" });
    }

    // Only HR/Admin can view any record, others only their own
    const user = req.session.user!;
    const isAdminOrHR = user.isSuperadmin || user.role === "ADMIN" || user.role === "HR";
    if (!isAdminOrHR && action.employeeId !== user.employeeId) {
      return res.status(403).json({ message: "Access denied" });
    }

    res.json(action);
  } catch (error) {
    logger.error("Error fetching disciplinary action:", error);
    res.status(500).json({ message: "Failed to fetch disciplinary action" });
  }
});

router.post("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "disciplinary.view_all", "disciplinary.manage"), async (req, res) => {
  try {
    const validatedData = insertDisciplinaryActionSchema.parse({
      ...req.body,
      nteIssuedDate: new Date().toISOString().slice(0, 10),
      responseDeadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
    });
    const action = await storage.createDisciplinaryAction(validatedData);
    notifyNTEIssued({
      employeeId: action.employeeId,
      issuedBy: req.session.user!.employeeId,
      violationType: action.violationType,
      responseDeadline: action.responseDeadline || "",
      disciplinaryId: action.id,
    }).catch(() => {});
    res.status(201).json(action);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error creating disciplinary action:", error);
    res.status(500).json({ message: "Failed to create disciplinary action" });
  }
});

router.post("/:id/explanation", isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user!;
    const { explanation } = req.body;

    // Verify the NTE belongs to the current employee
    const existingAction = await storage.getDisciplinaryAction(req.params.id);
    if (!existingAction) {
      return res.status(404).json({ message: "Disciplinary action not found" });
    }

    if (existingAction.employeeId !== user.employeeId) {
      return res.status(403).json({ message: "You can only respond to your own NTEs" });
    }

    if (!explanation || explanation.trim().length === 0) {
      return res.status(400).json({ message: "Explanation is required" });
    }

    const action = await storage.updateDisciplinaryAction(req.params.id, {
      employeeExplanation: explanation,
      explanationDate: new Date(),
      status: "Explanation_Received",
    });

    // Fire-and-forget: notify HR/Admin that explanation was received
    if (action) {
      (async () => {
        const empName = await storage.getEmployee(user.employeeId);
        const name = empName ? `${empName.firstName} ${empName.lastName}` : "Unknown";
        await notifyNTEExplanationReceived({
          employeeId: user.employeeId,
          employeeName: name,
          disciplinaryId: req.params.id,
        });
      })().catch(() => {});
    }
    res.json(action);
  } catch (error) {
    logger.error("Error submitting explanation:", error);
    res.status(500).json({ message: "Failed to submit explanation" });
  }
});

router.post("/:id/resolve", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "disciplinary.view_all", "disciplinary.manage"), async (req, res) => {
  try {
    const user = req.session.user!;
    const { resolution, sanction, sanctionDays } = req.body;

    if (!resolution || resolution.trim().length === 0) {
      return res.status(400).json({ message: "Resolution is required" });
    }

    const action = await storage.updateDisciplinaryAction(req.params.id, {
      resolution,
      sanction,
      sanctionDays,
      resolvedById: user.employeeId,
      resolvedAt: new Date(),
      status: "Resolved",
    });

    // Fire-and-forget: notify employee of resolution
    if (action) {
      notifyNTEResolution({
        employeeId: action.employeeId,
        resolvedBy: user.employeeId,
        status: "Resolved",
        sanction: sanction || undefined,
        disciplinaryId: req.params.id,
      }).catch(() => {});
    }
    res.json(action);
  } catch (error) {
    logger.error("Error resolving disciplinary action:", error);
    res.status(500).json({ message: "Failed to resolve disciplinary action" });
  }
});

// SECURITY FIX: Explicit field whitelist for disciplinary action updates
const disciplinaryUpdateSchema = z.object({
  violationType: z.string().optional(),
  incidentDate: z.string().optional(),
  description: z.string().optional(),
  attachmentUrl: z.string().optional(),
  nteIssuedDate: z.string().optional(),
  responseDeadline: z.string().optional(),
  status: z.enum(["Issued", "Explanation_Received", "Under_Review", "Resolved", "Escalated"]).optional(),
  resolution: z.string().optional(),
  sanction: z.string().optional(),
  sanctionDays: z.number().optional(),
}).strict(); // strict() rejects unknown fields

router.patch("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "disciplinary.view_all", "disciplinary.manage"), async (req, res) => {
  try {
    // Prevent employees from updating explanation via PATCH
    if ((req.body as any).employeeExplanation) {
      return res.status(400).json({
        message: "Use POST /:id/explanation endpoint to submit employee explanation"
      });
    }

    // Validate and whitelist allowed fields
    const validationResult = disciplinaryUpdateSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        message: "Validation failed - invalid or disallowed fields",
        errors: validationResult.error.errors
      });
    }

    const updates = validationResult.data;

    const action = await storage.updateDisciplinaryAction(req.params.id, updates);
    if (!action) {
      return res.status(404).json({ message: "Disciplinary action not found" });
    }
    if (updates.status === "Escalated") {
      notifyNTEResolution({
        employeeId: action.employeeId,
        resolvedBy: req.session.user!.employeeId,
        status: "Escalated",
        disciplinaryId: req.params.id,
      }).catch(() => {});
    }
    res.json(action);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error updating disciplinary action:", error);
    res.status(500).json({ message: "Failed to update disciplinary action" });
  }
});

export default router;
