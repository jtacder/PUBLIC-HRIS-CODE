import { Router } from "express";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { formatAttendanceLogForClient, calculateWorkingDays, getPhilippineTime, createPHTDateStart, createPHTDateEnd } from "../utils/datetime";
import { insertLeaveRequestSchema, insertCashAdvanceSchema, insertLoanSchema, loanTypeEnum } from "@shared/schema";
import { uploadPhoto } from "../utils/object-storage";
import logger from "../utils/logger";

const router = Router();

router.get("/attendance", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    // Use getEmployeeAttendance for database-level filtering (performance optimization)
    const myLogs = await storage.getEmployeeAttendance(employeeId);
    const formattedLogs = myLogs.map(formatAttendanceLogForClient);
    res.json(formattedLogs);
  } catch (error) {
    logger.error("Error fetching my attendance:", error);
    res.status(500).json({ message: "Failed to fetch attendance" });
  }
});

router.get("/tasks", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    // Use getEmployeeTasks for database-level filtering (performance optimization)
    const myTasks = await storage.getEmployeeTasks(employeeId);
    res.json(myTasks);
  } catch (error) {
    logger.error("Error fetching my tasks:", error);
    res.status(500).json({ message: "Failed to fetch tasks" });
  }
});

router.get("/leave-balance", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    const currentYear = new Date().getFullYear();
    const leaveTypes = await storage.getLeaveTypes();
    const allocations = await storage.getEmployeeLeaveAllocations(employeeId, currentYear);
    // Use getLeaveRequests(employeeId) for database-level filtering (performance optimization)
    const myLeaveRequests = await storage.getLeaveRequests(employeeId);
    const myApprovedLeaves = myLeaveRequests.filter(
      req => req.status === "Approved" &&
      new Date(req.startDate).getFullYear() === currentYear
    );

    // Build breakdown per leave type - prioritize employee allocations over leave type defaults
    const breakdown = leaveTypes.filter(type => type.isActive).map(type => {
      // Find allocation for this employee/leave type/year
      const allocation = allocations.find(a => a.leaveTypeId === type.id);

      // Calculate used days from approved leave requests (real-time calculation)
      const leavesOfType = myApprovedLeaves.filter(leave => leave.leaveTypeId === type.id);
      const usedDays = leavesOfType.reduce((sum, leave) => {
        return sum + parseFloat(leave.totalDays);
      }, 0);

      // If employee has allocation record, use it (supports accrual mode)
      // Otherwise fall back to leave type's annual allocation (for backward compatibility)
      let availableBalance: number;
      let totalAllocated: number;
      let accruedToDate: number;

      if (allocation) {
        // Use employee's specific allocation
        totalAllocated = parseFloat(allocation.totalAllocated);
        accruedToDate = parseFloat(allocation.accruedToDate || allocation.totalAllocated);
        const carriedOver = parseFloat(allocation.carriedOver || "0");

        // For monthly accrual, available balance is accrued amount + carryover
        // For annual mode, accrued equals total allocated
        availableBalance = accruedToDate + carriedOver;
      } else {
        // Fallback: use leave type default (annual allocation)
        totalAllocated = type.annualAllocation || 0;
        accruedToDate = totalAllocated; // Assume full allocation if no record
        availableBalance = totalAllocated;
      }

      return {
        leaveTypeId: type.id,
        leaveTypeName: type.name,
        leaveTypeCode: type.code,
        accrualMode: type.accrualMode || "annual",
        // New fields for accrual support
        totalAllocated,
        accruedToDate: Math.round(accruedToDate * 10) / 10,
        availableBalance: Math.round(availableBalance * 10) / 10,
        // Backward compatible field for existing dashboard UI (expects "allocated")
        allocated: Math.round(availableBalance * 10) / 10,
        used: Math.round(usedDays * 10) / 10,
        remaining: Math.round(Math.max(0, availableBalance - usedDays) * 10) / 10,
        isPaid: type.isPaid ?? true,
        hasAllocation: !!allocation,
      };
    });

    const totalAllocation = breakdown.reduce((sum, item) => sum + item.availableBalance, 0);
    const totalUsed = breakdown.reduce((sum, item) => sum + item.used, 0);

    res.json({
      year: currentYear,
      total: Math.round(totalAllocation * 10) / 10,
      used: Math.round(totalUsed * 10) / 10,
      remaining: Math.round(Math.max(0, totalAllocation - totalUsed) * 10) / 10,
      breakdown,
    });
  } catch (error) {
    logger.error("Error fetching leave balance:", error);
    res.status(500).json({ message: "Failed to fetch leave balance" });
  }
});

router.get("/dashboard", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    const employee = await storage.getEmployee(employeeId);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    // Use PHT for current date detection so cutoff matching works correctly
    // between midnight PHT and 8 AM PHT (when UTC date differs from PHT date)
    const now = getPhilippineTime();
    const currentDay = now.getUTCDate();
    const currentMonth = now.getUTCMonth();
    const currentYear = now.getUTCFullYear();

    let cutoffStart: Date;
    let cutoffEnd: Date;
    let cutoffName = "";

    // Use configured cutoffs from HR settings
    const configuredCutoffs = await storage.getPayrollCutoffs();

    if (configuredCutoffs.length > 0) {
      const sortedCutoffs = [...configuredCutoffs].sort((a, b) => a.startDay - b.startDay);

      let matchedCutoff = sortedCutoffs[0];
      let isInEndMonthPortion = false; // Track if we're in the "next month" portion of a spanning cutoff

      for (const cutoff of sortedCutoffs) {
        const spansMonth = cutoff.endDay < cutoff.startDay;

        if (spansMonth) {
          // Cutoff spans across months (e.g., Day 27 - Day 10)
          // Match if: currentDay >= startDay (in "start month" portion) OR currentDay <= endDay (in "end month" portion)
          if (currentDay >= cutoff.startDay) {
            // We're in the "start month" portion (e.g., Day 27-31)
            matchedCutoff = cutoff;
            isInEndMonthPortion = false;
            break;
          } else if (currentDay <= cutoff.endDay) {
            // We're in the "end month" portion (e.g., Day 1-10)
            matchedCutoff = cutoff;
            isInEndMonthPortion = true;
            break;
          }
        } else {
          // Normal cutoff within same month (e.g., Day 11 - Day 26)
          if (currentDay >= cutoff.startDay && currentDay <= cutoff.endDay) {
            matchedCutoff = cutoff;
            isInEndMonthPortion = false;
            break;
          }
          // Handle variable month lengths (endDay >= 28 could be end of month)
          if (cutoff.endDay >= 28 && currentDay >= cutoff.startDay) {
            const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
            if (currentDay <= lastDayOfMonth) {
              matchedCutoff = cutoff;
              isInEndMonthPortion = false;
              break;
            }
          }
        }
      }

      cutoffName = matchedCutoff.name;

      // Calculate the actual date range based on whether cutoff spans months
      // Use PHT-aware date boundaries so queries match Philippine midnight, not UTC midnight
      const spansMonth = matchedCutoff.endDay < matchedCutoff.startDay;

      // Helper to build YYYY-MM-DD string from year/month/day, handling month overflow
      const fmtDate = (y: number, m: number, d: number) => {
        const dt = new Date(y, m, d);
        return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
      };

      if (spansMonth) {
        if (isInEndMonthPortion) {
          // We're in the "end month" portion (e.g., Jan 1-10 for a Dec 27 - Jan 10 cutoff)
          // Start is in previous month, end is in current month
          cutoffStart = createPHTDateStart(fmtDate(currentYear, currentMonth - 1, matchedCutoff.startDay));
          cutoffEnd = createPHTDateEnd(fmtDate(currentYear, currentMonth, matchedCutoff.endDay));
        } else {
          // We're in the "start month" portion (e.g., Dec 27-31 for a Dec 27 - Jan 10 cutoff)
          // Start is in current month, end is in next month
          cutoffStart = createPHTDateStart(fmtDate(currentYear, currentMonth, matchedCutoff.startDay));
          cutoffEnd = createPHTDateEnd(fmtDate(currentYear, currentMonth + 1, matchedCutoff.endDay));
        }
      } else {
        // Normal cutoff within same month
        cutoffStart = createPHTDateStart(fmtDate(currentYear, currentMonth, matchedCutoff.startDay));
        const actualEndDay = matchedCutoff.endDay >= 28
          ? Math.min(matchedCutoff.endDay, new Date(currentYear, currentMonth + 1, 0).getDate())
          : matchedCutoff.endDay;
        cutoffEnd = createPHTDateEnd(fmtDate(currentYear, currentMonth, actualEndDay));
      }
    } else {
      // Fallback to default 1-15 / 16-end
      // Helper to build YYYY-MM-DD string from year/month/day, handling month overflow
      const fmtDate = (y: number, m: number, d: number) => {
        const dt = new Date(y, m, d);
        return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
      };

      if (currentDay <= 15) {
        cutoffName = "1st Cutoff";
        cutoffStart = createPHTDateStart(fmtDate(currentYear, currentMonth, 1));
        cutoffEnd = createPHTDateEnd(fmtDate(currentYear, currentMonth, 15));
      } else {
        cutoffName = "2nd Cutoff";
        cutoffStart = createPHTDateStart(fmtDate(currentYear, currentMonth, 16));
        const lastDay = new Date(currentYear, currentMonth + 1, 0).getDate();
        cutoffEnd = createPHTDateEnd(fmtDate(currentYear, currentMonth, lastDay));
      }
    }

    // Use getEmployeeAttendance with date range for database-level filtering (performance optimization)
    const myLogs = await storage.getEmployeeAttendance(employeeId, cutoffStart, cutoffEnd);

    // No need to filter again - already filtered at database level
    const cutoffLogs = myLogs;

    const totalAttendance = cutoffLogs.length;
    const totalLateMinutes = cutoffLogs.reduce((sum, log) => sum + (log.lateMinutes || 0), 0);

    // Only count APPROVED OT for employee dashboard
    const totalOTHours = cutoffLogs.reduce((sum, log) => {
      const isApproved = log.otStatus === "Approved" || (log.overtimeApproved && log.otStatus !== "Rejected");
      if (isApproved) {
        const approvedMinutes = log.otMinutesApproved ?? log.overtimeMinutes ?? 0;
        return sum + (Number(approvedMinutes) / 60);
      }
      return sum;
    }, 0);

    const workingDays = calculateWorkingDays(cutoffStart, cutoffEnd, now);
    const totalAbsences = Math.max(0, workingDays - totalAttendance);

    const allTasks = await storage.getTasks();
    const pendingTasks = allTasks.filter(
      task => task.assignedToId === employeeId && 
      (task.status === "Todo" || task.status === "In_Progress")
    ).length;

    const disciplinaryActions = await storage.getDisciplinaryActions();
    const pendingNTEs = disciplinaryActions.filter(
      action => action.employeeId === employeeId && 
      (action.status === "Issued" || action.status === "Explanation_Received" || action.status === "Under_Review")
    ).length;

    const dailyRate = parseFloat(employee.baseRate || "0");
    const expectedSalary = dailyRate * totalAttendance;

    res.json({
      cutoffPeriod: {
        start: cutoffStart.toISOString(),
        end: cutoffEnd.toISOString(),
        name: cutoffName,
      },
      totalAttendance,
      totalAbsences,
      totalLateMinutes,
      totalLateHours: Math.round((totalLateMinutes / 60) * 100) / 100,
      totalOTHours: Math.round(totalOTHours * 100) / 100,
      expectedSalary: Math.round(expectedSalary * 100) / 100,
      pendingTasks,
      pendingNTEs,
    });
  } catch (error) {
    logger.error("Error fetching employee dashboard:", error);
    res.status(500).json({ message: "Failed to fetch dashboard stats" });
  }
});

router.get("/payslips", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    const allPayslips = await storage.getEmployeePayroll(employeeId);
    const releasedPayslips = allPayslips.filter(p => p.status === "Released");
    res.json(releasedPayslips);
  } catch (error) {
    logger.error("Error fetching my payslips:", error);
    res.status(500).json({ message: "Failed to fetch payslips" });
  }
});

router.get("/disciplinary", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    // Use getDisciplinaryActions(employeeId) for database-level filtering (performance optimization)
    const myActions = await storage.getDisciplinaryActions(employeeId);
    res.json(myActions);
  } catch (error) {
    logger.error("Error fetching my disciplinary actions:", error);
    res.status(500).json({ message: "Failed to fetch disciplinary actions" });
  }
});

router.get("/leave-requests", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    // Use getLeaveRequests(employeeId) for database-level filtering (performance optimization)
    const myRequests = await storage.getLeaveRequests(employeeId);
    res.json(myRequests);
  } catch (error) {
    logger.error("Error fetching my leave requests:", error);
    res.status(500).json({ message: "Failed to fetch leave requests" });
  }
});

router.post("/leave-requests", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    // Validate with schema to ensure data types are correct
    const validated = insertLeaveRequestSchema.parse({
      ...req.body,
      employeeId,
      status: "Pending",
    });
    const request = await storage.createLeaveRequest(validated);
    res.status(201).json(request);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error creating leave request:", error);
    res.status(500).json({ message: "Failed to create leave request" });
  }
});

router.get("/cash-advances", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    // Use getCashAdvances(employeeId) for database-level filtering (performance optimization)
    const myAdvances = await storage.getCashAdvances(employeeId);
    res.json(myAdvances);
  } catch (error) {
    logger.error("Error fetching my cash advances:", error);
    res.status(500).json({ message: "Failed to fetch cash advances" });
  }
});

router.post("/cash-advances", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    // Validate with schema and set remainingBalance to the requested amount
    const validated = insertCashAdvanceSchema.parse({
      ...req.body,
      employeeId,
      status: "Pending",
      remainingBalance: req.body.amount, // Initialize remaining balance to full amount
    });
    const advance = await storage.createCashAdvance(validated);
    res.status(201).json(advance);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error creating cash advance:", error);
    res.status(500).json({ message: "Failed to create cash advance" });
  }
});

// ==================== LOANS ====================

router.get("/loans", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    // Use getLoans(employeeId) for database-level filtering
    const myLoans = await storage.getLoans(employeeId);
    res.json(myLoans);
  } catch (error) {
    logger.error("Error fetching my loans:", error);
    res.status(500).json({ message: "Failed to fetch loans" });
  }
});

router.post("/loans", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    const { loanType, amount, reason } = req.body;

    // Validate loan type
    if (!loanTypeEnum.includes(loanType)) {
      return res.status(400).json({
        message: "Invalid loan type",
        validTypes: loanTypeEnum
      });
    }

    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      return res.status(400).json({ message: "Amount must be a positive number" });
    }

    // For employee requests, interest is 0 (HR can add interest at approval)
    const validated = insertLoanSchema.parse({
      employeeId,
      loanType,
      amount,
      interest: "0",
      totalAmount: amount, // Initially same as amount (no interest)
      reason,
      status: "Pending",
      remainingBalance: amount, // Initialize to full amount
    });

    const loan = await storage.createLoan(validated);
    res.status(201).json(loan);
  } catch (error: any) {
    if (error.name === "ZodError") {
      return res.status(400).json({ message: "Validation failed", errors: error.errors });
    }
    logger.error("Error creating loan request:", error);
    res.status(500).json({ message: "Failed to create loan request" });
  }
});

// Get loan types for dropdown
router.get("/loan-types", isAuthenticated, async (req, res) => {
  try {
    const types = loanTypeEnum.map(type => ({
      value: type,
      label: type.replace(/_/g, " "),
    }));
    res.json(types);
  } catch (error) {
    logger.error("Error fetching loan types:", error);
    res.status(500).json({ message: "Failed to fetch loan types" });
  }
});

// Get loan payment history for a specific loan
router.get("/loans/:id/payments", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    // Verify the loan belongs to this employee
    const loan = await storage.getLoan(req.params.id);
    if (!loan) {
      return res.status(404).json({ message: "Loan not found" });
    }
    if (loan.employeeId !== employeeId) {
      return res.status(403).json({ message: "Access denied" });
    }

    const payments = await storage.getLoanPayments(req.params.id);
    res.json(payments);
  } catch (error) {
    logger.error("Error fetching loan payments:", error);
    res.status(500).json({ message: "Failed to fetch payment history" });
  }
});

// Update profile photo (self-service - users can update their own photo)
router.patch("/profile-photo", isAuthenticated, async (req, res) => {
  try {
    const employeeId = req.session.user?.employeeId;
    if (!employeeId) {
      return res.status(400).json({ message: "Employee not linked to user" });
    }

    const { profilePhotoUrl } = req.body;

    if (!profilePhotoUrl) {
      return res.status(400).json({ message: "Profile photo is required" });
    }

    let photoKey = profilePhotoUrl;

    // Upload to Object Storage if it's a base64 data URI
    if (profilePhotoUrl.startsWith("data:image/")) {
      const uploadResult = await uploadPhoto(profilePhotoUrl, "profile", employeeId);
      if (!uploadResult) {
        return res.status(500).json({ message: "Failed to upload photo" });
      }
      photoKey = uploadResult.key;
    }

    // Update employee record with the new photo
    const employee = await storage.updateEmployee(employeeId, { profilePhotoUrl: photoKey });

    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    res.json({
      message: "Profile photo updated successfully",
      profilePhotoUrl: photoKey
    });
  } catch (error) {
    logger.error("Error updating profile photo:", error);
    res.status(500).json({ message: "Failed to update profile photo" });
  }
});

export default router;
