import { Router } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { isAuthenticated } from "../email-auth";
import { hasRoleOrPermission } from "../middleware/permissions";
import { insertExpenseSchema } from "@shared/schema";
import { uploadFile } from "../utils/object-storage";
import { expenseRejectionSchema, expenseReimbursementSchema, validateBody } from "../validation/schemas";
import { notifyExpenseDecision, notifyExpenseReimbursed, notifyNewRequestPending } from "../services/notification-triggers";
import logger from "../utils/logger";

const router = Router();

// Expenses are only accessible to Admin, HR, superadmin, and Engineer roles
// Engineers can only see their own expenses, Admin/HR can see all
router.get("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR", "ENGINEER"], "expenses.view_all"), async (req, res) => {
  try {
    const { projectId, status } = req.query;
    const user = req.session.user!;

    // Check if user is Admin/HR/superadmin - they can see all expenses
    const isAdminOrHR = user.isSuperadmin || user.role === "ADMIN" || user.role === "HR";

    // For Engineers, filter to only show their own expenses
    const requesterId = isAdminOrHR ? undefined : user.employeeId;

    const expenses = await storage.getExpenses(
      projectId as string | undefined,
      status as string | undefined,
      requesterId
    );
    res.json(expenses);
  } catch (error) {
    logger.error("Error fetching expenses:", error);
    res.status(500).json({ message: "Failed to fetch expenses" });
  }
});

router.get("/:id", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR", "ENGINEER"], "expenses.view_all"), async (req, res) => {
  try {
    const expense = await storage.getExpense(req.params.id);
    if (!expense) {
      return res.status(404).json({ message: "Expense not found" });
    }

    const user = req.session.user!;
    const isAdminOrHR = user.isSuperadmin || user.role === "ADMIN" || user.role === "HR";

    // Engineers can only view their own expenses
    if (!isAdminOrHR && expense.requesterId !== user.employeeId) {
      return res.status(403).json({ message: "Access denied" });
    }

    res.json(expense);
  } catch (error) {
    logger.error("Error fetching expense:", error);
    res.status(500).json({ message: "Failed to fetch expense" });
  }
});

router.post("/", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR", "ENGINEER"], "expenses.view_all"), async (req, res) => {
  try {
    const validatedData = insertExpenseSchema.parse(req.body);

    // Upload receipt file to Object Storage if provided as base64 (supports images and PDFs)
    if (validatedData.receiptUrl?.startsWith("data:")) {
      const tempId = `expense-${Date.now()}`;
      const uploadResult = await uploadFile(validatedData.receiptUrl, "receipt", tempId);
      if (uploadResult) {
        validatedData.receiptUrl = uploadResult.key;
      }
    }

    const expense = await storage.createExpense(validatedData);

    // Fire-and-forget: notify admins of new expense request
    (async () => {
      const emp = await storage.getEmployee(expense.requesterId);
      const employeeName = emp ? `${emp.firstName} ${emp.lastName}` : "Unknown";
      await notifyNewRequestPending({
        employeeId: expense.requesterId,
        employeeName,
        requestType: "expense",
        amount: expense.amount,
        requestId: expense.id,
      });
    })().catch(() => {});

    res.status(201).json(expense);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Error creating expense:", error);
    res.status(500).json({ message: "Failed to create expense" });
  }
});

router.patch("/:id/approve", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "expenses.approve", "expenses.reimburse"), async (req, res) => {
  try {
    const approvedById = req.session.user!.employeeId;
    const expense = await storage.updateExpense(req.params.id, {
      status: "Approved",
      approvedById,
    } as any);

    // Fire-and-forget: notify employee of approval
    if (expense) {
      (async () => {
        const approver = await storage.getEmployee(approvedById);
        const approverName = approver ? `${approver.firstName} ${approver.lastName}` : "Admin";
        await notifyExpenseDecision({
          employeeId: expense.requesterId,
          approverId: approvedById,
          approverName,
          status: "Approved",
          amount: expense.amount,
          expenseId: expense.id,
        });
      })().catch(() => {});
    }
    res.json(expense);
  } catch (error) {
    logger.error("Error approving expense:", error);
    res.status(500).json({ message: "Failed to approve expense" });
  }
});

router.patch("/:id/reject", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "expenses.approve", "expenses.reimburse"), async (req, res) => {
  try {
    // Validate rejection reason
    const validation = validateBody(expenseRejectionSchema, req.body);
    if (!validation.success) {
      return res.status(400).json({ message: "Validation failed", errors: validation.errors });
    }

    const approvedById = req.session.user!.employeeId;
    const { rejectionReason } = validation.data;
    const expense = await storage.updateExpense(req.params.id, {
      status: "Rejected",
      rejectionReason,
      approvedById,
    } as any);

    // Fire-and-forget: notify employee of rejection
    if (expense) {
      (async () => {
        const approver = await storage.getEmployee(approvedById);
        const approverName = approver ? `${approver.firstName} ${approver.lastName}` : "Admin";
        await notifyExpenseDecision({
          employeeId: expense.requesterId,
          approverId: approvedById,
          approverName,
          status: "Rejected",
          amount: expense.amount,
          expenseId: expense.id,
        });
      })().catch(() => {});
    }
    res.json(expense);
  } catch (error) {
    logger.error("Error rejecting expense:", error);
    res.status(500).json({ message: "Failed to reject expense" });
  }
});

router.patch("/:id/reimburse", isAuthenticated, hasRoleOrPermission(["ADMIN", "HR"], "expenses.approve", "expenses.reimburse"), async (req, res) => {
  try {
    // Validate reimbursement reference
    const validation = validateBody(expenseReimbursementSchema, req.body);
    if (!validation.success) {
      return res.status(400).json({ message: "Validation failed", errors: validation.errors });
    }

    const approvedById = req.session.user!.employeeId;
    const { reimbursementRef } = validation.data;
    const expense = await storage.updateExpense(req.params.id, {
      status: "Reimbursed",
      reimbursementRef,
      approvedById,
    } as any);

    // Fire-and-forget: notify employee of reimbursement
    if (expense) {
      notifyExpenseReimbursed({
        employeeId: expense.requesterId,
        processedBy: approvedById,
        amount: expense.amount,
        expenseId: expense.id,
      }).catch(() => {});
    }
    res.json(expense);
  } catch (error) {
    logger.error("Error reimbursing expense:", error);
    res.status(500).json({ message: "Failed to reimburse expense" });
  }
});

export default router;
