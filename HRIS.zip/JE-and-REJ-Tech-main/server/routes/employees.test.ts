/**
 * Tests for Employees Route
 *
 * Tests all employee-related endpoints including:
 * - CRUD operations
 * - QR code generation
 * - 201 file retrieval
 * - Document management
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { Employee, PayrollRecord, DisciplinaryAction, CashAdvance, EmployeeDocument } from '@shared/schema';

// Mock storage
const mockStorage = {
  getEmployees: vi.fn(),
  getEmployee: vi.fn(),
  createEmployee: vi.fn(),
  updateEmployee: vi.fn(),
  deleteEmployee: vi.fn(),
  getEmployeeDocuments: vi.fn(),
  getDisciplinaryActions: vi.fn(),
  getEmployeePayroll: vi.fn(),
  getCashAdvances: vi.fn(),
  getEmployeeAssignments: vi.fn(),
  createEmployeeDocument: vi.fn(),
  createAuditLog: vi.fn(),
};

vi.mock('../storage', () => ({
  storage: mockStorage,
}));

// Test fixtures
const mockEmployee: Employee = {
  id: 'emp-001',
  firstName: 'Juan',
  lastName: 'Dela Cruz',
  middleName: null,
  email: 'juan@company.com',
  phone: '09171234567',
  address: '123 Main St',
  birthDate: '1990-01-15',
  gender: 'Male',
  civilStatus: 'Single',
  nationality: 'Filipino',
  profilePhotoUrl: null,
  emergencyContactName: 'Maria',
  emergencyContactPhone: '09181234567',
  emergencyContactRelation: 'Mother',
  role: 'WORKER',
  position: 'Electrician',
  department: 'Operations',
  employeeNo: 'EMP-001',
  rateType: 'daily',
  baseRate: '700',
  sssNo: null,
  tinNo: null,
  philhealthNo: null,
  pagibigNo: null,
  bankName: null,
  bankAccountNo: null,
  status: 'Active',
  startDate: '2023-01-15',
  endDate: null,
  regularizationDate: null,
  shiftStartTime: '08:00',
  shiftEndTime: '17:00',
  shiftWorkDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
  qrToken: 'abc123token',
  enableSSSDeduction: true,
  enablePhilhealthDeduction: true,
  enablePagibigDeduction: true,
  enableTaxWithholding: false,
  userId: null,
  createdAt: new Date(),
  updatedAt: new Date(),
};

describe('Employees Route Logic', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('GET /employees', () => {
    it('should return all employees', async () => {
      const employees = [mockEmployee];
      mockStorage.getEmployees.mockResolvedValue(employees);

      const result = await mockStorage.getEmployees();

      expect(result).toHaveLength(1);
      expect(result[0].firstName).toBe('Juan');
    });

    it('should filter employees by status', async () => {
      const activeEmployee = { ...mockEmployee, status: 'Active' as const };
      const resignedEmployee = { ...mockEmployee, id: 'emp-002', status: 'Terminated' as const };
      const employees = [activeEmployee, resignedEmployee];

      mockStorage.getEmployees.mockResolvedValue(employees);

      const result = await mockStorage.getEmployees();
      const filtered = result.filter(e => e.status === 'Active');

      expect(filtered).toHaveLength(1);
      expect(filtered[0].id).toBe('emp-001');
    });

    it('should filter employees by department', async () => {
      const opsEmployee = { ...mockEmployee, department: 'Operations' };
      const hrEmployee = { ...mockEmployee, id: 'emp-002', department: 'HR' };
      const employees = [opsEmployee, hrEmployee];

      mockStorage.getEmployees.mockResolvedValue(employees);

      const result = await mockStorage.getEmployees();
      const filtered = result.filter(e => e.department === 'Operations');

      expect(filtered).toHaveLength(1);
    });

    it('should search employees by name', async () => {
      const juanEmployee = mockEmployee;
      const mariaEmployee = { ...mockEmployee, id: 'emp-002', firstName: 'Maria', lastName: 'Santos' };
      const employees = [juanEmployee, mariaEmployee];

      mockStorage.getEmployees.mockResolvedValue(employees);

      const result = await mockStorage.getEmployees();
      const search = 'juan'.toLowerCase();
      const filtered = result.filter(e =>
        e.firstName.toLowerCase().includes(search) ||
        e.lastName.toLowerCase().includes(search)
      );

      expect(filtered).toHaveLength(1);
      expect(filtered[0].firstName).toBe('Juan');
    });

    it('should search employees by employee number', async () => {
      const employees = [mockEmployee];
      mockStorage.getEmployees.mockResolvedValue(employees);

      const result = await mockStorage.getEmployees();
      const search = 'emp-001'.toLowerCase();
      const filtered = result.filter(e =>
        e.employeeNo && e.employeeNo.toLowerCase().includes(search)
      );

      expect(filtered).toHaveLength(1);
    });
  });

  describe('GET /employees/:id', () => {
    it('should return employee by ID', async () => {
      mockStorage.getEmployee.mockResolvedValue(mockEmployee);

      const result = await mockStorage.getEmployee('emp-001');

      expect(result).toBeDefined();
      expect(result?.id).toBe('emp-001');
      expect(result?.firstName).toBe('Juan');
    });

    it('should return undefined for non-existent employee', async () => {
      mockStorage.getEmployee.mockResolvedValue(undefined);

      const result = await mockStorage.getEmployee('non-existent');

      expect(result).toBeUndefined();
    });
  });

  describe('POST /employees', () => {
    it('should create a new employee', async () => {
      const newEmployee = {
        firstName: 'New',
        lastName: 'Employee',
        role: 'WORKER' as const,
        rateType: 'daily' as const,
        baseRate: '600',
      };

      mockStorage.createEmployee.mockResolvedValue({
        ...mockEmployee,
        ...newEmployee,
        id: 'emp-new',
      });

      const result = await mockStorage.createEmployee(newEmployee as any);

      expect(result.id).toBe('emp-new');
      expect(result.firstName).toBe('New');
    });

    it('should create audit log on employee creation', async () => {
      mockStorage.createEmployee.mockResolvedValue(mockEmployee);
      mockStorage.createAuditLog.mockResolvedValue({});

      await mockStorage.createEmployee({ firstName: 'Test' } as any);
      await mockStorage.createAuditLog({
        userId: 'admin-001',
        action: 'CREATE',
        entityType: 'Employee',
        entityId: mockEmployee.id,
        newValues: {},
      });

      expect(mockStorage.createAuditLog).toHaveBeenCalledWith(
        expect.objectContaining({
          action: 'CREATE',
          entityType: 'Employee',
        })
      );
    });
  });

  describe('PATCH /employees/:id', () => {
    it('should update an existing employee', async () => {
      const updates = { firstName: 'Updated' };
      const updatedEmployee = { ...mockEmployee, ...updates };

      mockStorage.getEmployee.mockResolvedValue(mockEmployee);
      mockStorage.updateEmployee.mockResolvedValue(updatedEmployee);

      const result = await mockStorage.updateEmployee('emp-001', updates);

      expect(result?.firstName).toBe('Updated');
    });

    it('should return undefined for non-existent employee', async () => {
      mockStorage.getEmployee.mockResolvedValue(undefined);

      const result = await mockStorage.getEmployee('non-existent');

      expect(result).toBeUndefined();
    });
  });

  describe('DELETE /employees/:id', () => {
    it('should delete an existing employee', async () => {
      mockStorage.getEmployee.mockResolvedValue(mockEmployee);
      mockStorage.deleteEmployee.mockResolvedValue();

      await mockStorage.deleteEmployee('emp-001');

      expect(mockStorage.deleteEmployee).toHaveBeenCalledWith('emp-001');
    });
  });

  describe('GET /employees/:id/201-file', () => {
    it('should return complete 201 file', async () => {
      const documents: EmployeeDocument[] = [
        {
          id: 'doc-001',
          employeeId: 'emp-001',
          documentType: 'Resume',
          documentName: 'resume.pdf',
          fileUrl: 'https://storage.com/resume.pdf',
          uploadedById: 'hr-001',
          expiryDate: null,
          createdAt: new Date(),
        },
      ];

      const disciplinaryHistory: DisciplinaryAction[] = [
        {
          id: 'disc-001',
          employeeId: 'emp-001',
          issuerId: 'hr-001',
          violationType: 'Tardiness',
          incidentDate: '2025-01-10',
          description: 'Late without notice',
          attachmentUrl: null,
          nteIssuedDate: null,
          responseDeadline: null,
          employeeExplanation: null,
          explanationDate: null,
          status: 'Issued',
          resolution: null,
          sanction: null,
          sanctionDays: null,
          resolvedById: null,
          resolvedAt: null,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];

      const payrollHistory: PayrollRecord[] = [];
      const cashAdvances: CashAdvance[] = [];

      mockStorage.getEmployee.mockResolvedValue(mockEmployee);
      mockStorage.getEmployeeDocuments.mockResolvedValue(documents);
      mockStorage.getDisciplinaryActions.mockResolvedValue(disciplinaryHistory);
      mockStorage.getEmployeePayroll.mockResolvedValue(payrollHistory);
      mockStorage.getCashAdvances.mockResolvedValue(cashAdvances);

      const [emp, docs, disc, pay, ca] = await Promise.all([
        mockStorage.getEmployee('emp-001'),
        mockStorage.getEmployeeDocuments('emp-001'),
        mockStorage.getDisciplinaryActions('emp-001'),
        mockStorage.getEmployeePayroll('emp-001'),
        mockStorage.getCashAdvances('emp-001'),
      ]);

      expect(emp).toBeDefined();
      expect(docs).toHaveLength(1);
      expect(disc).toHaveLength(1);
      expect(pay).toHaveLength(0);
      expect(ca).toHaveLength(0);
    });
  });

  describe('QR Code functionality', () => {
    it('should have qrToken for employee', () => {
      expect(mockEmployee.qrToken).toBe('abc123token');
    });

    it('should generate QR data with correct structure', () => {
      const qrData = JSON.stringify({
        token: mockEmployee.qrToken,
        name: `${mockEmployee.firstName} ${mockEmployee.lastName}`,
        employeeNo: mockEmployee.employeeNo,
      });

      const parsed = JSON.parse(qrData);

      expect(parsed.token).toBe('abc123token');
      expect(parsed.name).toBe('Juan Dela Cruz');
      expect(parsed.employeeNo).toBe('EMP-001');
    });
  });

  describe('Employee assignments', () => {
    it('should get employee assignments', async () => {
      const assignments = [
        {
          id: 'assign-001',
          projectId: 'proj-001',
          employeeId: 'emp-001',
          role: 'Electrician',
          startDate: '2025-01-01',
          endDate: null,
          isActive: true,
          createdAt: new Date(),
        },
      ];

      mockStorage.getEmployeeAssignments.mockResolvedValue(assignments);

      const result = await mockStorage.getEmployeeAssignments('emp-001');

      expect(result).toHaveLength(1);
      expect(result[0].projectId).toBe('proj-001');
    });
  });

  describe('Employee documents', () => {
    it('should get employee documents', async () => {
      const documents = [
        {
          id: 'doc-001',
          employeeId: 'emp-001',
          documentType: 'Contract',
          documentName: 'contract.pdf',
          fileUrl: 'https://storage.com/contract.pdf',
          uploadedById: 'hr-001',
          expiryDate: null,
          createdAt: new Date(),
        },
      ];

      mockStorage.getEmployeeDocuments.mockResolvedValue(documents);

      const result = await mockStorage.getEmployeeDocuments('emp-001');

      expect(result).toHaveLength(1);
      expect(result[0].documentType).toBe('Contract');
    });

    it('should create a new document', async () => {
      const newDoc = {
        employeeId: 'emp-001',
        documentType: 'ID',
        documentName: 'id-card.pdf',
        fileUrl: 'https://storage.com/id.pdf',
      };

      mockStorage.createEmployeeDocument.mockResolvedValue({
        id: 'doc-new',
        ...newDoc,
        uploadedById: null,
        expiryDate: null,
        createdAt: new Date(),
      });

      const result = await mockStorage.createEmployeeDocument(newDoc as any);

      expect(result.id).toBe('doc-new');
      expect(result.documentType).toBe('ID');
    });
  });

  describe('Employee payroll history', () => {
    it('should get employee payroll history', async () => {
      const payrollRecords: PayrollRecord[] = [
        {
          id: 'pay-001',
          employeeId: 'emp-001',
          periodId: null,
          cutoffStart: '2025-01-01',
          cutoffEnd: '2025-01-15',
          payDate: '2025-01-20',
          daysWorked: '11',
          hoursWorked: '88',
          regularOTMinutes: 0,
          restDayOTMinutes: 0,
          holidayOTMinutes: 0,
          regularOTHours: '0',
          restDayOTHours: '0',
          holidayOTHours: '0',
          totalLateMinutes: 0,
          totalUndertimeMinutes: 0,
          basicPay: '7700',
          regularOTPay: '0',
          restDayOTPay: '0',
          holidayOTPay: '0',
          allowances: '0',
          bonusAmount: '0',
          bonusNotes: null,
          grossPay: '7700',
          sssDeduction: '315',
          philhealthDeduction: '192.50',
          pagibigDeduction: '50',
          taxDeduction: '0',
          lateDeduction: '0',
          undertimeDeduction: '0',
          otherDeductionAmount: '0',
          otherDeductionNotes: null,
          otherDeductions: [],
          cashAdvanceDeduction: '0',
          unpaidLeaveDays: '0',
          unpaidLeaveDeduction: '0',
          paidLeaveDays: '0',
          totalDeductions: '557.50',
          netPay: '7142.50',
          isEdited: false,
          overrideNetPay: null,
          editNotes: null,
          payslipStatus: 'Draft',
          status: 'Draft',
          processedBy: null,
          processedAt: null,
          approvedBy: null,
          approvedAt: null,
          releasedAt: null,
          pdfUrl: null,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];

      mockStorage.getEmployeePayroll.mockResolvedValue(payrollRecords);

      const result = await mockStorage.getEmployeePayroll('emp-001');

      expect(result).toHaveLength(1);
      expect(result[0].basicPay).toBe('7700');
    });
  });
});

describe('Employee Data Validation', () => {
  it('should have required fields', () => {
    expect(mockEmployee.firstName).toBeDefined();
    expect(mockEmployee.lastName).toBeDefined();
    expect(mockEmployee.role).toBeDefined();
  });

  it('should have valid role', () => {
    const validRoles = ['ADMIN', 'HR', 'ENGINEER', 'WORKER'];
    expect(validRoles).toContain(mockEmployee.role);
  });

  it('should have valid status', () => {
    const validStatuses = ['Active', 'Probationary', 'Suspended', 'Terminated', 'Inactive'];
    expect(validStatuses).toContain(mockEmployee.status);
  });

  it('should have valid rate type', () => {
    const validRateTypes = ['daily', 'monthly'];
    expect(validRateTypes).toContain(mockEmployee.rateType);
  });

  it('should have valid shift time format', () => {
    const timeRegex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
    expect(mockEmployee.shiftStartTime).toMatch(timeRegex);
    expect(mockEmployee.shiftEndTime).toMatch(timeRegex);
  });

  it('should have valid work days', () => {
    const validDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    expect(mockEmployee.shiftWorkDays).toBeDefined();
    mockEmployee.shiftWorkDays?.forEach(day => {
      expect(validDays).toContain(day);
    });
  });
});

describe('Employee Deduction Flags', () => {
  it('should have SSS deduction enabled by default', () => {
    expect(mockEmployee.enableSSSDeduction).toBe(true);
  });

  it('should have PhilHealth deduction enabled by default', () => {
    expect(mockEmployee.enablePhilhealthDeduction).toBe(true);
  });

  it('should have Pag-IBIG deduction enabled by default', () => {
    expect(mockEmployee.enablePagibigDeduction).toBe(true);
  });

  it('should have tax withholding disabled by default', () => {
    expect(mockEmployee.enableTaxWithholding).toBe(false);
  });
});
