import { Router, Request, Response } from "express";
import { isAuthenticated, hasRole } from "../email-auth";
import { notificationService, categoryDisplayNames, getDefaultPreferences } from "../services/notification.service";
import { getVapidPublicKey, isWebPushEnabled } from "../services/webpush.service";
import { z } from "zod";
import { logger } from "../utils/logger";
import type { NotificationCategory, NotificationChannel } from "@shared/schema";

const router = Router();

// ============================================
// USER NOTIFICATION ENDPOINTS
// ============================================

/**
 * GET /notifications - Get user's notifications with pagination
 */
router.get("/", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const employeeId = req.session.user!.employeeId;
    const limit = parseInt(req.query.limit as string) || 50;
    const offset = parseInt(req.query.offset as string) || 0;
    const unreadOnly = req.query.unreadOnly === "true";
    const category = req.query.category as NotificationCategory | undefined;

    const results = await notificationService.getNotifications(employeeId, {
      limit,
      offset,
      unreadOnly,
      category,
    });

    res.json(results);
  } catch (error) {
    logger.error("Failed to get notifications", error);
    res.status(500).json({ message: "Failed to get notifications" });
  }
});

/**
 * GET /notifications/unread-count - Get unread notification count
 */
router.get("/unread-count", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const employeeId = req.session.user!.employeeId;
    const count = await notificationService.getUnreadCount(employeeId);
    res.json({ count });
  } catch (error) {
    logger.error("Failed to get unread count", error);
    res.status(500).json({ message: "Failed to get unread count" });
  }
});

/**
 * PATCH /notifications/:id/read - Mark a notification as read
 */
router.patch("/:id/read", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const employeeId = req.session.user!.employeeId;
    const success = await notificationService.markAsRead(req.params.id, employeeId);
    if (!success) {
      return res.status(404).json({ message: "Notification not found" });
    }
    res.json({ success: true });
  } catch (error) {
    logger.error("Failed to mark notification as read", error);
    res.status(500).json({ message: "Failed to mark notification as read" });
  }
});

/**
 * PATCH /notifications/read-all - Mark all notifications as read
 */
router.patch("/read-all", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const employeeId = req.session.user!.employeeId;
    const count = await notificationService.markAllAsRead(employeeId);
    res.json({ success: true, count });
  } catch (error) {
    logger.error("Failed to mark all as read", error);
    res.status(500).json({ message: "Failed to mark all as read" });
  }
});

/**
 * DELETE /notifications/:id - Delete a notification
 */
router.delete("/:id", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const employeeId = req.session.user!.employeeId;
    const success = await notificationService.deleteNotification(req.params.id, employeeId);
    if (!success) {
      return res.status(404).json({ message: "Notification not found" });
    }
    res.json({ success: true });
  } catch (error) {
    logger.error("Failed to delete notification", error);
    res.status(500).json({ message: "Failed to delete notification" });
  }
});

// ============================================
// NOTIFICATION PREFERENCES
// ============================================

/**
 * GET /notifications/preferences - Get user's notification preferences
 */
router.get("/preferences", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const employeeId = req.session.user!.employeeId;
    const prefs = await notificationService.getPreferences(employeeId);
    res.json({
      ...prefs,
      categories: categoryDisplayNames,
      defaults: getDefaultPreferences(),
    });
  } catch (error) {
    logger.error("Failed to get preferences", error);
    res.status(500).json({ message: "Failed to get preferences" });
  }
});

/**
 * PATCH /notifications/preferences - Update notification preferences
 */
router.patch("/preferences", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const employeeId = req.session.user!.employeeId;
    const schema = z.object({
      enabled: z.boolean().optional(),
      preferences: z.record(z.record(z.boolean())).optional(),
      quietHoursStart: z.string().nullable().optional(),
      quietHoursEnd: z.string().nullable().optional(),
    });

    const updates = schema.parse(req.body);
    const result = await notificationService.updatePreferences(employeeId, updates as any);
    res.json(result);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Failed to update preferences", error);
    res.status(500).json({ message: "Failed to update preferences" });
  }
});

// ============================================
// PUSH SUBSCRIPTION MANAGEMENT
// ============================================

/**
 * GET /notifications/push/vapid-key - Get VAPID public key for push subscription
 */
router.get("/push/vapid-key", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const enabled = isWebPushEnabled();
    const publicKey = enabled ? getVapidPublicKey() : null;
    res.json({ enabled, publicKey });
  } catch (error) {
    logger.error("Failed to get VAPID key", error);
    res.status(500).json({ message: "Failed to get push configuration" });
  }
});

/**
 * POST /notifications/push/subscribe - Register a push subscription
 */
router.post("/push/subscribe", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const employeeId = req.session.user!.employeeId;
    const schema = z.object({
      endpoint: z.string().url(),
      keys: z.object({
        p256dh: z.string(),
        auth: z.string(),
      }),
    });

    const subscription = schema.parse(req.body);
    const userAgent = req.get("User-Agent");

    const result = await notificationService.addPushSubscription(
      employeeId,
      subscription,
      userAgent
    );

    res.json({ success: true, subscription: result[0] });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Invalid subscription data", errors: error.errors });
    }
    logger.error("Failed to register push subscription", error);
    res.status(500).json({ message: "Failed to register push subscription" });
  }
});

/**
 * POST /notifications/push/unsubscribe - Remove a push subscription
 */
router.post("/push/unsubscribe", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const employeeId = req.session.user!.employeeId;
    const { endpoint } = z.object({ endpoint: z.string() }).parse(req.body);

    await notificationService.removePushSubscription(employeeId, endpoint);
    res.json({ success: true });
  } catch (error) {
    logger.error("Failed to unsubscribe push", error);
    res.status(500).json({ message: "Failed to unsubscribe" });
  }
});

/**
 * GET /notifications/push/subscriptions - Get user's push subscriptions
 */
router.get("/push/subscriptions", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const employeeId = req.session.user!.employeeId;
    const subs = await notificationService.getPushSubscriptions(employeeId);
    res.json(subs);
  } catch (error) {
    logger.error("Failed to get push subscriptions", error);
    res.status(500).json({ message: "Failed to get subscriptions" });
  }
});

// ============================================
// ADMIN NOTIFICATION ENDPOINTS
// ============================================

/**
 * GET /notifications/admin/all - Get all notifications (admin view)
 */
router.get("/admin/all", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const user = req.session.user!;
    // Check for admin access
    if (user.role !== "ADMIN" && user.role !== "HR" && !user.isSuperadmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    const limit = parseInt(req.query.limit as string) || 100;
    const offset = parseInt(req.query.offset as string) || 0;
    const category = req.query.category as NotificationCategory | undefined;
    const employeeId = req.query.employeeId as string | undefined;

    const results = await notificationService.getAdminNotifications({
      limit,
      offset,
      category,
      employeeId,
    });

    res.json(results);
  } catch (error) {
    logger.error("Failed to get admin notifications", error);
    res.status(500).json({ message: "Failed to get notifications" });
  }
});

/**
 * GET /notifications/admin/stats - Get delivery statistics
 */
router.get("/admin/stats", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const user = req.session.user!;
    if (user.role !== "ADMIN" && user.role !== "HR" && !user.isSuperadmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    const stats = await notificationService.getDeliveryStats();
    res.json(stats);
  } catch (error) {
    logger.error("Failed to get notification stats", error);
    res.status(500).json({ message: "Failed to get stats" });
  }
});

/**
 * POST /notifications/admin/broadcast - Broadcast a notification to all employees
 */
router.post("/admin/broadcast", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const user = req.session.user!;
    if (user.role !== "ADMIN" && !user.isSuperadmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    const schema = z.object({
      title: z.string().min(1).max(255),
      message: z.string().min(1),
      category: z.enum(["system", "leave", "payroll", "attendance", "tasks", "expenses", "cash_advance", "disciplinary", "projects", "permissions", "devotional"]),
      priority: z.enum(["low", "normal", "high", "urgent"]).default("normal"),
      roles: z.array(z.string()).optional(),
    });

    const data = schema.parse(req.body);

    const count = await notificationService.broadcast({
      ...data,
      actorId: user.employeeId,
    });

    res.json({ success: true, recipientCount: count });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Failed to broadcast notification", error);
    res.status(500).json({ message: "Failed to broadcast" });
  }
});

// ============================================
// ADMIN - EMPLOYEE NOTIFICATION SETTINGS MANAGEMENT
// ============================================

/**
 * GET /notifications/admin/employees-push-status - Get push notification status for all employees
 */
router.get("/admin/employees-push-status", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const user = req.session.user!;
    if (user.role !== "ADMIN" && user.role !== "HR" && !user.isSuperadmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    const { db } = await import("../db");
    const { employees, notificationPreferences, pushSubscriptions } = await import("@shared/schema");
    const { eq, and, isNull, sql } = await import("drizzle-orm");

    // Get all active employees with their notification preference and push subscription status
    const employeeList = await db
      .select({
        id: employees.id,
        firstName: employees.firstName,
        lastName: employees.lastName,
        employeeNo: employees.employeeNo,
        role: employees.role,
        department: employees.department,
        email: employees.email,
      })
      .from(employees)
      .where(
        and(
          eq(employees.status, "Active"),
          isNull(employees.deletedAt),
          eq(employees.isHidden, false)
        )
      );

    // Get preferences for all employees
    const allPrefs = await db
      .select()
      .from(notificationPreferences);

    // Get active push subscriptions count per employee
    const pushSubCounts = await db
      .select({
        employeeId: pushSubscriptions.employeeId,
        activeCount: sql<number>`count(*) filter (where ${pushSubscriptions.isActive} = true)::int`,
        totalCount: sql<number>`count(*)::int`,
      })
      .from(pushSubscriptions)
      .groupBy(pushSubscriptions.employeeId);

    const prefsMap = new Map(allPrefs.map(p => [p.employeeId, p]));
    const pushMap = new Map(pushSubCounts.map(p => [p.employeeId, p]));

    const result = employeeList.map(emp => {
      const pref = prefsMap.get(emp.id);
      const pushStatus = pushMap.get(emp.id);

      // Check if any push category is enabled in preferences
      const hasPushEnabled = pref?.preferences
        ? Object.values(pref.preferences as Record<string, Record<string, boolean>>)
            .some(cat => cat.push === true)
        : false;

      return {
        ...emp,
        notificationsEnabled: pref?.enabled ?? true,
        hasPushEnabled,
        pushSubscriptionCount: pushStatus?.activeCount ?? 0,
        totalSubscriptions: pushStatus?.totalCount ?? 0,
        preferences: pref?.preferences ?? null,
      };
    });

    res.json(result);
  } catch (error) {
    logger.error("Failed to get employee push status", error);
    res.status(500).json({ message: "Failed to get employee push status" });
  }
});

/**
 * PATCH /notifications/admin/employee-preferences/:employeeId - Admin update employee preferences
 * Allows admin to enable/disable push and email channels for a specific employee
 */
router.patch("/admin/employee-preferences/:employeeId", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const user = req.session.user!;
    if (user.role !== "ADMIN" && !user.isSuperadmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    const { employeeId } = req.params;
    const schema = z.object({
      enabled: z.boolean().optional(),
      preferences: z.record(z.record(z.boolean())).optional(),
    });

    const updates = schema.parse(req.body);
    const result = await notificationService.updatePreferences(employeeId, updates as any);
    res.json(result);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Validation error", errors: error.errors });
    }
    logger.error("Failed to update employee preferences", error);
    res.status(500).json({ message: "Failed to update employee preferences" });
  }
});

/**
 * POST /notifications/admin/enable-push-for-employee/:employeeId - Enable all push channels for an employee
 */
router.post("/admin/enable-push-for-employee/:employeeId", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const user = req.session.user!;
    if (user.role !== "ADMIN" && !user.isSuperadmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    const { employeeId } = req.params;
    const prefs = await notificationService.getPreferences(employeeId);

    // Enable push for all categories
    const updatedPreferences = { ...(prefs.preferences as Record<string, Record<string, boolean>>) };
    for (const category of Object.keys(updatedPreferences)) {
      updatedPreferences[category] = { ...updatedPreferences[category], push: true };
    }

    const result = await notificationService.updatePreferences(employeeId, {
      enabled: true,
      preferences: updatedPreferences as any,
    });

    res.json({ success: true, result });
  } catch (error) {
    logger.error("Failed to enable push for employee", error);
    res.status(500).json({ message: "Failed to enable push for employee" });
  }
});

/**
 * POST /notifications/admin/disable-push-for-employee/:employeeId - Disable all push channels for an employee
 */
router.post("/admin/disable-push-for-employee/:employeeId", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const user = req.session.user!;
    if (user.role !== "ADMIN" && !user.isSuperadmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    const { employeeId } = req.params;
    const prefs = await notificationService.getPreferences(employeeId);

    // Disable push for all categories
    const updatedPreferences = { ...(prefs.preferences as Record<string, Record<string, boolean>>) };
    for (const category of Object.keys(updatedPreferences)) {
      updatedPreferences[category] = { ...updatedPreferences[category], push: false };
    }

    const result = await notificationService.updatePreferences(employeeId, {
      preferences: updatedPreferences as any,
    });

    res.json({ success: true, result });
  } catch (error) {
    logger.error("Failed to disable push for employee", error);
    res.status(500).json({ message: "Failed to disable push for employee" });
  }
});

/**
 * POST /notifications/admin/send-test-push/:employeeId - Send a test push notification to verify it works
 */
router.post("/admin/send-test-push/:employeeId", isAuthenticated, async (req: Request, res: Response) => {
  try {
    const user = req.session.user!;
    if (user.role !== "ADMIN" && !user.isSuperadmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    const { employeeId } = req.params;

    // Send a test notification via the notification service
    await notificationService.notify({
      category: "system",
      title: "Test Push Notification",
      message: "This is a test push notification sent by the administrator to verify your push notifications are working correctly.",
      priority: "normal",
      recipientIds: [employeeId],
      actorId: user.employeeId,
      actionUrl: "/my-profile?tab=notifications",
    });

    res.json({ success: true, message: "Test notification sent" });
  } catch (error) {
    logger.error("Failed to send test push", error);
    res.status(500).json({ message: "Failed to send test push notification" });
  }
});

export default router;
