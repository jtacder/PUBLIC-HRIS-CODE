import { db } from "../db";
import {
  permissions,
  roles,
  rolePermissions,
  userPermissions,
  employees,
  permissionAuditLogs,
  type Permission,
  type Role,
  type InsertPermissionAuditLog,
} from "@shared/schema";
import { eq, and, inArray, isNull, or, gt } from "drizzle-orm";
import { logger } from "../utils/logger";

// In-memory cache for permissions (5 minute TTL)
interface PermissionCache {
  permissions: string[];
  isSuperadmin: boolean;
  roleId: string | null;
  expiresAt: number;
}

const permissionCache = new Map<string, PermissionCache>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

/**
 * Permission Service - Handles all permission-related operations
 */
export class PermissionService {
  /**
   * Check if user has a specific permission
   */
  async hasPermission(employeeId: string, permissionCode: string): Promise<boolean> {
    const userPerms = await this.getUserPermissions(employeeId);
    if (userPerms.isSuperadmin) return true;
    return userPerms.permissions.includes(permissionCode);
  }

  /**
   * Check if user has any of the specified permissions
   */
  async hasAnyPermission(employeeId: string, permissionCodes: string[]): Promise<boolean> {
    const userPerms = await this.getUserPermissions(employeeId);
    if (userPerms.isSuperadmin) return true;
    return permissionCodes.some(code => userPerms.permissions.includes(code));
  }

  /**
   * Check if user has all of the specified permissions
   */
  async hasAllPermissions(employeeId: string, permissionCodes: string[]): Promise<boolean> {
    const userPerms = await this.getUserPermissions(employeeId);
    if (userPerms.isSuperadmin) return true;
    return permissionCodes.every(code => userPerms.permissions.includes(code));
  }

  /**
   * Get all effective permissions for a user (with caching)
   */
  async getUserPermissions(employeeId: string): Promise<PermissionCache> {
    // Check cache first
    const cached = permissionCache.get(employeeId);
    if (cached && cached.expiresAt > Date.now()) {
      return cached;
    }

    // Load from database
    const result = await this.loadUserPermissions(employeeId);

    // Cache the result
    permissionCache.set(employeeId, result);

    return result;
  }

  /**
   * Load all effective permissions for a user from database
   * Combines: role permissions + individual grants (excluding expired)
   */
  private async loadUserPermissions(employeeId: string): Promise<PermissionCache> {
    try {
      // Get employee with their role
      const [employee] = await db
        .select({
          roleId: employees.roleId,
        })
        .from(employees)
        .where(eq(employees.id, employeeId))
        .limit(1);

      if (!employee) {
        return {
          permissions: [],
          isSuperadmin: false,
          roleId: null,
          expiresAt: Date.now() + CACHE_TTL,
        };
      }

      // Check if user has a role and if it's a superadmin role
      let isSuperadmin = false;
      let rolePermissionCodes: string[] = [];

      if (employee.roleId) {
        // Get role details
        const [role] = await db
          .select()
          .from(roles)
          .where(eq(roles.id, employee.roleId))
          .limit(1);

        if (role) {
          isSuperadmin = role.isSuperadmin;

          // Get role permissions
          const rolePerms = await db
            .select({
              code: permissions.code,
            })
            .from(rolePermissions)
            .innerJoin(permissions, eq(rolePermissions.permissionId, permissions.id))
            .where(
              and(
                eq(rolePermissions.roleId, employee.roleId),
                eq(permissions.isActive, true)
              )
            );

          rolePermissionCodes = rolePerms.map(p => p.code);
        }
      }

      // Get individual permission grants (not expired)
      const now = new Date();
      const individualGrants = await db
        .select({
          code: permissions.code,
        })
        .from(userPermissions)
        .innerJoin(permissions, eq(userPermissions.permissionId, permissions.id))
        .where(
          and(
            eq(userPermissions.employeeId, employeeId),
            eq(permissions.isActive, true),
            or(
              isNull(userPermissions.expiresAt),
              gt(userPermissions.expiresAt, now)
            )
          )
        );

      const individualCodes = individualGrants.map(g => g.code);

      // Combine role permissions + individual grants (unique)
      const allPermissions = [...new Set([...rolePermissionCodes, ...individualCodes])];

      return {
        permissions: allPermissions,
        isSuperadmin,
        roleId: employee.roleId,
        expiresAt: Date.now() + CACHE_TTL,
      };
    } catch (error) {
      logger.error("Error loading user permissions", error);
      return {
        permissions: [],
        isSuperadmin: false,
        roleId: null,
        expiresAt: Date.now() + CACHE_TTL,
      };
    }
  }

  /**
   * Check if user is a superadmin
   */
  async isSuperadmin(employeeId: string): Promise<boolean> {
    const userPerms = await this.getUserPermissions(employeeId);
    return userPerms.isSuperadmin;
  }

  /**
   * Invalidate cache for a specific user
   */
  invalidateCache(employeeId: string): void {
    permissionCache.delete(employeeId);
  }

  /**
   * Invalidate cache for all users with a specific role
   */
  async invalidateCacheByRole(roleId: string): Promise<void> {
    const employeesWithRole = await db
      .select({ id: employees.id })
      .from(employees)
      .where(eq(employees.roleId, roleId));

    employeesWithRole.forEach(emp => {
      permissionCache.delete(emp.id);
    });
  }

  /**
   * Clear entire permission cache
   */
  clearCache(): void {
    permissionCache.clear();
  }

  /**
   * Get all available permissions grouped by feature
   */
  async getAllPermissions(): Promise<Permission[]> {
    return db
      .select()
      .from(permissions)
      .where(eq(permissions.isActive, true))
      .orderBy(permissions.category, permissions.feature, permissions.sortOrder);
  }

  /**
   * Get permissions grouped by category and feature
   */
  async getPermissionsGrouped(): Promise<Record<string, Record<string, Permission[]>>> {
    const allPerms = await this.getAllPermissions();

    const grouped: Record<string, Record<string, Permission[]>> = {};

    allPerms.forEach(perm => {
      if (!grouped[perm.category]) {
        grouped[perm.category] = {};
      }
      if (!grouped[perm.category][perm.feature]) {
        grouped[perm.category][perm.feature] = [];
      }
      grouped[perm.category][perm.feature].push(perm);
    });

    return grouped;
  }

  /**
   * Get all roles
   */
  async getAllRoles(): Promise<Role[]> {
    return db.select().from(roles).orderBy(roles.name);
  }

  /**
   * Get role by ID with its permissions
   */
  async getRoleWithPermissions(roleId: string): Promise<{ role: Role; permissions: Permission[] } | null> {
    const [role] = await db
      .select()
      .from(roles)
      .where(eq(roles.id, roleId))
      .limit(1);

    if (!role) return null;

    const rolePerms = await db
      .select({
        permission: permissions,
      })
      .from(rolePermissions)
      .innerJoin(permissions, eq(rolePermissions.permissionId, permissions.id))
      .where(eq(rolePermissions.roleId, roleId));

    return {
      role,
      permissions: rolePerms.map(rp => rp.permission),
    };
  }

  /**
   * Update role permissions
   */
  async updateRolePermissions(
    roleId: string,
    permissionIds: string[],
    actorId: string,
    ipAddress?: string,
    userAgent?: string
  ): Promise<void> {
    // Get current permissions for audit log
    const currentPerms = await db
      .select({ permissionId: rolePermissions.permissionId })
      .from(rolePermissions)
      .where(eq(rolePermissions.roleId, roleId));

    const currentPermIds = currentPerms.map(p => p.permissionId);

    // Delete existing role permissions
    await db.delete(rolePermissions).where(eq(rolePermissions.roleId, roleId));

    // Insert new role permissions
    if (permissionIds.length > 0) {
      await db.insert(rolePermissions).values(
        permissionIds.map(permissionId => ({
          roleId,
          permissionId,
        }))
      );
    }

    // Log the change
    await this.logPermissionChange({
      actorId,
      action: "role_permissions_updated",
      roleId,
      oldValue: { permissionIds: currentPermIds },
      newValue: { permissionIds },
      ipAddress,
      userAgent,
    });

    // Invalidate cache for all users with this role
    await this.invalidateCacheByRole(roleId);
  }

  /**
   * Grant individual permission to user
   */
  async grantPermission(
    employeeId: string,
    permissionId: string,
    grantedById: string,
    expiresAt?: Date,
    ipAddress?: string,
    userAgent?: string
  ): Promise<void> {
    // Check if already granted
    const [existing] = await db
      .select()
      .from(userPermissions)
      .where(
        and(
          eq(userPermissions.employeeId, employeeId),
          eq(userPermissions.permissionId, permissionId)
        )
      )
      .limit(1);

    if (existing) {
      // Update expiration if needed
      await db
        .update(userPermissions)
        .set({ expiresAt, grantedById, grantedAt: new Date() })
        .where(eq(userPermissions.id, existing.id));
    } else {
      // Insert new grant
      await db.insert(userPermissions).values({
        employeeId,
        permissionId,
        grantedById,
        expiresAt,
      });
    }

    // Get permission code for logging
    const [perm] = await db
      .select({ code: permissions.code })
      .from(permissions)
      .where(eq(permissions.id, permissionId))
      .limit(1);

    // Log the change
    await this.logPermissionChange({
      actorId: grantedById,
      targetEmployeeId: employeeId,
      action: "permission_granted",
      permissionCode: perm?.code,
      ipAddress,
      userAgent,
    });

    // Invalidate user's cache
    this.invalidateCache(employeeId);
  }

  /**
   * Revoke individual permission from user
   */
  async revokePermission(
    employeeId: string,
    permissionId: string,
    revokedById: string,
    ipAddress?: string,
    userAgent?: string
  ): Promise<void> {
    // Get permission code for logging
    const [perm] = await db
      .select({ code: permissions.code })
      .from(permissions)
      .where(eq(permissions.id, permissionId))
      .limit(1);

    // Delete the grant
    await db
      .delete(userPermissions)
      .where(
        and(
          eq(userPermissions.employeeId, employeeId),
          eq(userPermissions.permissionId, permissionId)
        )
      );

    // Log the change
    await this.logPermissionChange({
      actorId: revokedById,
      targetEmployeeId: employeeId,
      action: "permission_revoked",
      permissionCode: perm?.code,
      ipAddress,
      userAgent,
    });

    // Invalidate user's cache
    this.invalidateCache(employeeId);
  }

  /**
   * Update user's individual permissions (bulk)
   */
  async updateUserPermissions(
    employeeId: string,
    permissionIds: string[],
    grantedById: string,
    ipAddress?: string,
    userAgent?: string
  ): Promise<void> {
    // Get current permissions for audit log
    const currentPerms = await db
      .select({ permissionId: userPermissions.permissionId })
      .from(userPermissions)
      .where(eq(userPermissions.employeeId, employeeId));

    const currentPermIds = currentPerms.map(p => p.permissionId);

    // Delete existing user permissions
    await db.delete(userPermissions).where(eq(userPermissions.employeeId, employeeId));

    // Insert new user permissions
    if (permissionIds.length > 0) {
      await db.insert(userPermissions).values(
        permissionIds.map(permissionId => ({
          employeeId,
          permissionId,
          grantedById,
        }))
      );
    }

    // Log the change
    await this.logPermissionChange({
      actorId: grantedById,
      targetEmployeeId: employeeId,
      action: "user_permissions_updated",
      oldValue: { permissionIds: currentPermIds },
      newValue: { permissionIds },
      ipAddress,
      userAgent,
    });

    // Invalidate user's cache
    this.invalidateCache(employeeId);
  }

  /**
   * Change user's role
   * When a role is assigned, individual permissions are cleared (role takes over)
   * When a role is removed, individual permissions are also cleared for clean state
   */
  async changeUserRole(
    employeeId: string,
    newRoleId: string | null,
    changedById: string,
    ipAddress?: string,
    userAgent?: string,
    clearIndividualPermissions: boolean = true
  ): Promise<void> {
    // Get current role for audit log
    const [employee] = await db
      .select({ roleId: employees.roleId })
      .from(employees)
      .where(eq(employees.id, employeeId))
      .limit(1);

    const oldRoleId = employee?.roleId;

    // Update employee's role
    await db
      .update(employees)
      .set({ roleId: newRoleId, updatedAt: new Date() })
      .where(eq(employees.id, employeeId));

    // Clear individual permissions when role changes to prevent confusion
    // This ensures permissions come ONLY from the assigned role
    if (clearIndividualPermissions) {
      // Get current individual permissions for audit log
      const currentIndividualPerms = await db
        .select({ permissionId: userPermissions.permissionId })
        .from(userPermissions)
        .where(eq(userPermissions.employeeId, employeeId));

      if (currentIndividualPerms.length > 0) {
        await db.delete(userPermissions).where(eq(userPermissions.employeeId, employeeId));

        // Log the clearing of individual permissions
        await this.logPermissionChange({
          actorId: changedById,
          targetEmployeeId: employeeId,
          action: "individual_permissions_cleared_on_role_change",
          oldValue: { permissionIds: currentIndividualPerms.map(p => p.permissionId) },
          newValue: { permissionIds: [] },
          ipAddress,
          userAgent,
        });
      }
    }

    // Log the role change
    await this.logPermissionChange({
      actorId: changedById,
      targetEmployeeId: employeeId,
      action: "role_changed",
      roleId: newRoleId || undefined,
      oldValue: { roleId: oldRoleId },
      newValue: { roleId: newRoleId },
      ipAddress,
      userAgent,
    });

    // Invalidate user's cache
    this.invalidateCache(employeeId);
  }

  /**
   * Get user's individual permissions (not from role)
   */
  async getUserIndividualPermissions(employeeId: string): Promise<Permission[]> {
    const now = new Date();
    const grants = await db
      .select({
        permission: permissions,
      })
      .from(userPermissions)
      .innerJoin(permissions, eq(userPermissions.permissionId, permissions.id))
      .where(
        and(
          eq(userPermissions.employeeId, employeeId),
          or(
            isNull(userPermissions.expiresAt),
            gt(userPermissions.expiresAt, now)
          )
        )
      );

    return grants.map(g => g.permission);
  }

  /**
   * Get employee's effective permissions with details
   */
  async getEmployeePermissionDetails(employeeId: string): Promise<{
    role: Role | null;
    rolePermissions: Permission[];
    individualPermissions: Permission[];
    effectivePermissions: string[];
    isSuperadmin: boolean;
  }> {
    const [employee] = await db
      .select({
        roleId: employees.roleId,
      })
      .from(employees)
      .where(eq(employees.id, employeeId))
      .limit(1);

    let role: Role | null = null;
    let rolePerms: Permission[] = [];
    let isSuperadmin = false;

    if (employee?.roleId) {
      const roleData = await this.getRoleWithPermissions(employee.roleId);
      if (roleData) {
        role = roleData.role;
        rolePerms = roleData.permissions;
        isSuperadmin = role.isSuperadmin;
      }
    }

    const individualPerms = await this.getUserIndividualPermissions(employeeId);

    // Combine for effective permissions
    const allCodes = [
      ...rolePerms.map(p => p.code),
      ...individualPerms.map(p => p.code),
    ];
    const effectivePermissions = [...new Set(allCodes)];

    return {
      role,
      rolePermissions: rolePerms,
      individualPermissions: individualPerms,
      effectivePermissions,
      isSuperadmin,
    };
  }

  /**
   * Log permission change to audit log
   */
  private async logPermissionChange(data: Omit<InsertPermissionAuditLog, "id" | "createdAt">): Promise<void> {
    try {
      await db.insert(permissionAuditLogs).values(data);
    } catch (error) {
      logger.error("Error logging permission change", error);
    }
  }

  /**
   * Get permission audit logs
   */
  async getPermissionAuditLogs(options?: {
    targetEmployeeId?: string;
    actorId?: string;
    limit?: number;
    offset?: number;
  }): Promise<any[]> {
    let query = db
      .select({
        log: permissionAuditLogs,
        actor: {
          id: employees.id,
          firstName: employees.firstName,
          lastName: employees.lastName,
        },
      })
      .from(permissionAuditLogs)
      .leftJoin(employees, eq(permissionAuditLogs.actorId, employees.id))
      .orderBy(permissionAuditLogs.createdAt);

    // Apply filters would go here with dynamic query building
    // For now, return all with limit

    return query.limit(options?.limit || 100);
  }

  /**
   * Sync role permissions - ensures a role has the expected permissions
   * Used to fix cases where role exists but rolePermissions table is empty
   */
  async syncRolePermissions(
    roleId: string,
    permissionCodes: string[],
    actorId: string,
    ipAddress?: string,
    userAgent?: string
  ): Promise<{ added: number; existing: number }> {
    // Get permission IDs for the codes
    const perms = await db
      .select({ id: permissions.id, code: permissions.code })
      .from(permissions)
      .where(eq(permissions.isActive, true));

    const permissionMap = new Map(perms.map(p => [p.code, p.id]));
    const permissionIds = permissionCodes
      .filter(code => permissionMap.has(code))
      .map(code => permissionMap.get(code)!);

    // Get current role permissions
    const currentPerms = await db
      .select({ permissionId: rolePermissions.permissionId })
      .from(rolePermissions)
      .where(eq(rolePermissions.roleId, roleId));

    const currentPermIds = new Set(currentPerms.map(p => p.permissionId));

    // Find permissions to add
    const toAdd = permissionIds.filter(id => !currentPermIds.has(id));

    if (toAdd.length > 0) {
      await db.insert(rolePermissions).values(
        toAdd.map(permissionId => ({
          roleId,
          permissionId,
        }))
      );

      // Log the change
      await this.logPermissionChange({
        actorId,
        action: "role_permissions_synced",
        roleId,
        newValue: { addedPermissionIds: toAdd },
        ipAddress,
        userAgent,
      });

      // Invalidate cache for all users with this role
      await this.invalidateCacheByRole(roleId);
    }

    return {
      added: toAdd.length,
      existing: currentPermIds.size,
    };
  }

  /**
   * Get role permission count - useful for diagnostics
   */
  async getRolePermissionCount(roleId: string): Promise<number> {
    const [result] = await db
      .select({ count: permissions.id })
      .from(rolePermissions)
      .innerJoin(permissions, eq(rolePermissions.permissionId, permissions.id))
      .where(
        and(
          eq(rolePermissions.roleId, roleId),
          eq(permissions.isActive, true)
        )
      );

    return result ? 1 : 0; // Simplified - just check if any exist
  }

  /**
   * Verify and fix role permissions if empty
   */
  async verifyRoleHasPermissions(roleId: string): Promise<boolean> {
    const perms = await db
      .select({ id: rolePermissions.permissionId })
      .from(rolePermissions)
      .where(eq(rolePermissions.roleId, roleId))
      .limit(1);

    return perms.length > 0;
  }
}

// Singleton instance
export const permissionService = new PermissionService();
