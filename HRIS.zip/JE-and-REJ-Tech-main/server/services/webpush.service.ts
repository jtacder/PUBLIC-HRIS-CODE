import { config } from "../config";
import { logger } from "../utils/logger";

let webPushInitialized = false;

/**
 * Initialize Web Push with VAPID keys.
 * Called once at server startup.
 * If VAPID keys are not configured, push notifications are disabled gracefully.
 */
export async function initializeWebPush(): Promise<boolean> {
  if (!config.webPush.enabled) {
    logger.info("Web Push disabled: VAPID keys not configured. Set VAPID_PUBLIC_KEY and VAPID_PRIVATE_KEY to enable.");
    return false;
  }

  try {
    // @ts-ignore - optional dependency
    const webpush = await import("web-push") as any;
    webpush.default.setVapidDetails(
      config.webPush.vapidSubject,
      config.webPush.vapidPublicKey,
      config.webPush.vapidPrivateKey
    );
    webPushInitialized = true;
    logger.info("Web Push initialized with VAPID keys");
    return true;
  } catch (error) {
    logger.error("Failed to initialize Web Push", error);
    return false;
  }
}

/**
 * Check if Web Push is ready
 */
export function isWebPushEnabled(): boolean {
  return webPushInitialized;
}

/**
 * Get the VAPID public key for client subscription
 */
export function getVapidPublicKey(): string {
  return config.webPush.vapidPublicKey;
}
