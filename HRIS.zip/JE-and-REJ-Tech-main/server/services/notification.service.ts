import { db } from "../db";
import {
  notifications,
  notificationPreferences,
  pushSubscriptions,
  employees,
  type InsertNotification,
  type NotificationCategory,
  type NotificationChannel,
  type NotificationPriority,
  notificationCategoryEnum,
} from "@shared/schema";
import { eq, and, desc, lt, sql, isNull, or, inArray } from "drizzle-orm";
import { logger } from "../utils/logger";
import { sendEmail } from "./email.service";

// ============================================
// DEFAULT PREFERENCES
// ============================================

/** Default notification preferences for a new user - in-app ON, push OFF, email OFF */
export function getDefaultPreferences(): Record<NotificationCategory, Record<NotificationChannel, boolean>> {
  const defaults: Record<string, Record<NotificationChannel, boolean>> = {};
  for (const category of notificationCategoryEnum) {
    defaults[category] = {
      in_app: true,
      push: false,
      email: false,
    };
  }
  return defaults as Record<NotificationCategory, Record<NotificationChannel, boolean>>;
}

// ============================================
// NOTIFICATION EVENT DEFINITIONS
// ============================================

export interface NotificationEvent {
  category: NotificationCategory;
  title: string;
  message: string;
  priority: NotificationPriority;
  recipientIds: string[];
  actorId?: string;
  entityType?: string;
  entityId?: string;
  actionUrl?: string;
  emailSubject?: string; // Override for email subject
  emailHtml?: string;    // Custom email body HTML
}

// Category display names for preferences UI
export const categoryDisplayNames: Record<NotificationCategory, { label: string; description: string }> = {
  leave: { label: "Leave Requests", description: "Leave request submissions, approvals, and rejections" },
  payroll: { label: "Payroll & Payslips", description: "Payroll processing, releases, and payslip availability" },
  attendance: { label: "Attendance", description: "Tardiness, geofence violations, and attendance flags" },
  tasks: { label: "Tasks", description: "Task assignments, due dates, and status changes" },
  expenses: { label: "Expenses", description: "Expense requests, approvals, and reimbursements" },
  cash_advance: { label: "Cash Advances & Loans", description: "Cash advance and loan request workflows" },
  disciplinary: { label: "Disciplinary", description: "NTE issuances, deadlines, and resolutions" },
  projects: { label: "Projects", description: "Project assignments, status changes, and comments" },
  permissions: { label: "Permissions", description: "Role and permission changes" },
  system: { label: "System", description: "System announcements, holidays, and maintenance" },
  devotional: { label: "Devotional", description: "Reading streaks and milestone achievements" },
};

// ============================================
// CORE NOTIFICATION SERVICE
// ============================================

class NotificationService {
  // WebSocket broadcast function - set by websocket setup
  private wsBroadcast: ((employeeId: string, data: any) => void) | null = null;

  /**
   * Register the WebSocket broadcast function
   */
  setWebSocketBroadcast(fn: (employeeId: string, data: any) => void) {
    this.wsBroadcast = fn;
  }

  /**
   * Send a notification event to one or more recipients.
   * Respects user preferences for each delivery channel.
   */
  async notify(event: NotificationEvent): Promise<void> {
    try {
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30); // 30-day expiry

      for (const recipientId of event.recipientIds) {
        // Check preferences before creating
        const prefs = await this.getPreferences(recipientId);

        // If notifications are globally disabled, skip entirely
        if (!prefs.enabled) continue;

        const categoryPrefs = prefs.preferences[event.category];
        if (!categoryPrefs) continue;

        // Always create the in-app notification if enabled
        const shouldCreateInApp = categoryPrefs.in_app !== false;
        if (!shouldCreateInApp) continue;

        const [notification] = await db
          .insert(notifications)
          .values({
            recipientId,
            title: event.title,
            message: event.message,
            category: event.category,
            priority: event.priority,
            actionUrl: event.actionUrl,
            entityType: event.entityType,
            entityId: event.entityId,
            actorId: event.actorId,
            expiresAt,
          })
          .returning();

        // Send real-time WebSocket notification
        if (this.wsBroadcast && notification) {
          this.wsBroadcast(recipientId, {
            type: "notification",
            payload: notification,
          });
        }

        // Send push notification if enabled
        if (categoryPrefs.push) {
          this.sendPush(recipientId, notification).catch((err) => {
            logger.error("Push notification failed", err);
          });
        }

        // Send email notification if enabled (and email content provided or priority is high/urgent)
        if (categoryPrefs.email && (event.emailHtml || event.priority === "urgent" || event.priority === "high")) {
          this.sendEmailNotification(recipientId, event, notification?.id).catch((err) => {
            logger.error("Email notification failed", err);
          });
        }
      }
    } catch (error) {
      logger.error("Failed to send notification", error);
    }
  }

  /**
   * Get user preferences, creating defaults if they don't exist
   */
  async getPreferences(employeeId: string) {
    const [existing] = await db
      .select()
      .from(notificationPreferences)
      .where(eq(notificationPreferences.employeeId, employeeId))
      .limit(1);

    if (existing) return existing;

    // Create default preferences
    const defaults = getDefaultPreferences();
    const [created] = await db
      .insert(notificationPreferences)
      .values({
        employeeId,
        enabled: true,
        preferences: defaults,
      })
      .returning();

    return created;
  }

  /**
   * Update user preferences
   */
  async updatePreferences(
    employeeId: string,
    updates: {
      enabled?: boolean;
      preferences?: Record<NotificationCategory, Record<NotificationChannel, boolean>>;
      quietHoursStart?: string | null;
      quietHoursEnd?: string | null;
    }
  ) {
    const existing = await this.getPreferences(employeeId);

    const [updated] = await db
      .update(notificationPreferences)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(notificationPreferences.id, existing.id))
      .returning();

    return updated;
  }

  /**
   * Get notifications for a user with pagination
   */
  async getNotifications(
    employeeId: string,
    options: {
      limit?: number;
      offset?: number;
      unreadOnly?: boolean;
      category?: NotificationCategory;
    } = {}
  ) {
    const { limit = 50, offset = 0, unreadOnly = false, category } = options;

    const conditions = [eq(notifications.recipientId, employeeId)];

    if (unreadOnly) {
      conditions.push(eq(notifications.isRead, false));
    }
    if (category) {
      conditions.push(eq(notifications.category, category));
    }

    const results = await db
      .select({
        notification: notifications,
        actor: {
          id: employees.id,
          firstName: employees.firstName,
          lastName: employees.lastName,
          profilePhotoUrl: employees.profilePhotoUrl,
        },
      })
      .from(notifications)
      .leftJoin(employees, eq(notifications.actorId, employees.id))
      .where(and(...conditions))
      .orderBy(desc(notifications.createdAt))
      .limit(limit)
      .offset(offset);

    return results;
  }

  /**
   * Get unread count for badge display
   */
  async getUnreadCount(employeeId: string): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(notifications)
      .where(
        and(
          eq(notifications.recipientId, employeeId),
          eq(notifications.isRead, false)
        )
      );

    return result?.count || 0;
  }

  /**
   * Mark a single notification as read
   */
  async markAsRead(notificationId: string, employeeId: string): Promise<boolean> {
    const [updated] = await db
      .update(notifications)
      .set({ isRead: true, readAt: new Date() })
      .where(
        and(
          eq(notifications.id, notificationId),
          eq(notifications.recipientId, employeeId)
        )
      )
      .returning();

    return !!updated;
  }

  /**
   * Mark all notifications as read for a user
   */
  async markAllAsRead(employeeId: string): Promise<number> {
    const result = await db
      .update(notifications)
      .set({ isRead: true, readAt: new Date() })
      .where(
        and(
          eq(notifications.recipientId, employeeId),
          eq(notifications.isRead, false)
        )
      )
      .returning({ id: notifications.id });

    return result.length;
  }

  /**
   * Delete a notification
   */
  async deleteNotification(notificationId: string, employeeId: string): Promise<boolean> {
    const [deleted] = await db
      .delete(notifications)
      .where(
        and(
          eq(notifications.id, notificationId),
          eq(notifications.recipientId, employeeId)
        )
      )
      .returning();

    return !!deleted;
  }

  /**
   * Clean up expired notifications (30-day retention)
   */
  async cleanupExpired(): Promise<number> {
    const now = new Date();
    const result = await db
      .delete(notifications)
      .where(
        and(
          lt(notifications.expiresAt, now)
        )
      )
      .returning({ id: notifications.id });

    if (result.length > 0) {
      logger.info(`Cleaned up ${result.length} expired notifications`);
    }

    return result.length;
  }

  /**
   * Send push notification via Web Push API
   */
  private async sendPush(recipientId: string, notification: any): Promise<void> {
    try {
      // Dynamic import to avoid requiring web-push if not configured
      // @ts-ignore - dynamic import for optional dependency
      const webpush = await import("web-push").catch(() => null) as any;
      if (!webpush) return;

      const subs = await db
        .select()
        .from(pushSubscriptions)
        .where(
          and(
            eq(pushSubscriptions.employeeId, recipientId),
            eq(pushSubscriptions.isActive, true)
          )
        );

      if (subs.length === 0) return;

      const payload = JSON.stringify({
        title: notification.title,
        body: notification.message,
        icon: "/icons/notification-icon.png",
        badge: "/icons/badge-icon.png",
        data: {
          url: notification.actionUrl || "/",
          notificationId: notification.id,
          category: notification.category,
        },
      });

      for (const sub of subs) {
        try {
          await webpush.default.sendNotification(
            {
              endpoint: sub.endpoint,
              keys: {
                p256dh: sub.p256dh,
                auth: sub.auth,
              },
            },
            payload
          );

          // Update last used
          await db
            .update(pushSubscriptions)
            .set({ lastUsedAt: new Date(), failCount: 0 })
            .where(eq(pushSubscriptions.id, sub.id));

          // Mark push as sent on notification
          await db
            .update(notifications)
            .set({ pushSent: true })
            .where(eq(notifications.id, notification.id));
        } catch (pushError: any) {
          // If subscription is gone (410) or invalid (404), deactivate it
          if (pushError?.statusCode === 410 || pushError?.statusCode === 404) {
            await db
              .update(pushSubscriptions)
              .set({ isActive: false })
              .where(eq(pushSubscriptions.id, sub.id));
            logger.info(`Deactivated expired push subscription ${sub.id}`);
          } else {
            // Increment fail count, deactivate after 5 failures
            const newFailCount = (sub.failCount || 0) + 1;
            await db
              .update(pushSubscriptions)
              .set({
                failCount: newFailCount,
                isActive: newFailCount < 5,
              })
              .where(eq(pushSubscriptions.id, sub.id));
          }
        }
      }
    } catch (error) {
      logger.error("Push notification error", error);
    }
  }

  /**
   * Send email notification for critical events
   */
  private async sendEmailNotification(
    recipientId: string,
    event: NotificationEvent,
    notificationId?: string
  ): Promise<void> {
    try {
      // Get employee email
      const [employee] = await db
        .select({ email: employees.email, firstName: employees.firstName })
        .from(employees)
        .where(eq(employees.id, recipientId))
        .limit(1);

      if (!employee?.email) return;

      const subject = event.emailSubject || `[ElectroManage] ${event.title}`;
      const html = event.emailHtml || this.generateEmailHtml(event);

      const sent = await sendEmail({
        to: employee.email,
        subject,
        html,
        text: event.message,
      });

      if (sent && notificationId) {
        await db
          .update(notifications)
          .set({ emailSent: true })
          .where(eq(notifications.id, notificationId));
      }
    } catch (error) {
      logger.error("Email notification error", error);
    }
  }

  /**
   * Generate email HTML from notification event
   */
  private generateEmailHtml(event: NotificationEvent): string {
    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; text-align: center; border-radius: 10px 10px 0 0;">
    <h1 style="color: white; margin: 0; font-size: 22px;">JE & REJ Tech</h1>
  </div>
  <div style="background: #ffffff; padding: 24px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 10px 10px;">
    <h2 style="color: #1f2937; margin-top: 0; font-size: 18px;">${event.title}</h2>
    <p style="color: #4b5563;">${event.message}</p>
    ${event.actionUrl ? `
    <div style="text-align: center; margin: 24px 0;">
      <a href="${event.actionUrl}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block;">View Details</a>
    </div>` : ""}
    <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;">
    <p style="color: #9ca3af; font-size: 12px; margin-bottom: 0;">
      This is an automated notification from ElectroManage. You can manage your notification preferences in your profile settings.
    </p>
  </div>
</body>
</html>`;
  }

  // ============================================
  // ADMIN FUNCTIONS
  // ============================================

  /**
   * Get all notifications (admin view) with filtering
   */
  async getAdminNotifications(options: {
    limit?: number;
    offset?: number;
    category?: NotificationCategory;
    employeeId?: string;
  } = {}) {
    const { limit = 100, offset = 0, category, employeeId } = options;

    const conditions: any[] = [];
    if (category) conditions.push(eq(notifications.category, category));
    if (employeeId) conditions.push(eq(notifications.recipientId, employeeId));

    const query = db
      .select({
        notification: notifications,
        recipient: {
          id: employees.id,
          firstName: employees.firstName,
          lastName: employees.lastName,
        },
      })
      .from(notifications)
      .leftJoin(employees, eq(notifications.recipientId, employees.id))
      .orderBy(desc(notifications.createdAt))
      .limit(limit)
      .offset(offset);

    if (conditions.length > 0) {
      return query.where(and(...conditions));
    }
    return query;
  }

  /**
   * Get notification delivery stats (admin)
   */
  async getDeliveryStats() {
    const [stats] = await db
      .select({
        total: sql<number>`count(*)::int`,
        unread: sql<number>`count(*) filter (where ${notifications.isRead} = false)::int`,
        pushSent: sql<number>`count(*) filter (where ${notifications.pushSent} = true)::int`,
        emailSent: sql<number>`count(*) filter (where ${notifications.emailSent} = true)::int`,
      })
      .from(notifications);

    // Category breakdown
    const categoryStats = await db
      .select({
        category: notifications.category,
        count: sql<number>`count(*)::int`,
        unread: sql<number>`count(*) filter (where ${notifications.isRead} = false)::int`,
      })
      .from(notifications)
      .groupBy(notifications.category)
      .orderBy(desc(sql`count(*)`));

    return { ...stats, categoryBreakdown: categoryStats };
  }

  /**
   * Broadcast a notification to all active employees or specific roles
   */
  async broadcast(event: Omit<NotificationEvent, "recipientIds"> & { roles?: string[] }): Promise<number> {
    const conditions: any[] = [
      eq(employees.status, "Active"),
      isNull(employees.deletedAt),
      eq(employees.isHidden, false),
    ];

    if (event.roles && event.roles.length > 0) {
      conditions.push(inArray(employees.role, event.roles as ("ADMIN" | "HR" | "ENGINEER" | "WORKER")[]));

    }

    const activeEmployees = await db
      .select({ id: employees.id })
      .from(employees)
      .where(and(...conditions));

    const recipientIds = activeEmployees.map((e) => e.id);

    if (recipientIds.length > 0) {
      await this.notify({
        ...event,
        recipientIds,
      });
    }

    return recipientIds.length;
  }

  // ============================================
  // PUSH SUBSCRIPTION MANAGEMENT
  // ============================================

  async addPushSubscription(
    employeeId: string,
    subscription: { endpoint: string; keys: { p256dh: string; auth: string } },
    userAgent?: string
  ) {
    // Check for existing subscription with same endpoint
    const [existing] = await db
      .select()
      .from(pushSubscriptions)
      .where(eq(pushSubscriptions.endpoint, subscription.endpoint))
      .limit(1);

    if (existing) {
      // Update existing
      return db
        .update(pushSubscriptions)
        .set({
          employeeId,
          p256dh: subscription.keys.p256dh,
          auth: subscription.keys.auth,
          isActive: true,
          failCount: 0,
          lastUsedAt: new Date(),
          userAgent,
        })
        .where(eq(pushSubscriptions.id, existing.id))
        .returning();
    }

    return db
      .insert(pushSubscriptions)
      .values({
        employeeId,
        endpoint: subscription.endpoint,
        p256dh: subscription.keys.p256dh,
        auth: subscription.keys.auth,
        userAgent,
        isActive: true,
      })
      .returning();
  }

  async removePushSubscription(employeeId: string, endpoint: string) {
    return db
      .delete(pushSubscriptions)
      .where(
        and(
          eq(pushSubscriptions.employeeId, employeeId),
          eq(pushSubscriptions.endpoint, endpoint)
        )
      )
      .returning();
  }

  async getPushSubscriptions(employeeId: string) {
    return db
      .select()
      .from(pushSubscriptions)
      .where(
        and(
          eq(pushSubscriptions.employeeId, employeeId),
          eq(pushSubscriptions.isActive, true)
        )
      );
  }
}

// Export singleton instance
export const notificationService = new NotificationService();
