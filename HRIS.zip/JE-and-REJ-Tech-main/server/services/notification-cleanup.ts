/**
 * Notification Cleanup Service
 *
 * Runs periodically to clean up expired notifications (30-day retention).
 * Also deactivates push subscriptions with high fail counts.
 */

import { notificationService } from "./notification.service";
import { db } from "../db";
import { pushSubscriptions } from "@shared/schema";
import { eq, gte } from "drizzle-orm";
import { logger } from "../utils/logger";

let cleanupInterval: NodeJS.Timeout | null = null;

/**
 * Run the cleanup job once
 */
async function runCleanup(): Promise<void> {
  try {
    // 1. Clean up expired notifications (30-day retention via expiresAt field)
    const deletedCount = await notificationService.cleanupExpired();

    // 2. Deactivate push subscriptions with high fail counts
    const deactivated = await db
      .update(pushSubscriptions)
      .set({ isActive: false })
      .where(gte(pushSubscriptions.failCount, 5)) // Deactivate subscriptions that have failed 5+ times
      .returning({ id: pushSubscriptions.id });

    if (deletedCount > 0 || deactivated.length > 0) {
      logger.info(`Notification cleanup: ${deletedCount} expired notifications deleted, ${deactivated.length} push subscriptions deactivated`);
    }
  } catch (error) {
    logger.error("Notification cleanup failed", error);
  }
}

/**
 * Start the periodic cleanup job
 * Runs every 24 hours (reduced from 6 hours to lower compute usage)
 * For small user bases, daily cleanup is sufficient
 */
export function startNotificationCleanup(): void {
  // Run immediately on startup
  runCleanup();

  // Then run every 24 hours (reduced from 6 hours)
  const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
  cleanupInterval = setInterval(runCleanup, TWENTY_FOUR_HOURS);

  logger.info("Notification cleanup job scheduled (every 24 hours)");
}

/**
 * Stop the cleanup job (for graceful shutdown)
 */
export function stopNotificationCleanup(): void {
  if (cleanupInterval) {
    clearInterval(cleanupInterval);
    cleanupInterval = null;
    logger.info("Notification cleanup job stopped");
  }
}
