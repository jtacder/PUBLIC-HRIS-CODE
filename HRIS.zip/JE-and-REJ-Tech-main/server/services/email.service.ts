import { Resend } from "resend";
import { config } from "../config";
import { logger } from "../utils/logger";

// Email service singleton
let resendClient: Resend | null = null;

/**
 * Initialize the Resend client if email is enabled
 */
function getResendClient(): Resend | null {
  if (!config.email.enabled) {
    return null;
  }

  if (!config.email.resendApiKey) {
    logger.warn("Email is enabled but RESEND_API_KEY is not set");
    return null;
  }

  if (!resendClient) {
    resendClient = new Resend(config.email.resendApiKey);
  }

  return resendClient;
}

/**
 * Check if email service is available
 */
export function isEmailEnabled(): boolean {
  return config.email.enabled && !!config.email.resendApiKey;
}

/**
 * Email sending options
 */
export interface SendEmailOptions {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
  replyTo?: string;
}

/**
 * Send an email using Resend
 * Returns true if email was sent successfully, false otherwise
 */
export async function sendEmail(options: SendEmailOptions): Promise<boolean> {
  const client = getResendClient();

  if (!client) {
    if (config.isDevelopment) {
      // In development, log the email instead of sending
      logger.info("Email would be sent (development mode):", {
        to: options.to,
        subject: options.subject,
        preview: options.text?.substring(0, 100) || "HTML email",
      });
      return true;
    }
    logger.warn("Email service not available, skipping email send");
    return false;
  }

  try {
    const fromAddress = `${config.email.fromName} <${config.email.fromAddress}>`;

    const { data, error } = await client.emails.send({
      from: fromAddress,
      to: Array.isArray(options.to) ? options.to : [options.to],
      subject: options.subject,
      html: options.html,
      text: options.text,
      replyTo: options.replyTo,
    });

    if (error) {
      logger.error("Failed to send email via Resend", error);
      return false;
    }

    logger.info("Email sent successfully", {
      id: data?.id,
      to: Array.isArray(options.to) ? options.to.join(", ") : options.to,
      subject: options.subject,
    });

    return true;
  } catch (error) {
    logger.error("Error sending email", error);
    return false;
  }
}

/**
 * Send a password reset email
 */
export async function sendPasswordResetEmail(
  to: string,
  firstName: string,
  resetToken: string
): Promise<boolean> {
  const resetUrl = `${config.email.appUrl}/reset-password?token=${resetToken}`;

  const subject = "Reset Your Password - JE & REJ Tech";

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reset Your Password</title>
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
    <h1 style="color: white; margin: 0; font-size: 28px;">JE & REJ Tech</h1>
  </div>

  <div style="background: #ffffff; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 10px 10px;">
    <h2 style="color: #1f2937; margin-top: 0;">Password Reset Request</h2>

    <p>Hi ${firstName},</p>

    <p>We received a request to reset your password. Click the button below to create a new password:</p>

    <div style="text-align: center; margin: 30px 0;">
      <a href="${resetUrl}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 14px 30px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block;">Reset Password</a>
    </div>

    <p style="color: #6b7280; font-size: 14px;">This link will expire in <strong>1 hour</strong> for security reasons.</p>

    <p style="color: #6b7280; font-size: 14px;">If you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.</p>

    <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 30px 0;">

    <p style="color: #9ca3af; font-size: 12px; margin-bottom: 0;">
      If the button doesn't work, copy and paste this link into your browser:<br>
      <a href="${resetUrl}" style="color: #667eea; word-break: break-all;">${resetUrl}</a>
    </p>
  </div>

  <div style="text-align: center; padding: 20px; color: #9ca3af; font-size: 12px;">
    <p>&copy; ${new Date().getFullYear()} JE & REJ Tech. All rights reserved.</p>
  </div>
</body>
</html>
`;

  const text = `
Hi ${firstName},

We received a request to reset your password for your JE & REJ Tech account.

Click the link below to reset your password:
${resetUrl}

This link will expire in 1 hour for security reasons.

If you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.

---
JE & REJ Tech
`;

  return sendEmail({
    to,
    subject,
    html,
    text,
  });
}

/**
 * Send a welcome email with initial password
 * (For future use when HR creates employee accounts)
 */
export async function sendWelcomeEmail(
  to: string,
  firstName: string,
  temporaryPassword: string
): Promise<boolean> {
  const loginUrl = `${config.email.appUrl}/login`;

  const subject = "Welcome to JE & REJ Tech - Your Account is Ready";

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to JE & REJ Tech</title>
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
    <h1 style="color: white; margin: 0; font-size: 28px;">Welcome to JE & REJ Tech</h1>
  </div>

  <div style="background: #ffffff; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 10px 10px;">
    <h2 style="color: #1f2937; margin-top: 0;">Your Account is Ready!</h2>

    <p>Hi ${firstName},</p>

    <p>Welcome to the team! Your account has been created and you can now access the JE & REJ Tech employee portal.</p>

    <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
      <p style="margin: 0 0 10px 0;"><strong>Email:</strong> ${to}</p>
      <p style="margin: 0;"><strong>Temporary Password:</strong> ${temporaryPassword}</p>
    </div>

    <p style="color: #dc2626; font-size: 14px;"><strong>Important:</strong> You will be required to change your password when you first log in.</p>

    <div style="text-align: center; margin: 30px 0;">
      <a href="${loginUrl}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 14px 30px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block;">Log In Now</a>
    </div>

    <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 30px 0;">

    <p style="color: #6b7280; font-size: 14px;">If you have any questions, please contact HR.</p>
  </div>

  <div style="text-align: center; padding: 20px; color: #9ca3af; font-size: 12px;">
    <p>&copy; ${new Date().getFullYear()} JE & REJ Tech. All rights reserved.</p>
  </div>
</body>
</html>
`;

  const text = `
Hi ${firstName},

Welcome to the team! Your account has been created and you can now access the JE & REJ Tech employee portal.

Your login credentials:
- Email: ${to}
- Temporary Password: ${temporaryPassword}

IMPORTANT: You will be required to change your password when you first log in.

Log in here: ${loginUrl}

If you have any questions, please contact HR.

---
JE & REJ Tech
`;

  return sendEmail({
    to,
    subject,
    html,
    text,
  });
}
