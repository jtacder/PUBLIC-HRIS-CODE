/**
 * Payroll Reconciliation Service
 *
 * This service provides data integrity checks and cleanup for the payroll module.
 * It detects and reports (or optionally fixes) inconsistencies in:
 * - Cash advance balances vs payment records
 * - Loan balances vs payment records
 * - Orphaned payment records
 * - Stale draft payroll records
 * - 13th month accrual discrepancies
 *
 * Usage:
 * - Run manually via API endpoint: POST /api/payroll/reconcile
 * - Schedule as a cron job (recommended: daily during off-hours)
 */

import { storage } from "../storage";
import { db } from "../db";
import {
  cashAdvancePayments,
  loanPayments,
  payrollRecords,
  cashAdvances,
  loans,
  thirteenthMonthAccruals,
} from "@shared/schema";
import { eq, and, sql, isNull, lt, ne } from "drizzle-orm";
import logger from "../utils/logger";

export interface ReconciliationIssue {
  type:
    | "ORPHANED_CA_PAYMENT"
    | "ORPHANED_LOAN_PAYMENT"
    | "CA_BALANCE_MISMATCH"
    | "LOAN_BALANCE_MISMATCH"
    | "STALE_DRAFT"
    | "THIRTEENTH_MONTH_MISMATCH"
    | "MISSING_DEDUCTION_FLAG"
    | "DUPLICATE_PAYROLL";
  severity: "critical" | "warning" | "info";
  entityType: string;
  entityId: string;
  description: string;
  details: Record<string, any>;
  suggestedFix?: string;
}

export interface ReconciliationResult {
  runAt: Date;
  durationMs: number;
  issuesFound: number;
  issuesByType: Record<string, number>;
  issues: ReconciliationIssue[];
  fixesApplied?: number;
}

/**
 * Run a comprehensive reconciliation check on payroll data.
 * @param options Configuration options
 * @returns Reconciliation result with issues found
 */
export async function runPayrollReconciliation(options: {
  autoFix?: boolean;
  dryRun?: boolean;
  staleDraftDays?: number; // Days after which draft is considered stale
} = {}): Promise<ReconciliationResult> {
  const startTime = Date.now();
  const issues: ReconciliationIssue[] = [];
  const { autoFix = false, dryRun = true, staleDraftDays = 30 } = options;

  logger.info("Starting payroll reconciliation...", { autoFix, dryRun, staleDraftDays });

  try {
    // 1. Check for orphaned cash advance payments (pointing to deleted cash advances)
    await checkOrphanedCashAdvancePayments(issues);

    // 2. Check for orphaned loan payments (pointing to deleted loans)
    await checkOrphanedLoanPayments(issues);

    // 3. Check for cash advance balance mismatches
    await checkCashAdvanceBalances(issues);

    // 4. Check for loan balance mismatches
    await checkLoanBalances(issues);

    // 5. Check for stale draft payroll records
    await checkStaleDrafts(issues, staleDraftDays);

    // 6. Check for missing deduction_applied flags on approved/released payrolls
    await checkMissingDeductionFlags(issues);

    // 7. Check for duplicate payroll records (same employee, same cutoff)
    await checkDuplicatePayrolls(issues);

    // 8. Check 13th month accrual consistency
    await checkThirteenthMonthAccruals(issues);

  } catch (error) {
    logger.error("Error during payroll reconciliation:", error);
    throw error;
  }

  // Group issues by type
  const issuesByType: Record<string, number> = {};
  for (const issue of issues) {
    issuesByType[issue.type] = (issuesByType[issue.type] || 0) + 1;
  }

  const result: ReconciliationResult = {
    runAt: new Date(),
    durationMs: Date.now() - startTime,
    issuesFound: issues.length,
    issuesByType,
    issues,
  };

  logger.info("Payroll reconciliation completed", {
    issuesFound: result.issuesFound,
    durationMs: result.durationMs,
    issuesByType,
  });

  return result;
}

/**
 * Check for cash advance payments pointing to non-existent cash advances
 */
async function checkOrphanedCashAdvancePayments(issues: ReconciliationIssue[]): Promise<void> {
  const orphanedPayments = await db
    .select({
      paymentId: cashAdvancePayments.id,
      cashAdvanceId: cashAdvancePayments.cashAdvanceId,
      payrollRecordId: cashAdvancePayments.payrollRecordId,
      deductionAmount: cashAdvancePayments.deductionAmount,
    })
    .from(cashAdvancePayments)
    .leftJoin(cashAdvances, eq(cashAdvancePayments.cashAdvanceId, cashAdvances.id))
    .where(isNull(cashAdvances.id));

  for (const payment of orphanedPayments) {
    issues.push({
      type: "ORPHANED_CA_PAYMENT",
      severity: "critical",
      entityType: "CashAdvancePayment",
      entityId: payment.paymentId,
      description: `Cash advance payment references non-existent cash advance`,
      details: {
        paymentId: payment.paymentId,
        cashAdvanceId: payment.cashAdvanceId,
        payrollRecordId: payment.payrollRecordId,
        deductionAmount: payment.deductionAmount,
      },
      suggestedFix: "Delete orphaned payment record or restore cash advance",
    });
  }
}

/**
 * Check for loan payments pointing to non-existent loans
 */
async function checkOrphanedLoanPayments(issues: ReconciliationIssue[]): Promise<void> {
  const orphanedPayments = await db
    .select({
      paymentId: loanPayments.id,
      loanId: loanPayments.loanId,
      payrollRecordId: loanPayments.payrollRecordId,
      deductionAmount: loanPayments.deductionAmount,
    })
    .from(loanPayments)
    .leftJoin(loans, eq(loanPayments.loanId, loans.id))
    .where(isNull(loans.id));

  for (const payment of orphanedPayments) {
    issues.push({
      type: "ORPHANED_LOAN_PAYMENT",
      severity: "critical",
      entityType: "LoanPayment",
      entityId: payment.paymentId,
      description: `Loan payment references non-existent loan`,
      details: {
        paymentId: payment.paymentId,
        loanId: payment.loanId,
        payrollRecordId: payment.payrollRecordId,
        deductionAmount: payment.deductionAmount,
      },
      suggestedFix: "Delete orphaned payment record or restore loan",
    });
  }
}

/**
 * Check for cash advance balance mismatches
 * Compare current balance against sum of applied deductions
 */
async function checkCashAdvanceBalances(issues: ReconciliationIssue[]): Promise<void> {
  // Get all disbursed cash advances
  const allCashAdvances = await storage.getCashAdvances();
  const activeCAs = allCashAdvances.filter(ca =>
    ca.status === "Disbursed" || ca.status === "Fully_Paid"
  );

  for (const ca of activeCAs) {
    // Get all applied payments for this cash advance
    const payments = await storage.getCashAdvancePayments(ca.id);
    const appliedPayments = payments.filter((p: any) => p.deductionApplied === true);

    const totalDeducted = appliedPayments.reduce(
      (sum, p) => sum + parseFloat(String(p.deductionAmount) || "0"),
      0
    );

    const originalAmount = parseFloat(String(ca.amount) || "0");
    const currentBalance = parseFloat(String(ca.remainingBalance) || "0");
    const expectedBalance = originalAmount - totalDeducted;

    // Allow small floating point tolerance
    if (Math.abs(currentBalance - expectedBalance) > 0.01) {
      issues.push({
        type: "CA_BALANCE_MISMATCH",
        severity: "warning",
        entityType: "CashAdvance",
        entityId: ca.id,
        description: `Cash advance balance doesn't match applied deductions`,
        details: {
          cashAdvanceId: ca.id,
          employeeId: ca.employeeId,
          originalAmount,
          currentBalance,
          expectedBalance,
          totalDeducted,
          appliedPaymentCount: appliedPayments.length,
          difference: currentBalance - expectedBalance,
        },
        suggestedFix: `Update remaining balance to ${expectedBalance.toFixed(2)}`,
      });
    }
  }
}

/**
 * Check for loan balance mismatches
 * Compare current balance against sum of applied deductions
 */
async function checkLoanBalances(issues: ReconciliationIssue[]): Promise<void> {
  // Get all disbursed loans
  const allLoans = await storage.getLoans();
  const activeLoans = allLoans.filter(loan =>
    loan.status === "Disbursed" || loan.status === "Fully_Paid"
  );

  for (const loan of activeLoans) {
    // Get all applied payments for this loan
    const payments = await storage.getLoanPayments(loan.id);
    const appliedPayments = payments.filter((p: any) => p.deductionApplied === true);

    const totalDeducted = appliedPayments.reduce(
      (sum, p) => sum + parseFloat(String(p.deductionAmount) || "0"),
      0
    );

    const originalAmount = parseFloat(String(loan.amount) || "0");
    const currentBalance = parseFloat(String(loan.remainingBalance) || "0");
    const expectedBalance = originalAmount - totalDeducted;

    // Allow small floating point tolerance
    if (Math.abs(currentBalance - expectedBalance) > 0.01) {
      issues.push({
        type: "LOAN_BALANCE_MISMATCH",
        severity: "warning",
        entityType: "Loan",
        entityId: loan.id,
        description: `Loan balance doesn't match applied deductions`,
        details: {
          loanId: loan.id,
          employeeId: loan.employeeId,
          loanType: loan.loanType,
          originalAmount,
          currentBalance,
          expectedBalance,
          totalDeducted,
          appliedPaymentCount: appliedPayments.length,
          difference: currentBalance - expectedBalance,
        },
        suggestedFix: `Update remaining balance to ${expectedBalance.toFixed(2)}`,
      });
    }
  }
}

/**
 * Check for stale draft payroll records
 */
async function checkStaleDrafts(issues: ReconciliationIssue[], staleDays: number): Promise<void> {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - staleDays);

  const staleDrafts = await db
    .select()
    .from(payrollRecords)
    .where(and(
      eq(payrollRecords.status, "Draft"),
      isNull(payrollRecords.deletedAt),
      lt(payrollRecords.createdAt, cutoffDate)
    ));

  for (const draft of staleDrafts) {
    issues.push({
      type: "STALE_DRAFT",
      severity: "info",
      entityType: "PayrollRecord",
      entityId: draft.id,
      description: `Draft payroll record is ${staleDays}+ days old`,
      details: {
        recordId: draft.id,
        employeeId: draft.employeeId,
        cutoffStart: draft.cutoffStart,
        cutoffEnd: draft.cutoffEnd,
        createdAt: draft.createdAt,
        ageInDays: Math.floor((Date.now() - new Date(draft.createdAt!).getTime()) / (1000 * 60 * 60 * 24)),
      },
      suggestedFix: "Review and approve/release or delete this draft",
    });
  }
}

/**
 * Check for payment records with missing deduction_applied flag on approved/released payrolls
 */
async function checkMissingDeductionFlags(issues: ReconciliationIssue[]): Promise<void> {
  // Get approved/released payroll records
  const processedPayrolls = await db
    .select({ id: payrollRecords.id, status: payrollRecords.status, employeeId: payrollRecords.employeeId })
    .from(payrollRecords)
    .where(and(
      sql`${payrollRecords.status} IN ('Approved', 'Released')`,
      isNull(payrollRecords.deletedAt)
    ));

  for (const payroll of processedPayrolls) {
    // Check cash advance payments
    const caPayments = await storage.getCashAdvancePaymentsByPayrollRecord(payroll.id);
    const unappliedCAPayments = caPayments.filter((p: any) => p.deductionApplied !== true);

    if (unappliedCAPayments.length > 0) {
      issues.push({
        type: "MISSING_DEDUCTION_FLAG",
        severity: "warning",
        entityType: "CashAdvancePayment",
        entityId: payroll.id,
        description: `${unappliedCAPayments.length} cash advance payment(s) on ${payroll.status} payroll not marked as applied`,
        details: {
          payrollId: payroll.id,
          payrollStatus: payroll.status,
          employeeId: payroll.employeeId,
          unappliedCount: unappliedCAPayments.length,
          paymentIds: unappliedCAPayments.map(p => p.id),
        },
        suggestedFix: "Mark deduction_applied = true for these payments",
      });
    }

    // Check loan payments
    const loanPaymentsForPayroll = await storage.getLoanPaymentsByPayrollRecord(payroll.id);
    const unappliedLoanPayments = loanPaymentsForPayroll.filter((p: any) => p.deductionApplied !== true);

    if (unappliedLoanPayments.length > 0) {
      issues.push({
        type: "MISSING_DEDUCTION_FLAG",
        severity: "warning",
        entityType: "LoanPayment",
        entityId: payroll.id,
        description: `${unappliedLoanPayments.length} loan payment(s) on ${payroll.status} payroll not marked as applied`,
        details: {
          payrollId: payroll.id,
          payrollStatus: payroll.status,
          employeeId: payroll.employeeId,
          unappliedCount: unappliedLoanPayments.length,
          paymentIds: unappliedLoanPayments.map(p => p.id),
        },
        suggestedFix: "Mark deduction_applied = true for these payments",
      });
    }
  }
}

/**
 * Check for duplicate payroll records (same employee, same cutoff period)
 */
async function checkDuplicatePayrolls(issues: ReconciliationIssue[]): Promise<void> {
  const duplicates = await db.execute(sql`
    SELECT
      employee_id,
      cutoff_start,
      cutoff_end,
      COUNT(*) as count,
      array_agg(id) as record_ids,
      array_agg(status) as statuses
    FROM payroll_records
    WHERE deleted_at IS NULL
    GROUP BY employee_id, cutoff_start, cutoff_end
    HAVING COUNT(*) > 1
  `);

  for (const dup of duplicates.rows as any[]) {
    issues.push({
      type: "DUPLICATE_PAYROLL",
      severity: "critical",
      entityType: "PayrollRecord",
      entityId: dup.record_ids[0],
      description: `${dup.count} duplicate payroll records for same employee/period`,
      details: {
        employeeId: dup.employee_id,
        cutoffStart: dup.cutoff_start,
        cutoffEnd: dup.cutoff_end,
        count: parseInt(dup.count),
        recordIds: dup.record_ids,
        statuses: dup.statuses,
      },
      suggestedFix: "Keep one record and delete/archive others",
    });
  }
}

/**
 * Check 13th month accrual consistency
 */
async function checkThirteenthMonthAccruals(issues: ReconciliationIssue[]): Promise<void> {
  const currentYear = new Date().getFullYear();

  // Get all accruals for current year
  const accruals = await storage.getThirteenthMonthAccruals(currentYear);

  for (const accrual of accruals) {
    // Get released payrolls for this employee this year
    const releasedPayrolls = await storage.getReleasedPayrollsForYear(currentYear);
    const employeePayrolls = releasedPayrolls.filter(p => p.employeeId === accrual.employeeId);

    // Calculate expected accrual
    const expectedBasicPay = employeePayrolls.reduce(
      (sum, p) => sum + parseFloat(String(p.basicPay) || "0"),
      0
    );
    const expectedAccrued = expectedBasicPay / 12;

    const storedBasicPay = parseFloat(String(accrual.accumulatedBasicPay) || "0");
    const storedAccrued = parseFloat(String(accrual.accruedAmount) || "0");

    // Check for significant mismatches (allow 1 peso tolerance)
    if (Math.abs(storedBasicPay - expectedBasicPay) > 1 ||
        Math.abs(storedAccrued - expectedAccrued) > 1) {
      issues.push({
        type: "THIRTEENTH_MONTH_MISMATCH",
        severity: "warning",
        entityType: "ThirteenthMonthAccrual",
        entityId: accrual.id,
        description: `13th month accrual doesn't match released payroll totals`,
        details: {
          accrualId: accrual.id,
          employeeId: accrual.employeeId,
          year: currentYear,
          storedBasicPay,
          expectedBasicPay,
          storedAccrued,
          expectedAccrued,
          payrollCount: employeePayrolls.length,
        },
        suggestedFix: "Run /api/settings/13th-month/sync to recalculate",
      });
    }
  }
}

/**
 * Apply suggested fixes for issues (use with caution)
 * Only call this after reviewing the dry-run results
 */
export async function applyReconciliationFixes(issues: ReconciliationIssue[], userId: string): Promise<{
  fixed: number;
  failed: number;
  details: { issueId: string; result: "fixed" | "failed"; error?: string }[];
}> {
  const results: { issueId: string; result: "fixed" | "failed"; error?: string }[] = [];
  let fixed = 0;
  let failed = 0;

  for (const issue of issues) {
    try {
      switch (issue.type) {
        case "MISSING_DEDUCTION_FLAG":
          // Mark payments as applied
          if (issue.entityType === "CashAdvancePayment") {
            for (const paymentId of issue.details.paymentIds || []) {
              await storage.markCashAdvancePaymentApplied(paymentId);
            }
          } else if (issue.entityType === "LoanPayment") {
            for (const paymentId of issue.details.paymentIds || []) {
              await storage.markLoanPaymentApplied(paymentId);
            }
          }
          results.push({ issueId: issue.entityId, result: "fixed" });
          fixed++;
          break;

        // Add more fix handlers as needed
        // Note: Critical issues like ORPHANED_* and DUPLICATE_PAYROLL
        // should require manual intervention

        default:
          results.push({
            issueId: issue.entityId,
            result: "failed",
            error: "Auto-fix not implemented for this issue type"
          });
          failed++;
      }
    } catch (error: any) {
      results.push({
        issueId: issue.entityId,
        result: "failed",
        error: error.message
      });
      failed++;
    }
  }

  // Audit log
  await storage.createAuditLog({
    userId,
    action: "RECONCILIATION_FIX",
    entityType: "PayrollReconciliation",
    entityId: new Date().toISOString(),
    newValues: { fixed, failed, totalIssues: issues.length },
  });

  return { fixed, failed, details: results };
}

export default {
  runPayrollReconciliation,
  applyReconciliationFixes,
};
