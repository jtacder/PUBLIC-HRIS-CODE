import { Server as HttpServer } from "http";
import { WebSocketServer, WebSocket } from "ws";
// @ts-ignore - cookie module has no type declarations
import { parse as parseCookie } from "cookie";
import { logger } from "../utils/logger";

// Map of employeeId -> Set of WebSocket connections (supports multiple tabs/devices)
const clientConnections = new Map<string, Set<WebSocket>>();

// Store sessionParser function for auth validation
let sessionMiddleware: any = null;

/**
 * Initialize WebSocket server on the existing HTTP server
 * Uses the same session middleware to authenticate connections
 */
export function initializeWebSocket(httpServer: HttpServer, sessionMw: any): WebSocketServer {
  sessionMiddleware = sessionMw;

  const wss = new WebSocketServer({
    server: httpServer,
    path: "/ws/notifications",
  });

  wss.on("connection", (ws, req) => {
    // Authenticate the WebSocket connection using the session
    if (!sessionMiddleware) {
      ws.close(1008, "Session not configured");
      return;
    }

    // Parse the session from the upgrade request
    const res = {
      writeHead: () => {},
      setHeader: () => {},
      end: () => {},
    } as any;

    sessionMiddleware(req, res, () => {
      const session = (req as any).session;
      if (!session?.user?.employeeId) {
        ws.close(1008, "Unauthorized");
        return;
      }

      const employeeId = session.user.employeeId;

      // Register connection
      if (!clientConnections.has(employeeId)) {
        clientConnections.set(employeeId, new Set());
      }
      clientConnections.get(employeeId)!.add(ws);

      logger.debug(`WebSocket connected: employee ${employeeId} (${clientConnections.get(employeeId)!.size} connections)`);

      // Handle ping/pong for keepalive
      ws.on("pong", () => {
        (ws as any).isAlive = true;
      });
      (ws as any).isAlive = true;

      // Handle messages from client (for future features like read receipts)
      ws.on("message", (data) => {
        try {
          const msg = JSON.parse(data.toString());
          if (msg.type === "ping") {
            ws.send(JSON.stringify({ type: "pong" }));
          }
        } catch {
          // Ignore malformed messages
        }
      });

      // Handle disconnect
      ws.on("close", () => {
        const connections = clientConnections.get(employeeId);
        if (connections) {
          connections.delete(ws);
          if (connections.size === 0) {
            clientConnections.delete(employeeId);
          }
        }
        logger.debug(`WebSocket disconnected: employee ${employeeId}`);
      });

      ws.on("error", (err) => {
        logger.error(`WebSocket error for employee ${employeeId}`, err);
        const connections = clientConnections.get(employeeId);
        if (connections) {
          connections.delete(ws);
          if (connections.size === 0) {
            clientConnections.delete(employeeId);
          }
        }
      });

      // Send initial connection success
      ws.send(JSON.stringify({ type: "connected", employeeId }));
    });
  });

  // Keepalive ping every 5 minutes (reduced from 30s to lower compute usage)
  // For low-traffic apps, 5min is sufficient - only affects dead connection cleanup time
  const FIVE_MINUTES = 5 * 60 * 1000;
  const pingInterval = setInterval(() => {
    wss.clients.forEach((ws) => {
      if ((ws as any).isAlive === false) {
        return ws.terminate();
      }
      (ws as any).isAlive = false;
      ws.ping();
    });
  }, FIVE_MINUTES);

  wss.on("close", () => {
    clearInterval(pingInterval);
  });

  logger.info("WebSocket server initialized at /ws/notifications");

  return wss;
}

/**
 * Broadcast a message to a specific employee (all their connected devices/tabs)
 */
export function broadcastToEmployee(employeeId: string, data: any): void {
  const connections = clientConnections.get(employeeId);
  if (!connections || connections.size === 0) return;

  const message = JSON.stringify(data);

  connections.forEach((ws) => {
    if (ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(message);
      } catch (err) {
        logger.error(`Failed to send WebSocket message to employee ${employeeId}`, err);
      }
    }
  });
}

/**
 * Broadcast a message to all connected clients
 */
export function broadcastToAll(data: any): void {
  const message = JSON.stringify(data);

  clientConnections.forEach((connections, employeeId) => {
    connections.forEach((ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        try {
          ws.send(message);
        } catch (err) {
          logger.error(`Failed to broadcast to employee ${employeeId}`, err);
        }
      }
    });
  });
}

/**
 * Get the number of currently connected employees
 */
export function getConnectedCount(): number {
  return clientConnections.size;
}
