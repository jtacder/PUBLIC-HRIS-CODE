/**
 * Notification Triggers
 *
 * Defines all notification events for the application.
 * Each function is called from the relevant route handler to trigger notifications.
 * The notification service handles preference checks and delivery.
 */

import { notificationService } from "./notification.service";
import { db } from "../db";
import { employees } from "@shared/schema";
import { eq, and, isNull, inArray } from "drizzle-orm";
import { logger } from "../utils/logger";

// Helper: Get all HR/Admin employee IDs for approval notifications
async function getAdminHrIds(): Promise<string[]> {
  const admins = await db
    .select({ id: employees.id })
    .from(employees)
    .where(
      and(
        inArray(employees.role, ["ADMIN", "HR"]),
        eq(employees.status, "Active"),
        isNull(employees.deletedAt),
        eq(employees.isHidden, false),
      )
    );
  return admins.map((a) => a.id);
}

// Helper: Get employee name
async function getEmployeeName(employeeId: string): Promise<string> {
  const [emp] = await db
    .select({ firstName: employees.firstName, lastName: employees.lastName })
    .from(employees)
    .where(eq(employees.id, employeeId))
    .limit(1);
  return emp ? `${emp.firstName} ${emp.lastName}` : "Unknown";
}

// ============================================
// TIER 1 — CRITICAL NOTIFICATIONS
// ============================================

// 1. Leave Request Submitted
export async function notifyLeaveRequestSubmitted(params: {
  employeeId: string;
  employeeName: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  requestId: string;
}) {
  const adminIds = await getAdminHrIds();
  await notificationService.notify({
    category: "leave",
    title: "New Leave Request",
    message: `${params.employeeName} requested ${params.leaveType} leave from ${params.startDate} to ${params.endDate}.`,
    priority: "normal",
    recipientIds: adminIds,
    actorId: params.employeeId,
    entityType: "leave_request",
    entityId: params.requestId,
    actionUrl: "/hr-requests",
  });
}

// 1b. Leave Request Submitted on Behalf by HR
export async function notifyLeaveRequestSubmittedOnBehalf(params: {
  employeeId: string;
  submittedById: string;
  submitterName: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  requestId: string;
}) {
  // Notify the employee that a leave request was submitted on their behalf
  await notificationService.notify({
    category: "leave",
    title: "Leave Request Submitted on Your Behalf",
    message: `${params.submitterName} from HR submitted a ${params.leaveType} leave request on your behalf from ${params.startDate} to ${params.endDate}.`,
    priority: "normal",
    recipientIds: [params.employeeId],
    actorId: params.submittedById,
    entityType: "leave_request",
    entityId: params.requestId,
    actionUrl: "/my-requests",
  });

  // Also notify other HR admins about the submission
  const adminIds = await getAdminHrIds();
  const filteredAdminIds = adminIds.filter(id => id !== params.submittedById);
  if (filteredAdminIds.length > 0) {
    const employeeName = await getEmployeeName(params.employeeId);
    await notificationService.notify({
      category: "leave",
      title: "Leave Request Submitted on Behalf",
      message: `${params.submitterName} submitted a ${params.leaveType} leave request on behalf of ${employeeName} from ${params.startDate} to ${params.endDate}.`,
      priority: "normal",
      recipientIds: filteredAdminIds,
      actorId: params.submittedById,
      entityType: "leave_request",
      entityId: params.requestId,
      actionUrl: "/hr-requests",
    });
  }
}

// 2. Leave Request Approved/Rejected
export async function notifyLeaveRequestDecision(params: {
  employeeId: string;
  approverName: string;
  approverId: string;
  leaveType: string;
  status: "Approved" | "Rejected";
  remarks?: string;
  requestId: string;
}) {
  await notificationService.notify({
    category: "leave",
    title: `Leave Request ${params.status}`,
    message: `Your ${params.leaveType} leave has been ${params.status.toLowerCase()} by ${params.approverName}.${params.remarks ? ` Remarks: ${params.remarks}` : ""}`,
    priority: params.status === "Rejected" ? "high" : "normal",
    recipientIds: [params.employeeId],
    actorId: params.approverId,
    entityType: "leave_request",
    entityId: params.requestId,
    actionUrl: "/my-requests",
  });
}

// 3. Overtime Pending Approval
export async function notifyOvertimePending(params: {
  employeeId: string;
  employeeName: string;
  date: string;
  otMinutes: number;
  attendanceId: string;
}) {
  const adminIds = await getAdminHrIds();
  const hours = Math.floor(params.otMinutes / 60);
  const mins = params.otMinutes % 60;
  await notificationService.notify({
    category: "attendance",
    title: "Overtime Approval Needed",
    message: `${params.employeeName} filed ${hours}h ${mins}m overtime on ${params.date}.`,
    priority: "normal",
    recipientIds: adminIds,
    actorId: params.employeeId,
    entityType: "attendance",
    entityId: params.attendanceId,
    actionUrl: "/attendance",
  });
}

// 4. Overtime Approved/Rejected
export async function notifyOvertimeDecision(params: {
  employeeId: string;
  approverId: string;
  approverName: string;
  status: "Approved" | "Rejected";
  date: string;
  attendanceId: string;
}) {
  await notificationService.notify({
    category: "attendance",
    title: `Overtime ${params.status}`,
    message: `Your overtime on ${params.date} has been ${params.status.toLowerCase()} by ${params.approverName}.`,
    priority: "normal",
    recipientIds: [params.employeeId],
    actorId: params.approverId,
    entityType: "attendance",
    entityId: params.attendanceId,
    actionUrl: "/my-payslips",
  });
}

// 5. Payroll Released
export async function notifyPayrollReleased(params: {
  employeeIds: string[];
  periodLabel: string;
  periodId: string;
  releasedBy: string;
}) {
  await notificationService.notify({
    category: "payroll",
    title: "Payslip Available",
    message: `Your payslip for ${params.periodLabel} is now available for viewing.`,
    priority: "high",
    recipientIds: params.employeeIds,
    actorId: params.releasedBy,
    entityType: "payroll_period",
    entityId: params.periodId,
    actionUrl: "/my-payslips",
  });
}

// 6. NTE Issued
export async function notifyNTEIssued(params: {
  employeeId: string;
  issuedBy: string;
  violationType: string;
  responseDeadline: string;
  disciplinaryId: string;
}) {
  await notificationService.notify({
    category: "disciplinary",
    title: "Notice to Explain (NTE) Issued",
    message: `You have received a Notice to Explain for ${params.violationType.replace(/_/g, " ")}. Please respond by ${params.responseDeadline}.`,
    priority: "urgent",
    recipientIds: [params.employeeId],
    actorId: params.issuedBy,
    entityType: "disciplinary",
    entityId: params.disciplinaryId,
    actionUrl: "/my-disciplinary",
  });
}

// 7. NTE Response Deadline Approaching (3 days)
export async function notifyNTEDeadlineApproaching(params: {
  employeeId: string;
  responseDeadline: string;
  disciplinaryId: string;
}) {
  await notificationService.notify({
    category: "disciplinary",
    title: "NTE Response Deadline Approaching",
    message: `Your NTE response is due on ${params.responseDeadline}. Please submit your explanation soon.`,
    priority: "high",
    recipientIds: [params.employeeId],
    entityType: "disciplinary",
    entityId: params.disciplinaryId,
    actionUrl: "/my-disciplinary",
  });
}

// 8. NTE Resolved/Escalated
export async function notifyNTEResolution(params: {
  employeeId: string;
  resolvedBy: string;
  status: string;
  sanction?: string;
  disciplinaryId: string;
}) {
  await notificationService.notify({
    category: "disciplinary",
    title: `Disciplinary Case ${params.status.replace(/_/g, " ")}`,
    message: `Your disciplinary case has been ${params.status.toLowerCase().replace(/_/g, " ")}.${params.sanction ? ` Sanction: ${params.sanction}` : ""}`,
    priority: params.status === "Escalated" ? "urgent" : "high",
    recipientIds: [params.employeeId],
    actorId: params.resolvedBy,
    entityType: "disciplinary",
    entityId: params.disciplinaryId,
    actionUrl: "/my-disciplinary",
  });
}

// 9. Expense Approved/Rejected
export async function notifyExpenseDecision(params: {
  employeeId: string;
  approverId: string;
  approverName: string;
  status: "Approved" | "Rejected";
  amount: string;
  expenseId: string;
}) {
  await notificationService.notify({
    category: "expenses",
    title: `Expense ${params.status}`,
    message: `Your expense request for PHP ${params.amount} has been ${params.status.toLowerCase()} by ${params.approverName}.`,
    priority: "normal",
    recipientIds: [params.employeeId],
    actorId: params.approverId,
    entityType: "expense",
    entityId: params.expenseId,
    actionUrl: "/my-requests",
  });
}

// 10. Expense Reimbursed
export async function notifyExpenseReimbursed(params: {
  employeeId: string;
  processedBy: string;
  amount: string;
  expenseId: string;
}) {
  await notificationService.notify({
    category: "expenses",
    title: "Expense Reimbursed",
    message: `Your expense of PHP ${params.amount} has been reimbursed.`,
    priority: "normal",
    recipientIds: [params.employeeId],
    actorId: params.processedBy,
    entityType: "expense",
    entityId: params.expenseId,
    actionUrl: "/my-requests",
  });
}

// 11. Cash Advance Approved/Disbursed
export async function notifyCashAdvanceUpdate(params: {
  employeeId: string;
  processedBy: string;
  status: string;
  amount: string;
  cashAdvanceId: string;
}) {
  await notificationService.notify({
    category: "cash_advance",
    title: `Cash Advance ${params.status}`,
    message: `Your cash advance of PHP ${params.amount} has been ${params.status.toLowerCase()}.`,
    priority: "normal",
    recipientIds: [params.employeeId],
    actorId: params.processedBy,
    entityType: "cash_advance",
    entityId: params.cashAdvanceId,
    actionUrl: "/my-profile?tab=cash-advances",
  });
}

// 11b. Cash Advance Submitted on Behalf by HR
export async function notifyCashAdvanceSubmittedOnBehalf(params: {
  employeeId: string;
  submittedById: string;
  submitterName: string;
  amount: string;
  cashAdvanceId: string;
}) {
  // Notify the employee that a cash advance was submitted on their behalf
  await notificationService.notify({
    category: "cash_advance",
    title: "Cash Advance Submitted on Your Behalf",
    message: `${params.submitterName} from HR submitted a cash advance request of PHP ${params.amount} on your behalf.`,
    priority: "normal",
    recipientIds: [params.employeeId],
    actorId: params.submittedById,
    entityType: "cash_advance",
    entityId: params.cashAdvanceId,
    actionUrl: "/my-requests",
  });
}

// 12. Loan Approved/Disbursed
export async function notifyLoanUpdate(params: {
  employeeId: string;
  processedBy: string;
  status: string;
  amount: string;
  loanId: string;
}) {
  await notificationService.notify({
    category: "cash_advance",
    title: `Loan ${params.status}`,
    message: `Your loan of PHP ${params.amount} has been ${params.status.toLowerCase()}.`,
    priority: "normal",
    recipientIds: [params.employeeId],
    actorId: params.processedBy,
    entityType: "loan",
    entityId: params.loanId,
    actionUrl: "/my-requests",
  });
}

// 12b. Loan Submitted on Behalf by HR
export async function notifyLoanSubmittedOnBehalf(params: {
  employeeId: string;
  submittedById: string;
  submitterName: string;
  amount: string;
  loanType: string;
  loanId: string;
}) {
  const loanTypeLabel = params.loanType.replace(/_/g, " ");
  // Notify the employee that a loan was submitted on their behalf
  await notificationService.notify({
    category: "cash_advance",
    title: "Loan Submitted on Your Behalf",
    message: `${params.submitterName} from HR submitted a ${loanTypeLabel} application of PHP ${params.amount} on your behalf.`,
    priority: "normal",
    recipientIds: [params.employeeId],
    actorId: params.submittedById,
    entityType: "loan",
    entityId: params.loanId,
    actionUrl: "/my-requests",
  });
}

// 13. Attendance Flagged/Off-site
export async function notifyAttendanceFlagged(params: {
  employeeId: string;
  verificationStatus: string;
  date: string;
  attendanceId: string;
}) {
  await notificationService.notify({
    category: "attendance",
    title: `Attendance ${params.verificationStatus}`,
    message: `Your attendance on ${params.date} has been flagged as ${params.verificationStatus.toLowerCase()}.`,
    priority: "high",
    recipientIds: [params.employeeId],
    entityType: "attendance",
    entityId: params.attendanceId,
    actionUrl: "/my-dashboard",
  });
}

// ============================================
// TIER 2 — HIGH PRIORITY
// ============================================

// 14. Task Assigned
export async function notifyTaskAssigned(params: {
  assigneeId: string;
  assignedBy: string;
  taskTitle: string;
  projectName?: string;
  taskId: string;
}) {
  await notificationService.notify({
    category: "tasks",
    title: "New Task Assigned",
    message: `You've been assigned: "${params.taskTitle}"${params.projectName ? ` in ${params.projectName}` : ""}.`,
    priority: "normal",
    recipientIds: [params.assigneeId],
    actorId: params.assignedBy,
    entityType: "task",
    entityId: params.taskId,
    actionUrl: "/my-tasks",
  });
}

// 15. Task Due Date Approaching
export async function notifyTaskDueSoon(params: {
  assigneeId: string;
  taskTitle: string;
  dueDate: string;
  taskId: string;
}) {
  await notificationService.notify({
    category: "tasks",
    title: "Task Due Soon",
    message: `"${params.taskTitle}" is due on ${params.dueDate}.`,
    priority: "high",
    recipientIds: [params.assigneeId],
    entityType: "task",
    entityId: params.taskId,
    actionUrl: "/my-tasks",
  });
}

// 16. Task Overdue
export async function notifyTaskOverdue(params: {
  assigneeId: string;
  managerId?: string;
  taskTitle: string;
  taskId: string;
}) {
  const recipientIds = [params.assigneeId];
  if (params.managerId) recipientIds.push(params.managerId);

  await notificationService.notify({
    category: "tasks",
    title: "Task Overdue",
    message: `"${params.taskTitle}" is overdue. Please update its status.`,
    priority: "high",
    recipientIds,
    entityType: "task",
    entityId: params.taskId,
    actionUrl: "/my-tasks",
  });
}

// 17. Task Blocked
export async function notifyTaskBlocked(params: {
  assigneeId: string;
  managerId?: string;
  taskTitle: string;
  taskId: string;
  blockedBy: string;
}) {
  const recipientIds: string[] = [];
  if (params.managerId) recipientIds.push(params.managerId);

  if (recipientIds.length > 0) {
    await notificationService.notify({
      category: "tasks",
      title: "Task Blocked",
      message: `"${params.taskTitle}" has been marked as blocked by ${params.blockedBy}.`,
      priority: "high",
      recipientIds,
      actorId: params.assigneeId,
      entityType: "task",
      entityId: params.taskId,
      actionUrl: "/tasks",
    });
  }
}

// 18-20. New Request Pending (Expense / Cash Advance / Loan)
export async function notifyNewRequestPending(params: {
  employeeId: string;
  employeeName: string;
  requestType: "expense" | "cash_advance" | "loan";
  amount: string;
  requestId: string;
}) {
  const adminIds = await getAdminHrIds();
  const typeLabels = {
    expense: "Expense",
    cash_advance: "Cash Advance",
    loan: "Loan",
  };

  await notificationService.notify({
    category: params.requestType === "expense" ? "expenses" : "cash_advance",
    title: `New ${typeLabels[params.requestType]} Request`,
    message: `${params.employeeName} submitted a ${typeLabels[params.requestType].toLowerCase()} request for PHP ${params.amount}.`,
    priority: "normal",
    recipientIds: adminIds,
    actorId: params.employeeId,
    entityType: params.requestType,
    entityId: params.requestId,
    actionUrl: params.requestType === "expense" ? "/expenses" : params.requestType === "cash_advance" ? "/cash-advances" : "/loans",
  });
}

// 21. Project Assignment Added
export async function notifyProjectAssignment(params: {
  employeeId: string;
  assignedBy: string;
  projectName: string;
  projectId: string;
}) {
  await notificationService.notify({
    category: "projects",
    title: "New Project Assignment",
    message: `You have been assigned to project "${params.projectName}".`,
    priority: "normal",
    recipientIds: [params.employeeId],
    actorId: params.assignedBy,
    entityType: "project",
    entityId: params.projectId,
    actionUrl: "/projects",
  });
}

// 22. Payroll Draft Ready
export async function notifyPayrollDraftReady(params: {
  periodLabel: string;
  periodId: string;
  createdBy: string;
}) {
  const adminIds = await getAdminHrIds();
  await notificationService.notify({
    category: "payroll",
    title: "Payroll Draft Ready",
    message: `Payroll for ${params.periodLabel} is ready for review and approval.`,
    priority: "high",
    recipientIds: adminIds,
    actorId: params.createdBy,
    entityType: "payroll_period",
    entityId: params.periodId,
    actionUrl: "/payroll",
  });
}

// 23. 13th Month Released
export async function notify13thMonthReleased(params: {
  employeeId: string;
  amount: string;
  releasedBy: string;
}) {
  await notificationService.notify({
    category: "payroll",
    title: "13th Month Bonus Released",
    message: `Your 13th month bonus of PHP ${params.amount} has been released.`,
    priority: "high",
    recipientIds: [params.employeeId],
    actorId: params.releasedBy,
    entityType: "13th_month",
    actionUrl: "/my-payslips",
  });
}

// 24. Tardiness Recorded
export async function notifyTardinessRecorded(params: {
  employeeId: string;
  date: string;
  lateMinutes: number;
  attendanceId: string;
}) {
  await notificationService.notify({
    category: "attendance",
    title: "Tardiness Recorded",
    message: `You were marked ${params.lateMinutes} minutes late on ${params.date}.`,
    priority: "low",
    recipientIds: [params.employeeId],
    entityType: "attendance",
    entityId: params.attendanceId,
    actionUrl: "/my-dashboard",
  });
}

// ============================================
// TIER 3 — MEDIUM PRIORITY
// ============================================

// 25. Project Status Changed
export async function notifyProjectStatusChanged(params: {
  projectId: string;
  projectName: string;
  newStatus: string;
  changedBy: string;
  assigneeIds: string[];
}) {
  if (params.assigneeIds.length === 0) return;
  await notificationService.notify({
    category: "projects",
    title: "Project Status Updated",
    message: `Project "${params.projectName}" is now ${params.newStatus}.`,
    priority: "normal",
    recipientIds: params.assigneeIds,
    actorId: params.changedBy,
    entityType: "project",
    entityId: params.projectId,
    actionUrl: "/projects",
  });
}

// 26. New Comment on Task
export async function notifyTaskComment(params: {
  taskId: string;
  taskTitle: string;
  commentBy: string;
  commentByName: string;
  recipientIds: string[];
}) {
  if (params.recipientIds.length === 0) return;
  await notificationService.notify({
    category: "tasks",
    title: "New Comment on Task",
    message: `${params.commentByName} commented on "${params.taskTitle}".`,
    priority: "low",
    recipientIds: params.recipientIds,
    actorId: params.commentBy,
    entityType: "task",
    entityId: params.taskId,
    actionUrl: "/my-tasks",
  });
}

// 27. New Comment on Project
export async function notifyProjectComment(params: {
  projectId: string;
  projectName: string;
  commentBy: string;
  commentByName: string;
  recipientIds: string[];
}) {
  if (params.recipientIds.length === 0) return;
  await notificationService.notify({
    category: "projects",
    title: "New Comment on Project",
    message: `${params.commentByName} commented on "${params.projectName}".`,
    priority: "low",
    recipientIds: params.recipientIds,
    actorId: params.commentBy,
    entityType: "project",
    entityId: params.projectId,
    actionUrl: "/projects",
  });
}

// 28. Permission Granted/Revoked
export async function notifyPermissionChange(params: {
  employeeId: string;
  changedBy: string;
  action: "granted" | "revoked";
  permissionName: string;
}) {
  await notificationService.notify({
    category: "permissions",
    title: `Permission ${params.action === "granted" ? "Granted" : "Revoked"}`,
    message: `Your permission "${params.permissionName}" has been ${params.action}.`,
    priority: "normal",
    recipientIds: [params.employeeId],
    actorId: params.changedBy,
    entityType: "permission",
    actionUrl: "/my-profile",
  });
}

// 29. Role Changed
export async function notifyRoleChanged(params: {
  employeeId: string;
  changedBy: string;
  newRole: string;
}) {
  await notificationService.notify({
    category: "permissions",
    title: "Role Updated",
    message: `Your role has been changed to ${params.newRole}.`,
    priority: "high",
    recipientIds: [params.employeeId],
    actorId: params.changedBy,
    entityType: "role",
    actionUrl: "/my-profile",
  });
}

// 30. Leave Balance Low (triggered by system check)
export async function notifyLeaveBalanceLow(params: {
  employeeId: string;
  leaveType: string;
  remaining: number;
}) {
  await notificationService.notify({
    category: "leave",
    title: "Leave Balance Low",
    message: `You have ${params.remaining} ${params.leaveType} day(s) remaining this year.`,
    priority: "low",
    recipientIds: [params.employeeId],
    entityType: "leave_balance",
    actionUrl: "/my-profile?tab=leaves",
  });
}

// 32. Balance Adjustment Made
export async function notifyBalanceAdjustment(params: {
  employeeId: string;
  adjustedBy: string;
  type: string;
  entityType: "cash_advance" | "loan";
  reason: string;
}) {
  await notificationService.notify({
    category: "cash_advance",
    title: "Balance Adjustment",
    message: `A ${params.type.replace(/_/g, " ").toLowerCase()} has been applied to your ${params.entityType.replace(/_/g, " ")}. Reason: ${params.reason}`,
    priority: "normal",
    recipientIds: [params.employeeId],
    actorId: params.adjustedBy,
    entityType: "balance_adjustment",
    actionUrl: "/my-profile?tab=cash-advances",
  });
}

// 33-34. Cash Advance/Loan Fully Paid
export async function notifyFullyPaid(params: {
  employeeId: string;
  type: "Cash Advance" | "Loan";
  entityId: string;
}) {
  await notificationService.notify({
    category: "cash_advance",
    title: `${params.type} Fully Paid`,
    message: `Your ${params.type.toLowerCase()} has been fully paid. No more deductions will be applied.`,
    priority: "normal",
    recipientIds: [params.employeeId],
    entityType: params.type === "Cash Advance" ? "cash_advance" : "loan",
    entityId: params.entityId,
    actionUrl: "/my-profile?tab=cash-advances",
  });
}

// ============================================
// TIER 4 — LOW PRIORITY
// ============================================

// 35. Devotional Streak Milestone
export async function notifyDevotionalMilestone(params: {
  employeeId: string;
  streakDays: number;
}) {
  const milestones = [7, 30, 100, 365];
  if (!milestones.includes(params.streakDays)) return;

  await notificationService.notify({
    category: "devotional",
    title: "Devotional Milestone!",
    message: `You've maintained a ${params.streakDays}-day reading streak. Keep it up!`,
    priority: "low",
    recipientIds: [params.employeeId],
    entityType: "devotional",
    actionUrl: "/my-dashboard",
  });
}

// 37. Holiday Reminder
export async function notifyHolidayReminder(params: {
  name: string;
  date: string;
  type: string;
}) {
  await notificationService.broadcast({
    category: "system",
    title: "Holiday Reminder",
    message: `${params.name} (${params.type}) on ${params.date}.`,
    priority: "low",
  });
}

// 39. Pending Requests Digest
export async function notifyPendingDigest(params: {
  adminId: string;
  pendingLeaves: number;
  pendingExpenses: number;
  pendingOT: number;
  pendingCashAdvances: number;
}) {
  const total = params.pendingLeaves + params.pendingExpenses + params.pendingOT + params.pendingCashAdvances;
  if (total === 0) return;

  const parts: string[] = [];
  if (params.pendingLeaves > 0) parts.push(`${params.pendingLeaves} leave request(s)`);
  if (params.pendingExpenses > 0) parts.push(`${params.pendingExpenses} expense(s)`);
  if (params.pendingOT > 0) parts.push(`${params.pendingOT} overtime request(s)`);
  if (params.pendingCashAdvances > 0) parts.push(`${params.pendingCashAdvances} cash advance(s)`);

  await notificationService.notify({
    category: "system",
    title: "Pending Approvals Summary",
    message: `You have ${total} item(s) awaiting approval: ${parts.join(", ")}.`,
    priority: "normal",
    recipientIds: [params.adminId],
    entityType: "digest",
    actionUrl: "/dashboard",
  });
}

// NTE Explanation Received (notify HR/Admin)
export async function notifyNTEExplanationReceived(params: {
  employeeId: string;
  employeeName: string;
  disciplinaryId: string;
}) {
  const adminIds = await getAdminHrIds();
  await notificationService.notify({
    category: "disciplinary",
    title: "NTE Explanation Received",
    message: `${params.employeeName} has submitted their explanation for the Notice to Explain.`,
    priority: "normal",
    recipientIds: adminIds,
    actorId: params.employeeId,
    entityType: "disciplinary",
    entityId: params.disciplinaryId,
    actionUrl: "/disciplinary",
  });
}

// Task Status Changed
export async function notifyTaskStatusChanged(params: {
  taskId: string;
  taskTitle: string;
  newStatus: string;
  changedBy: string;
  changedByName: string;
  recipientIds: string[];
}) {
  if (params.recipientIds.length === 0) return;
  await notificationService.notify({
    category: "tasks",
    title: "Task Status Updated",
    message: `"${params.taskTitle}" is now ${params.newStatus.replace(/_/g, " ").toLowerCase()}.`,
    priority: params.newStatus === "Done" ? "normal" : "low",
    recipientIds: params.recipientIds,
    actorId: params.changedBy,
    entityType: "task",
    entityId: params.taskId,
    actionUrl: "/tasks",
  });
}
