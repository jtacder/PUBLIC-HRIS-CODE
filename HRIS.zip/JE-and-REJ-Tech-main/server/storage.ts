import {
  employees,
  attendanceLogs,
  payrollRecords,
  payrollPeriods,
  projects,
  projectAssignments,
  tasks,
  taskComments,
  projectComments,
  disciplinaryActions,
  expenses,
  employeeDocuments,
  auditLogs,
  payrollCutoffs,
  leaveTypes,
  leaveRequests,
  holidays,
  cashAdvances,
  cashAdvancePayments,
  loans,
  loanPayments,
  balanceAdjustments,
  companySettings,
  employeeLeaveAllocations,
  devotionals,
  employeeDevotionalProgress,
  devotionalReadingLogs,
  thirteenthMonthAccruals,
  thirteenthMonthReleases,
  roles,
  type Employee,
  type InsertEmployee,
  type AttendanceLog,
  type InsertAttendanceLog,
  type PayrollRecord,
  type InsertPayrollRecord,
  type PayrollPeriod,
  type InsertPayrollPeriod,
  type Project,
  type InsertProject,
  type ProjectAssignment,
  type InsertProjectAssignment,
  type Task,
  type InsertTask,
  type TaskComment,
  type InsertTaskComment,
  type ProjectComment,
  type InsertProjectComment,
  type DisciplinaryAction,
  type InsertDisciplinaryAction,
  type Expense,
  type InsertExpense,
  type EmployeeDocument,
  type InsertEmployeeDocument,
  type AuditLog,
  type InsertAuditLog,
  type PayrollCutoff,
  type InsertPayrollCutoff,
  type LeaveTypeRecord,
  type InsertLeaveType,
  type LeaveRequest,
  type InsertLeaveRequest,
  type Holiday,
  type InsertHoliday,
  type CashAdvance,
  type InsertCashAdvance,
  type CashAdvancePayment,
  type InsertCashAdvancePayment,
  type Loan,
  type InsertLoan,
  type LoanPayment,
  type InsertLoanPayment,
  type BalanceAdjustment,
  type InsertBalanceAdjustment,
  type CompanySetting,
  type InsertCompanySetting,
  type EmployeeLeaveAllocation,
  type InsertEmployeeLeaveAllocation,
  type Devotional,
  type InsertDevotional,
  type EmployeeDevotionalProgress,
  type InsertEmployeeDevotionalProgress,
  type DevotionalReadingLog,
  type InsertDevotionalReadingLog,
  type ThirteenthMonthAccrual,
  type InsertThirteenthMonthAccrual,
  type ThirteenthMonthRelease,
  type InsertThirteenthMonthRelease,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc, asc, or, isNull, sql } from "drizzle-orm";
import crypto from "crypto";
import { createPHTDateStart, createPHTDateEnd, getPhilippineDateString } from "./utils/datetime";

// Generate a secure random QR token
function generateQRToken(): string {
  return crypto.randomBytes(16).toString('hex');
}

// Helper to get current Philippine time (UTC+8)
function getPhilippineTime(): Date {
  const now = new Date();
  return new Date(now.getTime() + (8 * 60 * 60 * 1000));
}

export interface IStorage {
  // Employees
  getEmployees(includeHidden?: boolean): Promise<Employee[]>;
  getVisibleEmployees(): Promise<Employee[]>; // Always excludes hidden employees
  getHiddenEmployees(): Promise<Employee[]>; // Only hidden employees (for superadmin)
  getEmployee(id: string): Promise<Employee | undefined>;
  getEmployeeByEmail(email: string): Promise<Employee | undefined>;
  getEmployeeByQRToken(qrToken: string): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: string, employee: Partial<InsertEmployee>): Promise<Employee | undefined>;
  deleteEmployee(id: string): Promise<void>;

  // Projects
  getProjects(): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: string): Promise<void>;

  // Project Assignments
  getProjectAssignments(projectId?: string): Promise<ProjectAssignment[]>;
  getEmployeeAssignments(employeeId: string): Promise<ProjectAssignment[]>;
  createProjectAssignment(assignment: InsertProjectAssignment): Promise<ProjectAssignment>;
  deleteProjectAssignment(id: string): Promise<void>;

  // Tasks
  getTasks(projectId?: string): Promise<Task[]>;
  getTask(id: string): Promise<Task | undefined>;
  getEmployeeTasks(employeeId: string): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: string): Promise<void>;

  // Task Comments
  getTaskComments(taskId: string): Promise<TaskComment[]>;
  createTaskComment(comment: InsertTaskComment): Promise<TaskComment>;

  // Project Comments
  getProjectComments(projectId: string): Promise<ProjectComment[]>;
  createProjectComment(comment: InsertProjectComment): Promise<ProjectComment>;
  deleteProjectComment(id: string): Promise<void>;

  // Project Stats (for enriched project data)
  getProjectStats(projectId: string): Promise<{
    taskCount: number;
    completedTasks: number;
    totalApprovedExpenses: number;
    hoursUsed: number;
    assignedCount: number;
  }>;
  isEmployeeAssignedToProject(projectId: string, employeeId: string): Promise<boolean>;

  // Attendance
  getAttendanceLogs(startDate?: Date, endDate?: Date): Promise<AttendanceLog[]>;
  getAttendanceLog(id: string): Promise<AttendanceLog | undefined>;
  getTodayAttendance(): Promise<AttendanceLog[]>;
  getEmployeeAttendance(employeeId: string, startDate?: Date, endDate?: Date): Promise<AttendanceLog[]>;
  createAttendanceLog(log: InsertAttendanceLog): Promise<AttendanceLog>;
  updateAttendanceLog(id: string, log: Partial<InsertAttendanceLog>): Promise<AttendanceLog | undefined>;
  deleteAttendanceLog(id: string): Promise<void>;

  // Payroll Periods
  getPayrollPeriods(): Promise<PayrollPeriod[]>;
  getPayrollPeriod(id: string): Promise<PayrollPeriod | undefined>;
  createPayrollPeriod(period: InsertPayrollPeriod): Promise<PayrollPeriod>;
  updatePayrollPeriod(id: string, period: Partial<InsertPayrollPeriod>): Promise<PayrollPeriod | undefined>;
  deletePayrollPeriod(id: string): Promise<void>;

  // Payroll Records (Payslips)
  getPayrollRecords(cutoffStart: string, cutoffEnd: string): Promise<PayrollRecord[]>;
  getPayrollRecordsByPeriod(periodId: string): Promise<PayrollRecord[]>;
  getExistingPayrollCutoffs(): Promise<{ cutoffStart: string; cutoffEnd: string }[]>;
  getPayrollRecord(id: string): Promise<PayrollRecord | undefined>;
  getEmployeePayroll(employeeId: string): Promise<PayrollRecord[]>;
  createPayrollRecord(record: InsertPayrollRecord): Promise<PayrollRecord>;
  updatePayrollRecord(id: string, record: Partial<InsertPayrollRecord>): Promise<PayrollRecord | undefined>;
  deletePayrollRecordsForCutoff(cutoffStart: string, cutoffEnd: string): Promise<void>;
  getPayrollRecordsForCutoff(cutoffStart: string, cutoffEnd: string): Promise<PayrollRecord[]>;
  deletePayrollRecordsByPeriod(periodId: string): Promise<void>;

  // Disciplinary Actions
  getDisciplinaryActions(employeeId?: string): Promise<DisciplinaryAction[]>;
  getDisciplinaryAction(id: string): Promise<DisciplinaryAction | undefined>;
  createDisciplinaryAction(action: InsertDisciplinaryAction): Promise<DisciplinaryAction>;
  updateDisciplinaryAction(id: string, action: Partial<InsertDisciplinaryAction>): Promise<DisciplinaryAction | undefined>;

  // Expenses
  getExpenses(projectId?: string, status?: string, requesterId?: string): Promise<Expense[]>;
  getExpense(id: string): Promise<Expense | undefined>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: string, expense: Partial<InsertExpense>): Promise<Expense | undefined>;

  // Employee Documents
  getEmployeeDocument(id: string): Promise<EmployeeDocument | undefined>;
  getEmployeeDocuments(employeeId: string): Promise<EmployeeDocument[]>;
  createEmployeeDocument(doc: InsertEmployeeDocument): Promise<EmployeeDocument>;
  deleteEmployeeDocument(id: string): Promise<void>;

  // Audit Logs
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;
  getAuditLogs(entityType?: string, entityId?: string): Promise<AuditLog[]>;

  // HR Settings
  getPayrollCutoffs(): Promise<PayrollCutoff[]>;
  createPayrollCutoff(cutoff: InsertPayrollCutoff): Promise<PayrollCutoff>;
  updatePayrollCutoff(id: string, cutoff: Partial<InsertPayrollCutoff>): Promise<PayrollCutoff | undefined>;
  deletePayrollCutoff(id: string): Promise<void>;

  getLeaveTypes(): Promise<LeaveTypeRecord[]>;
  createLeaveType(leaveType: InsertLeaveType): Promise<LeaveTypeRecord>;
  updateLeaveType(id: string, leaveType: Partial<InsertLeaveType>): Promise<LeaveTypeRecord | undefined>;
  deleteLeaveType(id: string): Promise<void>;

  getLeaveRequests(employeeId?: string): Promise<LeaveRequest[]>;
  getLeaveRequest(id: string): Promise<LeaveRequest | undefined>;
  createLeaveRequest(request: InsertLeaveRequest): Promise<LeaveRequest>;
  updateLeaveRequest(id: string, request: Partial<InsertLeaveRequest>): Promise<LeaveRequest | undefined>;

  getHolidays(year?: number): Promise<Holiday[]>;
  createHoliday(holiday: InsertHoliday): Promise<Holiday>;
  updateHoliday(id: string, holiday: Partial<InsertHoliday>): Promise<Holiday | undefined>;
  deleteHoliday(id: string): Promise<void>;

  getCashAdvances(employeeId?: string): Promise<CashAdvance[]>;
  getCashAdvance(id: string): Promise<CashAdvance | undefined>;
  createCashAdvance(advance: InsertCashAdvance): Promise<CashAdvance>;
  updateCashAdvance(id: string, advance: Partial<InsertCashAdvance>): Promise<CashAdvance | undefined>;

  // Cash Advance Payments (Deduction History)
  getCashAdvancePayments(cashAdvanceId: string): Promise<CashAdvancePayment[]>;
  getCashAdvancePaymentsByPayrollRecord(payrollRecordId: string): Promise<CashAdvancePayment[]>;
  createCashAdvancePayment(payment: InsertCashAdvancePayment): Promise<CashAdvancePayment>;
  deleteCashAdvancePaymentsByPayrollRecord(payrollRecordId: string): Promise<void>;

  // Loans
  getLoans(employeeId?: string): Promise<Loan[]>;
  getLoan(id: string): Promise<Loan | undefined>;
  createLoan(loan: InsertLoan): Promise<Loan>;
  updateLoan(id: string, loan: Partial<InsertLoan>): Promise<Loan | undefined>;

  // Loan Payments (Deduction History)
  getLoanPayments(loanId: string): Promise<LoanPayment[]>;
  getLoanPaymentsByPayrollRecord(payrollRecordId: string): Promise<LoanPayment[]>;
  createLoanPayment(payment: InsertLoanPayment): Promise<LoanPayment>;
  deleteLoanPaymentsByPayrollRecord(payrollRecordId: string): Promise<void>;

  // Balance Adjustments (Audit Trail for Manual Overrides)
  getBalanceAdjustments(entityType?: string, entityId?: string): Promise<BalanceAdjustment[]>;
  createBalanceAdjustment(adjustment: InsertBalanceAdjustment): Promise<BalanceAdjustment>;

  getCompanySettings(category?: string): Promise<CompanySetting[]>;
  getCompanySetting(key: string): Promise<CompanySetting | undefined>;
  upsertCompanySetting(setting: InsertCompanySetting): Promise<CompanySetting>;

  getEmployeeLeaveAllocations(employeeId?: string, year?: number): Promise<EmployeeLeaveAllocation[]>;
  createEmployeeLeaveAllocation(allocation: InsertEmployeeLeaveAllocation): Promise<EmployeeLeaveAllocation>;
  updateEmployeeLeaveAllocation(id: string, allocation: Partial<InsertEmployeeLeaveAllocation>): Promise<EmployeeLeaveAllocation | undefined>;
  deleteEmployeeLeaveAllocation(id: string): Promise<void>;

  // 13th Month Accruals
  getThirteenthMonthAccruals(year?: number): Promise<ThirteenthMonthAccrual[]>;
  getThirteenthMonthAccrual(employeeId: string, year: number): Promise<ThirteenthMonthAccrual | undefined>;
  getThirteenthMonthAccrualById(id: string): Promise<ThirteenthMonthAccrual | undefined>;
  createThirteenthMonthAccrual(accrual: InsertThirteenthMonthAccrual): Promise<ThirteenthMonthAccrual>;
  updateThirteenthMonthAccrual(id: string, accrual: Partial<InsertThirteenthMonthAccrual>): Promise<ThirteenthMonthAccrual | undefined>;
  upsertThirteenthMonthAccrual(accrual: InsertThirteenthMonthAccrual): Promise<ThirteenthMonthAccrual>;

  // 13th Month Releases
  getThirteenthMonthReleases(year?: number, employeeId?: string): Promise<ThirteenthMonthRelease[]>;
  getThirteenthMonthReleasesByPayroll(payrollRecordId: string): Promise<ThirteenthMonthRelease[]>;
  createThirteenthMonthRelease(release: InsertThirteenthMonthRelease): Promise<ThirteenthMonthRelease>;

  // 13th Month Calculation Helpers
  getReleasedPayrollsForYear(year: number): Promise<PayrollRecord[]>;
}

export class DatabaseStorage implements IStorage {
  // ==================== EMPLOYEES ====================
  async getEmployees(includeHidden: boolean = false): Promise<Employee[]> {
    if (includeHidden) {
      return await db.select().from(employees).orderBy(employees.firstName);
    }
    return await db
      .select()
      .from(employees)
      .where(eq(employees.isHidden, false))
      .orderBy(employees.firstName);
  }

  async getVisibleEmployees(): Promise<Employee[]> {
    return await db
      .select()
      .from(employees)
      .where(eq(employees.isHidden, false))
      .orderBy(employees.firstName);
  }

  async getHiddenEmployees(): Promise<Employee[]> {
    return await db
      .select()
      .from(employees)
      .where(eq(employees.isHidden, true))
      .orderBy(employees.firstName);
  }

  async getEmployee(id: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.id, id));
    return employee;
  }

  async getEmployeeByEmail(email: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.email, email));
    return employee;
  }

  async createEmployee(employee: InsertEmployee): Promise<Employee> {
    // Generate QR token for attendance
    const qrToken = generateQRToken();

    // Auto-assign roleId based on legacy role for backward compatibility
    // This ensures new employees with ADMIN/HR roles get proper permissions
    let roleId = employee.roleId;
    if (!roleId && employee.role) {
      try {
        const roleMapping: Record<string, string> = {
          ADMIN: "SUPERADMIN",
          HR: "HR_ADMIN",
        };
        const targetRoleName = roleMapping[employee.role.toUpperCase()];
        if (targetRoleName) {
          const [role] = await db
            .select({ id: roles.id })
            .from(roles)
            .where(eq(roles.name, targetRoleName))
            .limit(1);
          if (role) {
            roleId = role.id;
          }
        }
      } catch {
        // Silently fail if roles table doesn't exist yet
        // Legacy role will still work
      }
    }

    const [created] = await db.insert(employees).values({ ...employee, qrToken, roleId } as any).returning();
    return created;
  }

  async getEmployeeByQRToken(qrToken: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.qrToken, qrToken));
    return employee;
  }

  async updateEmployee(id: string, employee: Partial<InsertEmployee>): Promise<Employee | undefined> {
    const [updated] = await db
      .update(employees)
      .set({ ...employee, updatedAt: new Date() } as any)
      .where(eq(employees.id, id))
      .returning();
    return updated;
  }

  async deleteEmployee(id: string): Promise<void> {
    await db.delete(employees).where(eq(employees.id, id));
  }

  // ==================== PROJECTS ====================
  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(desc(projects.createdAt));
  }

  async getProject(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [created] = await db.insert(projects).values(project as any).returning();
    return created;
  }

  async updateProject(id: string, project: Partial<InsertProject>): Promise<Project | undefined> {
    const [updated] = await db
      .update(projects)
      .set({ ...project, updatedAt: new Date() } as any)
      .where(eq(projects.id, id))
      .returning();
    return updated;
  }

  async deleteProject(id: string): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }

  // ==================== PROJECT ASSIGNMENTS ====================
  async getProjectAssignments(projectId?: string): Promise<ProjectAssignment[]> {
    if (projectId) {
      return await db
        .select()
        .from(projectAssignments)
        .where(eq(projectAssignments.projectId, projectId));
    }
    return await db.select().from(projectAssignments);
  }

  async getEmployeeAssignments(employeeId: string): Promise<ProjectAssignment[]> {
    return await db
      .select()
      .from(projectAssignments)
      .where(and(
        eq(projectAssignments.employeeId, employeeId),
        eq(projectAssignments.isActive, true)
      ));
  }

  async createProjectAssignment(assignment: InsertProjectAssignment): Promise<ProjectAssignment> {
    const [created] = await db.insert(projectAssignments).values(assignment as any).returning();
    return created;
  }

  async deleteProjectAssignment(id: string): Promise<void> {
    await db.delete(projectAssignments).where(eq(projectAssignments.id, id));
  }

  // ==================== TASKS ====================
  async getTasks(projectId?: string): Promise<Task[]> {
    if (projectId) {
      return await db
        .select()
        .from(tasks)
        .where(eq(tasks.projectId, projectId))
        .orderBy(asc(tasks.sortOrder), desc(tasks.createdAt));
    }
    return await db.select().from(tasks).orderBy(desc(tasks.createdAt));
  }

  async getTask(id: string): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async getEmployeeTasks(employeeId: string): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .where(eq(tasks.assignedToId, employeeId))
      .orderBy(asc(tasks.sortOrder), desc(tasks.createdAt));
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [created] = await db.insert(tasks).values(task as any).returning();
    return created;
  }

  async updateTask(id: string, task: Partial<InsertTask>): Promise<Task | undefined> {
    const [updated] = await db
      .update(tasks)
      .set({ ...task, updatedAt: new Date() } as any)
      .where(eq(tasks.id, id))
      .returning();
    return updated;
  }

  async deleteTask(id: string): Promise<void> {
    await db.delete(taskComments).where(eq(taskComments.taskId, id));
    await db.delete(tasks).where(eq(tasks.id, id));
  }

  // ==================== TASK COMMENTS ====================
  async getTaskComments(taskId: string): Promise<TaskComment[]> {
    return await db
      .select()
      .from(taskComments)
      .where(eq(taskComments.taskId, taskId))
      .orderBy(asc(taskComments.createdAt));
  }

  async createTaskComment(comment: InsertTaskComment): Promise<TaskComment> {
    const [created] = await db.insert(taskComments).values(comment as any).returning();
    return created;
  }

  // ==================== PROJECT COMMENTS ====================
  async getProjectComments(projectId: string): Promise<ProjectComment[]> {
    return await db
      .select()
      .from(projectComments)
      .where(eq(projectComments.projectId, projectId))
      .orderBy(asc(projectComments.createdAt));
  }

  async createProjectComment(comment: InsertProjectComment): Promise<ProjectComment> {
    const [created] = await db.insert(projectComments).values(comment as any).returning();
    return created;
  }

  async deleteProjectComment(id: string): Promise<void> {
    await db.delete(projectComments).where(eq(projectComments.id, id));
  }

  // ==================== PROJECT STATS ====================
  async getProjectStats(projectId: string): Promise<{
    taskCount: number;
    completedTasks: number;
    totalApprovedExpenses: number;
    hoursUsed: number;
    assignedCount: number;
  }> {
    // Get task counts
    const allTasks = await db
      .select()
      .from(tasks)
      .where(eq(tasks.projectId, projectId));

    const taskCount = allTasks.length;
    const completedTasks = allTasks.filter(t => t.status === "Done").length;

    // Get total approved expenses
    const approvedExpenses = await db
      .select({ amount: expenses.amount })
      .from(expenses)
      .where(and(
        eq(expenses.projectId, projectId),
        eq(expenses.status, "Approved")
      ));

    const totalApprovedExpenses = approvedExpenses.reduce((sum, e) =>
      sum + parseFloat(e.amount || "0"), 0);

    // Get total hours used from attendance logs
    const attendanceData = await db
      .select({ totalHours: attendanceLogs.totalHours })
      .from(attendanceLogs)
      .where(eq(attendanceLogs.projectId, projectId));

    const hoursUsed = attendanceData.reduce((sum, a) =>
      sum + parseFloat(a.totalHours || "0"), 0);

    // Get assigned employee count
    const assignments = await db
      .select()
      .from(projectAssignments)
      .where(and(
        eq(projectAssignments.projectId, projectId),
        eq(projectAssignments.isActive, true)
      ));

    const assignedCount = assignments.length;

    return {
      taskCount,
      completedTasks,
      totalApprovedExpenses,
      hoursUsed,
      assignedCount,
    };
  }

  async isEmployeeAssignedToProject(projectId: string, employeeId: string): Promise<boolean> {
    // Check if employee is directly assigned
    const assignment = await db
      .select()
      .from(projectAssignments)
      .where(and(
        eq(projectAssignments.projectId, projectId),
        eq(projectAssignments.employeeId, employeeId),
        eq(projectAssignments.isActive, true)
      ));

    if (assignment.length > 0) return true;

    // Also check if employee is the project manager
    const project = await db
      .select()
      .from(projects)
      .where(eq(projects.id, projectId));

    if (project.length > 0 && project[0].projectManagerId === employeeId) {
      return true;
    }

    return false;
  }

  // ==================== ATTENDANCE ====================
  async getAttendanceLogs(startDate?: Date, endDate?: Date): Promise<AttendanceLog[]> {
    if (startDate && endDate) {
      return await db
        .select()
        .from(attendanceLogs)
        .where(and(
          gte(attendanceLogs.timeIn, startDate),
          lte(attendanceLogs.timeIn, endDate)
        ))
        .orderBy(desc(attendanceLogs.timeIn));
    }
    return await db.select().from(attendanceLogs).orderBy(desc(attendanceLogs.timeIn));
  }

  async getAttendanceLog(id: string): Promise<AttendanceLog | undefined> {
    const [log] = await db.select().from(attendanceLogs).where(eq(attendanceLogs.id, id));
    return log;
  }

  async getTodayAttendance(): Promise<AttendanceLog[]> {
    // Get today's date in PHT and query using PHT-aware boundaries
    // Previously used DATE(time_in) which compared UTC dates, missing records
    // clocked in before 8 AM PHT (since their UTC date is the previous day)
    const todayStr = getPhilippineDateString();
    const dayStart = createPHTDateStart(todayStr);
    const dayEnd = createPHTDateEnd(todayStr);

    return await db
      .select()
      .from(attendanceLogs)
      .where(and(
        gte(attendanceLogs.timeIn, dayStart),
        lte(attendanceLogs.timeIn, dayEnd)
      ))
      .orderBy(desc(attendanceLogs.timeIn));
  }

  async getEmployeeAttendance(employeeId: string, startDate?: Date, endDate?: Date): Promise<AttendanceLog[]> {
    if (startDate && endDate) {
      return await db
        .select()
        .from(attendanceLogs)
        .where(and(
          eq(attendanceLogs.employeeId, employeeId),
          gte(attendanceLogs.timeIn, startDate),
          lte(attendanceLogs.timeIn, endDate)
        ))
        .orderBy(desc(attendanceLogs.timeIn));
    }
    return await db
      .select()
      .from(attendanceLogs)
      .where(eq(attendanceLogs.employeeId, employeeId))
      .orderBy(desc(attendanceLogs.timeIn));
  }

  async createAttendanceLog(log: InsertAttendanceLog): Promise<AttendanceLog> {
    const [created] = await db.insert(attendanceLogs).values(log as any).returning();
    return created;
  }

  async updateAttendanceLog(id: string, log: Partial<InsertAttendanceLog>): Promise<AttendanceLog | undefined> {
    const [updated] = await db
      .update(attendanceLogs)
      .set(log as any)
      .where(eq(attendanceLogs.id, id))
      .returning();
    return updated;
  }

  async deleteAttendanceLog(id: string): Promise<void> {
    await db.delete(attendanceLogs).where(eq(attendanceLogs.id, id));
  }

  // ==================== PAYROLL PERIODS ====================
  async getPayrollPeriods(): Promise<PayrollPeriod[]> {
    return await db
      .select()
      .from(payrollPeriods)
      .orderBy(desc(payrollPeriods.cutoffStart));
  }

  async getPayrollPeriod(id: string): Promise<PayrollPeriod | undefined> {
    const [period] = await db.select().from(payrollPeriods).where(eq(payrollPeriods.id, id));
    return period;
  }

  async createPayrollPeriod(period: InsertPayrollPeriod): Promise<PayrollPeriod> {
    const [created] = await db.insert(payrollPeriods).values(period as any).returning();
    return created;
  }

  async updatePayrollPeriod(id: string, period: Partial<InsertPayrollPeriod>): Promise<PayrollPeriod | undefined> {
    const [updated] = await db
      .update(payrollPeriods)
      .set({ ...period, updatedAt: new Date() } as any)
      .where(eq(payrollPeriods.id, id))
      .returning();
    return updated;
  }

  async deletePayrollPeriod(id: string): Promise<void> {
    await db.delete(payrollPeriods).where(eq(payrollPeriods.id, id));
  }

  // ==================== PAYROLL RECORDS (PAYSLIPS) ====================
  async getPayrollRecords(cutoffStart: string, cutoffEnd: string): Promise<PayrollRecord[]> {
    return await db
      .select()
      .from(payrollRecords)
      .where(and(
        eq(payrollRecords.cutoffStart, cutoffStart),
        eq(payrollRecords.cutoffEnd, cutoffEnd)
      ))
      .orderBy(payrollRecords.employeeId);
  }

  async getExistingPayrollCutoffs(): Promise<{ cutoffStart: string; cutoffEnd: string }[]> {
    const result = await db
      .selectDistinct({
        cutoffStart: payrollRecords.cutoffStart,
        cutoffEnd: payrollRecords.cutoffEnd,
      })
      .from(payrollRecords)
      .orderBy(desc(payrollRecords.cutoffStart));
    return result;
  }

  async getPayrollRecordsByPeriod(periodId: string): Promise<PayrollRecord[]> {
    return await db
      .select()
      .from(payrollRecords)
      .where(eq(payrollRecords.periodId, periodId))
      .orderBy(payrollRecords.employeeId);
  }

  async getPayrollRecord(id: string): Promise<PayrollRecord | undefined> {
    const [record] = await db.select().from(payrollRecords).where(eq(payrollRecords.id, id));
    return record;
  }

  async getEmployeePayroll(employeeId: string): Promise<PayrollRecord[]> {
    return await db
      .select()
      .from(payrollRecords)
      .where(eq(payrollRecords.employeeId, employeeId))
      .orderBy(desc(payrollRecords.cutoffStart));
  }

  async createPayrollRecord(record: InsertPayrollRecord): Promise<PayrollRecord> {
    const [created] = await db.insert(payrollRecords).values(record as any).returning();
    return created;
  }

  async updatePayrollRecord(id: string, record: Partial<InsertPayrollRecord>): Promise<PayrollRecord | undefined> {
    const [updated] = await db
      .update(payrollRecords)
      .set({ ...record, updatedAt: new Date() } as any)
      .where(eq(payrollRecords.id, id))
      .returning();
    return updated;
  }

  async deletePayrollRecordsForCutoff(cutoffStart: string, cutoffEnd: string): Promise<void> {
    // First get the draft records to delete their associated payments
    const draftRecords = await db
      .select({ id: payrollRecords.id })
      .from(payrollRecords)
      .where(and(
        eq(payrollRecords.cutoffStart, cutoffStart),
        eq(payrollRecords.cutoffEnd, cutoffEnd),
        eq(payrollRecords.status, "Draft")
      ));

    // Delete all related records that reference the payroll records
    for (const record of draftRecords) {
      // Delete cash advance payments
      await db
        .delete(cashAdvancePayments)
        .where(eq(cashAdvancePayments.payrollRecordId, record.id));
      // Delete loan payments
      await db
        .delete(loanPayments)
        .where(eq(loanPayments.payrollRecordId, record.id));
      // Delete thirteenth month releases (for records that were reverted from Released to Draft)
      await db
        .delete(thirteenthMonthReleases)
        .where(eq(thirteenthMonthReleases.payrollRecordId, record.id));
      // Clear lastPayrollId reference in thirteenth month accruals
      await db
        .update(thirteenthMonthAccruals)
        .set({ lastPayrollId: null })
        .where(eq(thirteenthMonthAccruals.lastPayrollId, record.id));
    }

    // Only delete Draft records - Approved/Released records cannot be deleted
    await db
      .delete(payrollRecords)
      .where(and(
        eq(payrollRecords.cutoffStart, cutoffStart),
        eq(payrollRecords.cutoffEnd, cutoffEnd),
        eq(payrollRecords.status, "Draft")
      ));
  }

  async getPayrollRecordsForCutoff(cutoffStart: string, cutoffEnd: string): Promise<PayrollRecord[]> {
    return await db
      .select()
      .from(payrollRecords)
      .where(and(
        eq(payrollRecords.cutoffStart, cutoffStart),
        eq(payrollRecords.cutoffEnd, cutoffEnd)
      ))
      .orderBy(payrollRecords.employeeId);
  }

  async deletePayrollRecordsByPeriod(periodId: string): Promise<void> {
    await db.delete(payrollRecords).where(eq(payrollRecords.periodId, periodId));
  }

  // ==================== DISCIPLINARY ACTIONS ====================
  async getDisciplinaryActions(employeeId?: string): Promise<DisciplinaryAction[]> {
    if (employeeId) {
      return await db
        .select()
        .from(disciplinaryActions)
        .where(eq(disciplinaryActions.employeeId, employeeId))
        .orderBy(desc(disciplinaryActions.createdAt));
    }
    return await db.select().from(disciplinaryActions).orderBy(desc(disciplinaryActions.createdAt));
  }

  async getDisciplinaryAction(id: string): Promise<DisciplinaryAction | undefined> {
    const [action] = await db.select().from(disciplinaryActions).where(eq(disciplinaryActions.id, id));
    return action;
  }

  async createDisciplinaryAction(action: InsertDisciplinaryAction): Promise<DisciplinaryAction> {
    const [created] = await db.insert(disciplinaryActions).values(action as any).returning();
    return created;
  }

  async updateDisciplinaryAction(id: string, action: Partial<InsertDisciplinaryAction>): Promise<DisciplinaryAction | undefined> {
    const [updated] = await db
      .update(disciplinaryActions)
      .set({ ...action, updatedAt: new Date() } as any)
      .where(eq(disciplinaryActions.id, id))
      .returning();
    return updated;
  }

  // ==================== EXPENSES ====================
  async getExpenses(projectId?: string, status?: string, requesterId?: string): Promise<Expense[]> {
    const conditions = [];

    if (projectId) {
      conditions.push(eq(expenses.projectId, projectId));
    }
    if (status) {
      conditions.push(eq(expenses.status, status as any));
    }
    if (requesterId) {
      conditions.push(eq(expenses.requesterId, requesterId));
    }

    if (conditions.length > 0) {
      return await db
        .select()
        .from(expenses)
        .where(conditions.length === 1 ? conditions[0] : and(...conditions))
        .orderBy(desc(expenses.createdAt));
    }

    return await db.select().from(expenses).orderBy(desc(expenses.createdAt));
  }

  async getExpense(id: string): Promise<Expense | undefined> {
    const [expense] = await db.select().from(expenses).where(eq(expenses.id, id));
    return expense;
  }

  async createExpense(expense: InsertExpense): Promise<Expense> {
    const [created] = await db.insert(expenses).values(expense as any).returning();
    return created;
  }

  async updateExpense(id: string, expense: Partial<InsertExpense>): Promise<Expense | undefined> {
    const [updated] = await db
      .update(expenses)
      .set({ ...expense, updatedAt: new Date() } as any)
      .where(eq(expenses.id, id))
      .returning();
    return updated;
  }

  // ==================== EMPLOYEE DOCUMENTS ====================
  async getEmployeeDocument(id: string): Promise<EmployeeDocument | undefined> {
    const [document] = await db
      .select()
      .from(employeeDocuments)
      .where(eq(employeeDocuments.id, id));
    return document;
  }

  async getEmployeeDocuments(employeeId: string): Promise<EmployeeDocument[]> {
    return await db
      .select()
      .from(employeeDocuments)
      .where(eq(employeeDocuments.employeeId, employeeId))
      .orderBy(desc(employeeDocuments.createdAt));
  }

  async createEmployeeDocument(doc: InsertEmployeeDocument): Promise<EmployeeDocument> {
    const [created] = await db.insert(employeeDocuments).values(doc as any).returning();
    return created;
  }

  async deleteEmployeeDocument(id: string): Promise<void> {
    await db.delete(employeeDocuments).where(eq(employeeDocuments.id, id));
  }

  // ==================== AUDIT LOGS ====================
  async createAuditLog(log: InsertAuditLog): Promise<AuditLog> {
    const [created] = await db.insert(auditLogs).values(log as any).returning();
    return created;
  }

  async getAuditLogs(entityType?: string, entityId?: string): Promise<AuditLog[]> {
    if (entityType && entityId) {
      return await db
        .select()
        .from(auditLogs)
        .where(and(
          eq(auditLogs.entityType, entityType),
          eq(auditLogs.entityId, entityId)
        ))
        .orderBy(desc(auditLogs.createdAt));
    }
    return await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(100);
  }

  // ==================== HR SETTINGS ====================
  
  // Payroll Cutoffs
  async getPayrollCutoffs(): Promise<PayrollCutoff[]> {
    return await db.select().from(payrollCutoffs);
  }

  async createPayrollCutoff(cutoff: InsertPayrollCutoff): Promise<PayrollCutoff> {
    const [created] = await db.insert(payrollCutoffs).values(cutoff as any).returning();
    return created;
  }

  async updatePayrollCutoff(id: string, cutoff: Partial<InsertPayrollCutoff>): Promise<PayrollCutoff | undefined> {
    const [updated] = await db
      .update(payrollCutoffs)
      .set(cutoff as any)
      .where(eq(payrollCutoffs.id, id))
      .returning();
    return updated;
  }

  async deletePayrollCutoff(id: string): Promise<void> {
    await db.delete(payrollCutoffs).where(eq(payrollCutoffs.id, id));
  }

  // Leave Types
  async getLeaveTypes(): Promise<LeaveTypeRecord[]> {
    return await db.select().from(leaveTypes);
  }

  async createLeaveType(leaveType: InsertLeaveType): Promise<LeaveTypeRecord> {
    const [created] = await db.insert(leaveTypes).values(leaveType as any).returning();
    return created;
  }

  async updateLeaveType(id: string, leaveType: Partial<InsertLeaveType>): Promise<LeaveTypeRecord | undefined> {
    const [updated] = await db
      .update(leaveTypes)
      .set(leaveType as any)
      .where(eq(leaveTypes.id, id))
      .returning();
    return updated;
  }

  async deleteLeaveType(id: string): Promise<void> {
    await db.delete(leaveTypes).where(eq(leaveTypes.id, id));
  }

  // Leave Requests
  async getLeaveRequests(employeeId?: string): Promise<LeaveRequest[]> {
    if (employeeId) {
      return await db
        .select()
        .from(leaveRequests)
        .where(eq(leaveRequests.employeeId, employeeId))
        .orderBy(desc(leaveRequests.createdAt));
    }
    return await db.select().from(leaveRequests).orderBy(desc(leaveRequests.createdAt));
  }

  async getLeaveRequest(id: string): Promise<LeaveRequest | undefined> {
    const [request] = await db.select().from(leaveRequests).where(eq(leaveRequests.id, id));
    return request;
  }

  async createLeaveRequest(request: InsertLeaveRequest): Promise<LeaveRequest> {
    const [created] = await db.insert(leaveRequests).values(request as any).returning();
    return created;
  }

  async updateLeaveRequest(id: string, request: Partial<InsertLeaveRequest>): Promise<LeaveRequest | undefined> {
    const [updated] = await db
      .update(leaveRequests)
      .set(request as any)
      .where(eq(leaveRequests.id, id))
      .returning();
    return updated;
  }

  // Holidays
  async getHolidays(year?: number): Promise<Holiday[]> {
    if (year) {
      return await db
        .select()
        .from(holidays)
        .where(eq(holidays.year, year))
        .orderBy(holidays.date);
    }
    return await db.select().from(holidays).orderBy(holidays.date);
  }

  async createHoliday(holiday: InsertHoliday): Promise<Holiday> {
    const [created] = await db.insert(holidays).values(holiday as any).returning();
    return created;
  }

  async updateHoliday(id: string, holiday: Partial<InsertHoliday>): Promise<Holiday | undefined> {
    const [updated] = await db
      .update(holidays)
      .set(holiday as any)
      .where(eq(holidays.id, id))
      .returning();
    return updated;
  }

  async deleteHoliday(id: string): Promise<void> {
    await db.delete(holidays).where(eq(holidays.id, id));
  }

  // Cash Advances
  async getCashAdvances(employeeId?: string): Promise<CashAdvance[]> {
    if (employeeId) {
      return await db
        .select()
        .from(cashAdvances)
        .where(eq(cashAdvances.employeeId, employeeId))
        .orderBy(desc(cashAdvances.createdAt));
    }
    return await db.select().from(cashAdvances).orderBy(desc(cashAdvances.createdAt));
  }

  async getCashAdvance(id: string): Promise<CashAdvance | undefined> {
    const [advance] = await db.select().from(cashAdvances).where(eq(cashAdvances.id, id));
    return advance;
  }

  async createCashAdvance(advance: InsertCashAdvance): Promise<CashAdvance> {
    const [created] = await db.insert(cashAdvances).values(advance as any).returning();
    return created;
  }

  async updateCashAdvance(id: string, advance: Partial<InsertCashAdvance>): Promise<CashAdvance | undefined> {
    const [updated] = await db
      .update(cashAdvances)
      .set(advance as any)
      .where(eq(cashAdvances.id, id))
      .returning();
    return updated;
  }

  // Cash Advance Payments (Deduction History)
  async getCashAdvancePayments(cashAdvanceId: string): Promise<CashAdvancePayment[]> {
    return await db
      .select()
      .from(cashAdvancePayments)
      .where(eq(cashAdvancePayments.cashAdvanceId, cashAdvanceId))
      .orderBy(desc(cashAdvancePayments.paymentDate));
  }

  async getCashAdvancePaymentsByPayrollRecord(payrollRecordId: string): Promise<CashAdvancePayment[]> {
    return await db
      .select()
      .from(cashAdvancePayments)
      .where(eq(cashAdvancePayments.payrollRecordId, payrollRecordId));
  }

  async createCashAdvancePayment(payment: InsertCashAdvancePayment): Promise<CashAdvancePayment> {
    const [created] = await db.insert(cashAdvancePayments).values(payment as any).returning();
    return created;
  }

  async deleteCashAdvancePaymentsByPayrollRecord(payrollRecordId: string): Promise<void> {
    await db
      .delete(cashAdvancePayments)
      .where(eq(cashAdvancePayments.payrollRecordId, payrollRecordId));
  }

  // ==================== LOANS ====================
  async getLoans(employeeId?: string): Promise<Loan[]> {
    if (employeeId) {
      return await db
        .select()
        .from(loans)
        .where(eq(loans.employeeId, employeeId))
        .orderBy(desc(loans.createdAt));
    }
    return await db.select().from(loans).orderBy(desc(loans.createdAt));
  }

  async getLoan(id: string): Promise<Loan | undefined> {
    const [loan] = await db.select().from(loans).where(eq(loans.id, id));
    return loan;
  }

  async createLoan(loan: InsertLoan): Promise<Loan> {
    const [created] = await db.insert(loans).values(loan as any).returning();
    return created;
  }

  async updateLoan(id: string, loan: Partial<InsertLoan>): Promise<Loan | undefined> {
    const [updated] = await db
      .update(loans)
      .set(loan as any)
      .where(eq(loans.id, id))
      .returning();
    return updated;
  }

  // Loan Payments (Deduction History)
  async getLoanPayments(loanId: string): Promise<LoanPayment[]> {
    return await db
      .select()
      .from(loanPayments)
      .where(eq(loanPayments.loanId, loanId))
      .orderBy(desc(loanPayments.paymentDate));
  }

  async getLoanPaymentsByPayrollRecord(payrollRecordId: string): Promise<LoanPayment[]> {
    return await db
      .select()
      .from(loanPayments)
      .where(eq(loanPayments.payrollRecordId, payrollRecordId));
  }

  async createLoanPayment(payment: InsertLoanPayment): Promise<LoanPayment> {
    const [created] = await db.insert(loanPayments).values(payment as any).returning();
    return created;
  }

  async deleteLoanPaymentsByPayrollRecord(payrollRecordId: string): Promise<void> {
    await db
      .delete(loanPayments)
      .where(eq(loanPayments.payrollRecordId, payrollRecordId));
  }

  // Mark cash advance payment as applied (idempotency)
  async markCashAdvancePaymentApplied(paymentId: string): Promise<void> {
    await db
      .update(cashAdvancePayments)
      .set({ deductionApplied: true } as any)
      .where(eq(cashAdvancePayments.id, paymentId));
  }

  // Mark loan payment as applied (idempotency)
  async markLoanPaymentApplied(paymentId: string): Promise<void> {
    await db
      .update(loanPayments)
      .set({ deductionApplied: true } as any)
      .where(eq(loanPayments.id, paymentId));
  }

  // Mark cash advance payment as unapplied (for revert)
  async markCashAdvancePaymentUnapplied(paymentId: string): Promise<void> {
    await db
      .update(cashAdvancePayments)
      .set({ deductionApplied: false } as any)
      .where(eq(cashAdvancePayments.id, paymentId));
  }

  // Mark loan payment as unapplied (for revert)
  async markLoanPaymentUnapplied(paymentId: string): Promise<void> {
    await db
      .update(loanPayments)
      .set({ deductionApplied: false } as any)
      .where(eq(loanPayments.id, paymentId));
  }

  // Get unapplied cash advance payments for a payroll record
  async getUnappliedCashAdvancePayments(payrollRecordId: string): Promise<CashAdvancePayment[]> {
    return await db
      .select()
      .from(cashAdvancePayments)
      .where(and(
        eq(cashAdvancePayments.payrollRecordId, payrollRecordId),
        eq(cashAdvancePayments.deductionApplied, false)
      ));
  }

  // Get unapplied loan payments for a payroll record
  async getUnappliedLoanPayments(payrollRecordId: string): Promise<LoanPayment[]> {
    return await db
      .select()
      .from(loanPayments)
      .where(and(
        eq(loanPayments.payrollRecordId, payrollRecordId),
        eq(loanPayments.deductionApplied, false)
      ));
  }

  // Get applied cash advance payments for a payroll record (for revert)
  async getAppliedCashAdvancePayments(payrollRecordId: string): Promise<CashAdvancePayment[]> {
    return await db
      .select()
      .from(cashAdvancePayments)
      .where(and(
        eq(cashAdvancePayments.payrollRecordId, payrollRecordId),
        eq(cashAdvancePayments.deductionApplied, true)
      ));
  }

  // Get applied loan payments for a payroll record (for revert)
  async getAppliedLoanPayments(payrollRecordId: string): Promise<LoanPayment[]> {
    return await db
      .select()
      .from(loanPayments)
      .where(and(
        eq(loanPayments.payrollRecordId, payrollRecordId),
        eq(loanPayments.deductionApplied, true)
      ));
  }

  // ==================== BALANCE ADJUSTMENTS ====================
  async getBalanceAdjustments(entityType?: string, entityId?: string): Promise<BalanceAdjustment[]> {
    if (entityType && entityId) {
      return await db
        .select()
        .from(balanceAdjustments)
        .where(and(
          eq(balanceAdjustments.entityType, entityType),
          eq(balanceAdjustments.entityId, entityId)
        ))
        .orderBy(desc(balanceAdjustments.createdAt));
    } else if (entityType) {
      return await db
        .select()
        .from(balanceAdjustments)
        .where(eq(balanceAdjustments.entityType, entityType))
        .orderBy(desc(balanceAdjustments.createdAt));
    }
    return await db.select().from(balanceAdjustments).orderBy(desc(balanceAdjustments.createdAt));
  }

  async createBalanceAdjustment(adjustment: InsertBalanceAdjustment): Promise<BalanceAdjustment> {
    const [created] = await db.insert(balanceAdjustments).values(adjustment as any).returning();
    return created;
  }

  // Company Settings
  async getCompanySettings(category?: string): Promise<CompanySetting[]> {
    if (category) {
      return await db
        .select()
        .from(companySettings)
        .where(eq(companySettings.category, category));
    }
    return await db.select().from(companySettings);
  }

  async getCompanySetting(key: string): Promise<CompanySetting | undefined> {
    const [setting] = await db
      .select()
      .from(companySettings)
      .where(eq(companySettings.key, key));
    return setting;
  }

  async upsertCompanySetting(setting: InsertCompanySetting): Promise<CompanySetting> {
    const existing = await this.getCompanySetting(setting.key);
    if (existing) {
      const [updated] = await db
        .update(companySettings)
        .set({ ...setting, updatedAt: new Date() } as any)
        .where(eq(companySettings.key, setting.key))
        .returning();
      return updated;
    }
    const [created] = await db.insert(companySettings).values(setting as any).returning();
    return created;
  }

  // Employee Leave Allocations
  async getEmployeeLeaveAllocations(employeeId?: string, year?: number): Promise<EmployeeLeaveAllocation[]> {
    let query = db.select().from(employeeLeaveAllocations);
    if (employeeId && year) {
      return await query.where(and(
        eq(employeeLeaveAllocations.employeeId, employeeId),
        eq(employeeLeaveAllocations.year, year)
      )).orderBy(employeeLeaveAllocations.createdAt);
    } else if (employeeId) {
      return await query.where(eq(employeeLeaveAllocations.employeeId, employeeId))
        .orderBy(desc(employeeLeaveAllocations.year));
    } else if (year) {
      return await query.where(eq(employeeLeaveAllocations.year, year))
        .orderBy(employeeLeaveAllocations.createdAt);
    }
    return await query.orderBy(desc(employeeLeaveAllocations.year));
  }

  async createEmployeeLeaveAllocation(allocation: InsertEmployeeLeaveAllocation): Promise<EmployeeLeaveAllocation> {
    const [created] = await db.insert(employeeLeaveAllocations).values(allocation as any).returning();
    return created;
  }

  async updateEmployeeLeaveAllocation(id: string, allocation: Partial<InsertEmployeeLeaveAllocation>): Promise<EmployeeLeaveAllocation | undefined> {
    const [updated] = await db
      .update(employeeLeaveAllocations)
      .set({ ...allocation as any, updatedAt: new Date() })
      .where(eq(employeeLeaveAllocations.id, id))
      .returning();
    return updated;
  }

  async deleteEmployeeLeaveAllocation(id: string): Promise<void> {
    await db.delete(employeeLeaveAllocations).where(eq(employeeLeaveAllocations.id, id));
  }

  // ==================== DEVOTIONAL SYSTEM ====================

  // Devotionals (base 365 entries)
  async getDevotionals(): Promise<Devotional[]> {
    return await db.select().from(devotionals).orderBy(asc(devotionals.dayNumber));
  }

  async getDevotional(id: string): Promise<Devotional | undefined> {
    const [devotional] = await db.select().from(devotionals).where(eq(devotionals.id, id));
    return devotional;
  }

  async getDevotionalByDay(dayNumber: number): Promise<Devotional | undefined> {
    const [devotional] = await db
      .select()
      .from(devotionals)
      .where(eq(devotionals.dayNumber, dayNumber));
    return devotional;
  }

  async createDevotional(devotional: InsertDevotional): Promise<Devotional> {
    const [created] = await db.insert(devotionals).values(devotional as any).returning();
    return created;
  }

  async updateDevotional(id: string, devotional: Partial<InsertDevotional>): Promise<Devotional | undefined> {
    const [updated] = await db
      .update(devotionals)
      .set({ ...devotional, updatedAt: new Date() } as any)
      .where(eq(devotionals.id, id))
      .returning();
    return updated;
  }

  async deleteDevotional(id: string): Promise<void> {
    await db.delete(devotionals).where(eq(devotionals.id, id));
  }

  // Employee Devotional Progress
  async getEmployeeDevotionalProgress(employeeId: string): Promise<EmployeeDevotionalProgress | undefined> {
    const [progress] = await db
      .select()
      .from(employeeDevotionalProgress)
      .where(eq(employeeDevotionalProgress.employeeId, employeeId));
    return progress;
  }

  async createEmployeeDevotionalProgress(progress: InsertEmployeeDevotionalProgress): Promise<EmployeeDevotionalProgress> {
    const [created] = await db.insert(employeeDevotionalProgress).values(progress as any).returning();
    return created;
  }

  async updateEmployeeDevotionalProgress(id: string, progress: Partial<InsertEmployeeDevotionalProgress>): Promise<EmployeeDevotionalProgress | undefined> {
    const [updated] = await db
      .update(employeeDevotionalProgress)
      .set({ ...progress, updatedAt: new Date() } as any)
      .where(eq(employeeDevotionalProgress.id, id))
      .returning();
    return updated;
  }

  // Devotional Reading Logs
  async getDevotionalReadingLogs(employeeId: string, limit?: number): Promise<DevotionalReadingLog[]> {
    let query = db
      .select()
      .from(devotionalReadingLogs)
      .where(eq(devotionalReadingLogs.employeeId, employeeId))
      .orderBy(desc(devotionalReadingLogs.readDate));

    if (limit) {
      return await query.limit(limit);
    }
    return await query;
  }

  async getDevotionalReadingLogByDate(employeeId: string, readDate: string): Promise<DevotionalReadingLog | undefined> {
    const [log] = await db
      .select()
      .from(devotionalReadingLogs)
      .where(and(
        eq(devotionalReadingLogs.employeeId, employeeId),
        eq(devotionalReadingLogs.readDate, readDate)
      ));
    return log;
  }

  async createDevotionalReadingLog(log: InsertDevotionalReadingLog): Promise<DevotionalReadingLog> {
    const [created] = await db.insert(devotionalReadingLogs).values(log as any).returning();
    return created;
  }

  async updateDevotionalReadingLog(id: string, log: Partial<InsertDevotionalReadingLog>): Promise<DevotionalReadingLog | undefined> {
    const [updated] = await db
      .update(devotionalReadingLogs)
      .set(log as any)
      .where(eq(devotionalReadingLogs.id, id))
      .returning();
    return updated;
  }

  async getFavoriteDevotionals(employeeId: string): Promise<DevotionalReadingLog[]> {
    return await db
      .select()
      .from(devotionalReadingLogs)
      .where(and(
        eq(devotionalReadingLogs.employeeId, employeeId),
        eq(devotionalReadingLogs.isFavorite, true)
      ))
      .orderBy(desc(devotionalReadingLogs.readDate));
  }

  // ==================== 13TH MONTH BONUS SYSTEM ====================

  // 13th Month Accruals
  async getThirteenthMonthAccruals(year?: number): Promise<ThirteenthMonthAccrual[]> {
    if (year) {
      return await db
        .select()
        .from(thirteenthMonthAccruals)
        .where(eq(thirteenthMonthAccruals.year, year))
        .orderBy(thirteenthMonthAccruals.employeeId);
    }
    return await db.select().from(thirteenthMonthAccruals).orderBy(desc(thirteenthMonthAccruals.year));
  }

  async getThirteenthMonthAccrual(employeeId: string, year: number): Promise<ThirteenthMonthAccrual | undefined> {
    const [accrual] = await db
      .select()
      .from(thirteenthMonthAccruals)
      .where(and(
        eq(thirteenthMonthAccruals.employeeId, employeeId),
        eq(thirteenthMonthAccruals.year, year)
      ));
    return accrual;
  }

  async getThirteenthMonthAccrualById(id: string): Promise<ThirteenthMonthAccrual | undefined> {
    const [accrual] = await db
      .select()
      .from(thirteenthMonthAccruals)
      .where(eq(thirteenthMonthAccruals.id, id));
    return accrual;
  }

  async createThirteenthMonthAccrual(accrual: InsertThirteenthMonthAccrual): Promise<ThirteenthMonthAccrual> {
    const [created] = await db.insert(thirteenthMonthAccruals).values(accrual as any).returning();
    return created;
  }

  async updateThirteenthMonthAccrual(id: string, accrual: Partial<InsertThirteenthMonthAccrual>): Promise<ThirteenthMonthAccrual | undefined> {
    const [updated] = await db
      .update(thirteenthMonthAccruals)
      .set({ ...accrual, updatedAt: new Date() } as any)
      .where(eq(thirteenthMonthAccruals.id, id))
      .returning();
    return updated;
  }

  async upsertThirteenthMonthAccrual(accrual: InsertThirteenthMonthAccrual): Promise<ThirteenthMonthAccrual> {
    // Check if accrual exists for this employee and year
    const existing = await this.getThirteenthMonthAccrual(accrual.employeeId, accrual.year);
    if (existing) {
      const updated = await this.updateThirteenthMonthAccrual(existing.id, accrual);
      return updated!;
    }
    return await this.createThirteenthMonthAccrual(accrual);
  }

  // 13th Month Releases
  async getThirteenthMonthReleases(year?: number, employeeId?: string): Promise<ThirteenthMonthRelease[]> {
    const conditions = [];
    if (year) {
      conditions.push(eq(thirteenthMonthReleases.year, year));
    }
    if (employeeId) {
      conditions.push(eq(thirteenthMonthReleases.employeeId, employeeId));
    }

    if (conditions.length > 0) {
      return await db
        .select()
        .from(thirteenthMonthReleases)
        .where(conditions.length === 1 ? conditions[0] : and(...conditions))
        .orderBy(desc(thirteenthMonthReleases.releasedAt));
    }
    return await db.select().from(thirteenthMonthReleases).orderBy(desc(thirteenthMonthReleases.releasedAt));
  }

  async getThirteenthMonthReleasesByPayroll(payrollRecordId: string): Promise<ThirteenthMonthRelease[]> {
    return await db
      .select()
      .from(thirteenthMonthReleases)
      .where(eq(thirteenthMonthReleases.payrollRecordId, payrollRecordId));
  }

  async createThirteenthMonthRelease(release: InsertThirteenthMonthRelease): Promise<ThirteenthMonthRelease> {
    const [created] = await db.insert(thirteenthMonthReleases).values(release as any).returning();
    return created;
  }

  // 13th Month Calculation Helpers
  async getReleasedPayrollsForYear(year: number): Promise<PayrollRecord[]> {
    // Get all released payroll records where the cutoff END falls within the specified year
    // We use cutoffEnd because that's when the pay period ends and the pay is considered earned
    // Use EXTRACT to compare year from the date column
    return await db
      .select()
      .from(payrollRecords)
      .where(and(
        eq(payrollRecords.status, "Released"),
        isNull(payrollRecords.deletedAt),
        // Extract year from cutoffEnd and compare with the target year
        sql`EXTRACT(YEAR FROM ${payrollRecords.cutoffEnd}) = ${year}`
      ))
      .orderBy(payrollRecords.cutoffStart);
  }
}

export const storage = new DatabaseStorage();
