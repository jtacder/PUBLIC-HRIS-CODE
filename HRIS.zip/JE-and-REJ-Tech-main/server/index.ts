// CRITICAL: Set TZ=UTC FIRST before any imports
// This ensures all Date operations use UTC, which is required for correct
// timezone handling when storing timestamps in PostgreSQL
// Must be at the very top before any other code runs
if (!process.env.TZ) {
  process.env.TZ = 'UTC';
}

import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { createServer } from "http";
import {
  setupSecurityMiddleware,
  globalRateLimiter,
  apiWriteRateLimiter,
  sanitizeInput,
  validateContentType,
} from "./middleware/security";
import { globalErrorHandler, notFoundHandler } from "./middleware/error-handler";
import { logger } from "./utils/logger";
import {
  initializeSentry,
  getSentryErrorHandler,
  captureException,
} from "./config/sentry";
import { autoSeedPermissionsIfNeeded } from "./utils/auto-seed-permissions";
import { initializeWebPush } from "./services/webpush.service";
import { startNotificationCleanup } from "./services/notification-cleanup";

// Initialize Sentry FIRST (before any other code)
// This ensures all errors are captured, including startup errors
initializeSentry();

const app = express();
const httpServer = createServer(app);

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

setupSecurityMiddleware(app);

app.use(globalRateLimiter);

app.use("/api", apiWriteRateLimiter);

app.use(
  express.json({
    limit: "10mb",
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  }),
);

app.use(express.urlencoded({ extended: false, limit: "10mb" }));

app.use(sanitizeInput);

app.use(validateContentType);

export function log(message: string, source = "express") {
  logger.info(message, { source });
}

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      logger.http(req.method, path, res.statusCode, duration, capturedJsonResponse);
    }
  });

  next();
});

(async () => {
  await registerRoutes(httpServer, app);

  // Auto-seed permissions if needed (runs only when permissions table is empty)
  await autoSeedPermissionsIfNeeded();

  // Initialize Web Push for browser push notifications (optional - requires VAPID keys)
  await initializeWebPush();

  // Start notification cleanup job (30-day retention, runs every 6 hours)
  startNotificationCleanup();

  app.use("/api/*", notFoundHandler);

  app.use(globalErrorHandler);

  // Sentry error handler MUST be the last error handler
  // This captures any errors that slip through the global error handler
  app.use(getSentryErrorHandler());

  if (process.env.NODE_ENV === "production") {
    serveStatic(app);
  } else {
    const { setupVite } = await import("./vite");
    await setupVite(httpServer, app);
  }

  const port = parseInt(process.env.PORT || "5000", 10);
  httpServer.listen(
    {
      port,
      host: "0.0.0.0",
      reusePort: true,
    },
    () => {
      logger.info(`Server started on port ${port}`);
    },
  );
})();

process.on("unhandledRejection", (reason, promise) => {
  logger.error("Unhandled Rejection", reason, { promise: String(promise) });
  // Report to Sentry if enabled
  if (reason instanceof Error) {
    captureException(reason, { type: "unhandledRejection" });
  }
});

process.on("uncaughtException", (error) => {
  logger.error("Uncaught Exception", error);
  // Report to Sentry if enabled
  captureException(error, { type: "uncaughtException" });
  if (process.env.NODE_ENV === "production") {
    process.exit(1);
  }
});
