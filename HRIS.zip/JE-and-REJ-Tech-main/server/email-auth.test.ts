/**
 * Tests for Email Authentication Module
 *
 * Tests authentication logic including:
 * - isAuthenticated middleware
 * - hasRole middleware
 * - Session validation
 * - Password reset requirement handling
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock database and related modules BEFORE importing email-auth
vi.mock('./db', () => ({
  db: {},
}));

vi.mock('./storage', () => ({
  storage: {},
}));

vi.mock('./middleware/security', () => ({
  authRateLimiter: vi.fn((req: any, res: any, next: any) => next()),
  passwordResetRateLimiter: vi.fn((req: any, res: any, next: any) => next()),
}));

vi.mock('./utils/logger', () => ({
  logger: {
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
  },
}));

import { isAuthenticated, hasRole } from './email-auth';

describe('Authentication Middleware', () => {
  describe('isAuthenticated', () => {
    let mockReq: any;
    let mockRes: any;
    let mockNext: any;

    beforeEach(() => {
      mockReq = {
        session: {},
        path: '/api/test',
        method: 'GET',
      };
      mockRes = {
        status: vi.fn().mockReturnThis(),
        json: vi.fn().mockReturnThis(),
      };
      mockNext = vi.fn();
    });

    it('should call next for authenticated user', () => {
      mockReq.session = {
        user: {
          id: 'user-001',
          email: 'test@company.com',
          employeeId: 'emp-001',
          role: 'WORKER',
          firstName: 'Test',
          lastName: 'User',
          mustResetPassword: false,
        },
      };

      isAuthenticated(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalled();
      expect(mockRes.status).not.toHaveBeenCalled();
    });

    it('should return 401 for missing session user', () => {
      mockReq.session = {};

      isAuthenticated(mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(401);
      expect(mockRes.json).toHaveBeenCalledWith({ message: 'Unauthorized' });
      expect(mockNext).not.toHaveBeenCalled();
    });

    it('should throw for undefined session (edge case)', () => {
      // Note: In production, express-session always provides a session object.
      // When session is undefined, accessing session.user throws TypeError.
      // This test documents that behavior.
      mockReq.session = undefined;

      expect(() => {
        isAuthenticated(mockReq, mockRes, mockNext);
      }).toThrow(TypeError);
    });

    describe('Password Reset Enforcement', () => {
      beforeEach(() => {
        mockReq.session = {
          user: {
            id: 'user-001',
            email: 'test@company.com',
            employeeId: 'emp-001',
            role: 'WORKER',
            firstName: 'Test',
            lastName: 'User',
            mustResetPassword: true,
          },
        };
      });

      it('should allow access to /api/auth/change-password', () => {
        mockReq.path = '/api/auth/change-password';
        mockReq.method = 'POST';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow access to /api/auth/logout', () => {
        mockReq.path = '/api/auth/logout';
        mockReq.method = 'POST';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow access to /api/auth/me', () => {
        mockReq.path = '/api/auth/me';
        mockReq.method = 'GET';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow access to /api/auth/csrf-token', () => {
        mockReq.path = '/api/auth/csrf-token';
        mockReq.method = 'GET';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow access to /api/attendance/clock-in', () => {
        mockReq.path = '/api/attendance/clock-in';
        mockReq.method = 'POST';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow access to /api/attendance/clock-out', () => {
        mockReq.path = '/api/attendance/clock-out';
        mockReq.method = 'POST';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow access to /api/attendance/today', () => {
        mockReq.path = '/api/attendance/today';
        mockReq.method = 'GET';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow access to /api/my/dashboard', () => {
        mockReq.path = '/api/my/dashboard';
        mockReq.method = 'GET';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow access to /api/my/payslips', () => {
        mockReq.path = '/api/my/payslips';
        mockReq.method = 'GET';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow GET to /api/employees for QR validation', () => {
        mockReq.path = '/api/employees/by-qr/abc123';
        mockReq.method = 'GET';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });

      it('should block other paths when password reset required', () => {
        mockReq.path = '/api/projects';
        mockReq.method = 'GET';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockRes.status).toHaveBeenCalledWith(403);
        expect(mockRes.json).toHaveBeenCalledWith({
          message: 'Password reset required',
          code: 'PASSWORD_RESET_REQUIRED',
        });
        expect(mockNext).not.toHaveBeenCalled();
      });

      it('should block POST to /api/employees', () => {
        mockReq.path = '/api/employees';
        mockReq.method = 'POST';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockRes.status).toHaveBeenCalledWith(403);
      });

      it('should block access to /api/payroll', () => {
        mockReq.path = '/api/payroll';
        mockReq.method = 'GET';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockRes.status).toHaveBeenCalledWith(403);
      });
    });

    describe('Normal user without password reset requirement', () => {
      beforeEach(() => {
        mockReq.session = {
          user: {
            id: 'user-001',
            email: 'test@company.com',
            employeeId: 'emp-001',
            role: 'WORKER',
            firstName: 'Test',
            lastName: 'User',
            mustResetPassword: false,
          },
        };
      });

      it('should allow access to /api/projects', () => {
        mockReq.path = '/api/projects';
        mockReq.method = 'GET';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow access to /api/tasks', () => {
        mockReq.path = '/api/tasks';
        mockReq.method = 'GET';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow POST requests', () => {
        mockReq.path = '/api/expenses';
        mockReq.method = 'POST';

        isAuthenticated(mockReq, mockRes, mockNext);

        expect(mockNext).toHaveBeenCalled();
      });
    });
  });

  describe('hasRole', () => {
    let mockReq: any;
    let mockRes: any;
    let mockNext: any;

    beforeEach(() => {
      mockReq = {
        session: {},
      };
      mockRes = {
        status: vi.fn().mockReturnThis(),
        json: vi.fn().mockReturnThis(),
      };
      mockNext = vi.fn();
    });

    it('should call next for user with required role', () => {
      mockReq.session = {
        user: {
          id: 'admin-001',
          role: 'ADMIN',
        },
      };

      const middleware = hasRole('ADMIN');
      middleware(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalled();
    });

    it('should call next for user with one of multiple required roles', () => {
      mockReq.session = {
        user: {
          id: 'hr-001',
          role: 'HR',
        },
      };

      const middleware = hasRole('ADMIN', 'HR');
      middleware(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalled();
    });

    it('should return 401 for missing session user', () => {
      mockReq.session = {};

      const middleware = hasRole('ADMIN');
      middleware(mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(401);
      expect(mockRes.json).toHaveBeenCalledWith({ message: 'Unauthorized' });
    });

    it('should return 403 for user without required role', () => {
      mockReq.session = {
        user: {
          id: 'worker-001',
          role: 'WORKER',
        },
      };

      const middleware = hasRole('ADMIN');
      middleware(mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(403);
      expect(mockRes.json).toHaveBeenCalledWith({ message: 'Forbidden' });
    });

    it('should return 403 when user role not in list', () => {
      mockReq.session = {
        user: {
          id: 'worker-001',
          role: 'WORKER',
        },
      };

      const middleware = hasRole('ADMIN', 'HR', 'ENGINEER');
      middleware(mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(403);
    });

    describe('Role combinations', () => {
      it('should allow ADMIN for ADMIN role', () => {
        mockReq.session = { user: { role: 'ADMIN' } };

        hasRole('ADMIN')(mockReq, mockRes, mockNext);
        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow HR for HR role', () => {
        mockReq.session = { user: { role: 'HR' } };

        hasRole('HR')(mockReq, mockRes, mockNext);
        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow ENGINEER for ENGINEER role', () => {
        mockReq.session = { user: { role: 'ENGINEER' } };

        hasRole('ENGINEER')(mockReq, mockRes, mockNext);
        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow WORKER for WORKER role', () => {
        mockReq.session = { user: { role: 'WORKER' } };

        hasRole('WORKER')(mockReq, mockRes, mockNext);
        expect(mockNext).toHaveBeenCalled();
      });

      it('should allow ADMIN or HR for admin operations', () => {
        mockReq.session = { user: { role: 'HR' } };

        hasRole('ADMIN', 'HR')(mockReq, mockRes, mockNext);
        expect(mockNext).toHaveBeenCalled();
      });

      it('should deny WORKER for admin operations', () => {
        mockReq.session = { user: { role: 'WORKER' } };

        hasRole('ADMIN', 'HR')(mockReq, mockRes, mockNext);
        expect(mockRes.status).toHaveBeenCalledWith(403);
      });
    });
  });
});

describe('Session User Structure', () => {
  it('should validate session user has required fields', () => {
    const validUser = {
      id: 'cred-001',
      email: 'test@company.com',
      employeeId: 'emp-001',
      role: 'WORKER',
      firstName: 'Test',
      lastName: 'User',
    };

    expect(validUser.id).toBeDefined();
    expect(validUser.email).toBeDefined();
    expect(validUser.employeeId).toBeDefined();
    expect(validUser.role).toBeDefined();
    expect(validUser.firstName).toBeDefined();
    expect(validUser.lastName).toBeDefined();
  });

  it('should handle optional mustResetPassword field', () => {
    const userWithoutReset = {
      id: 'cred-001',
      email: 'test@company.com',
      employeeId: 'emp-001',
      role: 'WORKER',
      firstName: 'Test',
      lastName: 'User',
    };

    const userWithReset = {
      ...userWithoutReset,
      mustResetPassword: true,
    };

    expect(userWithoutReset.mustResetPassword).toBeUndefined();
    expect(userWithReset.mustResetPassword).toBe(true);
  });
});
