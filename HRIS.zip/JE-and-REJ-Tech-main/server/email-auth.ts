import type { Express, RequestHandler } from "express";
import session from "express-session";
import connectPg from "connect-pg-simple";
import bcrypt from "bcrypt";
import crypto from "crypto";
import { db } from "./db";
import {
  employeeCredentials,
  loginSchema,
  setPasswordSchema,
  employees,
  passwordResetTokens,
  forgotPasswordSchema,
  resetPasswordSchema,
} from "@shared/schema";
import { eq, and, gt, isNull } from "drizzle-orm";
import { z } from "zod";
import { authRateLimiter, passwordResetRateLimiter } from "./middleware/security";
import { logger } from "./utils/logger";
import { permissionService } from "./services/permission-service";
import { sendPasswordResetEmail, isEmailEnabled } from "./services/email.service";
import { config } from "./config";

const SALT_ROUNDS = 12;

declare module "express-session" {
  interface SessionData {
    user: {
      id: string;
      email: string;
      employeeId: string;
      role: string;
      roleId?: string | null;
      firstName: string;
      lastName: string;
      mustResetPassword?: boolean;
      isSuperadmin?: boolean;
      permissions?: string[];
    };
    csrfToken?: string;
  }
}

export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  return session({
    secret: process.env.SESSION_SECRET!,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: sessionTtl,
    },
  });
}

export function setupEmailAuth(app: Express) {
  app.set("trust proxy", 1);
  app.use(getSession());
  
  // Generate CSRF token if not present
  app.use((req, res, next) => {
    if (!req.session.csrfToken) {
      req.session.csrfToken = crypto.randomBytes(32).toString("hex");
    }
    next();
  });
  
  // CSRF token endpoint - no caching to ensure fresh tokens
  app.get("/api/auth/csrf-token", (req, res) => {
    res.set({
      "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate",
      "Pragma": "no-cache",
      "Expires": "0",
    });
    res.json({ token: req.session.csrfToken });
  });
  
  // CSRF protection for all state-changing requests
  app.use((req, res, next) => {
    if (["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) {
      const csrfHeader = req.get("x-csrf-token");
      if (req.session.csrfToken && csrfHeader !== req.session.csrfToken) {
        return res.status(403).json({ message: "Invalid CSRF token" });
      }
    }
    next();
  });

  // Login route with rate limiting
  app.post("/api/auth/login", authRateLimiter, async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      // Find credentials by email
      const [credentials] = await db
        .select()
        .from(employeeCredentials)
        .where(eq(employeeCredentials.email, email.toLowerCase()))
        .limit(1);
      
      if (!credentials) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      if (!credentials.isActive) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Verify password
      const isValid = await bcrypt.compare(password, credentials.passwordHash);
      if (!isValid) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Get employee details
      const [employee] = await db
        .select()
        .from(employees)
        .where(eq(employees.id, credentials.employeeId))
        .limit(1);
      
      if (!employee) {
        return res.status(401).json({ message: "Employee record not found" });
      }
      
      // Update last login
      await db
        .update(employeeCredentials)
        .set({ lastLoginAt: new Date() })
        .where(eq(employeeCredentials.id, credentials.id));
      
      // Regenerate session on login for security and to ensure fresh CSRF token
      req.session.regenerate(async (err) => {
        if (err) {
          logger.error("Session regeneration error", err);
          return res.status(500).json({ message: "Login failed" });
        }

        // Generate new CSRF token for the new session
        req.session.csrfToken = crypto.randomBytes(32).toString("hex");

        // Load user permissions
        const userPerms = await permissionService.getUserPermissions(employee.id);

        // Set session user with permissions
        req.session.user = {
          id: credentials.id,
          email: credentials.email,
          employeeId: employee.id,
          role: employee.role,
          roleId: employee.roleId,
          firstName: employee.firstName,
          lastName: employee.lastName,
          mustResetPassword: credentials.mustResetPassword,
          isSuperadmin: userPerms.isSuperadmin,
          permissions: userPerms.permissions,
        };

        // Save session before responding
        req.session.save((saveErr) => {
          if (saveErr) {
            logger.error("Session save error", saveErr);
            return res.status(500).json({ message: "Login failed" });
          }

          // Determine redirect URL based on role/permissions
          const hasAdminAccess = userPerms.isSuperadmin ||
            userPerms.permissions.includes("dashboard.view_admin") ||
            employee.role === "ADMIN" ||
            employee.role === "HR";
          const redirectUrl = hasAdminAccess ? "/dashboard" : "/my-dashboard";

          // Return user info and redirect URL
          res.json({
            user: {
              id: credentials.id,
              email: credentials.email,
              employeeId: employee.id,
              role: employee.role,
              roleId: employee.roleId,
              firstName: employee.firstName,
              lastName: employee.lastName,
              isSuperadmin: userPerms.isSuperadmin,
              permissions: userPerms.permissions,
            },
            mustResetPassword: credentials.mustResetPassword,
            redirectUrl,
          });
        });
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      logger.error("Login error", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Logout route
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        logger.error("Logout error", err);
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie("connect.sid");
      res.json({ message: "Logged out successfully" });
    });
  });

  // Get current user
  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Refresh permissions from cache/database (in case they were updated)
    try {
      const userPerms = await permissionService.getUserPermissions(req.session.user.employeeId);
      req.session.user.isSuperadmin = userPerms.isSuperadmin;
      req.session.user.permissions = userPerms.permissions;
      req.session.user.roleId = userPerms.roleId;
    } catch (error) {
      logger.error("Error refreshing user permissions", error);
    }

    res.json({ user: req.session.user });
  });

  // Refresh current user's permissions (call after permission changes)
  app.post("/api/auth/refresh-permissions", isAuthenticated, async (req, res) => {
    try {
      const user = req.session.user!;

      // Invalidate cache and reload permissions
      permissionService.invalidateCache(user.employeeId);
      const userPerms = await permissionService.getUserPermissions(user.employeeId);

      // Update session
      req.session.user!.isSuperadmin = userPerms.isSuperadmin;
      req.session.user!.permissions = userPerms.permissions;
      req.session.user!.roleId = userPerms.roleId;

      res.json({
        permissions: userPerms.permissions,
        isSuperadmin: userPerms.isSuperadmin,
        roleId: userPerms.roleId,
      });
    } catch (error) {
      logger.error("Error refreshing permissions", error);
      res.status(500).json({ message: "Failed to refresh permissions" });
    }
  });

  // Set password for employee (HR/Admin only)
  app.post("/api/auth/set-password", isAuthenticated, async (req, res) => {
    try {
      const currentUser = req.session.user!;
      
      // Only Admin/HR can set passwords for others
      if (currentUser.role !== "ADMIN" && currentUser.role !== "HR") {
        return res.status(403).json({ message: "Only Admin/HR can set passwords" });
      }
      
      const { employeeId, password } = setPasswordSchema.parse(req.body);
      
      // Get employee email
      const [employee] = await db
        .select()
        .from(employees)
        .where(eq(employees.id, employeeId))
        .limit(1);
      
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }
      
      if (!employee.email) {
        return res.status(400).json({ message: "Employee must have an email address" });
      }
      
      const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
      
      // Check if credentials already exist
      const [existing] = await db
        .select()
        .from(employeeCredentials)
        .where(eq(employeeCredentials.employeeId, employeeId))
        .limit(1);
      
      if (existing) {
        // Update existing credentials
        await db
          .update(employeeCredentials)
          .set({ 
            passwordHash, 
            email: employee.email.toLowerCase(),
            mustResetPassword: false,
            updatedAt: new Date() 
          })
          .where(eq(employeeCredentials.id, existing.id));
      } else {
        // Create new credentials
        await db.insert(employeeCredentials).values({
          employeeId,
          email: employee.email.toLowerCase(),
          passwordHash,
          isActive: true,
          mustResetPassword: false,
        });
      }
      
      res.json({ message: "Password set successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      logger.error("Set password error", error);
      res.status(500).json({ message: "Failed to set password" });
    }
  });

  // Change own password with rate limiting
  app.post("/api/auth/change-password", passwordResetRateLimiter, isAuthenticated, async (req, res) => {
    try {
      const schema = z.object({
        currentPassword: z.string().min(1),
        newPassword: z.string()
          .min(8, "Password must be at least 8 characters")
          .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
          .regex(/[a-z]/, "Password must contain at least one lowercase letter")
          .regex(/[0-9]/, "Password must contain at least one number"),
      });

      const { currentPassword, newPassword } = schema.parse(req.body);
      const userId = req.session.user!.id;

      const [credentials] = await db
        .select()
        .from(employeeCredentials)
        .where(eq(employeeCredentials.id, userId))
        .limit(1);

      if (!credentials) {
        return res.status(404).json({ message: "Credentials not found" });
      }

      // Verify current password
      const isValid = await bcrypt.compare(currentPassword, credentials.passwordHash);
      if (!isValid) {
        return res.status(401).json({ message: "Current password is incorrect" });
      }

      // Hash and save new password
      const passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);
      await db
        .update(employeeCredentials)
        .set({
          passwordHash,
          mustResetPassword: false,
          updatedAt: new Date()
        })
        .where(eq(employeeCredentials.id, credentials.id));

      // Clear mustResetPassword from session
      if (req.session.user) {
        req.session.user.mustResetPassword = false;
      }

      res.json({ message: "Password changed successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      logger.error("Change password error", error);
      res.status(500).json({ message: "Failed to change password" });
    }
  });

  // ============================================
  // PASSWORD RESET VIA EMAIL
  // ============================================

  // Check if email service is available
  app.get("/api/auth/email-enabled", (req, res) => {
    res.json({ enabled: isEmailEnabled() });
  });

  // Request password reset (forgot password)
  app.post("/api/auth/forgot-password", passwordResetRateLimiter, async (req, res) => {
    try {
      // Check if email is enabled
      if (!isEmailEnabled()) {
        return res.status(503).json({
          message: "Password reset via email is not available. Please contact HR to reset your password."
        });
      }

      const { email } = forgotPasswordSchema.parse(req.body);
      const normalizedEmail = email.toLowerCase();

      // Always return success to prevent email enumeration attacks
      const successMessage = "If an account with that email exists, you will receive a password reset link shortly.";

      // Find employee credentials by email
      const [credentials] = await db
        .select({
          id: employeeCredentials.id,
          employeeId: employeeCredentials.employeeId,
          email: employeeCredentials.email,
          isActive: employeeCredentials.isActive,
        })
        .from(employeeCredentials)
        .where(eq(employeeCredentials.email, normalizedEmail))
        .limit(1);

      if (!credentials || !credentials.isActive) {
        // Don't reveal if email exists - just return success
        logger.info("Password reset requested for non-existent or inactive email", { email: normalizedEmail });
        return res.json({ message: successMessage });
      }

      // Get employee first name for personalized email
      const [employee] = await db
        .select({ firstName: employees.firstName })
        .from(employees)
        .where(eq(employees.id, credentials.employeeId))
        .limit(1);

      const firstName = employee?.firstName || "User";

      // Generate secure random token
      const resetToken = crypto.randomBytes(32).toString("hex");
      const tokenHash = crypto.createHash("sha256").update(resetToken).digest("hex");
      const expiresAt = new Date(Date.now() + config.email.passwordResetTokenExpiry);

      // Invalidate any existing tokens for this employee
      await db
        .delete(passwordResetTokens)
        .where(eq(passwordResetTokens.employeeId, credentials.employeeId));

      // Create new reset token
      await db.insert(passwordResetTokens).values({
        employeeId: credentials.employeeId,
        tokenHash,
        expiresAt,
      });

      // Send password reset email
      const emailSent = await sendPasswordResetEmail(normalizedEmail, firstName, resetToken);

      if (!emailSent) {
        logger.error("Failed to send password reset email", { email: normalizedEmail });
        // Still return success to prevent enumeration
      }

      logger.info("Password reset token created", {
        employeeId: credentials.employeeId,
        expiresAt: expiresAt.toISOString(),
      });

      res.json({ message: successMessage });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Please enter a valid email address" });
      }
      logger.error("Forgot password error", error);
      res.status(500).json({ message: "An error occurred. Please try again later." });
    }
  });

  // Verify reset token (for frontend validation before showing reset form)
  app.get("/api/auth/verify-reset-token/:token", async (req, res) => {
    try {
      const { token } = req.params;

      if (!token || token.length !== 64) {
        return res.status(400).json({ valid: false, message: "Invalid reset token" });
      }

      const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
      const now = new Date();

      // Find valid, unused token
      const [resetToken] = await db
        .select()
        .from(passwordResetTokens)
        .where(
          and(
            eq(passwordResetTokens.tokenHash, tokenHash),
            gt(passwordResetTokens.expiresAt, now),
            isNull(passwordResetTokens.usedAt)
          )
        )
        .limit(1);

      if (!resetToken) {
        return res.status(400).json({
          valid: false,
          message: "This password reset link is invalid or has expired. Please request a new one."
        });
      }

      res.json({ valid: true });
    } catch (error) {
      logger.error("Verify reset token error", error);
      res.status(500).json({ valid: false, message: "An error occurred" });
    }
  });

  // Reset password with token
  app.post("/api/auth/reset-password", passwordResetRateLimiter, async (req, res) => {
    try {
      const { token, newPassword } = resetPasswordSchema.parse(req.body);

      const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
      const now = new Date();

      // Find valid, unused token
      const [resetToken] = await db
        .select()
        .from(passwordResetTokens)
        .where(
          and(
            eq(passwordResetTokens.tokenHash, tokenHash),
            gt(passwordResetTokens.expiresAt, now),
            isNull(passwordResetTokens.usedAt)
          )
        )
        .limit(1);

      if (!resetToken) {
        return res.status(400).json({
          message: "This password reset link is invalid or has expired. Please request a new one."
        });
      }

      // Hash the new password
      const passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);

      // Update employee credentials
      await db
        .update(employeeCredentials)
        .set({
          passwordHash,
          mustResetPassword: false,
          updatedAt: new Date(),
        })
        .where(eq(employeeCredentials.employeeId, resetToken.employeeId));

      // Mark token as used
      await db
        .update(passwordResetTokens)
        .set({ usedAt: now })
        .where(eq(passwordResetTokens.id, resetToken.id));

      logger.info("Password reset successfully via email token", {
        employeeId: resetToken.employeeId
      });

      res.json({ message: "Your password has been reset successfully. You can now log in with your new password." });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      logger.error("Reset password error", error);
      res.status(500).json({ message: "Failed to reset password. Please try again." });
    }
  });
}

// Middleware to check if user is authenticated
export const isAuthenticated: RequestHandler = (req, res, next) => {
  if (!req.session.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  
  // Enforce password reset if required (allow password change, logout, and essential attendance/employee operations)
  const allowedPaths = [
    "/api/auth/change-password", 
    "/api/auth/logout", 
    "/api/auth/me", 
    "/api/auth/csrf-token",
    "/api/attendance/clock-in",
    "/api/attendance/clock-out",
    "/api/attendance/today",
    "/api/my/dashboard",
    "/api/my/payslips",
  ];
  // Allow GET requests to employee data for QR scanning validation
  const allowedReadPrefixes = ["/api/employees"];
  const isAllowedPath = allowedPaths.includes(req.path) || 
                        (req.method === "GET" && allowedReadPrefixes.some(prefix => req.path.startsWith(prefix)));
  if (req.session.user.mustResetPassword && !isAllowedPath) {
    return res.status(403).json({ 
      message: "Password reset required", 
      code: "PASSWORD_RESET_REQUIRED" 
    });
  }
  
  next();
};

// Middleware to check if user has specific roles
export function hasRole(...roles: string[]): RequestHandler {
  return (req, res, next) => {
    if (!req.session.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    if (!roles.includes(req.session.user.role)) {
      return res.status(403).json({ message: "Forbidden" });
    }
    next();
  };
}
