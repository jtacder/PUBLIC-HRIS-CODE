/**
 * Seed/Update Superadmin Account
 * 
 * This script creates or updates the superadmin account using environment variables.
 * It is idempotent and safe to run multiple times.
 * 
 * Required environment variable:
 *   SUPERADMIN_PASSWORD - The password for the superadmin account
 * 
 * Usage: npx tsx server/seed-superadmin.ts
 */

import { db } from "./db";
import { employees } from "@shared/schema";
import { employeeCredentials } from "@shared/models/auth";
import { roles } from "@shared/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcrypt";

const SALT_ROUNDS = 12;
const SUPERADMIN_EMAIL = "owner@jerejtech.com";
const SUPERADMIN_FIRST_NAME = "System";
const SUPERADMIN_LAST_NAME = "Administrator";

async function seedSuperadmin() {
  console.log("🔐 Seeding/Updating Superadmin Account...\n");

  // 1. Check for SUPERADMIN_PASSWORD environment variable
  const password = process.env.SUPERADMIN_PASSWORD;
  
  if (!password) {
    console.error("❌ ERROR: SUPERADMIN_PASSWORD environment variable is not set!");
    console.error("   Please set the SUPERADMIN_PASSWORD secret in your Replit environment.");
    process.exit(1);
  }

  if (password.length < 8) {
    console.error("❌ ERROR: SUPERADMIN_PASSWORD must be at least 8 characters!");
    process.exit(1);
  }

  console.log("✓ SUPERADMIN_PASSWORD environment variable found");

  try {
    // 2. Get SUPERADMIN role ID
    const [superadminRole] = await db
      .select({ id: roles.id })
      .from(roles)
      .where(eq(roles.name, "SUPERADMIN"))
      .limit(1);

    if (!superadminRole) {
      console.error("❌ ERROR: SUPERADMIN role not found in database!");
      console.error("   Please run 'npx tsx server/seed-permissions.ts' first.");
      process.exit(1);
    }

    console.log(`✓ Found SUPERADMIN role: ${superadminRole.id}`);

    // 3. Find existing superadmin employee (by role=ADMIN or email)
    let [existingEmployee] = await db
      .select()
      .from(employees)
      .where(eq(employees.role, "ADMIN"))
      .limit(1);

    // If not found by role, try by email
    if (!existingEmployee) {
      [existingEmployee] = await db
        .select()
        .from(employees)
        .where(eq(employees.email, SUPERADMIN_EMAIL))
        .limit(1);
    }

    let employeeId: string;

    if (existingEmployee) {
      // Update existing superadmin employee
      console.log(`\n📝 Updating existing superadmin: ${existingEmployee.firstName} ${existingEmployee.lastName}`);
      
      await db
        .update(employees)
        .set({
          email: SUPERADMIN_EMAIL,
          firstName: SUPERADMIN_FIRST_NAME,
          lastName: SUPERADMIN_LAST_NAME,
          role: "ADMIN",
          roleId: superadminRole.id,
          updatedAt: new Date(),
        })
        .where(eq(employees.id, existingEmployee.id));

      employeeId = existingEmployee.id;
      console.log(`  ✓ Updated employee email to: ${SUPERADMIN_EMAIL}`);
      console.log(`  ✓ Assigned SUPERADMIN role`);
    } else {
      // Create new superadmin employee
      console.log("\n📝 Creating new superadmin employee...");
      
      const [newEmployee] = await db
        .insert(employees)
        .values({
          employeeNo: "ADMIN-001",
          firstName: SUPERADMIN_FIRST_NAME,
          lastName: SUPERADMIN_LAST_NAME,
          email: SUPERADMIN_EMAIL,
          role: "ADMIN",
          roleId: superadminRole.id,
          department: "Administration",
          position: "System Administrator",
          status: "Active",
          startDate: new Date().toISOString().split("T")[0],
        })
        .returning();

      employeeId = newEmployee.id;
      console.log(`  ✓ Created employee: ${SUPERADMIN_FIRST_NAME} ${SUPERADMIN_LAST_NAME}`);
      console.log(`  ✓ Employee ID: ${employeeId}`);
    }

    // 4. Hash the password
    console.log("\n🔒 Hashing password...");
    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
    console.log("  ✓ Password hashed successfully");

    // 5. Update or create credentials
    const [existingCredentials] = await db
      .select()
      .from(employeeCredentials)
      .where(eq(employeeCredentials.employeeId, employeeId))
      .limit(1);

    if (existingCredentials) {
      // Update existing credentials
      await db
        .update(employeeCredentials)
        .set({
          email: SUPERADMIN_EMAIL,
          passwordHash: passwordHash,
          isActive: true,
          mustResetPassword: false,
          updatedAt: new Date(),
        })
        .where(eq(employeeCredentials.id, existingCredentials.id));

      console.log("\n✓ Updated existing credentials");
    } else {
      // Create new credentials
      await db.insert(employeeCredentials).values({
        employeeId: employeeId,
        email: SUPERADMIN_EMAIL,
        passwordHash: passwordHash,
        isActive: true,
        mustResetPassword: false,
      });

      console.log("\n✓ Created new credentials");
    }

    console.log("\n" + "=".repeat(50));
    console.log("✅ SUPERADMIN ACCOUNT CONFIGURED SUCCESSFULLY!");
    console.log("=".repeat(50));
    console.log(`\n📧 Email: ${SUPERADMIN_EMAIL}`);
    console.log("🔑 Password: [from SUPERADMIN_PASSWORD secret]");
    console.log("\n⚠️  Keep the SUPERADMIN_PASSWORD secret secure!");
    console.log("   To change the password, update the secret and re-run this script.");

  } catch (error) {
    console.error("\n❌ Error seeding superadmin:", error);
    throw error;
  }
}

// Run the seed function
seedSuperadmin()
  .then(() => {
    console.log("\n🎉 Done!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Failed to seed superadmin:", error);
    process.exit(1);
  });
