import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "@shared/schema";

// CRITICAL: Force UTC timezone for the Node.js process
// This ensures Date.getHours() etc. return UTC values, which is what pg uses for serialization
// Without this, Date serialization to PostgreSQL may use local timezone, causing 8-hour shifts
if (!process.env.TZ) {
  process.env.TZ = 'UTC';
}

const { Pool, types } = pg;

/**
 * CRITICAL: Configure pg to handle timestamps consistently as UTC.
 *
 * The pg driver's default Date handling can cause timezone issues:
 * - Date serialization may use local time methods (getHours vs getUTCHours)
 * - Timestamp parsing may interpret values in local timezone
 *
 * This configuration ensures:
 * 1. All timestamps are parsed as UTC
 * 2. Date objects are serialized consistently
 *
 * Without this fix, bulk attendance uploads and other date operations
 * may show times shifted by 8 hours (the PHT offset).
 */

// PostgreSQL OID for TIMESTAMP WITHOUT TIME ZONE
const TIMESTAMP_OID = 1114;
// PostgreSQL OID for TIMESTAMP WITH TIME ZONE
const TIMESTAMPTZ_OID = 1184;

// Override timestamp parsing to always interpret as UTC
// This prevents the pg driver from using local timezone
types.setTypeParser(TIMESTAMP_OID, (stringValue: string) => {
  // Parse as UTC by appending 'Z' if no timezone info
  if (stringValue && !stringValue.includes('+') && !stringValue.includes('Z')) {
    return new Date(stringValue + 'Z');
  }
  return new Date(stringValue);
});

types.setTypeParser(TIMESTAMPTZ_OID, (stringValue: string) => {
  return new Date(stringValue);
});

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle(pool, { schema });
