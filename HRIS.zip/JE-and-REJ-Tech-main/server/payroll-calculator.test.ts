/**
 * Unit Tests for Philippine Payroll Calculator
 * Tests government contribution calculations (SSS, PhilHealth, Pag-IBIG, Tax)
 *
 * These tests verify compliance with:
 * - SSS Contribution Table 2024 (RA 11199)
 * - PhilHealth Premium Rate 2024 (5% with floor/ceiling)
 * - Pag-IBIG Contribution Table
 * - TRAIN Law Withholding Tax Rates
 */

import { describe, it, expect } from 'vitest';
import {
  calculateSSS,
  calculatePhilHealth,
  calculatePagibig,
  calculateWithholdingTax,
  calculateLateDeduction,
  calculateUndertimeDeduction,
  calculateOvertimePay,
  calculatePayroll,
  calculateEnhancedPayroll,
} from './payroll-calculator';

describe('SSS Contribution Calculator', () => {
  describe('Semi-monthly contributions (per cutoff)', () => {
    it('should calculate SSS for minimum salary bracket (₱4,000 MSC)', () => {
      // Monthly salary ₱4,000 → Employee share ₱180/month → ₱90 semi-monthly
      const contribution = calculateSSS(4000, true);
      expect(contribution).toBe(90);
    });

    it('should calculate SSS for ₱10,000 monthly salary', () => {
      // ₱10,000 falls in ₱9,750-₱10,249.99 bracket → MSC ₱10,000 → EE ₱450/month → ₱225 semi-monthly
      const contribution = calculateSSS(10000, true);
      expect(contribution).toBe(225);
    });

    it('should calculate SSS for ₱15,000 monthly salary', () => {
      // ₱15,000 falls in ₱14,750-₱15,249.99 bracket → MSC ₱15,000 → EE ₱675/month → ₱337.50 semi-monthly
      const contribution = calculateSSS(15000, true);
      expect(contribution).toBe(337.5);
    });

    it('should calculate SSS for ₱20,000 monthly salary', () => {
      // ₱20,000 falls in ₱19,750-₱20,249.99 bracket → MSC ₱20,000 → EE ₱900/month → ₱450 semi-monthly
      const contribution = calculateSSS(20000, true);
      expect(contribution).toBe(450);
    });

    it('should calculate SSS for ₱25,000 monthly salary', () => {
      // ₱25,000 falls in ₱24,750-₱25,249.99 bracket → MSC ₱25,000 → EE ₱1,125/month → ₱562.50 semi-monthly
      const contribution = calculateSSS(25000, true);
      expect(contribution).toBe(562.5);
    });

    it('should calculate SSS for maximum bracket (₱30,000+ MSC)', () => {
      // ₱30,000+ → MSC ₱30,000 → EE ₱1,350/month → ₱675 semi-monthly
      const contribution = calculateSSS(35000, true);
      expect(contribution).toBe(675);
    });

    it('should cap SSS at maximum even for very high salaries', () => {
      const contribution = calculateSSS(100000, true);
      expect(contribution).toBe(675); // Maximum is ₱1,350/month = ₱675 semi-monthly
    });
  });

  describe('Monthly contributions (full month)', () => {
    it('should return full monthly contribution when isSemiMonthly is false', () => {
      const contribution = calculateSSS(20000, false);
      expect(contribution).toBe(900); // Full ₱900/month
    });
  });
});

describe('PhilHealth Contribution Calculator', () => {
  describe('Semi-monthly contributions', () => {
    it('should apply minimum floor of ₱10,000 for low salaries', () => {
      // Salary below ₱10,000 → Use ₱10,000 floor
      // ₱10,000 × 5% = ₱500/month total, ₱250 employee share, ₱125 semi-monthly
      const contribution = calculatePhilHealth(5000, true);
      expect(contribution).toBe(125);
    });

    it('should calculate 2.5% employee share for normal salary', () => {
      // ₱20,000 × 5% = ₱1,000/month total, ₱500 employee share, ₱250 semi-monthly
      const contribution = calculatePhilHealth(20000, true);
      expect(contribution).toBe(250);
    });

    it('should calculate correctly for ₱50,000 salary', () => {
      // ₱50,000 × 5% = ₱2,500/month total, ₱1,250 employee share, ₱625 semi-monthly
      const contribution = calculatePhilHealth(50000, true);
      expect(contribution).toBe(625);
    });

    it('should apply maximum ceiling of ₱100,000', () => {
      // Salary above ₱100,000 → Use ₱100,000 ceiling
      // ₱100,000 × 5% = ₱5,000/month total, ₱2,500 employee share, ₱1,250 semi-monthly
      const contribution = calculatePhilHealth(150000, true);
      expect(contribution).toBe(1250);
    });
  });

  describe('Monthly contributions', () => {
    it('should return full monthly contribution', () => {
      const contribution = calculatePhilHealth(20000, false);
      expect(contribution).toBe(500); // Full ₱500/month
    });
  });
});

describe('Pag-IBIG Contribution Calculator', () => {
  describe('Semi-monthly contributions', () => {
    it('should calculate 1% for salary ≤ ₱1,500', () => {
      // ₱1,500 × 1% = ₱15/month → ₱7.50 semi-monthly
      const contribution = calculatePagibig(1500, true);
      expect(contribution).toBe(7.5);
    });

    it('should calculate 2% for salary > ₱1,500', () => {
      // ₱5,000 × 2% = ₱100/month → ₱50 semi-monthly (capped at MSC ₱5,000)
      const contribution = calculatePagibig(5000, true);
      expect(contribution).toBe(50);
    });

    it('should cap at ₱5,000 MSC for higher salaries', () => {
      // Any salary above ₱5,000 → MSC ₱5,000 × 2% = ₱100/month → ₱50 semi-monthly
      const contribution = calculatePagibig(20000, true);
      expect(contribution).toBe(50);
    });

    it('should cap at ₱50 semi-monthly even for very high salaries', () => {
      const contribution = calculatePagibig(100000, true);
      expect(contribution).toBe(50);
    });
  });

  describe('Monthly contributions', () => {
    it('should return full monthly contribution', () => {
      const contribution = calculatePagibig(20000, false);
      expect(contribution).toBe(100); // Full ₱100/month (max)
    });
  });
});

describe('Withholding Tax Calculator (TRAIN Law)', () => {
  describe('Semi-monthly tax brackets', () => {
    it('should return 0 tax for taxable income ≤ ₱10,417', () => {
      // First bracket: 0% tax
      const tax = calculateWithholdingTax(10000, 0, 0, 0, true);
      expect(tax).toBe(0);
    });

    it('should calculate 15% for bracket ₱10,417 - ₱16,667', () => {
      // Gross: ₱15,000, deductions: ₱500 → taxable: ₱14,500
      // Excess over ₱10,417 = ₱4,083 × 15% = ₱612.45
      const tax = calculateWithholdingTax(15000, 225, 125, 50, true);
      // Taxable: 15000 - 225 - 125 - 50 = 14,600
      // Excess: 14,600 - 10,417 = 4,183 × 0.15 = 627.45
      expect(tax).toBeCloseTo(627.45, 1);
    });

    it('should return 0 tax when taxable income is 0 or negative', () => {
      const tax = calculateWithholdingTax(1000, 500, 300, 200, true);
      expect(tax).toBe(0);
    });
  });

  describe('Monthly tax brackets', () => {
    it('should use monthly tax table when isSemiMonthly is false', () => {
      // Monthly bracket: 0% for ≤ ₱20,833
      const tax = calculateWithholdingTax(20000, 450, 250, 100, false);
      // Taxable: 20000 - 450 - 250 - 100 = 19,200 (below ₱20,833)
      expect(tax).toBe(0);
    });
  });
});

describe('Late Deduction Calculator', () => {
  it('should return 0 for no late minutes', () => {
    const deduction = calculateLateDeduction(0, 800);
    expect(deduction).toBe(0);
  });

  it('should return 0 for negative late minutes', () => {
    const deduction = calculateLateDeduction(-10, 800);
    expect(deduction).toBe(0);
  });

  it('should calculate correctly for 30 minutes late', () => {
    // Daily rate ₱800, hourly rate ₱100, minute rate ₱1.67
    // 30 minutes × ₱1.67 = ₱50
    const deduction = calculateLateDeduction(30, 800);
    expect(deduction).toBeCloseTo(50, 0);
  });

  it('should calculate correctly for 60 minutes late', () => {
    // Daily rate ₱1000, hourly rate ₱125, minute rate ₱2.08
    // 60 minutes × ₱2.08 = ₱125
    const deduction = calculateLateDeduction(60, 1000);
    expect(deduction).toBeCloseTo(125, 0);
  });
});

describe('Undertime Deduction Calculator', () => {
  it('should return 0 for no undertime', () => {
    const deduction = calculateUndertimeDeduction(0, 800);
    expect(deduction).toBe(0);
  });

  it('should calculate correctly for 15 minutes undertime', () => {
    // Daily rate ₱800, minute rate ₱1.67
    // 15 minutes × ₱1.67 = ₱25
    const deduction = calculateUndertimeDeduction(15, 800);
    expect(deduction).toBeCloseTo(25, 0);
  });
});

describe('Overtime Pay Calculator', () => {
  it('should calculate regular OT at 125%', () => {
    // Daily rate ₱800, hourly ₱100, 2 hours OT
    // 2 × ₱100 × 1.25 = ₱250
    const otPay = calculateOvertimePay(800, 2, 'regular');
    expect(otPay).toBe(250);
  });

  it('should calculate rest day OT at 130%', () => {
    // Daily rate ₱800, hourly ₱100, 2 hours OT
    // 2 × ₱100 × 1.30 = ₱260
    const otPay = calculateOvertimePay(800, 2, 'restday');
    expect(otPay).toBe(260);
  });

  it('should calculate holiday OT at 200%', () => {
    // Daily rate ₱800, hourly ₱100, 2 hours OT
    // 2 × ₱100 × 2.00 = ₱400
    const otPay = calculateOvertimePay(800, 2, 'holiday');
    expect(otPay).toBe(400);
  });

  it('should return 0 for 0 or negative hours', () => {
    expect(calculateOvertimePay(800, 0, 'regular')).toBe(0);
    expect(calculateOvertimePay(800, -1, 'regular')).toBe(0);
  });
});

describe('Basic Payroll Calculator', () => {
  it('should calculate complete payroll for standard employee', () => {
    // 11 days worked (semi-monthly), daily rate ₱800
    const result = calculatePayroll(11, 800, 0, 0);

    expect(result.basicPay).toBe(8800); // 11 × 800
    expect(result.grossPay).toBe(8800); // No OT
    expect(result.sssDeduction).toBeGreaterThan(0);
    expect(result.philhealthDeduction).toBeGreaterThan(0);
    expect(result.pagibigDeduction).toBeGreaterThan(0);
    expect(result.netPay).toBeLessThan(result.grossPay);
  });

  it('should include overtime in gross pay', () => {
    const result = calculatePayroll(11, 800, 0, 4);

    // Basic: 8800, OT: 4 hours × (800/8) × 1.25 = 4 × 100 × 1.25 = 500
    expect(result.grossPay).toBe(9300);
  });

  it('should deduct late minutes', () => {
    const withoutLate = calculatePayroll(11, 800, 0, 0);
    const withLate = calculatePayroll(11, 800, 60, 0);

    expect(withLate.lateDeduction).toBeGreaterThan(0);
    expect(withLate.netPay).toBeLessThan(withoutLate.netPay);
  });
});

describe('Enhanced Payroll Calculator', () => {
  const baseInput = {
    daysWorked: 11,
    dailyRate: 800,
    hoursWorked: 88,
    regularOTMinutes: 0,
    restDayOTMinutes: 0,
    holidayOTMinutes: 0,
    lateMinutes: 0,
    undertimeMinutes: 0,
    deductionConfig: {
      applySss: true,
      applyPhilhealth: true,
      applyPagibig: true,
      applyTax: false,
    },
  };

  it('should calculate basic pay correctly', () => {
    const result = calculateEnhancedPayroll(baseInput);
    expect(result.basicPay).toBe(8800); // 11 × 800
  });

  it('should respect deduction configuration - all enabled', () => {
    const result = calculateEnhancedPayroll(baseInput);

    expect(result.sssDeduction).toBeGreaterThan(0);
    expect(result.philhealthDeduction).toBeGreaterThan(0);
    expect(result.pagibigDeduction).toBeGreaterThan(0);
    expect(result.taxDeduction).toBe(0); // applyTax is false
  });

  it('should respect deduction configuration - SSS disabled', () => {
    const input = {
      ...baseInput,
      deductionConfig: { ...baseInput.deductionConfig, applySss: false },
    };
    const result = calculateEnhancedPayroll(input);

    expect(result.sssDeduction).toBe(0);
    expect(result.philhealthDeduction).toBeGreaterThan(0);
  });

  it('should respect deduction configuration - all disabled', () => {
    const input = {
      ...baseInput,
      deductionConfig: {
        applySss: false,
        applyPhilhealth: false,
        applyPagibig: false,
        applyTax: false,
      },
    };
    const result = calculateEnhancedPayroll(input);

    expect(result.sssDeduction).toBe(0);
    expect(result.philhealthDeduction).toBe(0);
    expect(result.pagibigDeduction).toBe(0);
    expect(result.taxDeduction).toBe(0);
    expect(result.netPay).toBe(result.grossPay); // No deductions
  });

  it('should calculate different OT types correctly', () => {
    const input = {
      ...baseInput,
      regularOTMinutes: 120, // 2 hours
      restDayOTMinutes: 60,  // 1 hour
      holidayOTMinutes: 60,  // 1 hour
    };
    const result = calculateEnhancedPayroll(input);

    // Regular: 2 × 100 × 1.25 = 250
    expect(result.regularOTPay).toBe(250);
    // Rest Day: 1 × 100 × 1.30 = 130
    expect(result.restDayOTPay).toBe(130);
    // Holiday: 1 × 100 × 2.00 = 200
    expect(result.holidayOTPay).toBe(200);
    expect(result.totalOTPay).toBe(580);
  });

  it('should include late and undertime deductions', () => {
    const input = {
      ...baseInput,
      lateMinutes: 30,
      undertimeMinutes: 15,
    };
    const result = calculateEnhancedPayroll(input);

    expect(result.lateDeduction).toBeGreaterThan(0);
    expect(result.undertimeDeduction).toBeGreaterThan(0);
  });

  it('should include bonus in gross pay', () => {
    const input = {
      ...baseInput,
      bonusAmount: 1000,
    };
    const result = calculateEnhancedPayroll(input);

    expect(result.bonusAmount).toBe(1000);
    expect(result.grossPay).toBe(9800); // 8800 + 1000
  });

  it('should include cash advance deduction', () => {
    const input = {
      ...baseInput,
      cashAdvanceDeduction: 500,
    };
    const result = calculateEnhancedPayroll(input);

    expect(result.cashAdvanceDeduction).toBe(500);
    expect(result.totalDeductions).toBeGreaterThan(500);
  });

  it('should calculate net pay correctly', () => {
    const result = calculateEnhancedPayroll(baseInput);

    const expectedNet = result.grossPay - result.totalDeductions;
    expect(result.netPay).toBeCloseTo(expectedNet, 2);
  });

  it('should handle minimum wage worker scenario', () => {
    const input = {
      ...baseInput,
      dailyRate: 610, // NCR minimum wage 2024
      daysWorked: 13,
    };
    const result = calculateEnhancedPayroll(input);

    expect(result.basicPay).toBe(7930); // 13 × 610
    expect(result.netPay).toBeGreaterThan(0);
    expect(result.netPay).toBeLessThan(result.grossPay);
  });

  it('should handle high earner scenario', () => {
    const input = {
      ...baseInput,
      dailyRate: 5000, // High daily rate
      daysWorked: 11,
      deductionConfig: { ...baseInput.deductionConfig, applyTax: true },
    };
    const result = calculateEnhancedPayroll(input);

    expect(result.basicPay).toBe(55000);
    expect(result.taxDeduction).toBeGreaterThan(0); // Should have tax
    expect(result.sssDeduction).toBe(675); // Should hit SSS cap
  });
});

describe('Edge Cases and Boundary Conditions', () => {
  it('should handle zero days worked', () => {
    const result = calculateEnhancedPayroll({
      daysWorked: 0,
      dailyRate: 800,
      hoursWorked: 0,
      regularOTMinutes: 0,
      restDayOTMinutes: 0,
      holidayOTMinutes: 0,
      lateMinutes: 0,
      undertimeMinutes: 0,
      deductionConfig: {
        applySss: true,
        applyPhilhealth: true,
        applyPagibig: true,
        applyTax: false,
      },
    });

    expect(result.basicPay).toBe(0);
    expect(result.grossPay).toBe(0);
  });

  it('should handle very small daily rate', () => {
    const contribution = calculateSSS(100, true);
    expect(contribution).toBe(90); // Minimum bracket
  });

  it('should round all values to 2 decimal places', () => {
    const result = calculateEnhancedPayroll({
      daysWorked: 11,
      dailyRate: 799.99,
      hoursWorked: 88,
      regularOTMinutes: 33, // Will create odd numbers
      restDayOTMinutes: 0,
      holidayOTMinutes: 0,
      lateMinutes: 17, // Will create odd numbers
      undertimeMinutes: 0,
      deductionConfig: {
        applySss: true,
        applyPhilhealth: true,
        applyPagibig: true,
        applyTax: false,
      },
    });

    // All values should have at most 2 decimal places
    const checkDecimals = (value: number) => {
      const decimalPart = value.toString().split('.')[1];
      return !decimalPart || decimalPart.length <= 2;
    };

    expect(checkDecimals(result.basicPay)).toBe(true);
    expect(checkDecimals(result.regularOTPay)).toBe(true);
    expect(checkDecimals(result.lateDeduction)).toBe(true);
    expect(checkDecimals(result.netPay)).toBe(true);
  });
});

describe('Real-World Scenarios', () => {
  it('Scenario 1: Regular worker - semi-monthly payroll', () => {
    // Daily rate ₱700, worked 11 days, 30 mins late total
    const result = calculateEnhancedPayroll({
      daysWorked: 11,
      dailyRate: 700,
      hoursWorked: 88,
      regularOTMinutes: 0,
      restDayOTMinutes: 0,
      holidayOTMinutes: 0,
      lateMinutes: 30,
      undertimeMinutes: 0,
      deductionConfig: {
        applySss: true,
        applyPhilhealth: true,
        applyPagibig: true,
        applyTax: false,
      },
    });

    expect(result.basicPay).toBe(7700);
    expect(result.grossPay).toBe(7700);
    expect(result.lateDeduction).toBeCloseTo(43.75, 1); // 30 × (700/8/60)
    expect(result.netPay).toBeLessThan(7700);
  });

  it('Scenario 2: Engineer with OT - semi-monthly payroll', () => {
    // Daily rate ₱1,500, worked 11 days, 4 hours regular OT
    const result = calculateEnhancedPayroll({
      daysWorked: 11,
      dailyRate: 1500,
      hoursWorked: 88,
      regularOTMinutes: 240, // 4 hours
      restDayOTMinutes: 0,
      holidayOTMinutes: 0,
      lateMinutes: 0,
      undertimeMinutes: 0,
      deductionConfig: {
        applySss: true,
        applyPhilhealth: true,
        applyPagibig: true,
        applyTax: true,
      },
    });

    expect(result.basicPay).toBe(16500);
    // OT: 4 hours × (1500/8) × 1.25 = 4 × 187.5 × 1.25 = 937.5
    expect(result.regularOTPay).toBe(937.5);
    expect(result.grossPay).toBe(17437.5);
    expect(result.taxDeduction).toBeGreaterThan(0);
  });

  it('Scenario 3: Worker with cash advance deduction', () => {
    const result = calculateEnhancedPayroll({
      daysWorked: 11,
      dailyRate: 800,
      hoursWorked: 88,
      regularOTMinutes: 0,
      restDayOTMinutes: 0,
      holidayOTMinutes: 0,
      lateMinutes: 0,
      undertimeMinutes: 0,
      deductionConfig: {
        applySss: true,
        applyPhilhealth: true,
        applyPagibig: true,
        applyTax: false,
      },
      cashAdvanceDeduction: 1000,
    });

    expect(result.cashAdvanceDeduction).toBe(1000);
    expect(result.totalDeductions).toBeGreaterThan(1000);
  });
});
