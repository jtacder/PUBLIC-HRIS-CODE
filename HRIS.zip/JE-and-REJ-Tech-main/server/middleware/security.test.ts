/**
 * Tests for Security Middleware
 *
 * Tests all security-related middleware including:
 * - Rate limiters
 * - Input sanitization
 * - Content-Type validation
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  sanitizeInput,
  validateContentType,
} from './security';

describe('Security Middleware', () => {
  describe('sanitizeInput', () => {
    let mockReq: any;
    let mockRes: any;
    let mockNext: any;

    beforeEach(() => {
      mockReq = {
        body: {},
        query: {},
      };
      mockRes = {
        status: vi.fn().mockReturnThis(),
        json: vi.fn().mockReturnThis(),
      };
      mockNext = vi.fn();
    });

    it('should call next on valid input', () => {
      mockReq.body = { name: 'John Doe' };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalled();
    });

    it('should remove null bytes from strings', () => {
      mockReq.body = { name: 'John\0Doe' };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.name).toBe('JohnDoe');
      expect(mockNext).toHaveBeenCalled();
    });

    it('should remove control characters from strings', () => {
      mockReq.body = { name: 'John\x01\x02\x03Doe' };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.name).toBe('JohnDoe');
    });

    it('should preserve normal characters', () => {
      mockReq.body = {
        name: 'Juan Dela Cruz',
        email: 'juan@company.com',
        description: 'Hello, world! 123',
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.name).toBe('Juan Dela Cruz');
      expect(mockReq.body.email).toBe('juan@company.com');
      expect(mockReq.body.description).toBe('Hello, world! 123');
    });

    it('should handle nested objects', () => {
      mockReq.body = {
        user: {
          name: 'John\0Doe',
          details: {
            bio: 'Test\x01Bio',
          },
        },
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.user.name).toBe('JohnDoe');
      expect(mockReq.body.user.details.bio).toBe('TestBio');
    });

    it('should handle arrays', () => {
      mockReq.body = {
        tags: ['tag\x01one', 'tag\x02two', 'normal'],
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.tags[0]).toBe('tagone');
      expect(mockReq.body.tags[1]).toBe('tagtwo');
      expect(mockReq.body.tags[2]).toBe('normal');
    });

    it('should remove special characters from object keys', () => {
      mockReq.body = {
        'normal': 'value',
        '${injection}': 'malicious',
        'key{with}braces': 'test',
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body['normal']).toBe('value');
      expect(mockReq.body['injection']).toBe('malicious');
      expect(mockReq.body['keywithbraces']).toBe('test');
    });

    it('should handle numeric values', () => {
      mockReq.body = {
        count: 42,
        price: 99.99,
        id: 0,
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.count).toBe(42);
      expect(mockReq.body.price).toBe(99.99);
      expect(mockReq.body.id).toBe(0);
    });

    it('should handle boolean values', () => {
      mockReq.body = {
        active: true,
        deleted: false,
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.active).toBe(true);
      expect(mockReq.body.deleted).toBe(false);
    });

    it('should handle null values', () => {
      mockReq.body = {
        name: 'John',
        nickname: null,
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.nickname).toBeNull();
    });

    it('should sanitize query parameters', () => {
      mockReq.query = {
        search: 'test\0query',
        filter: 'normal',
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.query.search).toBe('testquery');
      expect(mockReq.query.filter).toBe('normal');
    });

    it('should handle empty body', () => {
      mockReq.body = {};

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body).toEqual({});
      expect(mockNext).toHaveBeenCalled();
    });

    it('should handle undefined body', () => {
      mockReq.body = undefined;

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalled();
    });

    it('should preserve newlines and tabs', () => {
      mockReq.body = {
        description: 'Line 1\nLine 2\tTabbed',
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.description).toBe('Line 1\nLine 2\tTabbed');
    });

    it('should preserve Unicode characters', () => {
      mockReq.body = {
        name: 'José García',
        text: '日本語テスト',
        emoji: '👍🎉',
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.name).toBe('José García');
      expect(mockReq.body.text).toBe('日本語テスト');
      expect(mockReq.body.emoji).toBe('👍🎉');
    });
  });

  describe('validateContentType', () => {
    let mockReq: any;
    let mockRes: any;
    let mockNext: any;

    beforeEach(() => {
      mockReq = {
        method: 'GET',
        get: vi.fn(),
      };
      mockRes = {
        status: vi.fn().mockReturnThis(),
        json: vi.fn().mockReturnThis(),
      };
      mockNext = vi.fn();
    });

    it('should allow GET requests without Content-Type', () => {
      mockReq.method = 'GET';

      validateContentType(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalled();
      expect(mockRes.status).not.toHaveBeenCalled();
    });

    it('should allow DELETE requests without Content-Type', () => {
      mockReq.method = 'DELETE';

      validateContentType(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalled();
    });

    it('should allow POST with application/json', () => {
      mockReq.method = 'POST';
      mockReq.get.mockReturnValue('application/json');

      validateContentType(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalled();
    });

    it('should allow POST with application/json; charset=utf-8', () => {
      mockReq.method = 'POST';
      mockReq.get.mockReturnValue('application/json; charset=utf-8');

      validateContentType(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalled();
    });

    it('should allow PUT with application/x-www-form-urlencoded', () => {
      mockReq.method = 'PUT';
      mockReq.get.mockReturnValue('application/x-www-form-urlencoded');

      validateContentType(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalled();
    });

    it('should allow PATCH with multipart/form-data', () => {
      mockReq.method = 'PATCH';
      mockReq.get.mockReturnValue('multipart/form-data; boundary=----WebKitFormBoundary');

      validateContentType(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalled();
    });

    it('should reject POST with text/plain', () => {
      mockReq.method = 'POST';
      mockReq.get.mockReturnValue('text/plain');

      validateContentType(mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(415);
      expect(mockRes.json).toHaveBeenCalledWith({ message: 'Unsupported Media Type' });
      expect(mockNext).not.toHaveBeenCalled();
    });

    it('should reject PUT with text/html', () => {
      mockReq.method = 'PUT';
      mockReq.get.mockReturnValue('text/html');

      validateContentType(mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(415);
    });

    it('should reject PATCH with application/xml', () => {
      mockReq.method = 'PATCH';
      mockReq.get.mockReturnValue('application/xml');

      validateContentType(mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(415);
    });

    it('should allow POST without Content-Type header', () => {
      mockReq.method = 'POST';
      mockReq.get.mockReturnValue(undefined);

      validateContentType(mockReq, mockRes, mockNext);

      // No content-type is acceptable (will be handled by body parser)
      expect(mockNext).toHaveBeenCalled();
    });

    it('should allow POST with empty Content-Type', () => {
      mockReq.method = 'POST';
      mockReq.get.mockReturnValue('');

      validateContentType(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalled();
    });
  });

  describe('Rate Limiters', () => {
    // Note: Rate limiters are configured at module level and tested via integration tests
    // Here we verify the configuration is correct

    it('should export globalRateLimiter', async () => {
      const { globalRateLimiter } = await import('./security');
      expect(globalRateLimiter).toBeDefined();
      expect(typeof globalRateLimiter).toBe('function');
    });

    it('should export authRateLimiter', async () => {
      const { authRateLimiter } = await import('./security');
      expect(authRateLimiter).toBeDefined();
      expect(typeof authRateLimiter).toBe('function');
    });

    it('should export passwordResetRateLimiter', async () => {
      const { passwordResetRateLimiter } = await import('./security');
      expect(passwordResetRateLimiter).toBeDefined();
      expect(typeof passwordResetRateLimiter).toBe('function');
    });

    it('should export apiWriteRateLimiter', async () => {
      const { apiWriteRateLimiter } = await import('./security');
      expect(apiWriteRateLimiter).toBeDefined();
      expect(typeof apiWriteRateLimiter).toBe('function');
    });
  });
});

describe('Security Edge Cases', () => {
  describe('sanitizeInput with edge cases', () => {
    let mockReq: any;
    let mockRes: any;
    let mockNext: any;

    beforeEach(() => {
      mockReq = { body: {}, query: {} };
      mockRes = {};
      mockNext = vi.fn();
    });

    it('should handle deeply nested objects', () => {
      mockReq.body = {
        level1: {
          level2: {
            level3: {
              level4: {
                value: 'test\x00data',
              },
            },
          },
        },
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.level1.level2.level3.level4.value).toBe('testdata');
    });

    it('should handle mixed arrays and objects', () => {
      mockReq.body = {
        items: [
          { name: 'item\x001' },
          { name: 'item\x002' },
        ],
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.items[0].name).toBe('item1');
      expect(mockReq.body.items[1].name).toBe('item2');
    });

    it('should handle empty strings', () => {
      mockReq.body = {
        name: '',
        description: '',
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.name).toBe('');
      expect(mockReq.body.description).toBe('');
    });

    it('should handle Date objects', () => {
      const date = new Date('2025-01-15');
      mockReq.body = {
        createdAt: date,
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      // Date should be passed through (it's an object, not a plain object)
      expect(mockNext).toHaveBeenCalled();
    });

    it('should handle very long strings', () => {
      const longString = 'a'.repeat(10000);
      mockReq.body = {
        content: longString,
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.content.length).toBe(10000);
    });

    it('should handle SQL injection attempts in values', () => {
      mockReq.body = {
        search: "'; DROP TABLE users; --",
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      // Sanitizer doesn't prevent SQL injection - that's ORM's job
      // But it should not crash
      expect(mockNext).toHaveBeenCalled();
    });

    it('should handle XSS attempts in values', () => {
      mockReq.body = {
        comment: '<script>alert("xss")</script>',
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      // Sanitizer preserves HTML - XSS prevention is frontend's job
      expect(mockReq.body.comment).toBe('<script>alert("xss")</script>');
    });

    it('should remove null bytes in XSS attempts', () => {
      mockReq.body = {
        comment: '<scr\x00ipt>alert("xss")</scr\x00ipt>',
      };

      sanitizeInput(mockReq, mockRes, mockNext);

      expect(mockReq.body.comment).toBe('<script>alert("xss")</script>');
    });
  });
});
