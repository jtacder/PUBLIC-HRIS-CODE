import type { Request, Response, NextFunction, RequestHandler } from "express";
import { ZodError } from "zod";
import { logger } from "../utils/logger";

/**
 * Custom application error class with HTTP status code and operational flag.
 * Operational errors are expected errors (validation, auth) vs programming errors.
 */
export class AppError extends Error {
  public readonly statusCode: number;
  public readonly isOperational: boolean;
  public readonly context?: Record<string, unknown>;

  constructor(
    message: string,
    statusCode: number = 500,
    isOperational: boolean = true,
    context?: Record<string, unknown>
  ) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = isOperational;
    this.context = context;
    Object.setPrototypeOf(this, AppError.prototype);
    Error.captureStackTrace(this, this.constructor);
  }
}

export class ValidationError extends AppError {
  constructor(message: string, context?: Record<string, unknown>) {
    super(message, 400, true, context);
  }
}

export class AuthenticationError extends AppError {
  constructor(message: string = "Authentication required") {
    super(message, 401, true);
  }
}

export class AuthorizationError extends AppError {
  constructor(message: string = "Access denied") {
    super(message, 403, true);
  }
}

export class NotFoundError extends AppError {
  constructor(resource: string = "Resource") {
    super(`${resource} not found`, 404, true);
  }
}

export class ConflictError extends AppError {
  constructor(message: string) {
    super(message, 409, true);
  }
}

function formatZodError(error: ZodError): string {
  return error.errors
    .map((e) => `${e.path.join(".")}: ${e.message}`)
    .join("; ");
}

/**
 * Global error handler middleware for Express.
 * Handles Zod validation errors, AppErrors, and unexpected errors.
 * Logs errors appropriately and returns JSON responses.
 * @param err - The error object
 * @param req - Express request object
 * @param res - Express response object
 * @param _next - Next middleware (unused but required for Express error handler signature)
 */
export function globalErrorHandler(
  err: Error,
  req: Request,
  res: Response,
  _next: NextFunction
) {
  if (err instanceof ZodError) {
    const message = formatZodError(err);
    logger.warn("Validation error", {
      path: req.path,
      method: req.method,
      errors: err.errors,
    });
    return res.status(400).json({
      message: "Validation error",
      errors: err.errors,
      details: message,
    });
  }

  if (err instanceof AppError) {
    if (err.statusCode >= 500) {
      logger.error(`Server error: ${err.message}`, err, {
        path: req.path,
        method: req.method,
        ...err.context,
      });
    } else {
      logger.warn(`Client error: ${err.message}`, {
        path: req.path,
        method: req.method,
        statusCode: err.statusCode,
        ...err.context,
      });
    }
    return res.status(err.statusCode).json({ message: err.message });
  }

  logger.error("Unhandled error", err, {
    path: req.path,
    method: req.method,
    body: process.env.NODE_ENV !== "production" ? req.body : undefined,
  });

  const statusCode = (err as any).status || (err as any).statusCode || 500;
  const message =
    process.env.NODE_ENV === "production"
      ? "An unexpected error occurred"
      : err.message || "Internal Server Error";

  return res.status(statusCode).json({ message });
}

type AsyncRouteHandler = (
  req: Request,
  res: Response,
  next: NextFunction
) => Promise<void | Response>;

/**
 * Wrapper for async route handlers to catch errors and forward to error middleware.
 * Eliminates the need for try-catch in every async route.
 * @param fn - Async route handler function
 * @returns Express RequestHandler that catches and forwards errors
 */
export function asyncHandler(fn: AsyncRouteHandler): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

/**
 * Handler for 404 Not Found errors when no route matches.
 * @param req - Express request object
 * @param res - Express response object
 */
export function notFoundHandler(req: Request, res: Response) {
  logger.warn("Route not found", {
    path: req.path,
    method: req.method,
  });
  res.status(404).json({ message: "Route not found" });
}
