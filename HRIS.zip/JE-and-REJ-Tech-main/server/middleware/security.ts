import helmet from "helmet";
import rateLimit from "express-rate-limit";
import type { Express, Request, Response, NextFunction } from "express";

/**
 * Configure security middleware for the Express application.
 * Sets up Helmet.js with CSP, HSTS, and other security headers.
 * @param app - The Express application instance
 */
export function setupSecurityMiddleware(app: Express) {
  const isDev = process.env.NODE_ENV !== "production";
  
  const cspDirectives = {
    defaultSrc: ["'self'"],
    scriptSrc: isDev
      ? ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://maps.googleapis.com"]
      : ["'self'", "https://maps.googleapis.com"],
    styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
    fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
    imgSrc: ["'self'", "data:", "blob:", "https://*.tile.openstreetmap.org", "https://unpkg.com", "https://maps.gstatic.com", "https://maps.googleapis.com", "https://*.ggpht.com"],
    connectSrc: isDev
      ? ["'self'", "ws:", "wss:", "https://maps.googleapis.com"]
      : ["'self'", "https://maps.googleapis.com"],
    frameSrc: ["'self'", "https://maps.googleapis.com"],
    objectSrc: ["'none'"],
    baseUri: ["'self'"],
    formAction: ["'self'"],
    upgradeInsecureRequests: isDev ? null : [],
  };
  
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: cspDirectives,
      },
      crossOriginEmbedderPolicy: false,
      crossOriginResourcePolicy: { policy: "cross-origin" },
    })
  );

  app.use(helmet.referrerPolicy({ policy: "strict-origin-when-cross-origin" }));

  app.use(helmet.noSniff());

  app.use(helmet.xssFilter());

  app.use(helmet.hidePoweredBy());

  app.use(
    helmet.hsts({
      maxAge: 31536000,
      includeSubDomains: true,
      preload: true,
    })
  );
}

/**
 * Global rate limiter for all API requests.
 * Allows 1000 requests per 15 minutes.
 * Skips static assets and Vite dev server requests.
 */
export const globalRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 1000,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: "Too many requests, please try again later." },
  skip: (req: Request) => {
    return req.path.startsWith("/assets") || req.path.startsWith("/@");
  },
});

/**
 * Strict rate limiter for authentication endpoints.
 * Allows 10 login attempts per 15 minutes to prevent brute force attacks.
 */
export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: "Too many login attempts, please try again after 15 minutes." },
  validate: { xForwardedForHeader: false },
});

/**
 * Rate limiter for password reset requests.
 * Allows 3 attempts per hour.
 */
export const passwordResetRateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 3,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: "Too many password reset attempts. Please try again in 1 hour." },
});

/**
 * Rate limiter for write operations (POST, PUT, PATCH, DELETE).
 * Allows 60 write operations per minute.
 */
export const apiWriteRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: "Too many write operations. Please slow down." },
  skip: (req: Request) => {
    return req.method === "GET";
  },
});

/**
 * Middleware to sanitize user input in request body and query parameters.
 * Removes null bytes and control characters to prevent injection attacks.
 * @param req - Express request object
 * @param res - Express response object
 * @param next - Next middleware function
 */
export function sanitizeInput(req: Request, res: Response, next: NextFunction) {
  const sanitizeValue = (value: unknown): unknown => {
    if (typeof value === "string") {
      return value
        .replace(/\0/g, "")
        .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, "");
    }
    if (Array.isArray(value)) {
      return value.map(sanitizeValue);
    }
    if (value && typeof value === "object") {
      const sanitized: Record<string, unknown> = {};
      for (const [key, val] of Object.entries(value)) {
        const sanitizedKey = key.replace(/[$\{\}]/g, "");
        sanitized[sanitizedKey] = sanitizeValue(val);
      }
      return sanitized;
    }
    return value;
  };

  if (req.body && typeof req.body === "object") {
    req.body = sanitizeValue(req.body);
  }

  if (req.query && typeof req.query === "object") {
    req.query = sanitizeValue(req.query) as typeof req.query;
  }

  next();
}

/**
 * Middleware to validate Content-Type header for write requests.
 * Only allows application/json, form-urlencoded, and multipart/form-data.
 * @param req - Express request object
 * @param res - Express response object
 * @param next - Next middleware function
 */
export function validateContentType(req: Request, res: Response, next: NextFunction) {
  if (["POST", "PUT", "PATCH"].includes(req.method)) {
    const contentType = req.get("Content-Type");
    if (contentType && !contentType.includes("application/json") && 
        !contentType.includes("application/x-www-form-urlencoded") &&
        !contentType.includes("multipart/form-data")) {
      return res.status(415).json({ message: "Unsupported Media Type" });
    }
  }
  next();
}
