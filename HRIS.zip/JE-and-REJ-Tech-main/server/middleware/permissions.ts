import type { RequestHandler } from "express";
import { permissionService } from "../services/permission-service";
import { logger } from "../utils/logger";

/**
 * Middleware to check if user has a specific permission
 * Replaces the simple hasRole() middleware with granular permission checking
 *
 * Usage:
 *   router.get("/employees", hasPermission("employees.view"), handler)
 *   router.post("/employees", hasPermission("employees.create"), handler)
 *   router.delete("/employees/:id", hasPermission("employees.delete"), handler)
 *
 * For multiple permissions (user needs ANY of them):
 *   router.get("/reports", hasPermission("reports.view", "dashboard.view_admin"), handler)
 */
export function hasPermission(...requiredPermissions: string[]): RequestHandler {
  return async (req, res, next) => {
    try {
      const user = req.session.user;

      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Check if user has any of the required permissions
      const hasAccess = await permissionService.hasAnyPermission(
        user.employeeId,
        requiredPermissions
      );

      if (!hasAccess) {
        logger.warn(`Permission denied for user ${user.employeeId}`, {
          requiredPermissions,
          path: req.path,
          method: req.method,
        });

        return res.status(403).json({
          message: "Access denied. You do not have permission to perform this action.",
          requiredPermissions,
        });
      }

      next();
    } catch (error) {
      logger.error("Permission check error", error);
      return res.status(500).json({ message: "Error checking permissions" });
    }
  };
}

/**
 * Middleware to check if user has ALL specified permissions
 *
 * Usage:
 *   router.post("/payroll/release", hasAllPermissions("payroll.process", "payroll.release"), handler)
 */
export function hasAllPermissions(...requiredPermissions: string[]): RequestHandler {
  return async (req, res, next) => {
    try {
      const user = req.session.user;

      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const hasAccess = await permissionService.hasAllPermissions(
        user.employeeId,
        requiredPermissions
      );

      if (!hasAccess) {
        logger.warn(`Permission denied for user ${user.employeeId}`, {
          requiredPermissions,
          path: req.path,
          method: req.method,
        });

        return res.status(403).json({
          message: "Access denied. You do not have all required permissions.",
          requiredPermissions,
        });
      }

      next();
    } catch (error) {
      logger.error("Permission check error", error);
      return res.status(500).json({ message: "Error checking permissions" });
    }
  };
}

/**
 * Middleware to check if user is a superadmin
 *
 * Usage:
 *   router.post("/roles", isSuperadmin, handler)
 */
export const isSuperadmin: RequestHandler = async (req, res, next) => {
  try {
    const user = req.session.user;

    if (!user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const superadmin = await permissionService.isSuperadmin(user.employeeId);

    if (!superadmin) {
      logger.warn(`Superadmin access denied for user ${user.employeeId}`, {
        path: req.path,
        method: req.method,
      });

      return res.status(403).json({
        message: "Access denied. This action requires superadmin privileges.",
      });
    }

    next();
  } catch (error) {
    logger.error("Superadmin check error", error);
    return res.status(500).json({ message: "Error checking superadmin status" });
  }
};

/**
 * Middleware that attaches user's permissions to the request for use in handlers
 * This is useful when you need to conditionally return data based on permissions
 *
 * Usage:
 *   router.get("/data", attachPermissions, (req, res) => {
 *     const { permissions, isSuperadmin } = req.userPermissions;
 *     // Use permissions to filter response
 *   })
 */
export const attachPermissions: RequestHandler = async (req, res, next) => {
  try {
    const user = req.session.user;

    if (!user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const userPerms = await permissionService.getUserPermissions(user.employeeId);

    // Attach to request object
    (req as any).userPermissions = {
      permissions: userPerms.permissions,
      isSuperadmin: userPerms.isSuperadmin,
      roleId: userPerms.roleId,
      hasPermission: (code: string) =>
        userPerms.isSuperadmin || userPerms.permissions.includes(code),
      hasAnyPermission: (...codes: string[]) =>
        userPerms.isSuperadmin || codes.some(c => userPerms.permissions.includes(c)),
    };

    next();
  } catch (error) {
    logger.error("Error attaching permissions", error);
    return res.status(500).json({ message: "Error loading permissions" });
  }
};

/**
 * Combined middleware for backward compatibility
 * Maps old role-based checks to new permission-based checks
 *
 * This allows gradual migration from hasRole() to hasPermission()
 */
export function hasRoleOrPermission(
  allowedRoles: string[],
  ...permissionCodes: string[]
): RequestHandler {
  return async (req, res, next) => {
    try {
      const user = req.session.user;

      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Check old role-based access (for backward compatibility)
      if (allowedRoles.includes(user.role)) {
        return next();
      }

      // Check new permission-based access
      if (permissionCodes.length > 0) {
        const hasAccess = await permissionService.hasAnyPermission(
          user.employeeId,
          permissionCodes
        );
        if (hasAccess) {
          return next();
        }
      }

      return res.status(403).json({ message: "Access denied" });
    } catch (error) {
      logger.error("Permission check error", error);
      return res.status(500).json({ message: "Error checking permissions" });
    }
  };
}

// Type augmentation for Express Request
declare global {
  namespace Express {
    interface Request {
      userPermissions?: {
        permissions: string[];
        isSuperadmin: boolean;
        roleId: string | null;
        hasPermission: (code: string) => boolean;
        hasAnyPermission: (...codes: string[]) => boolean;
      };
    }
  }
}
