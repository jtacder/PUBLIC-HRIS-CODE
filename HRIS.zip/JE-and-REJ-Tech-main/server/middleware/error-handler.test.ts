/**
 * Tests for Error Handling Middleware
 *
 * Tests all error handling components including:
 * - Custom error classes
 * - Global error handler
 * - Async handler wrapper
 * - 404 handler
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { ZodError, z } from 'zod';
import {
  AppError,
  ValidationError,
  AuthenticationError,
  AuthorizationError,
  NotFoundError,
  ConflictError,
  globalErrorHandler,
  asyncHandler,
  notFoundHandler,
} from './error-handler';

// Mock the logger
vi.mock('../utils/logger', () => ({
  logger: {
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
  },
}));

describe('Custom Error Classes', () => {
  describe('AppError', () => {
    it('should create error with default values', () => {
      const error = new AppError('Test error');

      expect(error.message).toBe('Test error');
      expect(error.statusCode).toBe(500);
      expect(error.isOperational).toBe(true);
      expect(error.context).toBeUndefined();
    });

    it('should create error with custom status code', () => {
      const error = new AppError('Not found', 404);

      expect(error.statusCode).toBe(404);
    });

    it('should create error with context', () => {
      const error = new AppError('Error with context', 400, true, { field: 'email' });

      expect(error.context).toEqual({ field: 'email' });
    });

    it('should create non-operational error', () => {
      const error = new AppError('System error', 500, false);

      expect(error.isOperational).toBe(false);
    });

    it('should be instanceof Error', () => {
      const error = new AppError('Test');

      expect(error).toBeInstanceOf(Error);
      expect(error).toBeInstanceOf(AppError);
    });

    it('should have stack trace', () => {
      const error = new AppError('Test');

      expect(error.stack).toBeDefined();
    });
  });

  describe('ValidationError', () => {
    it('should create error with 400 status', () => {
      const error = new ValidationError('Invalid input');

      expect(error.message).toBe('Invalid input');
      expect(error.statusCode).toBe(400);
      expect(error.isOperational).toBe(true);
    });

    it('should accept context', () => {
      const error = new ValidationError('Invalid email', { field: 'email' });

      expect(error.context).toEqual({ field: 'email' });
    });

    it('should be instanceof AppError', () => {
      const error = new ValidationError('Test');

      expect(error).toBeInstanceOf(AppError);
    });
  });

  describe('AuthenticationError', () => {
    it('should create error with 401 status and default message', () => {
      const error = new AuthenticationError();

      expect(error.message).toBe('Authentication required');
      expect(error.statusCode).toBe(401);
    });

    it('should accept custom message', () => {
      const error = new AuthenticationError('Invalid token');

      expect(error.message).toBe('Invalid token');
    });
  });

  describe('AuthorizationError', () => {
    it('should create error with 403 status and default message', () => {
      const error = new AuthorizationError();

      expect(error.message).toBe('Access denied');
      expect(error.statusCode).toBe(403);
    });

    it('should accept custom message', () => {
      const error = new AuthorizationError('Insufficient permissions');

      expect(error.message).toBe('Insufficient permissions');
    });
  });

  describe('NotFoundError', () => {
    it('should create error with 404 status and default message', () => {
      const error = new NotFoundError();

      expect(error.message).toBe('Resource not found');
      expect(error.statusCode).toBe(404);
    });

    it('should accept custom resource name', () => {
      const error = new NotFoundError('Employee');

      expect(error.message).toBe('Employee not found');
    });
  });

  describe('ConflictError', () => {
    it('should create error with 409 status', () => {
      const error = new ConflictError('Email already exists');

      expect(error.message).toBe('Email already exists');
      expect(error.statusCode).toBe(409);
    });
  });
});

describe('globalErrorHandler', () => {
  let mockReq: any;
  let mockRes: any;
  let mockNext: any;
  let originalNodeEnv: string | undefined;

  beforeEach(() => {
    mockReq = {
      path: '/test',
      method: 'POST',
      body: { test: 'data' },
    };
    mockRes = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn().mockReturnThis(),
    };
    mockNext = vi.fn();
    originalNodeEnv = process.env.NODE_ENV;
  });

  afterEach(() => {
    process.env.NODE_ENV = originalNodeEnv;
  });

  describe('ZodError handling', () => {
    it('should handle ZodError with 400 status', () => {
      const schema = z.object({
        email: z.string().email(),
        age: z.number().min(18),
      });

      try {
        schema.parse({ email: 'invalid', age: 10 });
      } catch (error) {
        globalErrorHandler(error as Error, mockReq, mockRes, mockNext);
      }

      expect(mockRes.status).toHaveBeenCalledWith(400);
      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({
          message: 'Validation error',
          errors: expect.any(Array),
        })
      );
    });

    it('should format ZodError details', () => {
      const schema = z.object({
        name: z.string().min(1),
      });

      try {
        schema.parse({ name: '' });
      } catch (error) {
        globalErrorHandler(error as Error, mockReq, mockRes, mockNext);
      }

      const response = mockRes.json.mock.calls[0][0];
      expect(response.details).toBeDefined();
    });
  });

  describe('AppError handling', () => {
    it('should handle AppError with correct status', () => {
      const error = new NotFoundError('Employee');

      globalErrorHandler(error, mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(404);
      expect(mockRes.json).toHaveBeenCalledWith({ message: 'Employee not found' });
    });

    it('should handle ValidationError', () => {
      const error = new ValidationError('Invalid input');

      globalErrorHandler(error, mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(400);
    });

    it('should handle AuthenticationError', () => {
      const error = new AuthenticationError();

      globalErrorHandler(error, mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(401);
    });

    it('should handle AuthorizationError', () => {
      const error = new AuthorizationError();

      globalErrorHandler(error, mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(403);
    });

    it('should handle ConflictError', () => {
      const error = new ConflictError('Duplicate entry');

      globalErrorHandler(error, mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(409);
    });

    it('should handle 500 AppError', () => {
      const error = new AppError('Internal error', 500);

      globalErrorHandler(error, mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(500);
    });
  });

  describe('Generic Error handling', () => {
    it('should handle generic Error with 500 status in production', () => {
      process.env.NODE_ENV = 'production';
      const error = new Error('Something went wrong');

      globalErrorHandler(error, mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(500);
      expect(mockRes.json).toHaveBeenCalledWith({
        message: 'An unexpected error occurred',
      });
    });

    it('should include error message in development', () => {
      process.env.NODE_ENV = 'development';
      const error = new Error('Detailed error message');

      globalErrorHandler(error, mockReq, mockRes, mockNext);

      expect(mockRes.json).toHaveBeenCalledWith({
        message: 'Detailed error message',
      });
    });

    it('should use status from error if available', () => {
      const error: any = new Error('Custom status');
      error.status = 422;

      globalErrorHandler(error, mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(422);
    });

    it('should use statusCode from error if available', () => {
      const error: any = new Error('Custom statusCode');
      error.statusCode = 418;

      globalErrorHandler(error, mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(418);
    });
  });

  describe('Edge cases', () => {
    it('should handle null error by throwing', () => {
      // The implementation throws when receiving null - this is expected behavior
      // since null errors should not occur in normal operation
      expect(() => {
        globalErrorHandler(null as any, mockReq, mockRes, mockNext);
      }).toThrow();
    });

    it('should handle undefined error by throwing', () => {
      // The implementation throws when receiving undefined - this is expected behavior
      // since undefined errors should not occur in normal operation
      expect(() => {
        globalErrorHandler(undefined as any, mockReq, mockRes, mockNext);
      }).toThrow();
    });

    it('should handle error without message', () => {
      const error = new Error();
      error.message = '';

      globalErrorHandler(error, mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalled();
    });
  });
});

describe('asyncHandler', () => {
  let mockReq: any;
  let mockRes: any;
  let mockNext: any;

  beforeEach(() => {
    mockReq = {};
    mockRes = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn().mockReturnThis(),
    };
    mockNext = vi.fn();
  });

  it('should call the handler function', async () => {
    const handler = vi.fn().mockResolvedValue(undefined);
    const wrapped = asyncHandler(handler);

    await wrapped(mockReq, mockRes, mockNext);

    expect(handler).toHaveBeenCalledWith(mockReq, mockRes, mockNext);
  });

  it('should pass through successful response', async () => {
    const handler = vi.fn().mockImplementation(async (req, res) => {
      res.json({ success: true });
    });
    const wrapped = asyncHandler(handler);

    await wrapped(mockReq, mockRes, mockNext);

    expect(mockRes.json).toHaveBeenCalledWith({ success: true });
    expect(mockNext).not.toHaveBeenCalled();
  });

  it('should catch and forward errors to next', async () => {
    const error = new Error('Handler error');
    const handler = vi.fn().mockRejectedValue(error);
    const wrapped = asyncHandler(handler);

    // Need to wait for the internal promise to resolve
    await new Promise<void>((resolve) => {
      mockNext.mockImplementation(() => resolve());
      wrapped(mockReq, mockRes, mockNext);
    });

    expect(mockNext).toHaveBeenCalledWith(error);
  });

  it('should forward AppError to next', async () => {
    const error = new NotFoundError('Item');
    const handler = vi.fn().mockRejectedValue(error);
    const wrapped = asyncHandler(handler);

    await new Promise<void>((resolve) => {
      mockNext.mockImplementation(() => resolve());
      wrapped(mockReq, mockRes, mockNext);
    });

    expect(mockNext).toHaveBeenCalledWith(error);
  });

  it('should forward ZodError to next', async () => {
    const schema = z.object({ name: z.string() });
    const handler = vi.fn().mockImplementation(async () => {
      schema.parse({ name: 123 });
    });
    const wrapped = asyncHandler(handler);

    await new Promise<void>((resolve) => {
      mockNext.mockImplementation(() => resolve());
      wrapped(mockReq, mockRes, mockNext);
    });

    expect(mockNext).toHaveBeenCalledWith(expect.any(ZodError));
  });

  it('should handle synchronous errors thrown from async functions', async () => {
    // asyncHandler wraps with Promise.resolve which catches errors from async functions
    const handler = vi.fn().mockImplementation(async () => {
      throw new Error('Async error');
    });
    const wrapped = asyncHandler(handler);

    await new Promise<void>((resolve) => {
      mockNext.mockImplementation(() => resolve());
      wrapped(mockReq, mockRes, mockNext);
    });

    expect(mockNext).toHaveBeenCalledWith(expect.any(Error));
  });

  it('should return a function', () => {
    const handler = vi.fn();
    const wrapped = asyncHandler(handler);

    expect(typeof wrapped).toBe('function');
  });
});

describe('notFoundHandler', () => {
  let mockReq: any;
  let mockRes: any;

  beforeEach(() => {
    mockReq = {
      path: '/unknown',
      method: 'GET',
    };
    mockRes = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn().mockReturnThis(),
    };
  });

  it('should return 404 status', () => {
    notFoundHandler(mockReq, mockRes);

    expect(mockRes.status).toHaveBeenCalledWith(404);
  });

  it('should return Route not found message', () => {
    notFoundHandler(mockReq, mockRes);

    expect(mockRes.json).toHaveBeenCalledWith({ message: 'Route not found' });
  });

  it('should handle any path', () => {
    mockReq.path = '/api/v1/nonexistent/resource';

    notFoundHandler(mockReq, mockRes);

    expect(mockRes.status).toHaveBeenCalledWith(404);
  });

  it('should handle any method', () => {
    mockReq.method = 'DELETE';

    notFoundHandler(mockReq, mockRes);

    expect(mockRes.status).toHaveBeenCalledWith(404);
  });
});

describe('Error Class Inheritance', () => {
  it('all custom errors should have proper inheritance chain', () => {
    const errors = [
      new ValidationError('test'),
      new AuthenticationError(),
      new AuthorizationError(),
      new NotFoundError(),
      new ConflictError('test'),
    ];

    errors.forEach(error => {
      expect(error).toBeInstanceOf(Error);
      expect(error).toBeInstanceOf(AppError);
      expect(error.stack).toBeDefined();
    });
  });
});
