import { z } from 'zod';

// Expense rejection
export const expenseRejectionSchema = z.object({
  rejectionReason: z.string()
    .min(1, "Rejection reason is required")
    .max(500, "Rejection reason too long")
    .trim()
});

// Expense reimbursement
export const expenseReimbursementSchema = z.object({
  reimbursementRef: z.string()
    .max(100, "Reference too long")
    .regex(/^[a-zA-Z0-9\-_]+$/, "Invalid reference format")
    .optional()
});

// Attendance time entries
export const attendanceTimeSchema = z.object({
  timeIn: z.string().datetime({ offset: true, message: "Invalid timeIn format" }).optional(),
  timeOut: z.string().datetime({ offset: true, message: "Invalid timeOut format" }).optional(),
});

// Attendance adjustment
export const attendanceAdjustmentSchema = z.object({
  lateMinutes: z.number().min(0).max(1440).optional(), // max 24 hours
  undertimeMinutes: z.number().min(0).max(1440).optional(),
});

// Loan creation/update
export const loanSchema = z.object({
  deductionPerCutoff: z.number().positive("Deduction must be positive"),
  interest: z.number().min(0, "Interest cannot be negative").max(100, "Interest too high"),
});

// Devotional personal note
export const devotionalNoteSchema = z.object({
  personalNote: z.string().max(2000, "Note too long").optional(),
});

// Generic validation helper
export function validateBody<T>(schema: z.ZodSchema<T>, body: unknown):
  { success: true; data: T } | { success: false; errors: string[] } {
  const result = schema.safeParse(body);
  if (result.success) {
    return { success: true, data: result.data };
  }
  return {
    success: false,
    errors: result.error.errors.map(e => `${e.path.join('.')}: ${e.message}`)
  };
}
