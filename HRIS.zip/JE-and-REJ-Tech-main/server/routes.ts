import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupEmailAuth, getSession } from "./email-auth";
import { registerApiRoutes } from "./routes/index";
import { initializeWebSocket, broadcastToEmployee } from "./services/websocket.service";
import { notificationService } from "./services/notification.service";
import path from "path";
import fs from "fs";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  setupEmailAuth(app);

  registerApiRoutes(app);

  // Serve the push notification service worker directly from Express.
  // This is critical because Vite's dev server catch-all serves index.html
  // for all non-API routes, which breaks service worker registration.
  // By serving it here (before Vite middleware), it works in both dev and prod.
  app.get("/sw-notifications.js", (_req, res) => {
    const swPath = path.resolve(import.meta.dirname, "..", "public", "sw-notifications.js");
    if (fs.existsSync(swPath)) {
      res.setHeader("Content-Type", "application/javascript");
      res.setHeader("Service-Worker-Allowed", "/");
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      res.sendFile(swPath);
    } else {
      res.status(404).send("Service worker not found");
    }
  });

  // Initialize WebSocket server for real-time notifications
  const sessionMw = getSession();
  initializeWebSocket(httpServer, sessionMw);

  // Connect WebSocket broadcast to notification service
  notificationService.setWebSocketBroadcast(broadcastToEmployee);

  return httpServer;
}
