/**
 * Tests for Geolocation Utilities
 *
 * Tests the Haversine formula implementation for:
 * - Distance calculations between coordinates
 * - Geo-fencing validation
 */

import { describe, it, expect } from 'vitest';
import { calculateDistance, isWithinRadius } from './geo';

describe('Geolocation Utilities', () => {
  describe('calculateDistance', () => {
    it('should return 0 for same coordinates', () => {
      const result = calculateDistance(14.5547, 121.0244, 14.5547, 121.0244);
      expect(result).toBe(0);
    });

    it('should calculate distance between Manila and Makati (~3km)', () => {
      // Manila City Hall coordinates
      const manilaLat = 14.5958;
      const manilaLng = 120.9772;

      // Makati City Hall coordinates
      const makatiLat = 14.5547;
      const makatiLng = 121.0244;

      const result = calculateDistance(manilaLat, manilaLng, makatiLat, makatiLng);

      // Distance should be approximately 6-7 km
      expect(result).toBeGreaterThan(5000);
      expect(result).toBeLessThan(8000);
    });

    it('should calculate distance between Manila and Quezon City (~10km)', () => {
      const manilaLat = 14.5958;
      const manilaLng = 120.9772;

      const qcLat = 14.6760;
      const qcLng = 121.0437;

      const result = calculateDistance(manilaLat, manilaLng, qcLat, qcLng);

      // Distance should be approximately 10-12 km
      expect(result).toBeGreaterThan(8000);
      expect(result).toBeLessThan(15000);
    });

    it('should calculate short distance (100 meters)', () => {
      const lat1 = 14.5547;
      const lng1 = 121.0244;

      // Move approximately 100 meters north
      const lat2 = 14.5556; // ~0.0009 degrees
      const lng2 = 121.0244;

      const result = calculateDistance(lat1, lng1, lat2, lng2);

      // Should be approximately 100 meters
      expect(result).toBeGreaterThan(80);
      expect(result).toBeLessThan(120);
    });

    it('should calculate very short distance (10 meters)', () => {
      const lat1 = 14.5547;
      const lng1 = 121.0244;

      // Move approximately 10 meters
      const lat2 = 14.55479;
      const lng2 = 121.0244;

      const result = calculateDistance(lat1, lng1, lat2, lng2);

      expect(result).toBeGreaterThan(5);
      expect(result).toBeLessThan(20);
    });

    it('should be symmetric (A to B equals B to A)', () => {
      const lat1 = 14.5547;
      const lng1 = 121.0244;
      const lat2 = 14.5958;
      const lng2 = 120.9772;

      const distanceAB = calculateDistance(lat1, lng1, lat2, lng2);
      const distanceBA = calculateDistance(lat2, lng2, lat1, lng1);

      expect(distanceAB).toBeCloseTo(distanceBA, 10);
    });

    it('should handle coordinates crossing the equator', () => {
      const lat1 = 1.0; // 1 degree north
      const lng1 = 100.0;
      const lat2 = -1.0; // 1 degree south
      const lng2 = 100.0;

      const result = calculateDistance(lat1, lng1, lat2, lng2);

      // 2 degrees of latitude ≈ 222 km
      expect(result).toBeGreaterThan(200000);
      expect(result).toBeLessThan(250000);
    });

    it('should handle coordinates near the prime meridian', () => {
      const lat1 = 51.5;
      const lng1 = 0.1;
      const lat2 = 51.5;
      const lng2 = -0.1;

      const result = calculateDistance(lat1, lng1, lat2, lng2);

      // Small longitude difference at ~51N latitude
      expect(result).toBeGreaterThan(10000);
      expect(result).toBeLessThan(20000);
    });

    it('should handle extreme latitude (near poles)', () => {
      const lat1 = 89.0;
      const lng1 = 0.0;
      const lat2 = 89.0;
      const lng2 = 180.0;

      const result = calculateDistance(lat1, lng1, lat2, lng2);

      // Near the pole, longitude differences should still produce reasonable distances
      expect(result).toBeGreaterThan(0);
      expect(result).toBeLessThan(500000); // Less than 500 km
    });
  });

  describe('isWithinRadius', () => {
    const siteLat = 14.5547;
    const siteLng = 121.0244;

    it('should return true for same location', () => {
      const result = isWithinRadius(siteLat, siteLng, siteLat, siteLng, 100);
      expect(result).toBe(true);
    });

    it('should return true for user within 100m radius', () => {
      // Move approximately 50 meters
      const userLat = 14.55515;
      const userLng = 121.0244;

      const result = isWithinRadius(userLat, userLng, siteLat, siteLng, 100);
      expect(result).toBe(true);
    });

    it('should return false for user outside 100m radius', () => {
      // Move approximately 200 meters
      const userLat = 14.5565;
      const userLng = 121.0244;

      const result = isWithinRadius(userLat, userLng, siteLat, siteLng, 100);
      expect(result).toBe(false);
    });

    it('should return true for user at exact radius boundary', () => {
      // The boundary case - depends on implementation
      const userLat = 14.5556; // Approximately 100m north
      const userLng = 121.0244;

      const distance = calculateDistance(userLat, userLng, siteLat, siteLng);
      const result = isWithinRadius(userLat, userLng, siteLat, siteLng, distance);

      expect(result).toBe(true);
    });

    it('should work with larger radius (500m)', () => {
      // Move approximately 400 meters
      const userLat = 14.5583;
      const userLng = 121.0244;

      const result = isWithinRadius(userLat, userLng, siteLat, siteLng, 500);
      expect(result).toBe(true);
    });

    it('should work with very small radius (10m)', () => {
      // Move approximately 5 meters
      const userLat = 14.55475;
      const userLng = 121.0244;

      const result = isWithinRadius(userLat, userLng, siteLat, siteLng, 10);
      expect(result).toBe(true);
    });

    it('should handle zero radius', () => {
      // Only exact same coordinates should be within
      const result = isWithinRadius(siteLat, siteLng, siteLat, siteLng, 0);
      expect(result).toBe(true);

      // Any different location should be outside
      const result2 = isWithinRadius(siteLat + 0.0001, siteLng, siteLat, siteLng, 0);
      expect(result2).toBe(false);
    });
  });

  describe('Real-world Philippine locations', () => {
    it('should calculate distance within BGC area', () => {
      // SM Aura coordinates
      const auraLat = 14.5498;
      const auraLng = 121.0542;

      // High Street BGC coordinates
      const highStreetLat = 14.5501;
      const highStreetLng = 121.0512;

      const result = calculateDistance(auraLat, auraLng, highStreetLat, highStreetLng);

      // Should be approximately 300-400 meters
      expect(result).toBeGreaterThan(200);
      expect(result).toBeLessThan(500);
    });

    it('should validate worker at construction site (within 100m)', () => {
      // Construction site center
      const siteLat = 14.5500;
      const siteLng = 121.0500;

      // Worker at site perimeter (50m away)
      const workerLat = 14.5505;
      const workerLng = 121.0500;

      const result = isWithinRadius(workerLat, workerLng, siteLat, siteLng, 100);
      expect(result).toBe(true);
    });

    it('should reject worker far from construction site', () => {
      // Construction site center
      const siteLat = 14.5500;
      const siteLng = 121.0500;

      // Worker at home (2km away)
      const workerLat = 14.5700;
      const workerLng = 121.0500;

      const result = isWithinRadius(workerLat, workerLng, siteLat, siteLng, 100);
      expect(result).toBe(false);
    });
  });

  describe('Edge cases', () => {
    it('should handle negative coordinates (Southern hemisphere)', () => {
      const lat1 = -6.2088; // Jakarta
      const lng1 = 106.8456;
      const lat2 = -6.2000;
      const lng2 = 106.8456;

      const result = calculateDistance(lat1, lng1, lat2, lng2);
      expect(result).toBeGreaterThan(0);
    });

    it('should handle coordinates near 180/-180 longitude', () => {
      const lat1 = 0;
      const lng1 = 179.9;
      const lat2 = 0;
      const lng2 = -179.9;

      const result = calculateDistance(lat1, lng1, lat2, lng2);

      // 0.2 degrees at equator, should be approximately 22 km
      // Note: This might not handle the date line crossing correctly
      expect(result).toBeGreaterThan(0);
    });

    it('should handle very precise coordinates', () => {
      const lat1 = 14.5547123456;
      const lng1 = 121.0244123456;
      const lat2 = 14.5547123457;
      const lng2 = 121.0244123457;

      const result = calculateDistance(lat1, lng1, lat2, lng2);

      // Very small distance - should be fractions of a meter
      expect(result).toBeLessThan(1);
      expect(result).toBeGreaterThanOrEqual(0);
    });
  });
});
