import * as XLSX from "xlsx";
import { z } from "zod";
import { ATTENDANCE_TEMPLATE_COLUMNS, getAttendanceTemplateColumns } from "./attendance-template";
import { createPHTDate, PHT_OFFSET } from "./datetime";
import type { Employee, Project, InsertAttendanceLog } from "@shared/schema";

export interface AttendanceImportError {
  row: number;
  field: string;
  message: string;
  value?: string;
}

export interface AttendanceImportResult {
  success: boolean;
  data: ParsedAttendanceRow[];
  errors: AttendanceImportError[];
  totalRows: number;
  validRows: number;
  invalidRows: number;
}

export interface ParsedAttendanceRow {
  employeeId: string;
  employeeName: string;
  projectId: string | null;
  date: string;
  timeIn: string;
  timeOut: string | null;
  notes: string | null;
  lunchPaid: boolean;
  verificationStatus: "Verified" | "Pending" | "Flagged" | "Off-site";
  // Calculated fields
  scheduledShiftStart: string;
  scheduledShiftEnd: string;
  lateMinutes: number;
  isLate: boolean;
  lateDeductible: boolean;
}

// Valid verification statuses
const VALID_VERIFICATION_STATUSES = ["Verified", "Pending", "Flagged", "Off-site"];

// Helper to parse boolean values from various formats
function parseBoolean(value: any): boolean | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  const strValue = String(value).toLowerCase().trim();
  if (["true", "yes", "1", "y"].includes(strValue)) return true;
  if (["false", "no", "0", "n"].includes(strValue)) return false;
  return undefined;
}

// Helper to parse and validate date (YYYY-MM-DD)
function parseDate(value: any): string | undefined {
  if (!value) return undefined;

  // If it's already a Date object (Excel dates)
  if (value instanceof Date) {
    return value.toISOString().split("T")[0];
  }

  // If it's a number (Excel serial date)
  if (typeof value === "number") {
    const date = XLSX.SSF.parse_date_code(value);
    if (date) {
      const year = date.y;
      const month = String(date.m).padStart(2, "0");
      const day = String(date.d).padStart(2, "0");
      return `${year}-${month}-${day}`;
    }
  }

  // If it's a string, try to parse
  const strValue = String(value).trim();
  const dateMatch = strValue.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (dateMatch) return strValue;

  // Try other common formats (M/D/YYYY or MM/DD/YYYY)
  const altMatch = strValue.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (altMatch) {
    const [, month, day, year] = altMatch;
    return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
  }

  return undefined;
}

// Helper to parse time (HH:MM format)
function parseTime(value: any): string | undefined {
  if (!value) return undefined;

  const strValue = String(value).trim();

  // Handle Excel time serial numbers (e.g., 0.333333 for 08:00)
  if (typeof value === "number" && value >= 0 && value < 1) {
    const totalMinutes = Math.round(value * 24 * 60);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
  }

  // Match HH:MM or H:MM format
  const timeMatch = strValue.match(/^([01]?[0-9]|2[0-3]):([0-5][0-9])$/);
  if (timeMatch) {
    const hours = timeMatch[1].padStart(2, "0");
    const minutes = timeMatch[2];
    return `${hours}:${minutes}`;
  }

  return undefined;
}

// Calculate late minutes based on scheduled shift start and actual time in
function calculateLateMinutes(scheduledStart: string, actualTimeIn: string): number {
  const [schedHours, schedMinutes] = scheduledStart.split(":").map(Number);
  const [actualHours, actualMinutes] = actualTimeIn.split(":").map(Number);

  const scheduledMinutes = schedHours * 60 + schedMinutes;
  const actualMinutesIn = actualHours * 60 + actualMinutes;

  return Math.max(0, actualMinutesIn - scheduledMinutes);
}

// Parse and validate a single row
function parseRow(
  row: any,
  rowIndex: number,
  employees: Employee[],
  projects: Project[]
): { data: ParsedAttendanceRow | null; errors: AttendanceImportError[] } {
  const errors: AttendanceImportError[] = [];

  // Get employee identifier (employeeNo or email)
  const employeeIdentifier = row["employeeNo or email*"] || row["employeeNo or email"] || row["employeeIdentifier*"] || row["employeeIdentifier"];

  if (!employeeIdentifier || String(employeeIdentifier).trim() === "") {
    errors.push({
      row: rowIndex,
      field: "employeeNo or email",
      message: "Employee identifier is required (employeeNo or email)",
    });
  }

  // Get date
  const rawDate = row["date*"] || row["date"];
  const parsedDate = parseDate(rawDate);
  if (!parsedDate) {
    errors.push({
      row: rowIndex,
      field: "date",
      message: "Date is required and must be in YYYY-MM-DD format",
      value: rawDate ? String(rawDate) : undefined,
    });
  }

  // Get timeIn
  const rawTimeIn = row["timeIn*"] || row["timeIn"];
  const parsedTimeIn = parseTime(rawTimeIn);
  if (!parsedTimeIn) {
    errors.push({
      row: rowIndex,
      field: "timeIn",
      message: "Time In is required and must be in HH:MM format (24-hour)",
      value: rawTimeIn ? String(rawTimeIn) : undefined,
    });
  }

  // Get optional fields
  const rawTimeOut = row["timeOut"];
  const parsedTimeOut = rawTimeOut ? parseTime(rawTimeOut) : null;
  if (rawTimeOut && !parsedTimeOut) {
    errors.push({
      row: rowIndex,
      field: "timeOut",
      message: "Time Out must be in HH:MM format (24-hour)",
      value: String(rawTimeOut),
    });
  }

  // Validate timeOut is after timeIn if both provided
  if (parsedTimeIn && parsedTimeOut) {
    const [inHours, inMinutes] = parsedTimeIn.split(":").map(Number);
    const [outHours, outMinutes] = parsedTimeOut.split(":").map(Number);
    const inTotal = inHours * 60 + inMinutes;
    const outTotal = outHours * 60 + outMinutes;

    // Allow overnight shifts (timeOut < timeIn means next day)
    // But for same-day, timeOut must be after timeIn
    if (outTotal <= inTotal && outTotal > 360) { // If timeOut is not early morning (before 6am)
      errors.push({
        row: rowIndex,
        field: "timeOut",
        message: "Time Out must be after Time In (for same-day entries)",
        value: `${parsedTimeIn} - ${parsedTimeOut}`,
      });
    }
  }

  // Get project name (optional)
  const projectName = row["projectName"];
  let projectId: string | null = null;
  if (projectName && String(projectName).trim() !== "") {
    const project = projects.find(
      (p) => p.name.toLowerCase() === String(projectName).trim().toLowerCase()
    );
    if (!project) {
      errors.push({
        row: rowIndex,
        field: "projectName",
        message: `Project "${projectName}" not found`,
        value: String(projectName),
      });
    } else {
      projectId = project.id;
    }
  }

  // Get notes (optional)
  const notes = row["notes"] ? String(row["notes"]).trim() : null;

  // Get lunchPaid (optional, default false)
  const rawLunchPaid = row["lunchPaid"];
  let lunchPaid = false;
  if (rawLunchPaid !== undefined && rawLunchPaid !== null && String(rawLunchPaid).trim() !== "") {
    const parsedLunchPaid = parseBoolean(rawLunchPaid);
    if (parsedLunchPaid === undefined) {
      errors.push({
        row: rowIndex,
        field: "lunchPaid",
        message: "lunchPaid must be TRUE or FALSE",
        value: String(rawLunchPaid),
      });
    } else {
      lunchPaid = parsedLunchPaid;
    }
  }

  // Get verificationStatus (optional, default "Verified")
  const rawVerificationStatus = row["verificationStatus"];
  let verificationStatus: "Verified" | "Pending" | "Flagged" | "Off-site" = "Verified";
  if (rawVerificationStatus && String(rawVerificationStatus).trim() !== "") {
    const matchedStatus = VALID_VERIFICATION_STATUSES.find(
      (s) => s.toLowerCase() === String(rawVerificationStatus).toLowerCase().trim()
    );
    if (!matchedStatus) {
      errors.push({
        row: rowIndex,
        field: "verificationStatus",
        message: `verificationStatus must be one of: ${VALID_VERIFICATION_STATUSES.join(", ")}`,
        value: String(rawVerificationStatus),
      });
    } else {
      verificationStatus = matchedStatus as typeof verificationStatus;
    }
  }

  // Look up employee
  let employee: Employee | undefined;
  let employeeId: string | undefined;
  let employeeName: string | undefined;

  if (employeeIdentifier) {
    const identifier = String(employeeIdentifier).trim();

    // Try to match by employeeNo first, then by email
    employee = employees.find(
      (e) => e.employeeNo === identifier ||
             (e.email && e.email.toLowerCase() === identifier.toLowerCase())
    );

    if (!employee) {
      errors.push({
        row: rowIndex,
        field: "employeeNo or email",
        message: `Employee not found with identifier "${identifier}"`,
        value: identifier,
      });
    } else {
      employeeId = employee.id;
      employeeName = `${employee.firstName} ${employee.lastName}`;
    }
  }

  // If there are errors, return them
  if (errors.length > 0) {
    return { data: null, errors };
  }

  // Get employee's shift schedule (or use defaults)
  const scheduledShiftStart = employee?.shiftStartTime || "08:00";
  const scheduledShiftEnd = employee?.shiftEndTime || "17:00";

  // Calculate late minutes
  const lateMinutes = calculateLateMinutes(scheduledShiftStart, parsedTimeIn!);
  const isLate = lateMinutes > 0;
  const lateDeductible = lateMinutes >= 15; // 15+ minutes late is deductible

  return {
    data: {
      employeeId: employeeId!,
      employeeName: employeeName!,
      projectId,
      date: parsedDate!,
      timeIn: parsedTimeIn!,
      timeOut: parsedTimeOut ?? null,
      notes,
      lunchPaid,
      verificationStatus,
      scheduledShiftStart,
      scheduledShiftEnd,
      lateMinutes,
      isLate,
      lateDeductible,
    },
    errors: [],
  };
}

export function parseAttendanceFile(
  fileBuffer: Buffer,
  fileType: "xlsx" | "csv",
  employees: Employee[],
  projects: Project[]
): AttendanceImportResult {
  const errors: AttendanceImportError[] = [];
  const validData: ParsedAttendanceRow[] = [];

  try {
    // Parse the file
    const workbook = XLSX.read(fileBuffer, {
      type: "buffer",
      cellDates: true,
      dateNF: "yyyy-mm-dd",
    });

    // Find the "Attendance" sheet first, fall back to first sheet
    let sheetName = workbook.SheetNames.find(name =>
      name.toLowerCase() === "attendance"
    );

    // If no "Attendance" sheet found, use first sheet that isn't "Instructions"
    if (!sheetName) {
      sheetName = workbook.SheetNames.find(name =>
        name.toLowerCase() !== "instructions"
      ) || workbook.SheetNames[0];
    }

    if (!sheetName) {
      return {
        success: false,
        data: [],
        errors: [{ row: 0, field: "file", message: "No worksheet found in the file" }],
        totalRows: 0,
        validRows: 0,
        invalidRows: 0,
      };
    }

    const sheet = workbook.Sheets[sheetName];

    // Convert to JSON with headers
    const jsonData = XLSX.utils.sheet_to_json(sheet, {
      raw: false,
      defval: "",
    });

    if (jsonData.length === 0) {
      return {
        success: false,
        data: [],
        errors: [{ row: 0, field: "file", message: `No data rows found in the "${sheetName}" sheet. Make sure you added data below the header row.` }],
        totalRows: 0,
        validRows: 0,
        invalidRows: 0,
      };
    }

    // Process each row (skip if it looks like the example row)
    for (let i = 0; i < jsonData.length; i++) {
      const row = jsonData[i] as any;
      const rowNumber = i + 2; // +2 because row 1 is header, and we're 0-indexed

      // Skip example row (check if employeeIdentifier is "EMP-001" and date is "2024-01-15")
      const employeeIdentifier = row["employeeNo or email*"] || row["employeeNo or email"] || row["employeeIdentifier*"] || row["employeeIdentifier"];
      const date = row["date*"] || row["date"];
      if (employeeIdentifier === "EMP-001" && (date === "2024-01-15" || parseDate(date) === "2024-01-15")) {
        continue;
      }

      // Skip completely empty rows
      const hasAnyValue = Object.values(row).some(
        (v) => v !== undefined && v !== null && v !== ""
      );
      if (!hasAnyValue) continue;

      const { data, errors: rowErrors } = parseRow(row, rowNumber, employees, projects);

      if (rowErrors.length > 0) {
        errors.push(...rowErrors);
      }

      if (data) {
        validData.push(data);
      }
    }

    // Check for duplicate entries (same employee + same date)
    const duplicateMap = new Map<string, number[]>();
    for (let i = 0; i < validData.length; i++) {
      const entry = validData[i];
      const key = `${entry.employeeId}:${entry.date}`;
      const rows = duplicateMap.get(key) || [];
      rows.push(i + 2); // +2 for header and 0-index
      duplicateMap.set(key, rows);
    }

    // Find actual row numbers for duplicate entries
    let rowOffset = 2; // Start after header
    const validDataRowNumbers: number[] = [];
    for (let i = 0; i < jsonData.length; i++) {
      const row = jsonData[i] as any;
      const employeeIdentifier = row["employeeNo or email*"] || row["employeeNo or email"] || row["employeeIdentifier*"] || row["employeeIdentifier"];
      const date = row["date*"] || row["date"];

      // Skip example row
      if (employeeIdentifier === "EMP-001" && (date === "2024-01-15" || parseDate(date) === "2024-01-15")) {
        continue;
      }

      // Skip empty rows
      const hasAnyValue = Object.values(row).some(
        (v) => v !== undefined && v !== null && v !== ""
      );
      if (!hasAnyValue) continue;

      validDataRowNumbers.push(i + 2);
    }

    // Add errors for duplicates within the file
    Array.from(duplicateMap.entries()).forEach(([key, indices]) => {
      if (indices.length > 1) {
        const [employeeId, date] = key.split(":");
        const employee = employees.find(e => e.id === employeeId);
        const employeeName = employee ? `${employee.firstName} ${employee.lastName}` : employeeId;

        indices.forEach((_, idx) => {
          const actualRow = validDataRowNumbers[indices[idx] - 2] || indices[idx];
          errors.push({
            row: actualRow,
            field: "duplicate",
            message: `Duplicate entry for employee "${employeeName}" on date ${date} found in rows: ${indices.map((_, i) => validDataRowNumbers[indices[i] - 2] || indices[i]).join(", ")}`,
            value: key,
          });
        });
      }
    });

    // Check if we ended up with no valid data after processing
    if (validData.length === 0 && jsonData.length > 0 && errors.length === 0) {
      return {
        success: false,
        data: [],
        errors: [{
          row: 0,
          field: "file",
          message: "No valid attendance data found. The sample row (EMP-001, 2024-01-15) was automatically skipped. Please add your actual attendance data to the template."
        }],
        totalRows: jsonData.length,
        validRows: 0,
        invalidRows: 0,
      };
    }

    return {
      success: errors.length === 0,
      data: validData,
      errors,
      totalRows: jsonData.length,
      validRows: validData.length,
      invalidRows: jsonData.length - validData.length,
    };
  } catch (error: any) {
    return {
      success: false,
      data: [],
      errors: [{ row: 0, field: "file", message: `Failed to parse file: ${error.message}` }],
      totalRows: 0,
      validRows: 0,
      invalidRows: 0,
    };
  }
}

// Convert parsed attendance data to InsertAttendanceLog format
export function convertToAttendanceLog(
  parsed: ParsedAttendanceRow,
  date: string
): Partial<InsertAttendanceLog> {
  // Create timeIn timestamp with PHT timezone to ensure correct UTC storage
  // The db.ts configures pg to parse timestamps as UTC and sets TZ=UTC for serialization
  const timeInDate = createPHTDate(date, parsed.timeIn);

  // Create timeOut timestamp if provided
  let timeOutDate: Date | undefined;
  let totalHours: string | undefined;
  let regularMinutes = 0;
  let overtimeMinutes = 0;
  let undertimeMinutes = 0;
  let lunchDeductionMinutes = 0;

  if (parsed.timeOut) {
    const [outHours, outMinutes] = parsed.timeOut.split(":").map(Number);
    const [inHours, inMinutes] = parsed.timeIn.split(":").map(Number);

    // Handle overnight shifts
    if (outHours * 60 + outMinutes < inHours * 60 + inMinutes) {
      // TimeOut is on the next day - calculate next day in PHT
      const nextDay = new Date(`${date}T12:00:00${PHT_OFFSET}`); // Use noon to avoid DST issues
      nextDay.setDate(nextDay.getDate() + 1);
      const nextDayStr = nextDay.toISOString().split("T")[0];
      timeOutDate = createPHTDate(nextDayStr, parsed.timeOut);
    } else {
      timeOutDate = createPHTDate(date, parsed.timeOut);
    }

    // Calculate gross minutes worked
    const grossMinutes = Math.round((timeOutDate.getTime() - timeInDate.getTime()) / (1000 * 60));

    // Calculate lunch deduction (60 minutes if gross >= 300 minutes and lunch not paid)
    if (grossMinutes >= 300 && !parsed.lunchPaid) {
      lunchDeductionMinutes = 60;
    }

    // Calculate net hours
    const netMinutes = grossMinutes - lunchDeductionMinutes;
    totalHours = (netMinutes / 60).toFixed(2);

    // Calculate scheduled shift duration
    const [schedStartH, schedStartM] = parsed.scheduledShiftStart.split(":").map(Number);
    const [schedEndH, schedEndM] = parsed.scheduledShiftEnd.split(":").map(Number);
    let scheduledMinutes = (schedEndH * 60 + schedEndM) - (schedStartH * 60 + schedStartM);
    if (scheduledMinutes < 0) scheduledMinutes += 24 * 60; // Handle overnight shifts

    // Calculate regular, overtime, undertime
    regularMinutes = Math.min(grossMinutes, scheduledMinutes);
    if (grossMinutes > scheduledMinutes) {
      overtimeMinutes = grossMinutes - scheduledMinutes;
    } else if (grossMinutes < scheduledMinutes) {
      undertimeMinutes = scheduledMinutes - grossMinutes;
    }
  }

  return {
    employeeId: parsed.employeeId,
    projectId: parsed.projectId || undefined,
    timeIn: timeInDate,
    timeOut: timeOutDate,
    totalHours,
    scheduledShiftStart: parsed.scheduledShiftStart,
    scheduledShiftEnd: parsed.scheduledShiftEnd,
    scheduledShiftDate: date,
    regularMinutes,
    overtimeMinutes,
    overtimeHours: (overtimeMinutes / 60).toFixed(2),
    lunchDeductionMinutes,
    lunchPaid: parsed.lunchPaid,
    isLate: parsed.isLate,
    lateMinutes: parsed.lateMinutes,
    lateDeductible: parsed.lateDeductible,
    undertimeMinutes,
    verificationStatus: parsed.verificationStatus,
    notes: parsed.notes ? `[Bulk Upload] ${parsed.notes}` : "[Bulk Upload]",
    locationSource: "Manual",
    otStatus: overtimeMinutes > 0 ? "Pending" : undefined,
  };
}
