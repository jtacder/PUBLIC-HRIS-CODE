import { z } from "zod";

export const clockInSchema = z.object({
  qrToken: z.string().min(1, "QR Token is required"),
  photoSnapshotUrl: z.string().min(1, "Photo is required for clock-in"),
  locationLat: z.number({ required_error: "Location is required" }),
  locationLng: z.number({ required_error: "Location is required" }),
  locationSource: z.string().optional(),
  locationAccuracy: z.number().optional(), // GPS accuracy in meters (±)
});

export const clockOutSchema = z.object({
  attendanceId: z.string().min(1, "Attendance ID is required"),
});

export const payrollComputeSchema = z.object({
  cutoffStart: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date format (YYYY-MM-DD)"),
  cutoffEnd: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date format (YYYY-MM-DD)"),
});

export const dateRangeSchema = z.object({
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date format").optional(),
  endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date format").optional(),
});

export function sanitizeOptionalFields<T extends Record<string, any>>(
  body: T, 
  fields: string[]
): T {
  const sanitized = { ...body };
  for (const field of fields) {
    if (sanitized[field] === '' || sanitized[field] === undefined) {
      (sanitized as any)[field] = null;
    }
  }
  return sanitized;
}

export const OPTIONAL_PROJECT_FIELDS = [
  'poNumber', 'deadline', 'startDate', 'completedDate',
  'locationLat', 'locationLng', 'allocatedHours',
  'budget', 'actualCost', 'mealAllowance'
];
