/**
 * Tests for Validation Utilities
 *
 * Tests all validation schemas and helper functions including:
 * - Clock-in/Clock-out validation
 * - Payroll computation validation
 * - Date range validation
 * - Field sanitization
 */

import { describe, it, expect } from 'vitest';
import { z } from 'zod';
import {
  clockInSchema,
  clockOutSchema,
  payrollComputeSchema,
  dateRangeSchema,
  sanitizeOptionalFields,
  OPTIONAL_PROJECT_FIELDS,
} from './validation';

describe('Validation Schemas', () => {
  describe('clockInSchema', () => {
    it('should accept valid clock-in data', () => {
      const validData = {
        qrToken: 'abc123token',
        photoSnapshotUrl: 'https://storage.com/photo.jpg',
        locationLat: 14.5547,
        locationLng: 121.0244,
      };

      const result = clockInSchema.safeParse(validData);
      expect(result.success).toBe(true);
    });

    it('should accept optional locationSource', () => {
      const validData = {
        qrToken: 'abc123token',
        photoSnapshotUrl: 'https://storage.com/photo.jpg',
        locationLat: 14.5547,
        locationLng: 121.0244,
        locationSource: 'GPS',
      };

      const result = clockInSchema.safeParse(validData);
      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.locationSource).toBe('GPS');
      }
    });

    it('should reject empty qrToken', () => {
      const invalidData = {
        qrToken: '',
        photoSnapshotUrl: 'https://storage.com/photo.jpg',
        locationLat: 14.5547,
        locationLng: 121.0244,
      };

      const result = clockInSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error.errors[0].path).toContain('qrToken');
      }
    });

    it('should reject missing qrToken', () => {
      const invalidData = {
        photoSnapshotUrl: 'https://storage.com/photo.jpg',
        locationLat: 14.5547,
        locationLng: 121.0244,
      };

      const result = clockInSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });

    it('should reject empty photoSnapshotUrl', () => {
      const invalidData = {
        qrToken: 'abc123token',
        photoSnapshotUrl: '',
        locationLat: 14.5547,
        locationLng: 121.0244,
      };

      const result = clockInSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error.errors[0].path).toContain('photoSnapshotUrl');
      }
    });

    it('should reject missing locationLat', () => {
      const invalidData = {
        qrToken: 'abc123token',
        photoSnapshotUrl: 'https://storage.com/photo.jpg',
        locationLng: 121.0244,
      };

      const result = clockInSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });

    it('should reject missing locationLng', () => {
      const invalidData = {
        qrToken: 'abc123token',
        photoSnapshotUrl: 'https://storage.com/photo.jpg',
        locationLat: 14.5547,
      };

      const result = clockInSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });

    it('should reject non-numeric location values', () => {
      const invalidData = {
        qrToken: 'abc123token',
        photoSnapshotUrl: 'https://storage.com/photo.jpg',
        locationLat: 'invalid',
        locationLng: 121.0244,
      };

      const result = clockInSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });

    it('should accept negative coordinates', () => {
      const validData = {
        qrToken: 'abc123token',
        photoSnapshotUrl: 'https://storage.com/photo.jpg',
        locationLat: -6.2088, // Jakarta
        locationLng: 106.8456,
      };

      const result = clockInSchema.safeParse(validData);
      expect(result.success).toBe(true);
    });

    it('should accept zero coordinates', () => {
      const validData = {
        qrToken: 'abc123token',
        photoSnapshotUrl: 'https://storage.com/photo.jpg',
        locationLat: 0,
        locationLng: 0,
      };

      const result = clockInSchema.safeParse(validData);
      expect(result.success).toBe(true);
    });
  });

  describe('clockOutSchema', () => {
    it('should accept valid attendance ID', () => {
      const validData = { attendanceId: 'att-001' };
      const result = clockOutSchema.safeParse(validData);
      expect(result.success).toBe(true);
    });

    it('should reject empty attendance ID', () => {
      const invalidData = { attendanceId: '' };
      const result = clockOutSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });

    it('should reject missing attendance ID', () => {
      const invalidData = {};
      const result = clockOutSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });
  });

  describe('payrollComputeSchema', () => {
    it('should accept valid date range', () => {
      const validData = {
        cutoffStart: '2025-01-01',
        cutoffEnd: '2025-01-15',
      };

      const result = payrollComputeSchema.safeParse(validData);
      expect(result.success).toBe(true);
    });

    it('should accept dates at end of month', () => {
      const validData = {
        cutoffStart: '2025-01-16',
        cutoffEnd: '2025-01-31',
      };

      const result = payrollComputeSchema.safeParse(validData);
      expect(result.success).toBe(true);
    });

    it('should reject invalid date format (DD-MM-YYYY)', () => {
      const invalidData = {
        cutoffStart: '01-01-2025',
        cutoffEnd: '15-01-2025',
      };

      const result = payrollComputeSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });

    it('should reject invalid date format (MM/DD/YYYY)', () => {
      const invalidData = {
        cutoffStart: '01/01/2025',
        cutoffEnd: '01/15/2025',
      };

      const result = payrollComputeSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });

    it('should reject incomplete date', () => {
      const invalidData = {
        cutoffStart: '2025-01',
        cutoffEnd: '2025-01-15',
      };

      const result = payrollComputeSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });

    it('should reject missing cutoffStart', () => {
      const invalidData = {
        cutoffEnd: '2025-01-15',
      };

      const result = payrollComputeSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });

    it('should reject missing cutoffEnd', () => {
      const invalidData = {
        cutoffStart: '2025-01-01',
      };

      const result = payrollComputeSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });

    it('should accept leap year date', () => {
      const validData = {
        cutoffStart: '2024-02-01',
        cutoffEnd: '2024-02-29',
      };

      const result = payrollComputeSchema.safeParse(validData);
      expect(result.success).toBe(true);
    });
  });

  describe('dateRangeSchema', () => {
    it('should accept valid date range', () => {
      const validData = {
        startDate: '2025-01-01',
        endDate: '2025-01-31',
      };

      const result = dateRangeSchema.safeParse(validData);
      expect(result.success).toBe(true);
    });

    it('should accept only startDate', () => {
      const validData = {
        startDate: '2025-01-01',
      };

      const result = dateRangeSchema.safeParse(validData);
      expect(result.success).toBe(true);
    });

    it('should accept only endDate', () => {
      const validData = {
        endDate: '2025-01-31',
      };

      const result = dateRangeSchema.safeParse(validData);
      expect(result.success).toBe(true);
    });

    it('should accept empty object', () => {
      const validData = {};

      const result = dateRangeSchema.safeParse(validData);
      expect(result.success).toBe(true);
    });

    it('should reject invalid startDate format', () => {
      const invalidData = {
        startDate: 'invalid-date',
        endDate: '2025-01-31',
      };

      const result = dateRangeSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });

    it('should reject invalid endDate format', () => {
      const invalidData = {
        startDate: '2025-01-01',
        endDate: 'invalid-date',
      };

      const result = dateRangeSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });
  });
});

describe('sanitizeOptionalFields', () => {
  it('should convert empty strings to null', () => {
    const body = {
      name: 'Project A',
      deadline: '',
      budget: '10000',
    };

    const result = sanitizeOptionalFields(body, ['deadline', 'budget']);

    expect(result.name).toBe('Project A');
    expect(result.deadline).toBeNull();
    expect(result.budget).toBe('10000');
  });

  it('should convert undefined to null', () => {
    const body = {
      name: 'Project A',
      deadline: undefined,
      startDate: '2025-01-01',
    };

    const result = sanitizeOptionalFields(body, ['deadline', 'startDate']);

    expect(result.deadline).toBeNull();
    expect(result.startDate).toBe('2025-01-01');
  });

  it('should not modify non-empty values', () => {
    const body = {
      name: 'Project A',
      deadline: '2025-06-30',
      budget: '50000',
    };

    const result = sanitizeOptionalFields(body, ['deadline', 'budget']);

    expect(result.deadline).toBe('2025-06-30');
    expect(result.budget).toBe('50000');
  });

  it('should not modify zero values', () => {
    const body = {
      name: 'Project A',
      budget: 0,
      allocatedHours: 0,
    };

    const result = sanitizeOptionalFields(body, ['budget', 'allocatedHours']);

    expect(result.budget).toBe(0);
    expect(result.allocatedHours).toBe(0);
  });

  it('should not modify null values', () => {
    const body = {
      name: 'Project A',
      deadline: null,
    };

    const result = sanitizeOptionalFields(body, ['deadline']);

    expect(result.deadline).toBeNull();
  });

  it('should handle fields not in the list', () => {
    const body = {
      name: '',
      description: 'Test',
    };

    const result = sanitizeOptionalFields(body, ['deadline']);

    expect(result.name).toBe(''); // Not in list, stays as is
    expect(result.description).toBe('Test');
  });

  it('should handle empty fields array', () => {
    const body = {
      name: '',
      deadline: '',
    };

    const result = sanitizeOptionalFields(body, []);

    expect(result.name).toBe('');
    expect(result.deadline).toBe('');
  });

  it('should return a copy, not mutate original', () => {
    const body = {
      name: 'Project A',
      deadline: '',
    };

    const result = sanitizeOptionalFields(body, ['deadline']);

    expect(body.deadline).toBe('');
    expect(result.deadline).toBeNull();
    expect(body).not.toBe(result);
  });
});

describe('OPTIONAL_PROJECT_FIELDS', () => {
  it('should contain expected project fields', () => {
    expect(OPTIONAL_PROJECT_FIELDS).toContain('deadline');
    expect(OPTIONAL_PROJECT_FIELDS).toContain('startDate');
    expect(OPTIONAL_PROJECT_FIELDS).toContain('completedDate');
    expect(OPTIONAL_PROJECT_FIELDS).toContain('locationLat');
    expect(OPTIONAL_PROJECT_FIELDS).toContain('locationLng');
    expect(OPTIONAL_PROJECT_FIELDS).toContain('allocatedHours');
    expect(OPTIONAL_PROJECT_FIELDS).toContain('budget');
    expect(OPTIONAL_PROJECT_FIELDS).toContain('actualCost');
  });

  it('should be usable with sanitizeOptionalFields', () => {
    const projectBody = {
      name: 'New Project',
      deadline: '',
      startDate: '2025-01-01',
      locationLat: '',
      locationLng: undefined,
      budget: '100000',
      actualCost: '',
    };

    const result = sanitizeOptionalFields(projectBody, OPTIONAL_PROJECT_FIELDS);

    expect(result.name).toBe('New Project');
    expect(result.deadline).toBeNull();
    expect(result.startDate).toBe('2025-01-01');
    expect(result.locationLat).toBeNull();
    expect(result.locationLng).toBeNull();
    expect(result.budget).toBe('100000');
    expect(result.actualCost).toBeNull();
  });
});
