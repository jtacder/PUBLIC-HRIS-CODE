import * as XLSX from "xlsx";
import { z } from "zod";
import { insertEmployeeSchema } from "@shared/schema";
import { TEMPLATE_COLUMNS, getTemplateColumns } from "./employee-template";

export interface ImportError {
  row: number;
  field: string;
  message: string;
  value?: string;
}

export interface ImportResult {
  success: boolean;
  data: any[];
  errors: ImportError[];
  totalRows: number;
  validRows: number;
  invalidRows: number;
}

// Valid enum values
const VALID_ROLES = ["ADMIN", "HR", "ENGINEER", "WORKER"];
const VALID_STATUSES = ["Active", "Probationary", "Suspended", "Terminated", "Inactive"];
const VALID_RATE_TYPES = ["daily", "monthly"];
const VALID_DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

// Helper to parse boolean values from various formats
function parseBoolean(value: any): boolean | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  const strValue = String(value).toLowerCase().trim();
  if (["true", "yes", "1", "y"].includes(strValue)) return true;
  if (["false", "no", "0", "n"].includes(strValue)) return false;
  return undefined;
}

// Helper to parse and validate date
function parseDate(value: any): string | undefined {
  if (!value) return undefined;

  // If it's already a Date object (Excel dates)
  if (value instanceof Date) {
    return value.toISOString().split("T")[0];
  }

  // If it's a number (Excel serial date)
  if (typeof value === "number") {
    const date = XLSX.SSF.parse_date_code(value);
    if (date) {
      const year = date.y;
      const month = String(date.m).padStart(2, "0");
      const day = String(date.d).padStart(2, "0");
      return `${year}-${month}-${day}`;
    }
  }

  // If it's a string, try to parse
  const strValue = String(value).trim();
  const dateMatch = strValue.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (dateMatch) return strValue;

  // Try other common formats
  const altMatch = strValue.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (altMatch) {
    const [, month, day, year] = altMatch;
    return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
  }

  return undefined;
}

// Helper to parse work days
function parseWorkDays(value: any): string[] | undefined {
  if (!value) return undefined;
  const strValue = String(value).trim();
  if (!strValue) return undefined;

  const days = strValue.split(",").map((d) => d.trim());
  const validDays = days.filter((d) => VALID_DAYS.includes(d));
  return validDays.length > 0 ? validDays : undefined;
}

// Parse and validate a single row
function parseRow(row: any, rowIndex: number): { data: any | null; errors: ImportError[] } {
  const errors: ImportError[] = [];
  const data: any = {};

  // Map header keys (remove asterisk from required field headers)
  const normalizeKey = (key: string) => key.replace("*", "").trim();

  // Process each column
  const templateColumns = getTemplateColumns();

  for (const key of templateColumns) {
    // Try to get value with both regular and asterisk-marked headers
    let value = row[key] ?? row[`${key}*`];

    // Skip undefined/null/empty for optional fields
    if (value === undefined || value === null || value === "") {
      // Check if it's a required field
      const isRequired = TEMPLATE_COLUMNS.required.some((c) => c.key === key);
      if (isRequired) {
        errors.push({
          row: rowIndex,
          field: key,
          message: `${key} is required`,
        });
      }
      continue;
    }

    // Convert to string for text processing
    const strValue = String(value).trim();

    switch (key) {
      case "firstName":
      case "lastName":
        if (strValue.length < 1) {
          errors.push({
            row: rowIndex,
            field: key,
            message: `${key} cannot be empty`,
            value: strValue,
          });
        } else {
          data[key] = strValue;
        }
        break;

      case "role":
        const upperRole = strValue.toUpperCase();
        if (!VALID_ROLES.includes(upperRole)) {
          errors.push({
            row: rowIndex,
            field: key,
            message: `role must be one of: ${VALID_ROLES.join(", ")}`,
            value: strValue,
          });
        } else {
          data[key] = upperRole;
        }
        break;

      case "status":
        // Case-insensitive matching
        const matchedStatus = VALID_STATUSES.find(
          (s) => s.toLowerCase() === strValue.toLowerCase()
        );
        if (!matchedStatus) {
          errors.push({
            row: rowIndex,
            field: key,
            message: `status must be one of: ${VALID_STATUSES.join(", ")}`,
            value: strValue,
          });
        } else {
          data[key] = matchedStatus;
        }
        break;

      case "rateType":
        const lowerRateType = strValue.toLowerCase();
        if (!VALID_RATE_TYPES.includes(lowerRateType)) {
          errors.push({
            row: rowIndex,
            field: key,
            message: `rateType must be one of: ${VALID_RATE_TYPES.join(", ")}`,
            value: strValue,
          });
        } else {
          data[key] = lowerRateType;
        }
        break;

      case "baseRate":
        const numValue = parseFloat(strValue);
        if (isNaN(numValue) || numValue < 0) {
          errors.push({
            row: rowIndex,
            field: key,
            message: "baseRate must be a valid positive number",
            value: strValue,
          });
        } else {
          data[key] = strValue;
        }
        break;

      case "email":
        if (strValue && !z.string().email().safeParse(strValue).success) {
          errors.push({
            row: rowIndex,
            field: key,
            message: "Invalid email format",
            value: strValue,
          });
        } else {
          data[key] = strValue || undefined;
        }
        break;

      case "birthDate":
      case "startDate":
        const parsedDate = parseDate(value);
        if (strValue && !parsedDate) {
          errors.push({
            row: rowIndex,
            field: key,
            message: "Date must be in YYYY-MM-DD format",
            value: strValue,
          });
        } else if (parsedDate) {
          data[key] = parsedDate;
        }
        break;

      case "shiftStartTime":
      case "shiftEndTime":
        const timeMatch = strValue.match(/^([01]?[0-9]|2[0-3]):([0-5][0-9])$/);
        if (strValue && !timeMatch) {
          errors.push({
            row: rowIndex,
            field: key,
            message: "Time must be in HH:MM format (24-hour)",
            value: strValue,
          });
        } else if (timeMatch) {
          // Normalize to HH:MM format
          const hours = timeMatch[1].padStart(2, "0");
          const minutes = timeMatch[2];
          data[key] = `${hours}:${minutes}`;
        }
        break;

      case "shiftWorkDays":
        const workDays = parseWorkDays(value);
        if (strValue && !workDays) {
          errors.push({
            row: rowIndex,
            field: key,
            message: `Work days must be comma-separated: ${VALID_DAYS.join(",")}`,
            value: strValue,
          });
        } else if (workDays) {
          data[key] = workDays;
        }
        break;

      case "enableSSSDeduction":
      case "enablePhilhealthDeduction":
      case "enablePagibigDeduction":
      case "enableTaxWithholding":
      case "allowAnywhereLogin":
        const boolValue = parseBoolean(value);
        if (strValue && boolValue === undefined) {
          errors.push({
            row: rowIndex,
            field: key,
            message: "Boolean value must be TRUE, FALSE, yes, no, 1, or 0",
            value: strValue,
          });
        } else if (boolValue !== undefined) {
          data[key] = boolValue;
        }
        break;

      // String fields that don't need special validation
      case "middleName":
      case "phone":
      case "address":
      case "position":
      case "department":
      case "employeeNo":
      case "gender":
      case "civilStatus":
      case "nationality":
      case "sssNo":
      case "tinNo":
      case "philhealthNo":
      case "pagibigNo":
      case "bankName":
      case "bankAccountNo":
      case "emergencyContactName":
      case "emergencyContactPhone":
      case "emergencyContactRelation":
        data[key] = strValue || undefined;
        break;
    }
  }

  // If there are errors, return null data
  if (errors.length > 0) {
    return { data: null, errors };
  }

  return { data, errors: [] };
}

export function parseEmployeeFile(fileBuffer: Buffer, fileType: "xlsx" | "csv"): ImportResult {
  const errors: ImportError[] = [];
  const validData: any[] = [];

  try {
    // Parse the file
    const workbook = XLSX.read(fileBuffer, {
      type: "buffer",
      cellDates: true,
      dateNF: "yyyy-mm-dd",
    });

    // Find the "Employees" sheet first, fall back to first sheet
    let sheetName = workbook.SheetNames.find(name =>
      name.toLowerCase() === "employees" || name.toLowerCase() === "employee"
    );

    // If no "Employees" sheet found, use first sheet that isn't "Instructions"
    if (!sheetName) {
      sheetName = workbook.SheetNames.find(name =>
        name.toLowerCase() !== "instructions"
      ) || workbook.SheetNames[0];
    }

    if (!sheetName) {
      return {
        success: false,
        data: [],
        errors: [{ row: 0, field: "file", message: "No worksheet found in the file" }],
        totalRows: 0,
        validRows: 0,
        invalidRows: 0,
      };
    }

    const sheet = workbook.Sheets[sheetName];

    // Convert to JSON with headers
    const jsonData = XLSX.utils.sheet_to_json(sheet, {
      raw: false,
      defval: "",
    });

    if (jsonData.length === 0) {
      return {
        success: false,
        data: [],
        errors: [{ row: 0, field: "file", message: `No data rows found in the "${sheetName}" sheet. Make sure you added data below the header row.` }],
        totalRows: 0,
        validRows: 0,
        invalidRows: 0,
      };
    }

    // Process each row (skip if it looks like the example row)
    for (let i = 0; i < jsonData.length; i++) {
      const row = jsonData[i] as any;
      const rowNumber = i + 2; // +2 because row 1 is header, and we're 0-indexed

      // Skip example row (check if firstName is "Juan" and lastName is "Dela Cruz")
      const firstName = row["firstName*"] || row["firstName"];
      const lastName = row["lastName*"] || row["lastName"];
      if (firstName === "Juan" && lastName === "Dela Cruz") {
        continue;
      }

      // Skip completely empty rows
      const hasAnyValue = Object.values(row).some(
        (v) => v !== undefined && v !== null && v !== ""
      );
      if (!hasAnyValue) continue;

      const { data, errors: rowErrors } = parseRow(row, rowNumber);

      if (rowErrors.length > 0) {
        errors.push(...rowErrors);
      }

      if (data) {
        validData.push(data);
      }
    }

    // Check if we ended up with no valid data after processing
    // This can happen if only the example row was present and got skipped
    if (validData.length === 0 && jsonData.length > 0 && errors.length === 0) {
      return {
        success: false,
        data: [],
        errors: [{
          row: 0,
          field: "file",
          message: "No valid employee data found. The sample row (Juan Dela Cruz) was automatically skipped. Please add your actual employee data to the template."
        }],
        totalRows: jsonData.length,
        validRows: 0,
        invalidRows: 0,
      };
    }

    return {
      success: errors.length === 0,
      data: validData,
      errors,
      totalRows: jsonData.length,
      validRows: validData.length,
      invalidRows: jsonData.length - validData.length,
    };
  } catch (error: any) {
    return {
      success: false,
      data: [],
      errors: [{ row: 0, field: "file", message: `Failed to parse file: ${error.message}` }],
      totalRows: 0,
      validRows: 0,
      invalidRows: 0,
    };
  }
}

// Validate parsed data against the schema
export function validateEmployeeData(data: any[]): { valid: any[]; errors: ImportError[] } {
  const valid: any[] = [];
  const errors: ImportError[] = [];

  for (let i = 0; i < data.length; i++) {
    const employee = data[i];
    const result = insertEmployeeSchema.safeParse(employee);

    if (result.success) {
      valid.push(result.data);
    } else {
      for (const error of result.error.errors) {
        errors.push({
          row: i + 2, // Adjust for header row
          field: error.path.join("."),
          message: error.message,
        });
      }
    }
  }

  return { valid, errors };
}
