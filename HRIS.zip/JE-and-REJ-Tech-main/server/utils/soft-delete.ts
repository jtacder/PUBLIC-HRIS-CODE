/**
 * Soft Delete Utilities
 *
 * Provides helper functions for soft delete operations. Soft deletes set a
 * `deletedAt` timestamp instead of permanently removing records, allowing
 * for data recovery and audit trails.
 *
 * IMPORTANT: These utilities are additive only. Existing delete operations
 * are NOT modified. Use these helpers when ready to migrate to soft deletes.
 */

import { eq, isNull, and, SQL } from "drizzle-orm";
import { db } from "../db";
import {
  employees,
  projects,
  payrollRecords,
  disciplinaryActions,
  leaveRequests,
} from "@shared/schema";
import { logger } from "./logger";

// Type for tables that support soft delete
type SoftDeleteTable =
  | typeof employees
  | typeof projects
  | typeof payrollRecords
  | typeof disciplinaryActions
  | typeof leaveRequests;

// Map table names to their Drizzle table objects
const tableMap = {
  employees,
  projects,
  payroll_records: payrollRecords,
  disciplinary_actions: disciplinaryActions,
  leave_requests: leaveRequests,
} as const;

type SoftDeleteTableName = keyof typeof tableMap;

/**
 * Soft delete a record by setting its deletedAt timestamp
 *
 * @param tableName - The name of the table (e.g., 'employees', 'projects')
 * @param id - The ID of the record to soft delete
 * @returns The updated record or null if not found
 *
 * @example
 * ```typescript
 * // Soft delete an employee
 * const deleted = await softDelete('employees', 'emp-123');
 * ```
 */
export async function softDelete(
  tableName: SoftDeleteTableName,
  id: string
): Promise<Record<string, unknown> | null> {
  const table = tableMap[tableName];

  if (!table) {
    logger.error(`Unknown table for soft delete: ${tableName}`);
    throw new Error(`Unknown table: ${tableName}`);
  }

  try {
    const now = new Date();

    // @ts-expect-error - Dynamic table access
    const result = await db
      .update(table)
      .set({ deletedAt: now })
      .where(eq(table.id, id))
      .returning();

    if (result.length === 0) {
      logger.warn(`Soft delete: Record not found`, { tableName, id });
      return null;
    }

    logger.info(`Soft deleted record`, { tableName, id, deletedAt: now });
    return result[0];
  } catch (error) {
    logger.error(`Soft delete failed`, error, { tableName, id });
    throw error;
  }
}

/**
 * Restore a soft-deleted record by setting deletedAt to null
 *
 * @param tableName - The name of the table
 * @param id - The ID of the record to restore
 * @returns The restored record or null if not found
 *
 * @example
 * ```typescript
 * // Restore a soft-deleted employee
 * const restored = await restore('employees', 'emp-123');
 * ```
 */
export async function restore(
  tableName: SoftDeleteTableName,
  id: string
): Promise<Record<string, unknown> | null> {
  const table = tableMap[tableName];

  if (!table) {
    logger.error(`Unknown table for restore: ${tableName}`);
    throw new Error(`Unknown table: ${tableName}`);
  }

  try {
    // @ts-expect-error - Dynamic table access
    const result = await db
      .update(table)
      .set({ deletedAt: null })
      .where(eq(table.id, id))
      .returning();

    if (result.length === 0) {
      logger.warn(`Restore: Record not found`, { tableName, id });
      return null;
    }

    logger.info(`Restored soft-deleted record`, { tableName, id });
    return result[0];
  } catch (error) {
    logger.error(`Restore failed`, error, { tableName, id });
    throw error;
  }
}

/**
 * Create a WHERE clause condition that filters out soft-deleted records
 *
 * @param table - The Drizzle table object
 * @returns A SQL condition for filtering deleted records
 *
 * @example
 * ```typescript
 * // Query only non-deleted employees
 * const activeEmployees = await db
 *   .select()
 *   .from(employees)
 *   .where(and(
 *     eq(employees.status, 'Active'),
 *     withoutDeleted(employees)
 *   ));
 * ```
 */
export function withoutDeleted(table: SoftDeleteTable): SQL {
  // @ts-expect-error - deletedAt exists on all soft-delete tables
  return isNull(table.deletedAt);
}

/**
 * Create a WHERE clause condition that includes only soft-deleted records
 *
 * @param table - The Drizzle table object
 * @returns A SQL condition for filtering to show only deleted records
 *
 * @example
 * ```typescript
 * // Query only deleted employees (for admin recovery purposes)
 * const deletedEmployees = await db
 *   .select()
 *   .from(employees)
 *   .where(onlyDeleted(employees));
 * ```
 */
export function onlyDeleted(table: SoftDeleteTable): SQL {
  // @ts-expect-error - deletedAt exists on all soft-delete tables
  return isNotNull(table.deletedAt);
}

// Import isNotNull for the onlyDeleted function
import { isNotNull } from "drizzle-orm";

/**
 * Check if a record is soft-deleted
 *
 * @param record - The record to check
 * @returns true if the record is soft-deleted
 */
export function isSoftDeleted(
  record: { deletedAt?: Date | null } | null
): boolean {
  return record?.deletedAt != null;
}

/**
 * Permanently delete all soft-deleted records older than a specified date
 * Use with caution - this performs a hard delete!
 *
 * @param tableName - The name of the table
 * @param olderThan - Delete records soft-deleted before this date
 * @returns The number of permanently deleted records
 *
 * @example
 * ```typescript
 * // Permanently delete records soft-deleted more than 90 days ago
 * const thirtyDaysAgo = new Date();
 * thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 90);
 * const count = await purgeDeleted('employees', thirtyDaysAgo);
 * console.log(`Purged ${count} old employee records`);
 * ```
 */
export async function purgeDeleted(
  tableName: SoftDeleteTableName,
  olderThan: Date
): Promise<number> {
  const table = tableMap[tableName];

  if (!table) {
    logger.error(`Unknown table for purge: ${tableName}`);
    throw new Error(`Unknown table: ${tableName}`);
  }

  try {
    // Import lt for the comparison
    const { lt } = await import("drizzle-orm");

    // @ts-expect-error - Dynamic table access
    const result = await db
      .delete(table)
      .where(
        and(
          // @ts-expect-error - deletedAt exists on all soft-delete tables
          isNotNull(table.deletedAt),
          // @ts-expect-error - deletedAt exists on all soft-delete tables
          lt(table.deletedAt, olderThan)
        )
      )
      .returning({ id: table.id });

    const count = result.length;
    logger.info(`Purged soft-deleted records`, {
      tableName,
      count,
      olderThan: olderThan.toISOString(),
    });
    return count;
  } catch (error) {
    logger.error(`Purge failed`, error, { tableName });
    throw error;
  }
}

// Export table map for advanced use cases
export { tableMap, type SoftDeleteTableName };
