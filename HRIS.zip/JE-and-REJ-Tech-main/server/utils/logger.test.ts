/**
 * Tests for Logger Utility
 *
 * Tests all logging functions including:
 * - Log level handling
 * - Message formatting
 * - Sensitive field masking
 * - HTTP request logging
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { logger, LogLevel } from './logger';

describe('Logger Utility', () => {
  // Capture console outputs
  let consoleLogSpy: ReturnType<typeof vi.spyOn>;
  let consoleWarnSpy: ReturnType<typeof vi.spyOn>;
  let consoleErrorSpy: ReturnType<typeof vi.spyOn>;
  let originalNodeEnv: string | undefined;

  beforeEach(() => {
    consoleLogSpy = vi.spyOn(console, 'log').mockImplementation(() => {});
    consoleWarnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    originalNodeEnv = process.env.NODE_ENV;
  });

  afterEach(() => {
    consoleLogSpy.mockRestore();
    consoleWarnSpy.mockRestore();
    consoleErrorSpy.mockRestore();
    process.env.NODE_ENV = originalNodeEnv;
  });

  describe('LogLevel Enum', () => {
    it('should have correct log levels', () => {
      expect(LogLevel.DEBUG).toBe('DEBUG');
      expect(LogLevel.INFO).toBe('INFO');
      expect(LogLevel.WARN).toBe('WARN');
      expect(LogLevel.ERROR).toBe('ERROR');
    });
  });

  describe('logger.debug', () => {
    it('should log debug messages in development', () => {
      process.env.NODE_ENV = 'development';

      logger.debug('Test debug message');

      expect(consoleLogSpy).toHaveBeenCalled();
      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('[DEBUG]');
      expect(output).toContain('Test debug message');
    });

    it('should not log debug messages in production', () => {
      process.env.NODE_ENV = 'production';

      logger.debug('Test debug message');

      expect(consoleLogSpy).not.toHaveBeenCalled();
    });

    it('should include context object', () => {
      process.env.NODE_ENV = 'development';

      logger.debug('Test message', { userId: 'user-001', action: 'test' });

      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('userId');
      expect(output).toContain('user-001');
    });
  });

  describe('logger.info', () => {
    it('should log info messages', () => {
      logger.info('Test info message');

      expect(consoleLogSpy).toHaveBeenCalled();
      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('[INFO]');
      expect(output).toContain('Test info message');
    });

    it('should log in production', () => {
      process.env.NODE_ENV = 'production';

      logger.info('Production info message');

      expect(consoleLogSpy).toHaveBeenCalled();
    });

    it('should include context', () => {
      logger.info('User logged in', { userId: 'user-001', ip: '192.168.1.1' });

      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('User logged in');
      expect(output).toContain('192.168.1.1');
    });
  });

  describe('logger.warn', () => {
    it('should log warning messages', () => {
      logger.warn('Test warning message');

      expect(consoleWarnSpy).toHaveBeenCalled();
      const output = consoleWarnSpy.mock.calls[0][0];
      expect(output).toContain('[WARN]');
      expect(output).toContain('Test warning message');
    });

    it('should include context', () => {
      logger.warn('Rate limit approaching', { remaining: 10, limit: 100 });

      const output = consoleWarnSpy.mock.calls[0][0];
      expect(output).toContain('Rate limit approaching');
      expect(output).toContain('10');
    });
  });

  describe('logger.error', () => {
    it('should log error messages', () => {
      logger.error('Test error message');

      expect(consoleErrorSpy).toHaveBeenCalled();
      const output = consoleErrorSpy.mock.calls[0][0];
      expect(output).toContain('[ERROR]');
      expect(output).toContain('Test error message');
    });

    it('should log Error object details', () => {
      process.env.NODE_ENV = 'development';
      const error = new Error('Something went wrong');

      logger.error('Operation failed', error);

      const output = consoleErrorSpy.mock.calls[0][0];
      expect(output).toContain('Operation failed');
      expect(output).toContain('Error:');
      expect(output).toContain('Something went wrong');
    });

    it('should log stack trace in development', () => {
      process.env.NODE_ENV = 'development';
      const error = new Error('Test error');

      logger.error('Error with stack', error);

      const output = consoleErrorSpy.mock.calls[0][0];
      expect(output).toContain('Stack:');
    });

    it('should not log stack trace in production', () => {
      process.env.NODE_ENV = 'production';
      const error = new Error('Test error');

      logger.error('Error without stack', error);

      const output = consoleErrorSpy.mock.calls[0][0];
      expect(output).not.toContain('Stack:');
    });

    it('should handle non-Error error values', () => {
      logger.error('Non-error value', 'string error');

      const output = consoleErrorSpy.mock.calls[0][0];
      expect(output).toContain('Non-error value');
      expect(output).toContain('errorValue');
    });

    it('should handle object error values', () => {
      logger.error('Object error', { code: 'ERR_001', details: 'test' });

      const output = consoleErrorSpy.mock.calls[0][0];
      expect(output).toContain('Object error');
      expect(output).toContain('errorValue');
    });

    it('should include additional context', () => {
      logger.error('Database error', new Error('Connection failed'), { dbHost: 'localhost' });

      const output = consoleErrorSpy.mock.calls[0][0];
      expect(output).toContain('Database error');
      expect(output).toContain('localhost');
    });
  });

  describe('logger.http', () => {
    it('should log HTTP request with INFO level for success', () => {
      logger.http('GET', '/api/users', 200, 45);

      expect(consoleLogSpy).toHaveBeenCalled();
      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('[GET]');
      expect(output).toContain('/api/users');
      expect(output).toContain('200');
      expect(output).toContain('45ms');
    });

    it('should log HTTP request with WARN level for client error', () => {
      logger.http('POST', '/api/login', 401, 15);

      expect(consoleLogSpy).toHaveBeenCalled();
      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('[POST]');
      expect(output).toContain('401');
    });

    it('should log HTTP request with ERROR level for server error', () => {
      logger.http('GET', '/api/data', 500, 100);

      expect(consoleLogSpy).toHaveBeenCalled();
      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('[GET]');
      expect(output).toContain('500');
    });

    it('should include request body in development', () => {
      process.env.NODE_ENV = 'development';

      logger.http('POST', '/api/employees', 201, 150, { name: 'John Doe' });

      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('John Doe');
    });

    it('should not include request body in production', () => {
      process.env.NODE_ENV = 'production';

      logger.http('POST', '/api/employees', 201, 150, { name: 'John Doe' });

      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).not.toContain('John Doe');
    });

    it('should truncate long body in development', () => {
      process.env.NODE_ENV = 'development';
      const longBody = { data: 'x'.repeat(1000) };

      logger.http('POST', '/api/data', 200, 50, longBody);

      // Should not include body since it's too long
      expect(consoleLogSpy).toHaveBeenCalled();
    });
  });

  describe('Sensitive Field Masking', () => {
    it('should mask password fields in HTTP body', () => {
      process.env.NODE_ENV = 'development';

      logger.http('POST', '/api/login', 200, 30, { email: 'user@test.com', password: 'secret123' });

      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('email');
      expect(output).toContain('user@test.com');
      expect(output).toContain('[REDACTED]');
      expect(output).not.toContain('secret123');
    });

    it('should mask passwordHash fields', () => {
      process.env.NODE_ENV = 'development';

      logger.http('GET', '/api/debug', 200, 10, { passwordHash: '$2b$12$xxx' });

      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('[REDACTED]');
      expect(output).not.toContain('$2b$12$xxx');
    });

    it('should mask token fields', () => {
      process.env.NODE_ENV = 'development';

      logger.http('POST', '/api/auth', 200, 20, { token: 'jwt.token.here' });

      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('[REDACTED]');
      expect(output).not.toContain('jwt.token.here');
    });

    it('should mask secret fields', () => {
      process.env.NODE_ENV = 'development';

      logger.http('GET', '/api/config', 200, 5, { clientSecret: 'mysecret' });

      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('[REDACTED]');
      expect(output).not.toContain('mysecret');
    });

    it('should mask apiKey fields', () => {
      process.env.NODE_ENV = 'development';

      logger.http('POST', '/api/webhook', 200, 15, { apiKey: 'key_abc123' });

      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('[REDACTED]');
      expect(output).not.toContain('key_abc123');
    });

    it('should mask authorization fields', () => {
      process.env.NODE_ENV = 'development';

      logger.http('GET', '/api/data', 200, 8, { authorization: 'Bearer xxx' });

      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('[REDACTED]');
      expect(output).not.toContain('Bearer xxx');
    });

    it('should mask nested sensitive fields', () => {
      process.env.NODE_ENV = 'development';

      logger.http('POST', '/api/user', 200, 25, {
        user: {
          email: 'test@test.com',
          password: 'nested-secret',
        },
      });

      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('test@test.com');
      expect(output).toContain('[REDACTED]');
      expect(output).not.toContain('nested-secret');
    });

    it('should mask arrays with sensitive fields', () => {
      process.env.NODE_ENV = 'development';

      logger.http('POST', '/api/users', 200, 40, {
        users: [
          { email: 'a@test.com', password: 'pass1' },
          { email: 'b@test.com', password: 'pass2' },
        ],
      });

      const output = consoleLogSpy.mock.calls[0][0];
      expect(output).toContain('[REDACTED]');
      expect(output).not.toContain('pass1');
      expect(output).not.toContain('pass2');
    });
  });

  describe('Timestamp Formatting', () => {
    it('should include timestamp in log output', () => {
      logger.info('Test message');

      const output = consoleLogSpy.mock.calls[0][0];
      // Should have some time format (AM/PM)
      expect(output).toMatch(/\d{1,2}:\d{2}:\d{2}\s*(AM|PM)/);
    });
  });

  describe('Edge Cases', () => {
    it('should handle undefined context', () => {
      expect(() => logger.info('Message', undefined)).not.toThrow();
    });

    it('should handle null context', () => {
      expect(() => logger.info('Message', null as any)).not.toThrow();
    });

    it('should handle empty context object', () => {
      logger.info('Message', {});
      expect(consoleLogSpy).toHaveBeenCalled();
    });

    it('should handle circular references in context', () => {
      const obj: any = { name: 'test' };
      obj.self = obj;

      // The logger may throw on circular references if it uses JSON.stringify
      // This tests the behavior rather than asserting a specific outcome
      try {
        logger.info('Message', { data: obj });
        // If it doesn't throw, that's acceptable
        expect(consoleLogSpy).toHaveBeenCalled();
      } catch (error) {
        // If it throws a TypeError for circular structure, that's also acceptable
        expect(error).toBeInstanceOf(TypeError);
      }
    });

    it('should handle null error value', () => {
      expect(() => logger.error('Message', null)).not.toThrow();
    });

    it('should handle undefined error value', () => {
      expect(() => logger.error('Message', undefined)).not.toThrow();
    });
  });
});
