/**
 * Auto Role Assignment Utility
 *
 * This utility automatically assigns the appropriate roleId (modern permission system)
 * based on the legacy role field when employees are created.
 *
 * SAFETY: This is designed to be backward compatible:
 * - Only runs on NEW employee creation
 * - Does NOT modify existing employees
 * - Falls back gracefully if roles don't exist
 * - Legacy role checks continue to work in parallel
 *
 * Mapping:
 * - ADMIN → SUPERADMIN role
 * - HR → HR_ADMIN role
 * - ENGINEER, WORKER → No automatic role (they use individual permissions or custom roles)
 */

import { db } from "../db";
import { roles } from "@shared/schema";
import { eq } from "drizzle-orm";
import { logger } from "./logger";

// Cache for role lookups (to avoid repeated DB queries)
let roleCache: Map<string, string> | null = null;
let cacheExpiry: number = 0;
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

/**
 * Get role ID by role name (with caching)
 */
async function getRoleIdByName(roleName: string): Promise<string | null> {
  try {
    // Check cache
    if (roleCache && Date.now() < cacheExpiry) {
      return roleCache.get(roleName) || null;
    }

    // Load all roles into cache
    const allRoles = await db.select({ id: roles.id, name: roles.name }).from(roles);
    roleCache = new Map(allRoles.map(r => [r.name, r.id]));
    cacheExpiry = Date.now() + CACHE_TTL;

    return roleCache.get(roleName) || null;
  } catch (error) {
    // If roles table doesn't exist yet, fail silently
    logger.debug("Could not lookup role (this is OK if permission system not yet seeded)", { roleName, error });
    return null;
  }
}

/**
 * Invalidate the role cache (call this when roles are modified)
 */
export function invalidateRoleCache(): void {
  roleCache = null;
  cacheExpiry = 0;
}

/**
 * Get the appropriate roleId for a given legacy role
 *
 * @param legacyRole - The legacy role (ADMIN, HR, ENGINEER, WORKER)
 * @returns The roleId to assign, or null if no automatic assignment
 */
export async function getRoleIdForLegacyRole(legacyRole: string): Promise<string | null> {
  switch (legacyRole?.toUpperCase()) {
    case "ADMIN":
      // ADMIN users get SUPERADMIN role
      return await getRoleIdByName("SUPERADMIN");

    case "HR":
      // HR users get HR_ADMIN role
      return await getRoleIdByName("HR_ADMIN");

    case "ENGINEER":
    case "WORKER":
    default:
      // Engineers and Workers don't get automatic role assignment
      // They should be manually assigned custom roles via the Permission Management UI
      return null;
  }
}

/**
 * Enhance employee data with automatic roleId assignment
 *
 * This function takes the employee data being created and adds the appropriate
 * roleId based on the legacy role field.
 *
 * SAFETY NOTES:
 * - Only adds roleId if not already set
 * - Falls back gracefully if role lookup fails
 * - Does not modify the original object
 *
 * @param employeeData - The employee data to enhance
 * @returns Enhanced employee data with roleId (if applicable)
 */
export async function enhanceEmployeeWithRoleId<T extends { role?: string; roleId?: string | null }>(
  employeeData: T
): Promise<T> {
  // Don't override if roleId is already set
  if (employeeData.roleId) {
    return employeeData;
  }

  // Don't assign if no role specified
  if (!employeeData.role) {
    return employeeData;
  }

  try {
    const roleId = await getRoleIdForLegacyRole(employeeData.role);

    if (roleId) {
      logger.info("Auto-assigning roleId based on legacy role", {
        legacyRole: employeeData.role,
        assignedRoleId: roleId,
      });

      return {
        ...employeeData,
        roleId,
      };
    }
  } catch (error) {
    // Log but don't fail - legacy role will still work
    logger.warn("Failed to auto-assign roleId, falling back to legacy role only", {
      role: employeeData.role,
      error,
    });
  }

  return employeeData;
}

/**
 * Check if the permission system has been seeded
 * (i.e., the roles table has the default system roles)
 */
export async function isPermissionSystemSeeded(): Promise<boolean> {
  try {
    const [superadminRole] = await db
      .select({ id: roles.id })
      .from(roles)
      .where(eq(roles.name, "SUPERADMIN"))
      .limit(1);

    return !!superadminRole;
  } catch (error) {
    return false;
  }
}
