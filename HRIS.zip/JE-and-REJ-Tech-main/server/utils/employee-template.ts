import * as XLSX from "xlsx";

// Column definitions for the employee import template
export const TEMPLATE_COLUMNS = {
  // Required fields (marked with asterisk in header)
  required: [
    { key: "firstName", header: "firstName*", description: "Employee first name", example: "Juan" },
    { key: "lastName", header: "lastName*", description: "Employee last name", example: "Dela Cruz" },
    { key: "role", header: "role*", description: "ADMIN, HR, ENGINEER, or WORKER", example: "WORKER" },
    { key: "baseRate", header: "baseRate*", description: "Base salary rate (number)", example: "500" },
    { key: "rateType", header: "rateType*", description: "daily or monthly", example: "daily" },
    { key: "status", header: "status*", description: "Active, Probationary, Suspended, Terminated, Inactive", example: "Active" },
  ],
  // Optional fields
  optional: [
    { key: "employeeNo", header: "employeeNo", description: "Company-assigned Employee ID", example: "EMP-001" },
    { key: "middleName", header: "middleName", description: "Middle name", example: "Santos" },
    { key: "email", header: "email", description: "Email address", example: "juan@email.com" },
    { key: "phone", header: "phone", description: "Contact number", example: "+63 917 123 4567" },
    { key: "address", header: "address", description: "Home address", example: "123 Main St, Manila" },
    { key: "position", header: "position", description: "Job position/title", example: "Electrician" },
    { key: "department", header: "department", description: "Department name", example: "Operations" },
    { key: "birthDate", header: "birthDate", description: "YYYY-MM-DD format", example: "1990-01-15" },
    { key: "gender", header: "gender", description: "Male, Female, or Other", example: "Male" },
    { key: "civilStatus", header: "civilStatus", description: "Single, Married, etc.", example: "Single" },
    { key: "nationality", header: "nationality", description: "Country of citizenship", example: "Filipino" },
    { key: "startDate", header: "startDate", description: "Employment start date (YYYY-MM-DD)", example: "2024-01-15" },
    { key: "sssNo", header: "sssNo", description: "SSS number", example: "00-0000000-0" },
    { key: "tinNo", header: "tinNo", description: "TIN number", example: "000-000-000-000" },
    { key: "philhealthNo", header: "philhealthNo", description: "PhilHealth number", example: "00-000000000-0" },
    { key: "pagibigNo", header: "pagibigNo", description: "Pag-IBIG number", example: "0000-0000-0000" },
    { key: "bankName", header: "bankName", description: "Bank name", example: "BDO" },
    { key: "bankAccountNo", header: "bankAccountNo", description: "Bank account number", example: "001234567890" },
    { key: "emergencyContactName", header: "emergencyContactName", description: "Emergency contact name", example: "Maria Dela Cruz" },
    { key: "emergencyContactPhone", header: "emergencyContactPhone", description: "Emergency contact phone", example: "+63 917 987 6543" },
    { key: "emergencyContactRelation", header: "emergencyContactRelation", description: "Relationship", example: "Spouse" },
    { key: "shiftStartTime", header: "shiftStartTime", description: "HH:MM format", example: "08:00" },
    { key: "shiftEndTime", header: "shiftEndTime", description: "HH:MM format", example: "17:00" },
    { key: "shiftWorkDays", header: "shiftWorkDays", description: "Comma-separated: Mon,Tue,Wed,Thu,Fri", example: "Mon,Tue,Wed,Thu,Fri" },
    { key: "enableSSSDeduction", header: "enableSSSDeduction", description: "TRUE or FALSE", example: "TRUE" },
    { key: "enablePhilhealthDeduction", header: "enablePhilhealthDeduction", description: "TRUE or FALSE", example: "TRUE" },
    { key: "enablePagibigDeduction", header: "enablePagibigDeduction", description: "TRUE or FALSE", example: "TRUE" },
    { key: "enableTaxWithholding", header: "enableTaxWithholding", description: "TRUE or FALSE", example: "FALSE" },
    { key: "allowAnywhereLogin", header: "allowAnywhereLogin", description: "TRUE or FALSE - bypass geofencing", example: "FALSE" },
  ],
};

export function generateEmployeeTemplate(): Buffer {
  // Create workbook
  const workbook = XLSX.utils.book_new();

  // Combine all columns
  const allColumns = [...TEMPLATE_COLUMNS.required, ...TEMPLATE_COLUMNS.optional];

  // Create headers row
  const headers = allColumns.map((col) => col.header);

  // Create example row
  const exampleRow = allColumns.map((col) => col.example);

  // Create the data sheet
  const dataSheet = XLSX.utils.aoa_to_sheet([headers, exampleRow]);

  // Set column widths
  const colWidths = allColumns.map((col) => ({
    wch: Math.max(col.header.length, col.example.length, 15),
  }));
  dataSheet["!cols"] = colWidths;

  // Add data sheet to workbook
  XLSX.utils.book_append_sheet(workbook, dataSheet, "Employees");

  // Create instructions sheet
  const instructionsData = [
    ["Employee Bulk Upload Template - Instructions"],
    [""],
    ["REQUIRED FIELDS (marked with *):"],
    ["These fields must have values for each row."],
    [""],
    ...TEMPLATE_COLUMNS.required.map((col) => [
      col.key,
      col.description,
      `Example: ${col.example}`,
    ]),
    [""],
    ["OPTIONAL FIELDS:"],
    ["These fields can be left empty."],
    [""],
    ...TEMPLATE_COLUMNS.optional.map((col) => [
      col.key,
      col.description,
      `Example: ${col.example}`,
    ]),
    [""],
    ["IMPORTANT NOTES:"],
    ["1. Do not modify the header row"],
    ["2. Delete the example row before uploading your data"],
    ["3. Dates must be in YYYY-MM-DD format"],
    ["4. Boolean values should be TRUE or FALSE"],
    ["5. Role must be exactly: ADMIN, HR, ENGINEER, or WORKER"],
    ["6. Status must be exactly: Active, Probationary, Suspended, Terminated, or Inactive"],
    ["7. Rate type must be exactly: daily or monthly"],
    ["8. Work days should be comma-separated: Mon,Tue,Wed,Thu,Fri"],
    ["9. Time should be in HH:MM format (24-hour)"],
  ];

  const instructionsSheet = XLSX.utils.aoa_to_sheet(instructionsData);
  instructionsSheet["!cols"] = [{ wch: 30 }, { wch: 50 }, { wch: 30 }];
  XLSX.utils.book_append_sheet(workbook, instructionsSheet, "Instructions");

  // Generate buffer
  const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
  return buffer;
}

export function getTemplateColumns(): string[] {
  return [
    ...TEMPLATE_COLUMNS.required.map((c) => c.key),
    ...TEMPLATE_COLUMNS.optional.map((c) => c.key),
  ];
}
