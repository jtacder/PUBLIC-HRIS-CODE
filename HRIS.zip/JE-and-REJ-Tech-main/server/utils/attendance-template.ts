import * as XLSX from "xlsx";

// Column definitions for the attendance import template
export const ATTENDANCE_TEMPLATE_COLUMNS = {
  // Required fields (marked with asterisk in header)
  required: [
    { key: "employeeIdentifier", header: "employeeNo or email*", description: "Employee number or email address to identify the employee", example: "EMP-001" },
    { key: "date", header: "date*", description: "Attendance date in YYYY-MM-DD format", example: "2024-01-15" },
    { key: "timeIn", header: "timeIn*", description: "Clock-in time in HH:MM format (24-hour)", example: "08:00" },
  ],
  // Optional fields
  optional: [
    { key: "timeOut", header: "timeOut", description: "Clock-out time in HH:MM format (24-hour)", example: "17:00" },
    { key: "projectName", header: "projectName", description: "Project name (must match existing project)", example: "Main Building" },
    { key: "notes", header: "notes", description: "Additional notes or remarks", example: "Manual entry for field work" },
    { key: "lunchPaid", header: "lunchPaid", description: "TRUE if lunch is paid (no deduction), FALSE otherwise", example: "FALSE" },
    { key: "verificationStatus", header: "verificationStatus", description: "Verified, Pending, Flagged, or Off-site", example: "Verified" },
  ],
};

export function generateAttendanceTemplate(): Buffer {
  // Create workbook
  const workbook = XLSX.utils.book_new();

  // Combine all columns
  const allColumns = [...ATTENDANCE_TEMPLATE_COLUMNS.required, ...ATTENDANCE_TEMPLATE_COLUMNS.optional];

  // Create headers row
  const headers = allColumns.map((col) => col.header);

  // Create example row
  const exampleRow = allColumns.map((col) => col.example);

  // Create the data sheet
  const dataSheet = XLSX.utils.aoa_to_sheet([headers, exampleRow]);

  // Set column widths
  const colWidths = allColumns.map((col) => ({
    wch: Math.max(col.header.length, col.example.length, 20),
  }));
  dataSheet["!cols"] = colWidths;

  // Add data sheet to workbook
  XLSX.utils.book_append_sheet(workbook, dataSheet, "Attendance");

  // Create instructions sheet
  const instructionsData = [
    ["Attendance Bulk Upload Template - Instructions"],
    [""],
    ["REQUIRED FIELDS (marked with *):"],
    ["These fields must have values for each row."],
    [""],
    ...ATTENDANCE_TEMPLATE_COLUMNS.required.map((col) => [
      col.key === "employeeIdentifier" ? "employeeNo or email" : col.key,
      col.description,
      `Example: ${col.example}`,
    ]),
    [""],
    ["OPTIONAL FIELDS:"],
    ["These fields can be left empty."],
    [""],
    ...ATTENDANCE_TEMPLATE_COLUMNS.optional.map((col) => [
      col.key,
      col.description,
      `Example: ${col.example}`,
    ]),
    [""],
    ["IMPORTANT NOTES:"],
    ["1. Do not modify the header row"],
    ["2. Delete the example row before uploading your data"],
    ["3. Use employee number OR email to identify the employee - the system will look up by employeeNo first, then email"],
    ["4. Date must be in YYYY-MM-DD format (e.g., 2024-01-15)"],
    ["5. Time must be in HH:MM 24-hour format (e.g., 08:00 for 8 AM, 17:00 for 5 PM)"],
    ["6. If timeOut is provided, it must be after timeIn"],
    ["7. Project name is optional - if provided, it must match an existing project exactly"],
    ["8. Duplicate entries (same employee + same date) will be flagged as errors"],
    ["9. The system will automatically calculate: late minutes, lunch deduction, overtime, and undertime"],
    ["10. Boolean values (lunchPaid) should be TRUE or FALSE"],
    ["11. verificationStatus must be one of: Verified, Pending, Flagged, Off-site"],
  ];

  const instructionsSheet = XLSX.utils.aoa_to_sheet(instructionsData);
  instructionsSheet["!cols"] = [{ wch: 25 }, { wch: 60 }, { wch: 30 }];
  XLSX.utils.book_append_sheet(workbook, instructionsSheet, "Instructions");

  // Generate buffer
  const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
  return buffer;
}

export function getAttendanceTemplateColumns(): string[] {
  return [
    ...ATTENDANCE_TEMPLATE_COLUMNS.required.map((c) => c.key),
    ...ATTENDANCE_TEMPLATE_COLUMNS.optional.map((c) => c.key),
  ];
}
