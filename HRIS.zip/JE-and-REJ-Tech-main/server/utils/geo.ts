/**
 * Calculate the distance between two geographic coordinates using the Haversine formula.
 * @param lat1 - Latitude of the first point in degrees
 * @param lng1 - Longitude of the first point in degrees
 * @param lat2 - Latitude of the second point in degrees
 * @param lng2 - Longitude of the second point in degrees
 * @returns Distance between the two points in meters
 */
export function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lng2 - lng1) * Math.PI / 180;

  const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
          Math.cos(φ1) * Math.cos(φ2) *
          Math.sin(Δλ/2) * Math.sin(Δλ/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

  return R * c; // Distance in meters
}

/**
 * Check if a user's location is within a specified radius of a site location.
 * Used for geo-fencing attendance validation.
 * @param userLat - User's current latitude
 * @param userLng - User's current longitude
 * @param siteLat - Site/project latitude
 * @param siteLng - Site/project longitude
 * @param radiusMeters - Allowed radius in meters
 * @returns True if user is within the radius, false otherwise
 */
export function isWithinRadius(
  userLat: number, 
  userLng: number, 
  siteLat: number, 
  siteLng: number, 
  radiusMeters: number
): boolean {
  const distance = calculateDistance(userLat, userLng, siteLat, siteLng);
  return distance <= radiusMeters;
}
