/**
 * Auto-seed permissions utility
 * Automatically seeds permissions, roles, and role-permission assignments
 * if the permissions table is empty.
 *
 * This ensures that new deployments automatically have the permission system
 * initialized without requiring manual intervention.
 */

import { db } from "../db";
import { permissions, roles, rolePermissions, employees } from "@shared/schema";
import { employeeCredentials } from "@shared/models/auth";
import { eq, sql } from "drizzle-orm";
import { logger } from "./logger";
import bcrypt from "bcrypt";

const SALT_ROUNDS = 12;
const SUPERADMIN_EMAIL = "owner@jerejtech.com";

// Default permissions organized by category and feature
const defaultPermissions = [
  // Operations
  { feature: "dashboard", action: "view_admin", code: "dashboard.view_admin", name: "View Admin Dashboard", description: "Access admin-level dashboard with system metrics", category: "Operations", sortOrder: 1 },
  { feature: "projects", action: "view", code: "projects.view", name: "View Projects", description: "Can view all projects list and details", category: "Operations", sortOrder: 10 },
  { feature: "projects", action: "create", code: "projects.create", name: "Create Projects", description: "Can create new projects", category: "Operations", sortOrder: 11 },
  { feature: "projects", action: "edit", code: "projects.edit", name: "Edit Projects", description: "Can modify project details", category: "Operations", sortOrder: 12 },
  { feature: "projects", action: "delete", code: "projects.delete", name: "Delete Projects", description: "Can delete projects", category: "Operations", sortOrder: 13 },
  { feature: "projects", action: "assign", code: "projects.assign_members", name: "Assign Project Members", description: "Can assign employees to projects", category: "Operations", sortOrder: 14 },
  { feature: "tasks", action: "view_all", code: "tasks.view_all", name: "View All Tasks", description: "Can view all tasks (not just assigned)", category: "Operations", sortOrder: 20 },
  { feature: "tasks", action: "create", code: "tasks.create", name: "Create Tasks", description: "Can create tasks for anyone", category: "Operations", sortOrder: 21 },
  { feature: "tasks", action: "edit_all", code: "tasks.edit_all", name: "Edit All Tasks", description: "Can edit any task", category: "Operations", sortOrder: 22 },
  { feature: "tasks", action: "delete", code: "tasks.delete", name: "Delete Tasks", description: "Can delete any task", category: "Operations", sortOrder: 23 },

  // Schedules
  { feature: "schedules", action: "view", code: "schedules.view", name: "View Schedule Management", description: "Can view employee schedules and project assignments calendar", category: "Operations", sortOrder: 30 },
  { feature: "schedules", action: "edit", code: "schedules.edit", name: "Edit Schedules & Assignments", description: "Can modify employee work schedules and project assignments", category: "Operations", sortOrder: 31 },

  // Human Resources
  { feature: "employees", action: "view", code: "employees.view", name: "View Employees", description: "Can view employee list and profiles", category: "Human Resources", sortOrder: 100 },
  { feature: "employees", action: "create", code: "employees.create", name: "Create Employees", description: "Can add new employees", category: "Human Resources", sortOrder: 101 },
  { feature: "employees", action: "edit", code: "employees.edit", name: "Edit Employees", description: "Can modify employee data", category: "Human Resources", sortOrder: 102 },
  { feature: "employees", action: "delete", code: "employees.delete", name: "Delete Employees", description: "Can deactivate/delete employees", category: "Human Resources", sortOrder: 103 },
  { feature: "employees", action: "bulk_upload", code: "employees.bulk_upload", name: "Bulk Upload Employees", description: "Can use bulk employee upload feature", category: "Human Resources", sortOrder: 104 },
  { feature: "employees", action: "reset_password", code: "employees.reset_password", name: "Reset Employee Password", description: "Can reset employee login passwords", category: "Human Resources", sortOrder: 105 },
  { feature: "documents", action: "view", code: "documents.view", name: "View 201 Files", description: "Can view employee documents", category: "Human Resources", sortOrder: 110 },
  { feature: "documents", action: "upload", code: "documents.upload", name: "Upload Documents", description: "Can upload employee documents", category: "Human Resources", sortOrder: 111 },
  { feature: "documents", action: "delete", code: "documents.delete", name: "Delete Documents", description: "Can delete employee documents", category: "Human Resources", sortOrder: 112 },
  { feature: "attendance", action: "view_all", code: "attendance.view_all", name: "View All Attendance", description: "Can view everyone's attendance records", category: "Human Resources", sortOrder: 120 },
  { feature: "attendance", action: "edit", code: "attendance.edit", name: "Edit Attendance", description: "Can modify attendance records", category: "Human Resources", sortOrder: 121 },
  { feature: "attendance", action: "approve_ot", code: "attendance.approve_ot", name: "Approve Overtime", description: "Can approve overtime requests", category: "Human Resources", sortOrder: 122 },
  { feature: "payroll", action: "view", code: "payroll.view", name: "View Payroll", description: "Can view payroll records", category: "Human Resources", sortOrder: 130 },
  { feature: "payroll", action: "process", code: "payroll.process", name: "Process Payroll", description: "Can compute/generate payroll", category: "Human Resources", sortOrder: 131 },
  { feature: "payroll", action: "edit", code: "payroll.edit", name: "Edit Payroll", description: "Can modify payroll entries", category: "Human Resources", sortOrder: 132 },
  { feature: "payroll", action: "approve", code: "payroll.approve", name: "Approve Payroll", description: "Can approve payroll batches", category: "Human Resources", sortOrder: 133 },
  { feature: "payroll", action: "release", code: "payroll.release", name: "Release Payroll", description: "Can release/finalize payroll", category: "Human Resources", sortOrder: 134 },
  { feature: "payslips", action: "view_all", code: "payslips.view_all", name: "View All Payslips", description: "Can view anyone's payslips", category: "Human Resources", sortOrder: 140 },
  { feature: "payslips", action: "generate", code: "payslips.generate", name: "Generate Payslips", description: "Can generate payslip documents", category: "Human Resources", sortOrder: 141 },
  { feature: "leave", action: "view_all", code: "leave.view_all", name: "View All Leave Requests", description: "Can view all leave requests", category: "Human Resources", sortOrder: 150 },
  { feature: "leave", action: "approve", code: "leave.approve", name: "Approve Leave Requests", description: "Can approve/reject leave requests", category: "Human Resources", sortOrder: 151 },
  { feature: "leave", action: "manage_types", code: "leave.manage_types", name: "Manage Leave Types", description: "Can create/edit leave types", category: "Human Resources", sortOrder: 152 },
  { feature: "leave", action: "manage_allocations", code: "leave.manage_allocations", name: "Manage Leave Allocations", description: "Can adjust employee leave balances", category: "Human Resources", sortOrder: 153 },
  { feature: "disciplinary", action: "view_all", code: "disciplinary.view_all", name: "View All Disciplinary Records", description: "Can view all disciplinary records", category: "Human Resources", sortOrder: 160 },
  { feature: "disciplinary", action: "issue", code: "disciplinary.issue", name: "Issue NTE", description: "Can issue notices to explain", category: "Human Resources", sortOrder: 161 },
  { feature: "disciplinary", action: "resolve", code: "disciplinary.resolve", name: "Resolve Disciplinary Cases", description: "Can resolve disciplinary cases with sanctions", category: "Human Resources", sortOrder: 162 },
  { feature: "hr_settings", action: "view", code: "hr_settings.view", name: "View HR Settings", description: "Can view company settings", category: "Human Resources", sortOrder: 170 },
  { feature: "hr_settings", action: "edit", code: "hr_settings.edit", name: "Edit HR Settings", description: "Can modify company settings", category: "Human Resources", sortOrder: 171 },
  { feature: "hr_settings", action: "manage_holidays", code: "hr_settings.manage_holidays", name: "Manage Holidays", description: "Can add/edit/delete holidays", category: "Human Resources", sortOrder: 172 },
  { feature: "hr_settings", action: "manage_cutoffs", code: "hr_settings.manage_cutoffs", name: "Manage Payroll Cutoffs", description: "Can configure payroll cutoff periods", category: "Human Resources", sortOrder: 173 },

  // Finance
  { feature: "expenses", action: "view_all", code: "expenses.view_all", name: "View All Expenses", description: "Can view all expense requests", category: "Finance", sortOrder: 200 },
  { feature: "expenses", action: "approve", code: "expenses.approve", name: "Approve Expenses", description: "Can approve/reject expense requests", category: "Finance", sortOrder: 201 },
  { feature: "expenses", action: "reimburse", code: "expenses.reimburse", name: "Process Reimbursement", description: "Can mark expenses as reimbursed", category: "Finance", sortOrder: 202 },
  { feature: "cash_advances", action: "view_all", code: "cash_advances.view_all", name: "View All Cash Advances", description: "Can view all cash advance requests", category: "Finance", sortOrder: 210 },
  { feature: "cash_advances", action: "approve", code: "cash_advances.approve", name: "Approve Cash Advances", description: "Can approve cash advance requests", category: "Finance", sortOrder: 211 },
  { feature: "cash_advances", action: "disburse", code: "cash_advances.disburse", name: "Disburse Cash Advances", description: "Can mark cash advances as disbursed", category: "Finance", sortOrder: 212 },

  // Administration
  { feature: "audit", action: "view", code: "audit.view", name: "View Audit Logs", description: "Can view system audit trail", category: "Administration", sortOrder: 300 },
  { feature: "audit", action: "export", code: "audit.export", name: "Export Audit Logs", description: "Can export audit data", category: "Administration", sortOrder: 301 },
  { feature: "devotionals", action: "view_all", code: "devotionals.view_all", name: "View All Devotional Progress", description: "Can view everyone's devotional progress", category: "Administration", sortOrder: 310 },
  { feature: "devotionals", action: "manage", code: "devotionals.manage", name: "Manage Devotionals", description: "Can create/edit devotional content", category: "Administration", sortOrder: 311 },
  { feature: "permissions", action: "view", code: "permissions.view", name: "View Permissions", description: "Can view role and permission settings", category: "Administration", sortOrder: 320 },
  { feature: "permissions", action: "manage", code: "permissions.manage", name: "Manage Permissions", description: "Can assign/revoke user permissions", category: "Administration", sortOrder: 321 },
  { feature: "permissions", action: "manage_roles", code: "permissions.manage_roles", name: "Manage Roles", description: "Can create/edit/delete roles (superadmin only)", category: "Administration", sortOrder: 322 },
] as const;

// Default roles
const defaultRoles = [
  {
    name: "SUPERADMIN",
    displayName: "Super Administrator",
    description: "Full system access with all permissions. Can manage other administrators and the permission system.",
    isSystemRole: true,
    isSuperadmin: true,
  },
  {
    name: "HR_ADMIN",
    displayName: "HR Administrator",
    description: "Default HR role with access to all HR-related features. Permissions can be customized per user.",
    isSystemRole: true,
    isSuperadmin: false,
  },
] as const;

// HR Admin default permissions
const hrAdminPermissionCodes = [
  "dashboard.view_admin",
  "projects.view",
  "tasks.view_all",
  "schedules.view",
  "schedules.edit",
  "employees.view",
  "employees.create",
  "employees.edit",
  "employees.bulk_upload",
  "employees.reset_password",
  "documents.view",
  "documents.upload",
  "documents.delete",
  "attendance.view_all",
  "attendance.edit",
  "attendance.approve_ot",
  "payroll.view",
  "payroll.process",
  "payroll.edit",
  "payroll.approve",
  "payroll.release",
  "payslips.view_all",
  "payslips.generate",
  "leave.view_all",
  "leave.approve",
  "leave.manage_types",
  "leave.manage_allocations",
  "disciplinary.view_all",
  "disciplinary.issue",
  "disciplinary.resolve",
  "hr_settings.view",
  "hr_settings.edit",
  "hr_settings.manage_holidays",
  "hr_settings.manage_cutoffs",
  "expenses.view_all",
  "expenses.approve",
  "expenses.reimburse",
  "cash_advances.view_all",
  "cash_advances.approve",
  "cash_advances.disburse",
  "audit.view",
  "devotionals.view_all",
  "devotionals.manage",
  "permissions.view",
];

/**
 * Checks if the permissions table needs seeding and seeds it if empty.
 * This function is safe to call on every server startup - it only seeds
 * if the permissions table is empty.
 */
export async function autoSeedPermissionsIfNeeded(): Promise<void> {
  try {
    // Check if permissions table has any records
    const [countResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(permissions);

    const permissionCount = Number(countResult?.count || 0);

    if (permissionCount > 0) {
      logger.info(`Permission system already initialized (${permissionCount} permissions found)`);
      // Always ensure roles exist and users are migrated (fixes production login issues)
      await ensureRolesExist();
      await migrateAdminUsersToSuperadminRole();
      // Ensure superadmin account exists with correct password
      await ensureSuperadminAccount();
      // Always verify and sync role permissions even if permissions exist
      await syncRolePermissionsIfMissing();
      return;
    }

    logger.info("Permissions table empty - auto-seeding permission system...");

    // 1. Seed permissions
    for (const perm of defaultPermissions) {
      await db.insert(permissions).values({
        feature: perm.feature,
        action: perm.action,
        code: perm.code,
        name: perm.name,
        description: perm.description,
        category: perm.category as any,
        sortOrder: perm.sortOrder,
        isActive: true,
      });
    }
    logger.info(`Created ${defaultPermissions.length} permissions`);

    // 2. Seed roles
    const createdRoles: Record<string, string> = {};
    for (const role of defaultRoles) {
      const [existing] = await db
        .select()
        .from(roles)
        .where(eq(roles.name, role.name))
        .limit(1);

      if (!existing) {
        const [created] = await db
          .insert(roles)
          .values({
            name: role.name,
            displayName: role.displayName,
            description: role.description,
            isSystemRole: role.isSystemRole,
            isSuperadmin: role.isSuperadmin,
          })
          .returning();
        createdRoles[role.name] = created.id;
      } else {
        createdRoles[role.name] = existing.id;
      }
    }
    logger.info(`Created/verified ${defaultRoles.length} roles`);

    // 3. Assign permissions to HR_ADMIN role
    const hrAdminRoleId = createdRoles["HR_ADMIN"];
    if (hrAdminRoleId) {
      const hrPermissions = await db
        .select({ id: permissions.id, code: permissions.code })
        .from(permissions)
        .where(eq(permissions.isActive, true));

      const hrPermissionIds = hrPermissions
        .filter((p) => hrAdminPermissionCodes.includes(p.code))
        .map((p) => p.id);

      // Clear existing and insert new role permissions
      await db.delete(rolePermissions).where(eq(rolePermissions.roleId, hrAdminRoleId));

      if (hrPermissionIds.length > 0) {
        await db.insert(rolePermissions).values(
          hrPermissionIds.map((permissionId) => ({
            roleId: hrAdminRoleId,
            permissionId,
          }))
        );
      }
      logger.info(`Assigned ${hrPermissionIds.length} permissions to HR_ADMIN role`);
    }

    // 4. Migrate existing ADMIN users to SUPERADMIN role
    const superadminRoleId = createdRoles["SUPERADMIN"];
    if (superadminRoleId) {
      const adminUsers = await db
        .select({ id: employees.id, firstName: employees.firstName, lastName: employees.lastName, roleId: employees.roleId })
        .from(employees)
        .where(eq(employees.role, "ADMIN"));

      for (const user of adminUsers) {
        if (!user.roleId) {
          await db
            .update(employees)
            .set({ roleId: superadminRoleId, updatedAt: new Date() })
            .where(eq(employees.id, user.id));
          logger.info(`Migrated ${user.firstName} ${user.lastName} to SUPERADMIN role`);
        }
      }
    }

    // 5. Migrate existing HR users to HR_ADMIN role
    if (hrAdminRoleId) {
      const hrUsers = await db
        .select({ id: employees.id, firstName: employees.firstName, lastName: employees.lastName, roleId: employees.roleId })
        .from(employees)
        .where(eq(employees.role, "HR"));

      for (const user of hrUsers) {
        if (!user.roleId) {
          await db
            .update(employees)
            .set({ roleId: hrAdminRoleId, updatedAt: new Date() })
            .where(eq(employees.id, user.id));
          logger.info(`Migrated ${user.firstName} ${user.lastName} to HR_ADMIN role`);
        }
      }
    }

    logger.info("Permission system auto-seeded successfully!");
  } catch (error) {
    logger.error("Failed to auto-seed permissions", error);
    // Don't throw - allow server to continue starting even if seeding fails
    // The manual seed script can be run as a fallback
  }
}

/**
 * Ensure required roles exist in the database
 * This fixes cases where permissions exist but roles table is missing entries
 */
async function ensureRolesExist(): Promise<void> {
  try {
    for (const role of defaultRoles) {
      const [existing] = await db
        .select()
        .from(roles)
        .where(eq(roles.name, role.name))
        .limit(1);

      if (!existing) {
        await db
          .insert(roles)
          .values({
            name: role.name,
            displayName: role.displayName,
            description: role.description,
            isSystemRole: role.isSystemRole,
            isSuperadmin: role.isSuperadmin,
          });
        logger.info(`Created missing role: ${role.name}`);
      } else if (role.name === "SUPERADMIN" && !existing.isSuperadmin) {
        // Ensure SUPERADMIN role has isSuperadmin flag set
        await db
          .update(roles)
          .set({ isSuperadmin: true, updatedAt: new Date() })
          .where(eq(roles.id, existing.id));
        logger.info(`Fixed SUPERADMIN role isSuperadmin flag`);
      }
    }
  } catch (error) {
    logger.error("Failed to ensure roles exist", error);
  }
}

/**
 * Migrate existing ADMIN users to SUPERADMIN role
 * This fixes cases where admin users exist but don't have roleId assigned
 */
async function migrateAdminUsersToSuperadminRole(): Promise<void> {
  try {
    // Get SUPERADMIN role ID
    const [superadminRole] = await db
      .select({ id: roles.id })
      .from(roles)
      .where(eq(roles.name, "SUPERADMIN"))
      .limit(1);

    if (!superadminRole) {
      logger.warn("Cannot migrate admin users - SUPERADMIN role not found");
      return;
    }

    // Find ADMIN users without roleId
    const adminUsers = await db
      .select({ id: employees.id, firstName: employees.firstName, lastName: employees.lastName, roleId: employees.roleId, email: employees.email })
      .from(employees)
      .where(eq(employees.role, "ADMIN"));

    for (const user of adminUsers) {
      if (!user.roleId) {
        await db
          .update(employees)
          .set({ roleId: superadminRole.id, updatedAt: new Date() })
          .where(eq(employees.id, user.id));
        logger.info(`Migrated admin user ${user.firstName} ${user.lastName} (${user.email}) to SUPERADMIN role`);
      }
    }
  } catch (error) {
    logger.error("Failed to migrate admin users", error);
  }
}

/**
 * Ensure superadmin account exists with correct credentials
 * This creates or updates the superadmin account using SUPERADMIN_PASSWORD env var
 */
async function ensureSuperadminAccount(): Promise<void> {
  const password = process.env.SUPERADMIN_PASSWORD;

  if (!password) {
    logger.warn("SUPERADMIN_PASSWORD not set - skipping superadmin account setup");
    return;
  }

  if (password.length < 8) {
    logger.warn("SUPERADMIN_PASSWORD too short (min 8 chars) - skipping superadmin account setup");
    return;
  }

  try {
    // Get SUPERADMIN role
    const [superadminRole] = await db
      .select({ id: roles.id })
      .from(roles)
      .where(eq(roles.name, "SUPERADMIN"))
      .limit(1);

    if (!superadminRole) {
      logger.warn("SUPERADMIN role not found - cannot create superadmin account");
      return;
    }

    // Check if superadmin employee exists
    let [adminEmployee] = await db
      .select()
      .from(employees)
      .where(eq(employees.email, SUPERADMIN_EMAIL))
      .limit(1);

    // If not found by email, try by role=ADMIN
    if (!adminEmployee) {
      [adminEmployee] = await db
        .select()
        .from(employees)
        .where(eq(employees.role, "ADMIN"))
        .limit(1);
    }

    let employeeId: string;

    if (adminEmployee) {
      // Update existing employee
      await db
        .update(employees)
        .set({
          email: SUPERADMIN_EMAIL,
          role: "ADMIN",
          roleId: superadminRole.id,
          updatedAt: new Date(),
        })
        .where(eq(employees.id, adminEmployee.id));
      employeeId = adminEmployee.id;
      logger.info(`Updated superadmin employee: ${adminEmployee.firstName} ${adminEmployee.lastName}`);
    } else {
      // Create new superadmin employee
      const [newEmployee] = await db
        .insert(employees)
        .values({
          employeeNo: "ADMIN-001",
          firstName: "System",
          lastName: "Administrator",
          email: SUPERADMIN_EMAIL,
          role: "ADMIN",
          roleId: superadminRole.id,
          department: "Administration",
          position: "System Administrator",
          status: "Active",
          startDate: new Date().toISOString().split("T")[0],
        })
        .returning();
      employeeId = newEmployee.id;
      logger.info(`Created superadmin employee: System Administrator`);
    }

    // Hash the password
    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

    // Check if credentials exist
    const [existingCreds] = await db
      .select()
      .from(employeeCredentials)
      .where(eq(employeeCredentials.employeeId, employeeId))
      .limit(1);

    if (existingCreds) {
      // Update credentials with new password hash
      await db
        .update(employeeCredentials)
        .set({
          email: SUPERADMIN_EMAIL,
          passwordHash: passwordHash,
          isActive: true,
          mustResetPassword: false,
          updatedAt: new Date(),
        })
        .where(eq(employeeCredentials.id, existingCreds.id));
      logger.info(`Updated superadmin credentials for ${SUPERADMIN_EMAIL}`);
    } else {
      // Create new credentials
      await db.insert(employeeCredentials).values({
        employeeId: employeeId,
        email: SUPERADMIN_EMAIL,
        passwordHash: passwordHash,
        isActive: true,
        mustResetPassword: false,
      });
      logger.info(`Created superadmin credentials for ${SUPERADMIN_EMAIL}`);
    }
  } catch (error) {
    logger.error("Failed to ensure superadmin account", error);
  }
}

/**
 * Ensure role permissions are properly synced
 * This fixes cases where roles exist but rolePermissions table is empty
 */
async function syncRolePermissionsIfMissing(): Promise<void> {
  try {
    // Get all roles
    const allRoles = await db.select().from(roles);

    for (const role of allRoles) {
      // Check if role has any permissions
      const [permCount] = await db
        .select({ count: sql<number>`count(*)` })
        .from(rolePermissions)
        .where(eq(rolePermissions.roleId, role.id));

      const count = Number(permCount?.count || 0);

      if (count === 0) {
        logger.warn(`Role "${role.displayName}" has NO permissions assigned - syncing...`);

        // Determine which permissions this role should have
        let permissionCodes: string[] = [];

        if (role.isSuperadmin || role.name === "SUPERADMIN") {
          // Superadmin gets all permissions
          const allPerms = await db
            .select({ id: permissions.id })
            .from(permissions)
            .where(eq(permissions.isActive, true));

          if (allPerms.length > 0) {
            await db.insert(rolePermissions).values(
              allPerms.map(p => ({ roleId: role.id, permissionId: p.id }))
            );
            logger.info(`Synced ${allPerms.length} permissions to SUPERADMIN role`);
          }
        } else if (role.name === "HR_ADMIN") {
          // HR Admin gets specific permissions
          permissionCodes = hrAdminPermissionCodes;
        }

        // Sync HR_ADMIN permissions if codes are set
        if (permissionCodes.length > 0) {
          const perms = await db
            .select({ id: permissions.id, code: permissions.code })
            .from(permissions)
            .where(eq(permissions.isActive, true));

          const permIds = perms
            .filter(p => permissionCodes.includes(p.code))
            .map(p => p.id);

          if (permIds.length > 0) {
            await db.insert(rolePermissions).values(
              permIds.map(permissionId => ({ roleId: role.id, permissionId }))
            );
            logger.info(`Synced ${permIds.length} permissions to ${role.displayName} role`);
          }
        }
      }
    }
  } catch (error) {
    logger.error("Failed to sync role permissions", error);
  }
}
