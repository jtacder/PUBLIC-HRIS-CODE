/**
 * Tests for DateTime Utilities
 *
 * Tests all date/time functions including:
 * - Philippine timezone handling
 * - Date string formatting
 * - Shift time calculations
 * - Working day calculations
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
  getPhilippineTime,
  getPhilippineDateString,
  getPhilippineDayName,
  extractDateString,
  formatTimestampAsPHT,
  formatAttendanceLogForClient,
  parseShiftTime,
  calculateShiftMinutes,
  isNightClockIn,
  getScheduledShiftDate,
  calculateWorkingDays,
} from './datetime';

// Mock the config module
vi.mock('../config', () => ({
  config: {
    timezone: {
      offset: 8, // Philippines UTC+8
    },
  },
}));

describe('DateTime Utilities', () => {
  describe('getPhilippineTime', () => {
    it('should return a Date object', () => {
      const result = getPhilippineTime();
      expect(result).toBeInstanceOf(Date);
    });

    it('should return time ahead of UTC by 8 hours', () => {
      const utcNow = new Date();
      const phtNow = getPhilippineTime();

      // PHT should be approximately 8 hours ahead of UTC
      const diffMs = phtNow.getTime() - utcNow.getTime();
      const diffHours = diffMs / (1000 * 60 * 60);

      expect(diffHours).toBeCloseTo(8, 0);
    });
  });

  describe('getPhilippineDateString', () => {
    it('should return date in YYYY-MM-DD format', () => {
      const result = getPhilippineDateString();
      expect(result).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    });

    it('should return a valid date string', () => {
      const result = getPhilippineDateString();
      const parsedDate = new Date(result);
      expect(parsedDate.getTime()).not.toBeNaN();
    });
  });

  describe('getPhilippineDayName', () => {
    it('should return a valid day abbreviation', () => {
      const validDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const result = getPhilippineDayName();
      expect(validDays).toContain(result);
    });
  });

  describe('extractDateString', () => {
    it('should extract date from ISO string', () => {
      const result = extractDateString('2025-01-15T10:30:00.000Z');
      expect(result).toBe('2025-01-15');
    });

    it('should extract date from date-only string', () => {
      const result = extractDateString('2025-01-15');
      expect(result).toBe('2025-01-15');
    });

    it('should extract date from Date object', () => {
      const date = new Date(2025, 0, 15); // January 15, 2025
      const result = extractDateString(date);
      expect(result).toBe('2025-01-15');
    });

    it('should handle date string with time', () => {
      const result = extractDateString('2025-06-30T23:59:59');
      expect(result).toBe('2025-06-30');
    });

    it('should pad single digit months and days', () => {
      const result = extractDateString('2025-1-5');
      expect(result).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    });

    it('should handle timestamp with timezone', () => {
      const result = extractDateString('2025-01-15T08:00:00+08:00');
      expect(result).toBe('2025-01-15');
    });

    it('should fallback for invalid input', () => {
      const result = extractDateString('invalid-date-string-12345');
      // The function may parse it differently or fall back to slice(0,10)
      // Just verify we get some result back that's 10 characters
      expect(result.length).toBeGreaterThanOrEqual(10);
    });
  });

  describe('formatTimestampAsPHT', () => {
    it('should return null for null input', () => {
      const result = formatTimestampAsPHT(null);
      expect(result).toBeNull();
    });

    it('should format Date object with PHT offset', () => {
      const utcDate = new Date('2025-01-15T00:00:00.000Z');
      const result = formatTimestampAsPHT(utcDate);

      expect(result).not.toBeNull();
      expect(result).toMatch(/\+08:00$/);
    });

    it('should handle string timestamp', () => {
      const result = formatTimestampAsPHT('2025-01-15 08:30:00');

      expect(result).not.toBeNull();
      expect(result).toMatch(/\+08:00$/);
      expect(result).toContain('2025-01-15');
    });

    it('should include correct time components', () => {
      const utcDate = new Date('2025-01-15T04:30:00.000Z'); // 12:30 PM PHT
      const result = formatTimestampAsPHT(utcDate);

      expect(result).toContain('12:30');
    });
  });

  describe('formatAttendanceLogForClient', () => {
    it('should format all timestamp fields', () => {
      const log = {
        id: 'log-001',
        timeIn: new Date('2025-01-15T00:00:00.000Z'),
        timeOut: new Date('2025-01-15T09:00:00.000Z'),
        createdAt: new Date('2025-01-15T00:00:00.000Z'),
        otApprovedAt: null,
        employeeId: 'emp-001',
      };

      const result = formatAttendanceLogForClient(log);

      expect(result.timeIn).toContain('+08:00');
      expect(result.timeOut).toContain('+08:00');
      expect(result.createdAt).toContain('+08:00');
      expect(result.otApprovedAt).toBeNull();
      expect(result.employeeId).toBe('emp-001');
    });

    it('should preserve non-timestamp fields', () => {
      const log = {
        id: 'log-001',
        employeeId: 'emp-001',
        projectId: 'proj-001',
        timeIn: new Date(),
        timeOut: null,
        createdAt: new Date(),
        otApprovedAt: null,
        notes: 'Test notes',
      };

      const result = formatAttendanceLogForClient(log);

      expect(result.id).toBe('log-001');
      expect(result.employeeId).toBe('emp-001');
      expect(result.projectId).toBe('proj-001');
      expect(result.notes).toBe('Test notes');
    });
  });

  describe('parseShiftTime', () => {
    it('should parse standard time format', () => {
      const result = parseShiftTime('08:00');
      expect(result).toEqual({ hours: 8, minutes: 0 });
    });

    it('should parse time with non-zero minutes', () => {
      const result = parseShiftTime('17:30');
      expect(result).toEqual({ hours: 17, minutes: 30 });
    });

    it('should parse midnight', () => {
      const result = parseShiftTime('00:00');
      expect(result).toEqual({ hours: 0, minutes: 0 });
    });

    it('should parse late night time', () => {
      const result = parseShiftTime('22:45');
      expect(result).toEqual({ hours: 22, minutes: 45 });
    });
  });

  describe('calculateShiftMinutes', () => {
    it('should calculate normal day shift (8 AM - 5 PM)', () => {
      const result = calculateShiftMinutes('08:00', '17:00');
      expect(result).toBe(540); // 9 hours = 540 minutes
    });

    it('should calculate short shift', () => {
      const result = calculateShiftMinutes('09:00', '13:00');
      expect(result).toBe(240); // 4 hours = 240 minutes
    });

    it('should handle overnight shift', () => {
      const result = calculateShiftMinutes('22:00', '06:00');
      expect(result).toBe(480); // 8 hours = 480 minutes
    });

    it('should handle shift starting at midnight', () => {
      const result = calculateShiftMinutes('00:00', '08:00');
      expect(result).toBe(480); // 8 hours = 480 minutes
    });

    it('should handle shift ending at midnight', () => {
      const result = calculateShiftMinutes('16:00', '00:00');
      expect(result).toBe(480); // 8 hours = 480 minutes
    });

    it('should handle 24-hour shift edge case', () => {
      const result = calculateShiftMinutes('08:00', '08:00');
      // When start equals end, could be 0 or 24 hours - implementation specific
      expect(result).toBe(0);
    });
  });

  describe('isNightClockIn', () => {
    it('should return true for 10 PM', () => {
      expect(isNightClockIn(22)).toBe(true);
    });

    it('should return true for 11 PM', () => {
      expect(isNightClockIn(23)).toBe(true);
    });

    it('should return true for midnight', () => {
      expect(isNightClockIn(0)).toBe(true);
    });

    it('should return true for 1 AM', () => {
      expect(isNightClockIn(1)).toBe(true);
    });

    it('should return true for 3 AM', () => {
      expect(isNightClockIn(3)).toBe(true);
    });

    it('should return false for 4 AM', () => {
      expect(isNightClockIn(4)).toBe(false);
    });

    it('should return false for 8 AM', () => {
      expect(isNightClockIn(8)).toBe(false);
    });

    it('should return false for 5 PM', () => {
      expect(isNightClockIn(17)).toBe(false);
    });

    it('should return false for 9 PM', () => {
      expect(isNightClockIn(21)).toBe(false);
    });
  });

  describe('getScheduledShiftDate', () => {
    it('should return same day for day shift', () => {
      const date = new Date('2025-01-15T10:00:00.000Z');
      const result = getScheduledShiftDate(date, false);
      expect(result).toBe('2025-01-15');
    });

    it('should return same day for night shift after midnight but before 6 AM', () => {
      const date = new Date('2025-01-15T03:00:00.000Z'); // 3 AM UTC
      const result = getScheduledShiftDate(date, true);
      // Should return previous day since this is an overnight shift
      expect(result).toBe('2025-01-14');
    });

    it('should return same day for night shift clock-in before midnight', () => {
      const date = new Date('2025-01-15T15:00:00.000Z'); // 11 PM PHT (next day)
      const result = getScheduledShiftDate(date, true);
      expect(result).toBe('2025-01-15');
    });

    it('should return same day for night shift after 6 AM', () => {
      const date = new Date('2025-01-15T07:00:00.000Z'); // 7 AM UTC
      const result = getScheduledShiftDate(date, true);
      expect(result).toBe('2025-01-15');
    });
  });

  describe('calculateWorkingDays', () => {
    it('should count weekdays in a full week', () => {
      const start = new Date('2025-01-13'); // Monday
      const end = new Date('2025-01-17'); // Friday
      const result = calculateWorkingDays(start, end);
      expect(result).toBe(5);
    });

    it('should exclude weekends', () => {
      const start = new Date('2025-01-13'); // Monday
      const end = new Date('2025-01-19'); // Sunday
      const result = calculateWorkingDays(start, end);
      expect(result).toBe(5); // Only Mon-Fri
    });

    it('should return 0 for weekend only period', () => {
      const start = new Date('2025-01-18'); // Saturday
      const end = new Date('2025-01-19'); // Sunday
      const result = calculateWorkingDays(start, end);
      expect(result).toBe(0);
    });

    it('should count single working day', () => {
      const start = new Date('2025-01-15'); // Wednesday
      const end = new Date('2025-01-15'); // Wednesday
      const result = calculateWorkingDays(start, end);
      expect(result).toBe(1);
    });

    it('should handle two weeks', () => {
      const start = new Date('2025-01-01'); // Wednesday
      const end = new Date('2025-01-15'); // Wednesday
      const result = calculateWorkingDays(start, end);
      expect(result).toBe(11); // 11 working days
    });

    it('should respect currentDate limit for partial periods', () => {
      const start = new Date('2025-01-13'); // Monday
      const end = new Date('2025-01-17'); // Friday
      const current = new Date('2025-01-15'); // Wednesday
      const result = calculateWorkingDays(start, end, current);
      expect(result).toBe(3); // Mon, Tue, Wed
    });

    it('should use endDate when currentDate is after endDate', () => {
      const start = new Date('2025-01-13'); // Monday
      const end = new Date('2025-01-15'); // Wednesday
      const current = new Date('2025-01-20'); // Monday next week
      const result = calculateWorkingDays(start, end, current);
      expect(result).toBe(3); // Mon, Tue, Wed
    });
  });
});

describe('Edge Cases and Boundary Conditions', () => {
  describe('Date handling across months', () => {
    it('should handle month boundary correctly', () => {
      const start = new Date('2025-01-30');
      const end = new Date('2025-02-03');
      const result = calculateWorkingDays(start, end);
      // Jan 30 (Thu), Jan 31 (Fri), Feb 3 (Mon)
      expect(result).toBe(3);
    });

    it('should handle year boundary correctly', () => {
      const start = new Date('2024-12-30');
      const end = new Date('2025-01-03');
      const result = calculateWorkingDays(start, end);
      // Dec 30 (Mon), Dec 31 (Tue), Jan 1 (Wed), Jan 2 (Thu), Jan 3 (Fri)
      expect(result).toBe(5);
    });
  });

  describe('February and leap year handling', () => {
    it('should handle February 28 in non-leap year', () => {
      const start = new Date('2025-02-28');
      const end = new Date('2025-02-28');
      const result = calculateWorkingDays(start, end);
      expect(result).toBe(1); // Feb 28, 2025 is Friday
    });

    it('should handle leap year February 29', () => {
      const start = new Date('2024-02-29');
      const end = new Date('2024-02-29');
      const result = calculateWorkingDays(start, end);
      expect(result).toBe(1); // Feb 29, 2024 is Thursday
    });
  });

  describe('extractDateString edge cases', () => {
    it('should handle Date object at midnight UTC', () => {
      const date = new Date('2025-06-15T00:00:00.000Z');
      const result = extractDateString(date);
      // Result depends on local timezone interpretation
      expect(result).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    });

    it('should handle Date object at end of day UTC', () => {
      const date = new Date('2025-06-15T23:59:59.999Z');
      const result = extractDateString(date);
      expect(result).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    });
  });
});
