export enum LogLevel {
  DEBUG = "DEBUG",
  INFO = "INFO",
  WARN = "WARN",
  ERROR = "ERROR",
}

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  context?: Record<string, unknown>;
  error?: {
    name: string;
    message: string;
    stack?: string;
  };
}

const LOG_COLORS = {
  [LogLevel.DEBUG]: "\x1b[36m",
  [LogLevel.INFO]: "\x1b[32m",
  [LogLevel.WARN]: "\x1b[33m",
  [LogLevel.ERROR]: "\x1b[31m",
  reset: "\x1b[0m",
};

function formatTimestamp(): string {
  const now = new Date();
  return now.toISOString();
}

function formatLocalTime(): string {
  return new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
}

function formatLogEntry(entry: LogEntry): string {
  const color = LOG_COLORS[entry.level];
  const reset = LOG_COLORS.reset;
  
  let output = `${formatLocalTime()} ${color}[${entry.level}]${reset} ${entry.message}`;
  
  if (entry.context && Object.keys(entry.context).length > 0) {
    output += ` ${JSON.stringify(entry.context)}`;
  }
  
  if (entry.error) {
    output += `\n  Error: ${entry.error.name}: ${entry.error.message}`;
    if (entry.error.stack && process.env.NODE_ENV !== "production") {
      output += `\n  Stack: ${entry.error.stack}`;
    }
  }
  
  return output;
}

function createLogEntry(
  level: LogLevel,
  message: string,
  context?: Record<string, unknown>,
  error?: Error
): LogEntry {
  const entry: LogEntry = {
    timestamp: formatTimestamp(),
    level,
    message,
    context,
  };
  
  if (error) {
    entry.error = {
      name: error.name,
      message: error.message,
      stack: error.stack,
    };
  }
  
  return entry;
}

export const logger = {
  debug(message: string, context?: Record<string, unknown>) {
    if (process.env.NODE_ENV === "production") return;
    const entry = createLogEntry(LogLevel.DEBUG, message, context);
    console.log(formatLogEntry(entry));
  },

  info(message: string, context?: Record<string, unknown>) {
    const entry = createLogEntry(LogLevel.INFO, message, context);
    console.log(formatLogEntry(entry));
  },

  warn(message: string, context?: Record<string, unknown>) {
    const entry = createLogEntry(LogLevel.WARN, message, context);
    console.warn(formatLogEntry(entry));
  },

  error(message: string, error?: Error | unknown, context?: Record<string, unknown>) {
    let err: Error | undefined;
    let additionalContext = context || {};
    
    if (error instanceof Error) {
      err = error;
    } else if (error !== undefined && error !== null) {
      additionalContext = {
        ...additionalContext,
        errorValue: typeof error === "object" ? JSON.stringify(error) : String(error),
        errorType: typeof error,
      };
    }
    
    const entry = createLogEntry(LogLevel.ERROR, message, additionalContext, err);
    console.error(formatLogEntry(entry));
  },

  http(method: string, path: string, statusCode: number, duration: number, body?: unknown) {
    const level = statusCode >= 500 ? LogLevel.ERROR : statusCode >= 400 ? LogLevel.WARN : LogLevel.INFO;
    const color = LOG_COLORS[level];
    const reset = LOG_COLORS.reset;
    
    let output = `${formatLocalTime()} ${color}[${method}]${reset} ${path} ${statusCode} in ${duration}ms`;
    
    if (body && process.env.NODE_ENV !== "production") {
      const safeBody = maskSensitiveFields(body);
      const bodyStr = JSON.stringify(safeBody);
      if (bodyStr.length < 500) {
        output += ` :: ${bodyStr}`;
      }
    }
    
    console.log(output);
  },
};

const SENSITIVE_FIELDS = [
  "password",
  "passwordHash",
  "token",
  "secret",
  "apiKey",
  "authorization",
  // HR/Payroll sensitive fields
  "ssn",
  "sss",
  "tin",
  "philhealth",
  "pagibig",
  "hdmf",
  "gsis",
  "bankAccount",
  "accountNumber",
  "salary",
  "basicSalary",
  "grossPay",
  "netPay"
];

function maskSensitiveFields(obj: unknown): unknown {
  if (typeof obj !== "object" || obj === null) {
    return obj;
  }
  
  if (Array.isArray(obj)) {
    return obj.map(maskSensitiveFields);
  }
  
  const masked: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj as Record<string, unknown>)) {
    if (SENSITIVE_FIELDS.some(field => key.toLowerCase().includes(field.toLowerCase()))) {
      masked[key] = "[REDACTED]";
    } else if (typeof value === "object" && value !== null) {
      masked[key] = maskSensitiveFields(value);
    } else {
      masked[key] = value;
    }
  }
  return masked;
}

export default logger;
