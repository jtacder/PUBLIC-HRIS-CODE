import { config } from "../config";

/**
 * Philippine timezone offset string for ISO date parsing.
 * Using this constant ensures consistent timezone handling across the codebase.
 */
export const PHT_OFFSET = "+08:00";

/**
 * Create a Date object from a date string and time string, interpreting them as Philippine Time (UTC+8).
 *
 * IMPORTANT: Always use this function when creating Date objects from user-provided date/time
 * values (e.g., from bulk uploads, form inputs). This prevents timezone misinterpretation
 * that occurs when using `new Date("YYYY-MM-DDTHH:MM:SS")` without a timezone suffix.
 *
 * Without timezone suffix, JavaScript interprets date strings as LOCAL server time,
 * which causes incorrect UTC storage if the server isn't in Philippine timezone.
 *
 * @param dateStr - Date string in YYYY-MM-DD format
 * @param timeStr - Time string in HH:MM format (24-hour)
 * @returns Date object with correct UTC value for the given PHT date/time
 *
 * @example
 * // User enters 08:00 AM Philippine time on Jan 15, 2024
 * const date = createPHTDate("2024-01-15", "08:00");
 * // Correctly stored as 2024-01-15T00:00:00Z (midnight UTC = 8AM PHT)
 */
export function createPHTDate(dateStr: string, timeStr: string): Date {
  // Append :00 for seconds and +08:00 for Philippine timezone
  return new Date(`${dateStr}T${timeStr}:00${PHT_OFFSET}`);
}

/**
 * Create a UTC ISO string from a date string and time string, interpreting them as Philippine Time.
 * This is the RECOMMENDED function for database inserts because it avoids pg driver timezone issues.
 *
 * The pg driver serializes Date objects using local time methods (getHours, etc.), which can cause
 * 8-hour shifts on non-UTC servers. By returning an ISO string with explicit 'Z' suffix, we ensure
 * PostgreSQL receives the correct UTC timestamp regardless of server timezone.
 *
 * @param dateStr - Date string in YYYY-MM-DD format
 * @param timeStr - Time string in HH:MM format (24-hour)
 * @returns ISO string in UTC (e.g., "2024-01-15T00:00:00.000Z" for 8AM PHT)
 */
export function createPHTDateAsUTCString(dateStr: string, timeStr: string): string {
  const date = new Date(`${dateStr}T${timeStr}:00${PHT_OFFSET}`);
  return date.toISOString();
}

/**
 * Create a Date object from a date string only, interpreting it as start of day in Philippine Time.
 * Useful for date-range queries where you need the start of a PHT day.
 *
 * @param dateStr - Date string in YYYY-MM-DD format
 * @returns Date object representing 00:00:00 PHT on the given date
 */
export function createPHTDateStart(dateStr: string): Date {
  return new Date(`${dateStr}T00:00:00${PHT_OFFSET}`);
}

/**
 * Create a Date object from a date string only, interpreting it as end of day in Philippine Time.
 * Useful for date-range queries where you need the end of a PHT day.
 *
 * @param dateStr - Date string in YYYY-MM-DD format
 * @returns Date object representing 23:59:59 PHT on the given date
 */
export function createPHTDateEnd(dateStr: string): Date {
  return new Date(`${dateStr}T23:59:59${PHT_OFFSET}`);
}

/**
 * Get the current date/time adjusted to Philippine timezone (UTC+8).
 * @returns Date object representing current Philippine time
 */
export function getPhilippineTime(): Date {
  const now = new Date();
  return new Date(now.getTime() + (config.timezone.offset * 60 * 60 * 1000));
}

/**
 * Get the current date as YYYY-MM-DD string in Philippine timezone.
 * @returns Date string in YYYY-MM-DD format
 */
export function getPhilippineDateString(): string {
  const pht = getPhilippineTime();
  const year = pht.getUTCFullYear();
  const month = String(pht.getUTCMonth() + 1).padStart(2, '0');
  const day = String(pht.getUTCDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Get the day of week name for Philippine timezone (abbreviated format).
 * Returns abbreviated day names to match employee shift schedule format.
 * @returns Day name abbreviation (Sun, Mon, Tue, Wed, Thu, Fri, Sat)
 */
export function getPhilippineDayName(): string {
  const pht = getPhilippineTime();
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  return dayNames[pht.getUTCDay()];
}

/**
 * Safely parse shiftWorkDays field which might be stored as JSON array or string.
 *
 * PostgreSQL JSONB columns may return data as parsed objects or strings depending
 * on the ORM configuration. This function handles both cases.
 *
 * @param shiftWorkDays - The shiftWorkDays value from employee record
 * @returns Array of work day names, or null if no valid schedule
 */
export function parseShiftWorkDays(shiftWorkDays: unknown): string[] | null {
  if (!shiftWorkDays) return null;

  // If it's already an array, return it if non-empty
  if (Array.isArray(shiftWorkDays)) {
    return shiftWorkDays.length > 0 ? shiftWorkDays : null;
  }

  // If it's a string, try to parse it as JSON
  if (typeof shiftWorkDays === 'string') {
    try {
      const parsed = JSON.parse(shiftWorkDays);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    } catch {
      // Not valid JSON, ignore
    }
  }

  return null;
}

/**
 * Extract date portion as YYYY-MM-DD string for date-only comparisons.
 * 
 * PostgreSQL DATE columns store date-only values without time/timezone.
 * When comparing leave dates with today's date, we need consistent 
 * date-only comparison without timezone conversion affecting the date.
 * 
 * This function:
 * - For strings: extracts the YYYY-MM-DD portion (works for ISO strings, date-only strings)
 * - For Date objects from DB DATE columns: uses local date components
 *   (DATE columns represent calendar dates, not instants in time)
 * 
 * @param date - Date object or string representing a calendar date
 * @returns Date string in YYYY-MM-DD format
 */
export function extractDateString(date: Date | string): string {
  if (typeof date === 'string') {
    const match = date.match(/^(\d{4}-\d{2}-\d{2})/);
    if (match) {
      return match[1];
    }
    const parsed = new Date(date);
    if (!isNaN(parsed.getTime())) {
      const year = parsed.getFullYear();
      const month = String(parsed.getMonth() + 1).padStart(2, '0');
      const day = String(parsed.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    }
  }
  
  if (date instanceof Date && !isNaN(date.getTime())) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  
  return String(date).slice(0, 10);
}

/**
 * Format a timestamp as an ISO string with Philippine timezone offset (+08:00).
 * This function converts UTC timestamps from the database to PHT for display.
 * @param timestamp - Date object or string to format
 * @returns ISO string with PHT offset, or null if input is null
 */
export function formatTimestampAsPHT(timestamp: Date | string | null): string | null {
  if (!timestamp) return null;

  let dateStr: string;

  if (timestamp instanceof Date) {
    // Convert UTC timestamp to PHT by adding 8 hours
    const phtTime = new Date(timestamp.getTime() + (config.timezone.offset * 60 * 60 * 1000));

    // Extract components using UTC methods on the shifted time
    const year = phtTime.getUTCFullYear();
    const month = String(phtTime.getUTCMonth() + 1).padStart(2, '0');
    const day = String(phtTime.getUTCDate()).padStart(2, '0');
    const hours = String(phtTime.getUTCHours()).padStart(2, '0');
    const minutes = String(phtTime.getUTCMinutes()).padStart(2, '0');
    const seconds = String(phtTime.getUTCSeconds()).padStart(2, '0');
    dateStr = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
  } else {
    dateStr = String(timestamp).replace(' ', 'T').slice(0, 19);
  }

  return dateStr + '+08:00';
}

/**
 * Format an attendance log record with Philippine timezone for client display.
 * @param log - Attendance log record from database
 * @returns Log with formatted timestamp fields
 */
export function formatAttendanceLogForClient(log: any) {
  return {
    ...log,
    timeIn: formatTimestampAsPHT(log.timeIn),
    timeOut: formatTimestampAsPHT(log.timeOut),
    createdAt: formatTimestampAsPHT(log.createdAt),
    otApprovedAt: formatTimestampAsPHT(log.otApprovedAt),
  };
}

/**
 * Parse a time string in HH:MM format into hours and minutes.
 * @param timeStr - Time string in "HH:MM" format
 * @returns Object with hours and minutes as numbers
 */
export function parseShiftTime(timeStr: string): { hours: number; minutes: number } {
  const [hours, minutes] = timeStr.split(':').map(Number);
  return { hours, minutes };
}

/**
 * Calculate the total minutes in a shift, handling overnight shifts.
 * @param startTime - Shift start time in "HH:MM" format
 * @param endTime - Shift end time in "HH:MM" format
 * @returns Total shift duration in minutes
 */
export function calculateShiftMinutes(startTime: string, endTime: string): number {
  const start = parseShiftTime(startTime);
  const end = parseShiftTime(endTime);
  
  let minutes = (end.hours * 60 + end.minutes) - (start.hours * 60 + start.minutes);
  
  if (minutes < 0) {
    minutes += 24 * 60;
  }
  
  return minutes;
}

/**
 * Check if a clock-in hour qualifies as a night shift clock-in.
 * Night shifts are between 10 PM and 4 AM.
 * @param hour - Hour of the day (0-23)
 * @returns True if the hour is during night shift hours
 */
export function isNightClockIn(hour: number): boolean {
  return hour >= 22 || hour < 4;
}

/**
 * Get the scheduled shift date, accounting for overnight shifts.
 * For night shifts clocked in after midnight, returns the previous day.
 * @param now - Current date/time
 * @param isNightShift - Whether this is a night shift
 * @returns Date string in YYYY-MM-DD format
 */
export function getScheduledShiftDate(now: Date, isNightShift: boolean): string {
  if (isNightShift && now.getUTCHours() < 6) {
    const yesterday = new Date(now);
    yesterday.setUTCDate(yesterday.getUTCDate() - 1);
    return yesterday.toISOString().split('T')[0];
  }
  return now.toISOString().split('T')[0];
}

/**
 * Calculate the number of working days (Mon-Fri) between two dates.
 * @param startDate - Start date of the period
 * @param endDate - End date of the period
 * @param currentDate - Optional current date to limit calculation (for partial periods)
 * @returns Number of working days (excluding weekends)
 */
export function calculateWorkingDays(startDate: Date, endDate: Date, currentDate?: Date): number {
  let workingDays = 0;
  const tempDate = new Date(startDate);
  const limitDate = currentDate && currentDate < endDate ? currentDate : endDate;

  while (tempDate <= limitDate) {
    const dayOfWeek = tempDate.getUTCDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) {
      workingDays++;
    }
    tempDate.setUTCDate(tempDate.getUTCDate() + 1);
  }

  return workingDays;
}
