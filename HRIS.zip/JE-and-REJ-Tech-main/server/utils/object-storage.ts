/**
 * Replit Object Storage utility for photo storage.
 * Replaces base64 database storage with cloud object storage.
 *
 * @see https://docs.replit.com/cloud-services/storage-and-databases/object-storage
 */
import { Client } from "@replit/object-storage";
import crypto from "crypto";

// Initialize the Replit Object Storage client
// No configuration needed - auto-authenticates on Replit
const client = new Client();

// Folder prefixes for different photo types
const FOLDERS = {
  attendance: "attendance-photos",
  profile: "profile-photos",
  task: "task-photos",
  receipt: "receipt-photos",
} as const;

type PhotoType = keyof typeof FOLDERS;

/**
 * Extract MIME type and extension from a data URI
 */
function getFileInfoFromDataUri(dataUri: string): { mimeType: string; extension: string } {
  const match = dataUri.match(/^data:([^;]+);base64,/);
  if (!match) {
    return { mimeType: "application/octet-stream", extension: "bin" };
  }

  const mimeType = match[1];
  const extensionMap: Record<string, string> = {
    "image/jpeg": "jpg",
    "image/jpg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "image/gif": "gif",
    "application/pdf": "pdf",
  };

  return {
    mimeType,
    extension: extensionMap[mimeType] || mimeType.split("/")[1] || "bin",
  };
}

/**
 * Generate a unique filename for a file
 * Format: {folder}/{employeeId}/{timestamp}-{random}.{extension}
 */
function generateFileKey(type: PhotoType, employeeId: string, extension: string = "jpg"): string {
  const timestamp = Date.now();
  const random = crypto.randomBytes(4).toString("hex");
  return `${FOLDERS[type]}/${employeeId}/${timestamp}-${random}.${extension}`;
}

/**
 * Generate a unique filename for a photo (backwards compatible)
 * Format: {folder}/{employeeId}/{timestamp}-{random}.jpg
 */
function generatePhotoKey(type: PhotoType, employeeId: string): string {
  return generateFileKey(type, employeeId, "jpg");
}

/**
 * Convert a base64 data URI to a Buffer
 * @param dataUri - Base64 encoded data URI (e.g., "data:image/jpeg;base64,..." or "data:application/pdf;base64,...")
 * @returns Buffer containing the binary data
 */
function dataUriToBuffer(dataUri: string): Buffer {
  // Remove the data URI prefix (e.g., "data:image/jpeg;base64," or "data:application/pdf;base64,")
  const base64Data = dataUri.replace(/^data:[^;]+;base64,/, "");
  return Buffer.from(base64Data, "base64");
}

/**
 * Upload a photo to Replit Object Storage
 * @param dataUri - Base64 encoded data URI from the frontend
 * @param type - Type of photo (attendance, profile, task, receipt)
 * @param employeeId - Employee ID for folder organization
 * @returns Object key (path) for the uploaded photo, or null on failure
 */
export async function uploadPhoto(
  dataUri: string,
  type: PhotoType,
  employeeId: string
): Promise<{ key: string; url: string } | null> {
  try {
    const key = generatePhotoKey(type, employeeId);
    const buffer = dataUriToBuffer(dataUri);

    const { ok, error } = await client.uploadFromBytes(key, buffer);

    if (!ok) {
      console.error(`Failed to upload ${type} photo:`, error);
      return null;
    }

    // Return the key and the API URL for serving the photo
    const url = `/api/photos/${encodeURIComponent(key)}`;
    return { key, url };
  } catch (err) {
    console.error(`Error uploading ${type} photo:`, err);
    return null;
  }
}

/**
 * Upload any file (image, PDF, etc.) to Replit Object Storage
 * @param dataUri - Base64 encoded data URI from the frontend
 * @param type - Type of file (attendance, profile, task, receipt)
 * @param entityId - ID for folder organization (employee ID or other entity)
 * @returns Object key (path) for the uploaded file, or null on failure
 */
export async function uploadFile(
  dataUri: string,
  type: PhotoType,
  entityId: string
): Promise<{ key: string; url: string; mimeType: string } | null> {
  try {
    const { extension, mimeType } = getFileInfoFromDataUri(dataUri);
    const key = generateFileKey(type, entityId, extension);
    const buffer = dataUriToBuffer(dataUri);

    const { ok, error } = await client.uploadFromBytes(key, buffer);

    if (!ok) {
      console.error(`Failed to upload ${type} file:`, error);
      return null;
    }

    // Return the key, API URL, and mime type
    const url = `/api/photos/${encodeURIComponent(key)}`;
    return { key, url, mimeType };
  } catch (err) {
    console.error(`Error uploading ${type} file:`, err);
    return null;
  }
}

/**
 * Get the display URL for a stored photo
 * Photos are served via the /api/photos endpoint which proxies to Object Storage
 * @param key - Object key/path in storage
 * @returns URL path for the photo
 */
export function getPhotoUrl(key: string): string {
  return `/api/photos/${encodeURIComponent(key)}`;
}

/**
 * Download a photo from Object Storage
 * @param key - Object key/path in storage
 * @returns Buffer containing the photo data, or null on failure
 */
export async function downloadPhoto(key: string): Promise<Buffer | null> {
  try {
    const result = await client.downloadAsBytes(key);

    if (!result.ok) {
      console.error(`Failed to download ${key}:`, result.error);
      return null;
    }

    // downloadAsBytes returns [Buffer] tuple, extract the buffer
    return result.value[0];
  } catch (err) {
    console.error(`Error downloading photo:`, err);
    return null;
  }
}

/**
 * Delete a photo from Object Storage
 * @param key - Object key/path in storage
 * @returns True if deleted successfully, false otherwise
 */
export async function deletePhoto(key: string): Promise<boolean> {
  try {
    const { ok, error } = await client.delete(key);

    if (!ok) {
      console.error(`Failed to delete ${key}:`, error);
      return false;
    }

    return true;
  } catch (err) {
    console.error(`Error deleting photo:`, err);
    return false;
  }
}

/**
 * List all photos for an employee
 * @param type - Type of photos to list
 * @param employeeId - Employee ID
 * @returns Array of object keys (names)
 */
export async function listEmployeePhotos(
  type: PhotoType,
  employeeId: string
): Promise<string[]> {
  try {
    const prefix = `${FOLDERS[type]}/${employeeId}/`;
    const result = await client.list({ prefix });

    if (!result.ok) {
      console.error(`Failed to list photos for ${employeeId}:`, result.error);
      return [];
    }

    return result.value.map((obj) => obj.name);
  } catch (err) {
    console.error(`Error listing photos:`, err);
    return [];
  }
}

/**
 * Check if a string is a base64 data URI (legacy format) or an object storage key
 * @param value - The photo URL/key to check
 * @returns True if it's a legacy base64 data URI
 */
export function isLegacyBase64(value: string | null | undefined): boolean {
  if (!value) return false;
  return value.startsWith("data:image/");
}

/**
 * Get the display URL for a photo, handling both legacy and new formats
 * @param value - Either a base64 data URI (legacy) or an object storage key
 * @returns URL that can be used in an <img> src
 */
export async function getDisplayUrl(value: string | null | undefined): Promise<string | null> {
  if (!value) return null;

  // Legacy base64 format - return as-is for backwards compatibility
  if (isLegacyBase64(value)) {
    return value;
  }

  // New format - get URL from object storage
  return getPhotoUrl(value);
}

export { FOLDERS, type PhotoType };
