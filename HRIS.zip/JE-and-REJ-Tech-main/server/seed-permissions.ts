/**
 * Seed script for Permission Role Management System
 * Run this script to initialize the permissions and roles tables
 *
 * Usage: npx tsx server/seed-permissions.ts
 */

import { db } from "./db";
import { permissions, roles, rolePermissions, employees } from "@shared/schema";
import { eq } from "drizzle-orm";

// Default permissions organized by category and feature
const defaultPermissions = [
  // ============================================
  // OPERATIONS
  // ============================================
  // Dashboard
  { feature: "dashboard", action: "view_admin", code: "dashboard.view_admin", name: "View Admin Dashboard", description: "Access admin-level dashboard with system metrics", category: "Operations", sortOrder: 1 },

  // Projects
  { feature: "projects", action: "view", code: "projects.view", name: "View Projects", description: "Can view all projects list and details", category: "Operations", sortOrder: 10 },
  { feature: "projects", action: "create", code: "projects.create", name: "Create Projects", description: "Can create new projects", category: "Operations", sortOrder: 11 },
  { feature: "projects", action: "edit", code: "projects.edit", name: "Edit Projects", description: "Can modify project details", category: "Operations", sortOrder: 12 },
  { feature: "projects", action: "delete", code: "projects.delete", name: "Delete Projects", description: "Can delete projects", category: "Operations", sortOrder: 13 },
  { feature: "projects", action: "assign", code: "projects.assign_members", name: "Assign Project Members", description: "Can assign employees to projects", category: "Operations", sortOrder: 14 },

  // Tasks
  { feature: "tasks", action: "view_all", code: "tasks.view_all", name: "View All Tasks", description: "Can view all tasks (not just assigned)", category: "Operations", sortOrder: 20 },
  { feature: "tasks", action: "create", code: "tasks.create", name: "Create Tasks", description: "Can create tasks for anyone", category: "Operations", sortOrder: 21 },
  { feature: "tasks", action: "edit_all", code: "tasks.edit_all", name: "Edit All Tasks", description: "Can edit any task", category: "Operations", sortOrder: 22 },
  { feature: "tasks", action: "delete", code: "tasks.delete", name: "Delete Tasks", description: "Can delete any task", category: "Operations", sortOrder: 23 },

  // Schedules
  { feature: "schedules", action: "view", code: "schedules.view", name: "View Schedule Management", description: "Can view employee schedules and project assignments calendar", category: "Operations", sortOrder: 30 },
  { feature: "schedules", action: "edit", code: "schedules.edit", name: "Edit Schedules & Assignments", description: "Can modify employee work schedules and project assignments", category: "Operations", sortOrder: 31 },

  // ============================================
  // HUMAN RESOURCES
  // ============================================
  // Employees
  { feature: "employees", action: "view", code: "employees.view", name: "View Employees", description: "Can view employee list and profiles", category: "Human Resources", sortOrder: 100 },
  { feature: "employees", action: "create", code: "employees.create", name: "Create Employees", description: "Can add new employees", category: "Human Resources", sortOrder: 101 },
  { feature: "employees", action: "edit", code: "employees.edit", name: "Edit Employees", description: "Can modify employee data", category: "Human Resources", sortOrder: 102 },
  { feature: "employees", action: "delete", code: "employees.delete", name: "Delete Employees", description: "Can deactivate/delete employees", category: "Human Resources", sortOrder: 103 },
  { feature: "employees", action: "bulk_upload", code: "employees.bulk_upload", name: "Bulk Upload Employees", description: "Can use bulk employee upload feature", category: "Human Resources", sortOrder: 104 },
  { feature: "employees", action: "reset_password", code: "employees.reset_password", name: "Reset Employee Password", description: "Can reset employee login passwords", category: "Human Resources", sortOrder: 105 },

  // 201 Files / Documents
  { feature: "documents", action: "view", code: "documents.view", name: "View 201 Files", description: "Can view employee documents", category: "Human Resources", sortOrder: 110 },
  { feature: "documents", action: "upload", code: "documents.upload", name: "Upload Documents", description: "Can upload employee documents", category: "Human Resources", sortOrder: 111 },
  { feature: "documents", action: "delete", code: "documents.delete", name: "Delete Documents", description: "Can delete employee documents", category: "Human Resources", sortOrder: 112 },

  // Attendance
  { feature: "attendance", action: "view_all", code: "attendance.view_all", name: "View All Attendance", description: "Can view everyone's attendance records", category: "Human Resources", sortOrder: 120 },
  { feature: "attendance", action: "edit", code: "attendance.edit", name: "Edit Attendance", description: "Can modify attendance records", category: "Human Resources", sortOrder: 121 },
  { feature: "attendance", action: "approve_ot", code: "attendance.approve_ot", name: "Approve Overtime", description: "Can approve overtime requests", category: "Human Resources", sortOrder: 122 },

  // Payroll
  { feature: "payroll", action: "view", code: "payroll.view", name: "View Payroll", description: "Can view payroll records", category: "Human Resources", sortOrder: 130 },
  { feature: "payroll", action: "process", code: "payroll.process", name: "Process Payroll", description: "Can compute/generate payroll", category: "Human Resources", sortOrder: 131 },
  { feature: "payroll", action: "edit", code: "payroll.edit", name: "Edit Payroll", description: "Can modify payroll entries", category: "Human Resources", sortOrder: 132 },
  { feature: "payroll", action: "approve", code: "payroll.approve", name: "Approve Payroll", description: "Can approve payroll batches", category: "Human Resources", sortOrder: 133 },
  { feature: "payroll", action: "release", code: "payroll.release", name: "Release Payroll", description: "Can release/finalize payroll", category: "Human Resources", sortOrder: 134 },

  // Payslips
  { feature: "payslips", action: "view_all", code: "payslips.view_all", name: "View All Payslips", description: "Can view anyone's payslips", category: "Human Resources", sortOrder: 140 },
  { feature: "payslips", action: "generate", code: "payslips.generate", name: "Generate Payslips", description: "Can generate payslip documents", category: "Human Resources", sortOrder: 141 },

  // Leave Management
  { feature: "leave", action: "view_all", code: "leave.view_all", name: "View All Leave Requests", description: "Can view all leave requests", category: "Human Resources", sortOrder: 150 },
  { feature: "leave", action: "approve", code: "leave.approve", name: "Approve Leave Requests", description: "Can approve/reject leave requests", category: "Human Resources", sortOrder: 151 },
  { feature: "leave", action: "manage_types", code: "leave.manage_types", name: "Manage Leave Types", description: "Can create/edit leave types", category: "Human Resources", sortOrder: 152 },
  { feature: "leave", action: "manage_allocations", code: "leave.manage_allocations", name: "Manage Leave Allocations", description: "Can adjust employee leave balances", category: "Human Resources", sortOrder: 153 },

  // Disciplinary
  { feature: "disciplinary", action: "view_all", code: "disciplinary.view_all", name: "View All Disciplinary Records", description: "Can view all disciplinary records", category: "Human Resources", sortOrder: 160 },
  { feature: "disciplinary", action: "issue", code: "disciplinary.issue", name: "Issue NTE", description: "Can issue notices to explain", category: "Human Resources", sortOrder: 161 },
  { feature: "disciplinary", action: "resolve", code: "disciplinary.resolve", name: "Resolve Disciplinary Cases", description: "Can resolve disciplinary cases with sanctions", category: "Human Resources", sortOrder: 162 },

  // HR Settings
  { feature: "hr_settings", action: "view", code: "hr_settings.view", name: "View HR Settings", description: "Can view company settings", category: "Human Resources", sortOrder: 170 },
  { feature: "hr_settings", action: "edit", code: "hr_settings.edit", name: "Edit HR Settings", description: "Can modify company settings", category: "Human Resources", sortOrder: 171 },
  { feature: "hr_settings", action: "manage_holidays", code: "hr_settings.manage_holidays", name: "Manage Holidays", description: "Can add/edit/delete holidays", category: "Human Resources", sortOrder: 172 },
  { feature: "hr_settings", action: "manage_cutoffs", code: "hr_settings.manage_cutoffs", name: "Manage Payroll Cutoffs", description: "Can configure payroll cutoff periods", category: "Human Resources", sortOrder: 173 },

  // ============================================
  // FINANCE
  // ============================================
  // Expenses
  { feature: "expenses", action: "view_all", code: "expenses.view_all", name: "View All Expenses", description: "Can view all expense requests", category: "Finance", sortOrder: 200 },
  { feature: "expenses", action: "approve", code: "expenses.approve", name: "Approve Expenses", description: "Can approve/reject expense requests", category: "Finance", sortOrder: 201 },
  { feature: "expenses", action: "reimburse", code: "expenses.reimburse", name: "Process Reimbursement", description: "Can mark expenses as reimbursed", category: "Finance", sortOrder: 202 },

  // Cash Advances
  { feature: "cash_advances", action: "view_all", code: "cash_advances.view_all", name: "View All Cash Advances", description: "Can view all cash advance requests", category: "Finance", sortOrder: 210 },
  { feature: "cash_advances", action: "approve", code: "cash_advances.approve", name: "Approve Cash Advances", description: "Can approve cash advance requests", category: "Finance", sortOrder: 211 },
  { feature: "cash_advances", action: "disburse", code: "cash_advances.disburse", name: "Disburse Cash Advances", description: "Can mark cash advances as disbursed", category: "Finance", sortOrder: 212 },

  // ============================================
  // ADMINISTRATION
  // ============================================
  // Audit Logs
  { feature: "audit", action: "view", code: "audit.view", name: "View Audit Logs", description: "Can view system audit trail", category: "Administration", sortOrder: 300 },
  { feature: "audit", action: "export", code: "audit.export", name: "Export Audit Logs", description: "Can export audit data", category: "Administration", sortOrder: 301 },

  // Devotionals
  { feature: "devotionals", action: "view_all", code: "devotionals.view_all", name: "View All Devotional Progress", description: "Can view everyone's devotional progress", category: "Administration", sortOrder: 310 },
  { feature: "devotionals", action: "manage", code: "devotionals.manage", name: "Manage Devotionals", description: "Can create/edit devotional content", category: "Administration", sortOrder: 311 },

  // Permissions (meta)
  { feature: "permissions", action: "view", code: "permissions.view", name: "View Permissions", description: "Can view role and permission settings", category: "Administration", sortOrder: 320 },
  { feature: "permissions", action: "manage", code: "permissions.manage", name: "Manage Permissions", description: "Can assign/revoke user permissions", category: "Administration", sortOrder: 321 },
  { feature: "permissions", action: "manage_roles", code: "permissions.manage_roles", name: "Manage Roles", description: "Can create/edit/delete roles (superadmin only)", category: "Administration", sortOrder: 322 },
] as const;

// Default roles
const defaultRoles = [
  {
    name: "SUPERADMIN",
    displayName: "Super Administrator",
    description: "Full system access with all permissions. Can manage other administrators and the permission system.",
    isSystemRole: true,
    isSuperadmin: true,
  },
  {
    name: "HR_ADMIN",
    displayName: "HR Administrator",
    description: "Default HR role with access to all HR-related features. Permissions can be customized per user.",
    isSystemRole: true,
    isSuperadmin: false,
  },
] as const;

// HR Admin default permissions (all HR-related permissions)
const hrAdminPermissionCodes = [
  "dashboard.view_admin",
  "projects.view",
  "tasks.view_all",
  "schedules.view",
  "schedules.edit",
  "employees.view",
  "employees.create",
  "employees.edit",
  "employees.bulk_upload",
  "employees.reset_password",
  "documents.view",
  "documents.upload",
  "documents.delete",
  "attendance.view_all",
  "attendance.edit",
  "attendance.approve_ot",
  "payroll.view",
  "payroll.process",
  "payroll.edit",
  "payroll.approve",
  "payroll.release",
  "payslips.view_all",
  "payslips.generate",
  "leave.view_all",
  "leave.approve",
  "leave.manage_types",
  "leave.manage_allocations",
  "disciplinary.view_all",
  "disciplinary.issue",
  "disciplinary.resolve",
  "hr_settings.view",
  "hr_settings.edit",
  "hr_settings.manage_holidays",
  "hr_settings.manage_cutoffs",
  "expenses.view_all",
  "expenses.approve",
  "expenses.reimburse",
  "cash_advances.view_all",
  "cash_advances.approve",
  "cash_advances.disburse",
  "audit.view",
  "devotionals.view_all",
  "devotionals.manage",
  "permissions.view",
];

async function seedPermissions() {
  console.log("🔐 Seeding Permission Role Management System...\n");

  try {
    // 1. Seed permissions
    console.log("📋 Creating permissions...");
    for (const perm of defaultPermissions) {
      const [existing] = await db
        .select()
        .from(permissions)
        .where(eq(permissions.code, perm.code))
        .limit(1);

      if (!existing) {
        await db.insert(permissions).values({
          feature: perm.feature,
          action: perm.action,
          code: perm.code,
          name: perm.name,
          description: perm.description,
          category: perm.category as any,
          sortOrder: perm.sortOrder,
          isActive: true,
        });
        console.log(`  ✓ Created permission: ${perm.code}`);
      } else {
        // Update existing permission details
        await db
          .update(permissions)
          .set({
            name: perm.name,
            description: perm.description,
            category: perm.category as any,
            sortOrder: perm.sortOrder,
          })
          .where(eq(permissions.id, existing.id));
        console.log(`  ↻ Updated permission: ${perm.code}`);
      }
    }

    // 2. Seed roles
    console.log("\n👥 Creating roles...");
    const createdRoles: Record<string, string> = {};

    for (const role of defaultRoles) {
      const [existing] = await db
        .select()
        .from(roles)
        .where(eq(roles.name, role.name))
        .limit(1);

      if (!existing) {
        const [created] = await db
          .insert(roles)
          .values({
            name: role.name,
            displayName: role.displayName,
            description: role.description,
            isSystemRole: role.isSystemRole,
            isSuperadmin: role.isSuperadmin,
          })
          .returning();
        createdRoles[role.name] = created.id;
        console.log(`  ✓ Created role: ${role.name}`);
      } else {
        createdRoles[role.name] = existing.id;
        console.log(`  ↻ Role exists: ${role.name}`);
      }
    }

    // 3. Assign permissions to HR_ADMIN role
    console.log("\n🔗 Assigning permissions to HR_ADMIN role...");
    const hrAdminRoleId = createdRoles["HR_ADMIN"];

    if (hrAdminRoleId) {
      // Get all permission IDs for HR Admin
      const hrPermissions = await db
        .select({ id: permissions.id, code: permissions.code })
        .from(permissions)
        .where(eq(permissions.isActive, true));

      const hrPermissionIds = hrPermissions
        .filter((p) => hrAdminPermissionCodes.includes(p.code))
        .map((p) => p.id);

      // Clear existing role permissions
      await db.delete(rolePermissions).where(eq(rolePermissions.roleId, hrAdminRoleId));

      // Insert new role permissions
      if (hrPermissionIds.length > 0) {
        await db.insert(rolePermissions).values(
          hrPermissionIds.map((permissionId) => ({
            roleId: hrAdminRoleId,
            permissionId,
          }))
        );
      }

      console.log(`  ✓ Assigned ${hrPermissionIds.length} permissions to HR_ADMIN`);
    }

    // 4. Migrate existing ADMIN users to SUPERADMIN role
    console.log("\n🔄 Migrating existing ADMIN users to SUPERADMIN role...");
    const superadminRoleId = createdRoles["SUPERADMIN"];

    if (superadminRoleId) {
      const adminUsers = await db
        .select({ id: employees.id, firstName: employees.firstName, lastName: employees.lastName })
        .from(employees)
        .where(eq(employees.role, "ADMIN"));

      for (const user of adminUsers) {
        // Only update if they don't already have a role assigned
        const [employee] = await db
          .select({ roleId: employees.roleId })
          .from(employees)
          .where(eq(employees.id, user.id))
          .limit(1);

        if (!employee?.roleId) {
          await db
            .update(employees)
            .set({ roleId: superadminRoleId, updatedAt: new Date() })
            .where(eq(employees.id, user.id));
          console.log(`  ✓ Migrated ${user.firstName} ${user.lastName} to SUPERADMIN`);
        } else {
          console.log(`  ↻ ${user.firstName} ${user.lastName} already has a role assigned`);
        }
      }
    }

    // 5. Migrate existing HR users to HR_ADMIN role
    console.log("\n🔄 Migrating existing HR users to HR_ADMIN role...");

    if (hrAdminRoleId) {
      const hrUsers = await db
        .select({ id: employees.id, firstName: employees.firstName, lastName: employees.lastName })
        .from(employees)
        .where(eq(employees.role, "HR"));

      for (const user of hrUsers) {
        const [employee] = await db
          .select({ roleId: employees.roleId })
          .from(employees)
          .where(eq(employees.id, user.id))
          .limit(1);

        if (!employee?.roleId) {
          await db
            .update(employees)
            .set({ roleId: hrAdminRoleId, updatedAt: new Date() })
            .where(eq(employees.id, user.id));
          console.log(`  ✓ Migrated ${user.firstName} ${user.lastName} to HR_ADMIN`);
        } else {
          console.log(`  ↻ ${user.firstName} ${user.lastName} already has a role assigned`);
        }
      }
    }

    console.log("\n✅ Permission Role Management System seeded successfully!");
    console.log("\n📊 Summary:");
    console.log(`  • Permissions: ${defaultPermissions.length}`);
    console.log(`  • Roles: ${defaultRoles.length}`);
    console.log(`  • HR Admin permissions: ${hrAdminPermissionCodes.length}`);

  } catch (error) {
    console.error("❌ Error seeding permissions:", error);
    throw error;
  }
}

// Run the seed function
seedPermissions()
  .then(() => {
    console.log("\n🎉 Done!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Failed to seed permissions:", error);
    process.exit(1);
  });
