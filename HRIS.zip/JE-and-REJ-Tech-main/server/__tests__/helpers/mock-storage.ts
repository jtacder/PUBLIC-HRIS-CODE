/**
 * Mock Storage Implementation
 *
 * A complete mock implementation of the IStorage interface for testing.
 * All methods return mocked data and track function calls.
 */

import { vi } from 'vitest';
import type { IStorage } from '../../storage';
import type {
  Employee, InsertEmployee,
  Project, InsertProject,
  ProjectAssignment, InsertProjectAssignment,
  Task, InsertTask,
  TaskComment, InsertTaskComment,
  AttendanceLog, InsertAttendanceLog,
  PayrollPeriod, InsertPayrollPeriod,
  PayrollRecord, InsertPayrollRecord,
  DisciplinaryAction, InsertDisciplinaryAction,
  Expense, InsertExpense,
  EmployeeDocument, InsertEmployeeDocument,
  AuditLog, InsertAuditLog,
  PayrollCutoff, InsertPayrollCutoff,
  LeaveTypeRecord, InsertLeaveType,
  LeaveRequest, InsertLeaveRequest,
  Holiday, InsertHoliday,
  CashAdvance, InsertCashAdvance,
  CashAdvancePayment, InsertCashAdvancePayment,
  CompanySetting, InsertCompanySetting,
  EmployeeLeaveAllocation, InsertEmployeeLeaveAllocation,
} from '@shared/schema';

export function createMockStorage(): IStorage & { _reset: () => void } {
  const mockStorage: IStorage & { _reset: () => void } = {
    // Employees
    getEmployees: vi.fn(),
    getEmployee: vi.fn(),
    getEmployeeByEmail: vi.fn(),
    getEmployeeByQRToken: vi.fn(),
    createEmployee: vi.fn(),
    updateEmployee: vi.fn(),
    deleteEmployee: vi.fn(),

    // Projects
    getProjects: vi.fn(),
    getProject: vi.fn(),
    createProject: vi.fn(),
    updateProject: vi.fn(),
    deleteProject: vi.fn(),

    // Project Assignments
    getProjectAssignments: vi.fn(),
    getEmployeeAssignments: vi.fn(),
    createProjectAssignment: vi.fn(),
    deleteProjectAssignment: vi.fn(),

    // Tasks
    getTasks: vi.fn(),
    getTask: vi.fn(),
    getEmployeeTasks: vi.fn(),
    createTask: vi.fn(),
    updateTask: vi.fn(),
    deleteTask: vi.fn(),

    // Task Comments
    getTaskComments: vi.fn(),
    createTaskComment: vi.fn(),

    // Project Comments
    getProjectComments: vi.fn(),
    createProjectComment: vi.fn(),
    deleteProjectComment: vi.fn(),
    getProjectStats: vi.fn(),
    isEmployeeAssignedToProject: vi.fn(),

    // Employee visibility
    getVisibleEmployees: vi.fn(),
    getHiddenEmployees: vi.fn(),

    // Attendance
    getAttendanceLogs: vi.fn(),
    getAttendanceLog: vi.fn(),
    getTodayAttendance: vi.fn(),
    getEmployeeAttendance: vi.fn(),
    createAttendanceLog: vi.fn(),
    updateAttendanceLog: vi.fn(),
    deleteAttendanceLog: vi.fn(),

    // Payroll Periods
    getPayrollPeriods: vi.fn(),
    getPayrollPeriod: vi.fn(),
    createPayrollPeriod: vi.fn(),
    updatePayrollPeriod: vi.fn(),
    deletePayrollPeriod: vi.fn(),

    // Payroll Records
    getPayrollRecords: vi.fn(),
    getPayrollRecordsByPeriod: vi.fn(),
    getExistingPayrollCutoffs: vi.fn(),
    getPayrollRecord: vi.fn(),
    getEmployeePayroll: vi.fn(),
    createPayrollRecord: vi.fn(),
    updatePayrollRecord: vi.fn(),
    deletePayrollRecordsForCutoff: vi.fn(),
    getPayrollRecordsForCutoff: vi.fn(),
    deletePayrollRecordsByPeriod: vi.fn(),

    // Disciplinary Actions
    getDisciplinaryActions: vi.fn(),
    getDisciplinaryAction: vi.fn(),
    createDisciplinaryAction: vi.fn(),
    updateDisciplinaryAction: vi.fn(),

    // Expenses
    getExpenses: vi.fn(),
    getExpense: vi.fn(),
    createExpense: vi.fn(),
    updateExpense: vi.fn(),

    // Employee Documents
    getEmployeeDocument: vi.fn(),
    getEmployeeDocuments: vi.fn(),
    createEmployeeDocument: vi.fn(),
    deleteEmployeeDocument: vi.fn(),

    // Audit Logs
    createAuditLog: vi.fn(),
    getAuditLogs: vi.fn(),

    // HR Settings - Payroll Cutoffs
    getPayrollCutoffs: vi.fn(),
    createPayrollCutoff: vi.fn(),
    updatePayrollCutoff: vi.fn(),
    deletePayrollCutoff: vi.fn(),

    // HR Settings - Leave Types
    getLeaveTypes: vi.fn(),
    createLeaveType: vi.fn(),
    updateLeaveType: vi.fn(),
    deleteLeaveType: vi.fn(),

    // HR Settings - Leave Requests
    getLeaveRequests: vi.fn(),
    getLeaveRequest: vi.fn(),
    createLeaveRequest: vi.fn(),
    updateLeaveRequest: vi.fn(),

    // HR Settings - Holidays
    getHolidays: vi.fn(),
    createHoliday: vi.fn(),
    updateHoliday: vi.fn(),
    deleteHoliday: vi.fn(),

    // Cash Advances
    getCashAdvances: vi.fn(),
    getCashAdvance: vi.fn(),
    createCashAdvance: vi.fn(),
    updateCashAdvance: vi.fn(),

    // Cash Advance Payments
    getCashAdvancePayments: vi.fn(),
    getCashAdvancePaymentsByPayrollRecord: vi.fn(),
    createCashAdvancePayment: vi.fn(),
    deleteCashAdvancePaymentsByPayrollRecord: vi.fn(),

    // Company Settings
    getCompanySettings: vi.fn(),
    getCompanySetting: vi.fn(),
    upsertCompanySetting: vi.fn(),

    // Employee Leave Allocations
    getEmployeeLeaveAllocations: vi.fn(),
    createEmployeeLeaveAllocation: vi.fn(),
    updateEmployeeLeaveAllocation: vi.fn(),
    deleteEmployeeLeaveAllocation: vi.fn(),

    // Reset all mocks
    _reset: function() {
      Object.keys(this).forEach(key => {
        if (typeof (this as any)[key]?.mockReset === 'function') {
          (this as any)[key].mockReset();
        }
      });
    },
  };

  return mockStorage;
}

/**
 * Sets up mock storage with default responses
 */
export function setupMockStorageDefaults(mockStorage: ReturnType<typeof createMockStorage>) {
  // Default empty arrays for list operations
  vi.mocked(mockStorage.getEmployees).mockResolvedValue([]);
  vi.mocked(mockStorage.getProjects).mockResolvedValue([]);
  vi.mocked(mockStorage.getTasks).mockResolvedValue([]);
  vi.mocked(mockStorage.getAttendanceLogs).mockResolvedValue([]);
  vi.mocked(mockStorage.getPayrollPeriods).mockResolvedValue([]);
  vi.mocked(mockStorage.getPayrollRecords).mockResolvedValue([]);
  vi.mocked(mockStorage.getDisciplinaryActions).mockResolvedValue([]);
  vi.mocked(mockStorage.getExpenses).mockResolvedValue([]);
  vi.mocked(mockStorage.getLeaveTypes).mockResolvedValue([]);
  vi.mocked(mockStorage.getLeaveRequests).mockResolvedValue([]);
  vi.mocked(mockStorage.getHolidays).mockResolvedValue([]);
  vi.mocked(mockStorage.getCashAdvances).mockResolvedValue([]);
  vi.mocked(mockStorage.getAuditLogs).mockResolvedValue([]);
  vi.mocked(mockStorage.getCompanySettings).mockResolvedValue([]);
  vi.mocked(mockStorage.getEmployeeLeaveAllocations).mockResolvedValue([]);

  // Default undefined for single item operations
  vi.mocked(mockStorage.getEmployee).mockResolvedValue(undefined);
  vi.mocked(mockStorage.getProject).mockResolvedValue(undefined);
  vi.mocked(mockStorage.getTask).mockResolvedValue(undefined);
  vi.mocked(mockStorage.getAttendanceLog).mockResolvedValue(undefined);
  vi.mocked(mockStorage.getPayrollPeriod).mockResolvedValue(undefined);
  vi.mocked(mockStorage.getPayrollRecord).mockResolvedValue(undefined);
  vi.mocked(mockStorage.getDisciplinaryAction).mockResolvedValue(undefined);
  vi.mocked(mockStorage.getExpense).mockResolvedValue(undefined);
  vi.mocked(mockStorage.getLeaveRequest).mockResolvedValue(undefined);
  vi.mocked(mockStorage.getCashAdvance).mockResolvedValue(undefined);
  vi.mocked(mockStorage.getCompanySetting).mockResolvedValue(undefined);

  // Default void for delete operations
  vi.mocked(mockStorage.deleteEmployee).mockResolvedValue();
  vi.mocked(mockStorage.deleteProject).mockResolvedValue();
  vi.mocked(mockStorage.deleteTask).mockResolvedValue();
  vi.mocked(mockStorage.deleteAttendanceLog).mockResolvedValue();
  vi.mocked(mockStorage.deletePayrollPeriod).mockResolvedValue();
  vi.mocked(mockStorage.deletePayrollRecordsForCutoff).mockResolvedValue();
  vi.mocked(mockStorage.deleteEmployeeDocument).mockResolvedValue();
  vi.mocked(mockStorage.deletePayrollCutoff).mockResolvedValue();
  vi.mocked(mockStorage.deleteLeaveType).mockResolvedValue();
  vi.mocked(mockStorage.deleteHoliday).mockResolvedValue();
  vi.mocked(mockStorage.deleteEmployeeLeaveAllocation).mockResolvedValue();
}
