/**
 * Test Helpers and Utilities
 *
 * Provides common utilities for testing the ERP system.
 * Includes mock factories, test data generators, and helper functions.
 */

import { vi } from 'vitest';
import type { Employee, Project, AttendanceLog, PayrollRecord, Task, LeaveRequest, CashAdvance, DisciplinaryAction, Expense } from '@shared/schema';

// ==================== MOCK FACTORIES ====================

/**
 * Creates a mock employee with default values
 */
export function createMockEmployee(overrides: Partial<Employee> = {}): Employee {
  return {
    id: 'emp-001',
    firstName: 'Juan',
    lastName: 'Dela Cruz',
    middleName: null,
    email: 'juan@company.com',
    phone: '09171234567',
    address: '123 Main St, Manila',
    birthDate: '1990-01-15',
    gender: 'Male',
    civilStatus: 'Single',
    nationality: 'Filipino',
    profilePhotoUrl: null,
    emergencyContactName: 'Maria Dela Cruz',
    emergencyContactPhone: '09181234567',
    emergencyContactRelation: 'Mother',
    role: 'WORKER',
    position: 'Electrician',
    department: 'Operations',
    employeeNo: 'EMP-001',
    rateType: 'daily',
    baseRate: '700',
    sssNo: '12-3456789-0',
    tinNo: '123-456-789-000',
    philhealthNo: '12-345678901-2',
    pagibigNo: '1234-5678-9012',
    bankName: 'BDO',
    bankAccountNo: '1234567890',
    status: 'Active',
    startDate: '2023-01-15',
    endDate: null,
    regularizationDate: '2023-07-15',
    shiftStartTime: '08:00',
    shiftEndTime: '17:00',
    shiftWorkDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    qrToken: 'abc123token',
    enableSSSDeduction: true,
    enablePhilhealthDeduction: true,
    enablePagibigDeduction: true,
    enableTaxWithholding: false,
    colaAllowance: '0',
    userId: null,
    createdAt: new Date('2023-01-15'),
    updatedAt: new Date('2023-01-15'),
    deletedAt: null,
    ...overrides,
  };
}

/**
 * Creates a mock admin employee
 */
export function createMockAdmin(overrides: Partial<Employee> = {}): Employee {
  return createMockEmployee({
    id: 'admin-001',
    firstName: 'Admin',
    lastName: 'User',
    email: 'admin@company.com',
    employeeNo: 'ADMIN-001',
    role: 'ADMIN',
    position: 'System Administrator',
    department: 'IT',
    ...overrides,
  });
}

/**
 * Creates a mock HR employee
 */
export function createMockHR(overrides: Partial<Employee> = {}): Employee {
  return createMockEmployee({
    id: 'hr-001',
    firstName: 'HR',
    lastName: 'Manager',
    email: 'hr@company.com',
    employeeNo: 'HR-001',
    role: 'HR',
    position: 'HR Manager',
    department: 'Human Resources',
    ...overrides,
  });
}

/**
 * Creates a mock project with default values
 */
export function createMockProject(overrides: Partial<Project> = {}): Project {
  return {
    id: 'proj-001',
    name: 'Building A Electrical Installation',
    code: 'PROJ-001',
    description: 'Complete electrical installation for Building A',
    client: 'ABC Construction',
    isOffice: false,
    locationName: 'Building A Site',
    locationAddress: '456 Project St, Makati',
    locationLat: '14.5547',
    locationLng: '121.0244',
    geoRadius: 100,
    startDate: '2025-01-01',
    deadline: '2025-06-30',
    completedDate: null,
    budget: '1000000',
    actualCost: '0',
    allocatedHours: '5000',
    mealAllowance: '0',
    status: 'Active',
    projectManagerId: 'eng-001',
    createdAt: new Date('2025-01-01'),
    updatedAt: new Date('2025-01-01'),
    deletedAt: null,
    ...overrides,
  };
}

/**
 * Creates a mock attendance log
 */
export function createMockAttendanceLog(overrides: Partial<AttendanceLog> = {}): AttendanceLog {
  return {
    id: 'att-001',
    employeeId: 'emp-001',
    projectId: 'proj-001',
    timeIn: new Date('2025-01-15T08:00:00'),
    timeOut: new Date('2025-01-15T17:00:00'),
    totalHours: '8',
    scheduledShiftStart: '08:00',
    scheduledShiftEnd: '17:00',
    scheduledShiftStartOverride: null,
    scheduledShiftEndOverride: null,
    scheduledShiftDate: '2025-01-15',
    actualShiftType: 'day',
    regularMinutes: 480,
    overtimeMinutes: 0,
    locationLat: '14.5547',
    locationLng: '121.0244',
    locationSource: 'GPS',
    locationAccuracy: '15.0',
    distanceFromSite: '25.5',
    photoSnapshotUrl: 'https://storage.com/photo.jpg',
    faceVerified: true,
    verificationStatus: 'Verified',
    isLate: false,
    lateMinutes: 0,
    lateDeductible: false,
    undertimeMinutes: 0,
    lunchDeductionMinutes: 60,
    lunchPaid: false,
    overtimeHours: '0',
    overtimeType: null,
    overtimeApproved: false,
    otStatus: null,
    otMinutesApproved: 0,
    otApprovedById: null,
    otApprovedAt: null,
    otReason: null,
    isOvertimeSession: false,
    parentAttendanceId: null,
    justification: null,
    notes: null,
    createdAt: new Date('2025-01-15T08:00:00'),
    ...overrides,
  };
}

/**
 * Creates a mock payroll record
 */
export function createMockPayrollRecord(overrides: Partial<PayrollRecord> = {}): PayrollRecord {
  return {
    id: 'pay-001',
    employeeId: 'emp-001',
    periodId: null,
    cutoffStart: '2025-01-01',
    cutoffEnd: '2025-01-15',
    payDate: '2025-01-20',
    daysWorked: '11',
    hoursWorked: '88',
    regularOTMinutes: 0,
    restDayOTMinutes: 0,
    holidayOTMinutes: 0,
    regularOTHours: '0',
    restDayOTHours: '0',
    holidayOTHours: '0',
    totalLateMinutes: 0,
    totalUndertimeMinutes: 0,
    basicPay: '7700',
    regularOTPay: '0',
    restDayOTPay: '0',
    holidayOTPay: '0',
    allowances: '0',
    bonusAmount: '0',
    bonusNotes: null,
    colaAllowance: '0',
    grossPay: '7700',
    mealAllowanceTotal: '0',
    sssDeduction: '315',
    philhealthDeduction: '192.50',
    pagibigDeduction: '50',
    taxDeduction: '0',
    lateDeduction: '0',
    undertimeDeduction: '0',
    otherDeductionAmount: '0',
    otherDeductionNotes: null,
    otherDeductions: [],
    cashAdvanceDeduction: '0',
    unpaidLeaveDays: '0',
    unpaidLeaveDeduction: '0',
    paidLeaveDays: '0',
    totalDeductions: '557.50',
    netPay: '7142.50',
    isEdited: false,
    overrideNetPay: null,
    editNotes: null,
    payslipStatus: 'Draft',
    status: 'Draft',
    processedBy: null,
    processedAt: null,
    approvedBy: null,
    approvedAt: null,
    releasedAt: null,
    pdfUrl: null,
    createdAt: new Date('2025-01-16'),
    updatedAt: new Date('2025-01-16'),
    deletedAt: null,
    ...overrides,
  };
}

/**
 * Creates a mock task
 */
export function createMockTask(overrides: Partial<Task> = {}): Task {
  return {
    id: 'task-001',
    projectId: 'proj-001',
    title: 'Install electrical panels',
    description: 'Install main electrical panels on floor 1',
    poNumber: null,
    assignedToId: 'emp-001',
    createdById: 'eng-001',
    status: 'Todo',
    priority: 'Medium',
    dueDate: '2025-02-15',
    completedDate: null,
    estimatedHours: '8',
    actualHours: null,
    completionPhotoUrl: null,
    completionNotes: null,
    sortOrder: 0,
    createdAt: new Date('2025-01-15'),
    updatedAt: new Date('2025-01-15'),
    ...overrides,
  };
}

/**
 * Creates a mock leave request
 */
export function createMockLeaveRequest(overrides: Partial<LeaveRequest> = {}): LeaveRequest {
  return {
    id: 'leave-001',
    employeeId: 'emp-001',
    leaveTypeId: 'ltype-001',
    startDate: '2025-02-01',
    endDate: '2025-02-03',
    totalDays: '3',
    reason: 'Family vacation',
    status: 'Pending',
    approvedById: null,
    approvedAt: null,
    remarks: null,
    createdAt: new Date('2025-01-20'),
    deletedAt: null,
    ...overrides,
  };
}

/**
 * Creates a mock cash advance
 */
export function createMockCashAdvance(overrides: Partial<CashAdvance> = {}): CashAdvance {
  return {
    id: 'ca-001',
    employeeId: 'emp-001',
    amount: '5000',
    reason: 'Emergency medical expenses',
    status: 'Pending',
    approvedById: null,
    approvedAt: null,
    disbursedAt: null,
    deductionPerCutoff: null,
    remainingBalance: null,
    createdAt: new Date('2025-01-15'),
    ...overrides,
  };
}

/**
 * Creates a mock disciplinary action
 */
export function createMockDisciplinaryAction(overrides: Partial<DisciplinaryAction> = {}): DisciplinaryAction {
  return {
    id: 'disc-001',
    employeeId: 'emp-001',
    issuerId: 'hr-001',
    violationType: 'Tardiness',
    incidentDate: '2025-01-10',
    description: 'Employee was 3 hours late without prior notice',
    attachmentUrl: null,
    nteIssuedDate: '2025-01-11',
    responseDeadline: '2025-01-16',
    employeeExplanation: null,
    explanationDate: null,
    status: 'Issued',
    resolution: null,
    sanction: null,
    sanctionDays: null,
    resolvedById: null,
    resolvedAt: null,
    createdAt: new Date('2025-01-11'),
    updatedAt: new Date('2025-01-11'),
    deletedAt: null,
    ...overrides,
  };
}

/**
 * Creates a mock expense
 */
export function createMockExpense(overrides: Partial<Expense> = {}): Expense {
  return {
    id: 'exp-001',
    projectId: 'proj-001',
    requesterId: 'emp-001',
    category: 'Material',
    description: 'Purchased electrical wires',
    amount: '5000',
    receiptUrl: 'https://storage.com/receipt.jpg',
    expenseDate: '2025-01-15',
    status: 'Pending',
    approvedById: null,
    approvedAt: null,
    rejectionReason: null,
    reimbursedAt: null,
    reimbursementRef: null,
    createdAt: new Date('2025-01-15'),
    updatedAt: new Date('2025-01-15'),
    ...overrides,
  };
}

// ==================== MOCK SESSION ====================

export function createMockSession(user: Partial<{
  id: string;
  email: string;
  employeeId: string;
  role: string;
  firstName: string;
  lastName: string;
  mustResetPassword?: boolean;
}> = {}) {
  return {
    user: {
      id: 'cred-001',
      email: 'test@company.com',
      employeeId: 'emp-001',
      role: 'WORKER',
      firstName: 'Test',
      lastName: 'User',
      mustResetPassword: false,
      ...user,
    },
    csrfToken: 'test-csrf-token',
  };
}

export function createMockAdminSession() {
  return createMockSession({
    id: 'admin-cred-001',
    email: 'admin@company.com',
    employeeId: 'admin-001',
    role: 'ADMIN',
    firstName: 'Admin',
    lastName: 'User',
  });
}

export function createMockHRSession() {
  return createMockSession({
    id: 'hr-cred-001',
    email: 'hr@company.com',
    employeeId: 'hr-001',
    role: 'HR',
    firstName: 'HR',
    lastName: 'Manager',
  });
}

// ==================== MOCK REQUEST/RESPONSE ====================

export function createMockRequest(overrides: Record<string, any> = {}): any {
  return {
    body: {},
    params: {},
    query: {},
    session: {},
    get: vi.fn(),
    method: 'GET',
    path: '/test',
    ...overrides,
  };
}

export function createMockResponse(): any {
  const res: any = {};
  res.status = vi.fn().mockReturnValue(res);
  res.json = vi.fn().mockReturnValue(res);
  res.send = vi.fn().mockReturnValue(res);
  res.set = vi.fn().mockReturnValue(res);
  res.clearCookie = vi.fn().mockReturnValue(res);
  return res;
}

export function createMockNext(): any {
  return vi.fn();
}

// ==================== DATE HELPERS ====================

/**
 * Creates a date in Philippine timezone
 */
export function createPHDate(year: number, month: number, day: number, hour: number = 0, minute: number = 0): Date {
  // Create UTC date and subtract 8 hours to represent PHT when stored as UTC
  const date = new Date(Date.UTC(year, month - 1, day, hour, minute));
  return new Date(date.getTime() - (8 * 60 * 60 * 1000));
}

/**
 * Creates a date string in YYYY-MM-DD format
 */
export function formatDate(date: Date): string {
  return date.toISOString().split('T')[0];
}

// ==================== RANDOM DATA GENERATORS ====================

/**
 * Generates a random UUID-like string
 */
export function randomId(): string {
  return 'id-' + Math.random().toString(36).substring(2, 15);
}

/**
 * Generates a random email
 */
export function randomEmail(): string {
  return `test${Math.floor(Math.random() * 10000)}@company.com`;
}

/**
 * Generates a random phone number (PH format)
 */
export function randomPhone(): string {
  return `09${Math.floor(Math.random() * 1000000000).toString().padStart(9, '0')}`;
}

// ==================== ASYNC HELPERS ====================

/**
 * Waits for the specified number of milliseconds
 */
export function wait(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Flushes all pending promises
 */
export async function flushPromises(): Promise<void> {
  await new Promise(resolve => setImmediate(resolve));
}
