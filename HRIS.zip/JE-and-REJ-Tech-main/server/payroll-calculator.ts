/**
 * Philippine Payroll Calculator
 * Implements official 2024/2025 contribution tables for:
 * - SSS (Social Security System)
 * - PhilHealth
 * - Pag-IBIG Fund
 * - Withholding Tax (TRAIN Law)
 */

interface PayrollCalculation {
  basicPay: number;
  grossPay: number;
  sssDeduction: number;
  philhealthDeduction: number;
  pagibigDeduction: number;
  taxDeduction: number;
  lateDeduction: number;
  totalDeductions: number;
  netPay: number;
}

interface EmployeeDeductionConfig {
  applySss: boolean;
  applyPhilhealth: boolean;
  applyPagibig: boolean;
  applyTax: boolean;
}

interface EnhancedPayrollInput {
  daysWorked: number;
  dailyRate: number;
  hoursWorked: number;
  regularOTMinutes: number;
  restDayOTMinutes: number;
  holidayOTMinutes: number;
  lateMinutes: number;
  undertimeMinutes: number;
  deductionConfig: EmployeeDeductionConfig;
  bonusAmount?: number;
  otherDeductions?: number;
  cashAdvanceDeduction?: number;
}

interface EnhancedPayrollResult {
  basicPay: number;
  regularOTPay: number;
  restDayOTPay: number;
  holidayOTPay: number;
  totalOTPay: number;
  grossPay: number;
  sssDeduction: number;
  philhealthDeduction: number;
  pagibigDeduction: number;
  taxDeduction: number;
  lateDeduction: number;
  undertimeDeduction: number;
  bonusAmount: number;
  otherDeductions: number;
  cashAdvanceDeduction: number;
  totalDeductions: number;
  netPay: number;
}

interface SSSSalaryBracket {
  min: number;
  max: number;
  msc: number; // Monthly Salary Credit
  er: number;  // Employer share
  ee: number;  // Employee share
}

// SSS Contribution Table 2024 (Effective January 2024)
// Based on RA 11199 (Social Security Act of 2018)
const SSS_TABLE: SSSSalaryBracket[] = [
  { min: 0, max: 4249.99, msc: 4000, er: 380, ee: 180 },
  { min: 4250, max: 4749.99, msc: 4500, er: 427.50, ee: 202.50 },
  { min: 4750, max: 5249.99, msc: 5000, er: 475, ee: 225 },
  { min: 5250, max: 5749.99, msc: 5500, er: 522.50, ee: 247.50 },
  { min: 5750, max: 6249.99, msc: 6000, er: 570, ee: 270 },
  { min: 6250, max: 6749.99, msc: 6500, er: 617.50, ee: 292.50 },
  { min: 6750, max: 7249.99, msc: 7000, er: 665, ee: 315 },
  { min: 7250, max: 7749.99, msc: 7500, er: 712.50, ee: 337.50 },
  { min: 7750, max: 8249.99, msc: 8000, er: 760, ee: 360 },
  { min: 8250, max: 8749.99, msc: 8500, er: 807.50, ee: 382.50 },
  { min: 8750, max: 9249.99, msc: 9000, er: 855, ee: 405 },
  { min: 9250, max: 9749.99, msc: 9500, er: 902.50, ee: 427.50 },
  { min: 9750, max: 10249.99, msc: 10000, er: 950, ee: 450 },
  { min: 10250, max: 10749.99, msc: 10500, er: 997.50, ee: 472.50 },
  { min: 10750, max: 11249.99, msc: 11000, er: 1045, ee: 495 },
  { min: 11250, max: 11749.99, msc: 11500, er: 1092.50, ee: 517.50 },
  { min: 11750, max: 12249.99, msc: 12000, er: 1140, ee: 540 },
  { min: 12250, max: 12749.99, msc: 12500, er: 1187.50, ee: 562.50 },
  { min: 12750, max: 13249.99, msc: 13000, er: 1235, ee: 585 },
  { min: 13250, max: 13749.99, msc: 13500, er: 1282.50, ee: 607.50 },
  { min: 13750, max: 14249.99, msc: 14000, er: 1330, ee: 630 },
  { min: 14250, max: 14749.99, msc: 14500, er: 1377.50, ee: 652.50 },
  { min: 14750, max: 15249.99, msc: 15000, er: 1425, ee: 675 },
  { min: 15250, max: 15749.99, msc: 15500, er: 1472.50, ee: 697.50 },
  { min: 15750, max: 16249.99, msc: 16000, er: 1520, ee: 720 },
  { min: 16250, max: 16749.99, msc: 16500, er: 1567.50, ee: 742.50 },
  { min: 16750, max: 17249.99, msc: 17000, er: 1615, ee: 765 },
  { min: 17250, max: 17749.99, msc: 17500, er: 1662.50, ee: 787.50 },
  { min: 17750, max: 18249.99, msc: 18000, er: 1710, ee: 810 },
  { min: 18250, max: 18749.99, msc: 18500, er: 1757.50, ee: 832.50 },
  { min: 18750, max: 19249.99, msc: 19000, er: 1805, ee: 855 },
  { min: 19250, max: 19749.99, msc: 19500, er: 1852.50, ee: 877.50 },
  { min: 19750, max: 20249.99, msc: 20000, er: 1900, ee: 900 },
  { min: 20250, max: 20749.99, msc: 20500, er: 1947.50, ee: 922.50 },
  { min: 20750, max: 21249.99, msc: 21000, er: 1995, ee: 945 },
  { min: 21250, max: 21749.99, msc: 21500, er: 2042.50, ee: 967.50 },
  { min: 21750, max: 22249.99, msc: 22000, er: 2090, ee: 990 },
  { min: 22250, max: 22749.99, msc: 22500, er: 2137.50, ee: 1012.50 },
  { min: 22750, max: 23249.99, msc: 23000, er: 2185, ee: 1035 },
  { min: 23250, max: 23749.99, msc: 23500, er: 2232.50, ee: 1057.50 },
  { min: 23750, max: 24249.99, msc: 24000, er: 2280, ee: 1080 },
  { min: 24250, max: 24749.99, msc: 24500, er: 2327.50, ee: 1102.50 },
  { min: 24750, max: 25249.99, msc: 25000, er: 2375, ee: 1125 },
  { min: 25250, max: 25749.99, msc: 25500, er: 2422.50, ee: 1147.50 },
  { min: 25750, max: 26249.99, msc: 26000, er: 2470, ee: 1170 },
  { min: 26250, max: 26749.99, msc: 26500, er: 2517.50, ee: 1192.50 },
  { min: 26750, max: 27249.99, msc: 27000, er: 2565, ee: 1215 },
  { min: 27250, max: 27749.99, msc: 27500, er: 2612.50, ee: 1237.50 },
  { min: 27750, max: 28249.99, msc: 28000, er: 2660, ee: 1260 },
  { min: 28250, max: 28749.99, msc: 28500, er: 2707.50, ee: 1282.50 },
  { min: 28750, max: 29249.99, msc: 29000, er: 2755, ee: 1305 },
  { min: 29250, max: 29749.99, msc: 29500, er: 2802.50, ee: 1327.50 },
  { min: 29750, max: Infinity, msc: 30000, er: 2850, ee: 1350 },
];

/**
 * Calculate SSS contribution based on monthly salary
 * For semi-monthly (15 days), contribution is halved
 */
export function calculateSSS(monthlySalary: number, isSemiMonthly: boolean = true): number {
  const bracket = SSS_TABLE.find(b => monthlySalary >= b.min && monthlySalary < b.max) 
    || SSS_TABLE[SSS_TABLE.length - 1];
  
  // For semi-monthly payroll, we divide the monthly contribution by 2
  return isSemiMonthly ? bracket.ee / 2 : bracket.ee;
}

/**
 * Calculate PhilHealth contribution
 * 2024 Rate: 5% of monthly basic salary (2.5% employee, 2.5% employer)
 * Minimum contribution floor: ₱10,000 (employee share: ₱250)
 * Maximum contribution ceiling: ₱100,000 (employee share: ₱2,500)
 */
export function calculatePhilHealth(monthlySalary: number, isSemiMonthly: boolean = true): number {
  const rate = 0.05; // 5% total
  const employeeShare = 0.5; // 50% of total (2.5%)
  
  // Apply floor and ceiling
  const adjustedSalary = Math.max(10000, Math.min(100000, monthlySalary));
  
  const monthlyContribution = adjustedSalary * rate * employeeShare;
  
  return isSemiMonthly ? monthlyContribution / 2 : monthlyContribution;
}

/**
 * Calculate Pag-IBIG contribution
 * Standard rate: 2% for employee, 2% for employer (if salary > ₱1,500)
 * Maximum monthly salary credit: ₱5,000
 * Employee share cap: ₱100/month
 */
export function calculatePagibig(monthlySalary: number, isSemiMonthly: boolean = true): number {
  if (monthlySalary <= 1500) {
    const rate = 0.01; // 1% for salary ≤ ₱1,500
    const contribution = monthlySalary * rate;
    return isSemiMonthly ? contribution / 2 : contribution;
  }
  
  // For salary > ₱1,500, rate is 2% capped at ₱5,000 MSC
  const msc = Math.min(5000, monthlySalary);
  const rate = 0.02;
  const monthlyContribution = msc * rate; // Max ₱100/month
  
  return isSemiMonthly ? monthlyContribution / 2 : monthlyContribution;
}

interface TaxBracket {
  min: number;
  max: number;
  rate: number;
  baseTax: number;
}

// Withholding Tax Table 2023+ (TRAIN Law - Monthly)
const TAX_TABLE_MONTHLY: TaxBracket[] = [
  { min: 0, max: 20833, rate: 0, baseTax: 0 },
  { min: 20833, max: 33333, rate: 0.15, baseTax: 0 },
  { min: 33333, max: 66667, rate: 0.20, baseTax: 1875 },
  { min: 66667, max: 166667, rate: 0.25, baseTax: 8541.67 },
  { min: 166667, max: 666667, rate: 0.30, baseTax: 33541.67 },
  { min: 666667, max: Infinity, rate: 0.35, baseTax: 183541.67 },
];

// Semi-Monthly Tax Table (for 15-day payrolls)
const TAX_TABLE_SEMIMONTHLY: TaxBracket[] = [
  { min: 0, max: 10417, rate: 0, baseTax: 0 },
  { min: 10417, max: 16667, rate: 0.15, baseTax: 0 },
  { min: 16667, max: 33333, rate: 0.20, baseTax: 937.50 },
  { min: 33333, max: 83333, rate: 0.25, baseTax: 4270.83 },
  { min: 83333, max: 333333, rate: 0.30, baseTax: 16770.83 },
  { min: 333333, max: Infinity, rate: 0.35, baseTax: 91770.83 },
];

/**
 * Calculate Withholding Tax
 * Based on TRAIN Law (2018) rates for compensation income
 */
export function calculateWithholdingTax(
  grossPay: number, 
  sss: number, 
  philhealth: number, 
  pagibig: number,
  isSemiMonthly: boolean = true
): number {
  // Taxable income = Gross - mandatory contributions
  const taxableIncome = grossPay - sss - philhealth - pagibig;
  
  if (taxableIncome <= 0) return 0;
  
  const taxTable = isSemiMonthly ? TAX_TABLE_SEMIMONTHLY : TAX_TABLE_MONTHLY;
  
  const bracket = taxTable.find(b => taxableIncome > b.min && taxableIncome <= b.max)
    || taxTable[taxTable.length - 1];
  
  if (bracket.rate === 0) return 0;
  
  const excessAmount = taxableIncome - bracket.min;
  const tax = bracket.baseTax + (excessAmount * bracket.rate);
  
  return Math.max(0, tax);
}

/**
 * Calculate late deduction based on minutes late and hourly rate
 */
export function calculateLateDeduction(lateMinutes: number, dailyRate: number): number {
  if (lateMinutes <= 0) return 0;
  
  // Assuming 8 hours per day
  const hourlyRate = dailyRate / 8;
  const minuteRate = hourlyRate / 60;
  
  return lateMinutes * minuteRate;
}

/**
 * Calculate complete payroll for an employee
 */
export function calculatePayroll(
  daysWorked: number,
  dailyRate: number,
  lateMinutes: number = 0,
  overtimeHours: number = 0
): PayrollCalculation {
  // Basic calculations
  const basicPay = daysWorked * dailyRate;
  const overtimePay = overtimeHours * (dailyRate / 8) * 1.25; // 125% for regular OT
  const grossPay = basicPay + overtimePay;
  
  // Estimate monthly salary (for contribution calculations)
  // Using 22 working days per month as standard
  const estimatedMonthlySalary = dailyRate * 22;
  
  // Calculate contributions (semi-monthly, i.e., per cutoff)
  const sssDeduction = calculateSSS(estimatedMonthlySalary, true);
  const philhealthDeduction = calculatePhilHealth(estimatedMonthlySalary, true);
  const pagibigDeduction = calculatePagibig(estimatedMonthlySalary, true);
  
  // Calculate tax based on gross pay for this cutoff
  const taxDeduction = calculateWithholdingTax(
    grossPay, 
    sssDeduction, 
    philhealthDeduction, 
    pagibigDeduction,
    true
  );
  
  // Late deduction
  const lateDeduction = calculateLateDeduction(lateMinutes, dailyRate);
  
  // Total deductions
  const totalDeductions = sssDeduction + philhealthDeduction + pagibigDeduction + taxDeduction + lateDeduction;
  
  // Net pay
  const netPay = grossPay - totalDeductions;
  
  return {
    basicPay: Math.round(basicPay * 100) / 100,
    grossPay: Math.round(grossPay * 100) / 100,
    sssDeduction: Math.round(sssDeduction * 100) / 100,
    philhealthDeduction: Math.round(philhealthDeduction * 100) / 100,
    pagibigDeduction: Math.round(pagibigDeduction * 100) / 100,
    taxDeduction: Math.round(taxDeduction * 100) / 100,
    lateDeduction: Math.round(lateDeduction * 100) / 100,
    totalDeductions: Math.round(totalDeductions * 100) / 100,
    netPay: Math.round(netPay * 100) / 100,
  };
}

/**
 * Calculate overtime pay based on Philippine labor law rates
 * Regular OT: 125% of hourly rate
 * Rest Day OT: 130% of hourly rate  
 * Holiday OT: 200% of hourly rate (regular holiday) or 130% (special holiday)
 */
export function calculateOvertimePay(
  dailyRate: number,
  hours: number,
  overtimeType: "regular" | "restday" | "holiday" = "regular"
): number {
  if (hours <= 0) return 0;
  
  const hourlyRate = dailyRate / 8;
  
  let multiplier: number;
  switch (overtimeType) {
    case "regular":
      multiplier = 1.25; // 125% for regular OT
      break;
    case "restday":
      multiplier = 1.30; // 130% for rest day OT
      break;
    case "holiday":
      multiplier = 2.00; // 200% for regular holiday OT
      break;
    default:
      multiplier = 1.25;
  }
  
  return Math.round(hours * hourlyRate * multiplier * 100) / 100;
}

/**
 * Calculate undertime deduction based on minutes undertime and daily rate
 */
export function calculateUndertimeDeduction(undertimeMinutes: number, dailyRate: number): number {
  if (undertimeMinutes <= 0) return 0;
  
  const hourlyRate = dailyRate / 8;
  const minuteRate = hourlyRate / 60;
  
  return Math.round(undertimeMinutes * minuteRate * 100) / 100;
}

/**
 * Enhanced payroll calculation with configurable deductions per employee
 * Supports semi-monthly cutoffs with proper government contribution splitting
 */
export function calculateEnhancedPayroll(input: EnhancedPayrollInput): EnhancedPayrollResult {
  const {
    daysWorked,
    dailyRate,
    regularOTMinutes,
    restDayOTMinutes,
    holidayOTMinutes,
    lateMinutes,
    undertimeMinutes,
    deductionConfig,
    bonusAmount = 0,
    otherDeductions = 0,
    cashAdvanceDeduction = 0,
  } = input;

  const hourlyRate = dailyRate / 8;
  
  // Basic pay
  const basicPay = daysWorked * dailyRate;
  
  // Overtime calculations (convert minutes to hours)
  const regularOTHours = regularOTMinutes / 60;
  const restDayOTHours = restDayOTMinutes / 60;
  const holidayOTHours = holidayOTMinutes / 60;
  
  const regularOTPay = calculateOvertimePay(dailyRate, regularOTHours, "regular");
  const restDayOTPay = calculateOvertimePay(dailyRate, restDayOTHours, "restday");
  const holidayOTPay = calculateOvertimePay(dailyRate, holidayOTHours, "holiday");
  const totalOTPay = regularOTPay + restDayOTPay + holidayOTPay;
  
  // Gross pay (basic + OT + bonus)
  const grossPay = basicPay + totalOTPay + bonusAmount;
  
  // Estimate monthly salary for contribution calculations
  const estimatedMonthlySalary = dailyRate * 22;
  
  // Calculate contributions based on employee configuration (semi-monthly)
  const sssDeduction = deductionConfig.applySss 
    ? calculateSSS(estimatedMonthlySalary, true) 
    : 0;
  const philhealthDeduction = deductionConfig.applyPhilhealth 
    ? calculatePhilHealth(estimatedMonthlySalary, true) 
    : 0;
  const pagibigDeduction = deductionConfig.applyPagibig 
    ? calculatePagibig(estimatedMonthlySalary, true) 
    : 0;
  
  // Tax calculation (based on employee configuration)
  const taxDeduction = deductionConfig.applyTax 
    ? calculateWithholdingTax(grossPay, sssDeduction, philhealthDeduction, pagibigDeduction, true) 
    : 0;
  
  // Late and undertime deductions
  const lateDeduction = calculateLateDeduction(lateMinutes, dailyRate);
  const undertimeDeduction = calculateUndertimeDeduction(undertimeMinutes, dailyRate);
  
  // Total deductions
  const totalDeductions = sssDeduction + philhealthDeduction + pagibigDeduction + 
    taxDeduction + lateDeduction + undertimeDeduction + otherDeductions + cashAdvanceDeduction;
  
  // Net pay
  const netPay = grossPay - totalDeductions;
  
  const round = (n: number) => Math.round(n * 100) / 100;
  
  return {
    basicPay: round(basicPay),
    regularOTPay: round(regularOTPay),
    restDayOTPay: round(restDayOTPay),
    holidayOTPay: round(holidayOTPay),
    totalOTPay: round(totalOTPay),
    grossPay: round(grossPay),
    sssDeduction: round(sssDeduction),
    philhealthDeduction: round(philhealthDeduction),
    pagibigDeduction: round(pagibigDeduction),
    taxDeduction: round(taxDeduction),
    lateDeduction: round(lateDeduction),
    undertimeDeduction: round(undertimeDeduction),
    bonusAmount: round(bonusAmount),
    otherDeductions: round(otherDeductions),
    cashAdvanceDeduction: round(cashAdvanceDeduction),
    totalDeductions: round(totalDeductions),
    netPay: round(netPay),
  };
}

export type { EmployeeDeductionConfig, EnhancedPayrollInput, EnhancedPayrollResult };
