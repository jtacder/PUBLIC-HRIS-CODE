import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  PORT: z.string().default("5000"),
  DATABASE_URL: z.string().min(1, "DATABASE_URL is required"),
  SESSION_SECRET: z.string().min(32, "SESSION_SECRET must be at least 32 characters for security"),
  // Email configuration (optional - feature disabled if not set)
  EMAIL_ENABLED: z.enum(["true", "false"]).default("false"),
  RESEND_API_KEY: z.string().optional(),
  EMAIL_FROM_ADDRESS: z.string().email().optional(),
  EMAIL_FROM_NAME: z.string().optional(),
  // App URL for password reset links
  APP_URL: z.string().url().optional(),
  // Web Push VAPID keys (optional - push disabled if not set)
  VAPID_PUBLIC_KEY: z.string().optional(),
  VAPID_PRIVATE_KEY: z.string().optional(),
  VAPID_SUBJECT: z.string().optional(), // mailto: or https:// URL
});

function validateEnv() {
  const result = envSchema.safeParse(process.env);
  
  if (!result.success) {
    console.error("Environment validation failed:");
    result.error.errors.forEach((err) => {
      console.error(`  - ${err.path.join(".")}: ${err.message}`);
    });
    process.exit(1);
  }
  
  return result.data;
}

const env = validateEnv();

export const config = {
  nodeEnv: env.NODE_ENV,
  isProduction: env.NODE_ENV === "production",
  isDevelopment: env.NODE_ENV === "development",
  port: parseInt(env.PORT, 10),
  databaseUrl: env.DATABASE_URL,
  sessionSecret: env.SESSION_SECRET,
  session: {
    ttl: 7 * 24 * 60 * 60 * 1000, // 1 week in milliseconds
    cookieName: "connect.sid",
  },
  security: {
    bcryptSaltRounds: 12,
    csrfTokenLength: 32,
  },
  timezone: {
    offset: 8, // Philippines UTC+8
    name: "Asia/Manila",
  },
  geo: {
    defaultRadius: 100, // meters
  },
  payroll: {
    defaultWorkingDaysPerMonth: 22,
    defaultHoursPerDay: 8,
    lunchBreakMinutes: 60,
    minHoursForLunchDeduction: 5, // 5 hours = 300 minutes
    lateGraceMinutes: 15, // Minutes before late deduction applies
  },
  email: {
    enabled: env.EMAIL_ENABLED === "true",
    resendApiKey: env.RESEND_API_KEY,
    fromAddress: env.EMAIL_FROM_ADDRESS || "noreply@jerejtech.org",
    fromName: env.EMAIL_FROM_NAME || "JE & REJ Tech",
    appUrl: env.APP_URL || "http://localhost:5000",
    passwordResetTokenExpiry: 60 * 60 * 1000, // 1 hour in milliseconds
  },
  webPush: {
    enabled: !!(env.VAPID_PUBLIC_KEY && env.VAPID_PRIVATE_KEY),
    vapidPublicKey: env.VAPID_PUBLIC_KEY || "",
    vapidPrivateKey: env.VAPID_PRIVATE_KEY || "",
    vapidSubject: env.VAPID_SUBJECT || "mailto:admin@jerejtech.org",
  },
} as const;

export type Config = typeof config;
