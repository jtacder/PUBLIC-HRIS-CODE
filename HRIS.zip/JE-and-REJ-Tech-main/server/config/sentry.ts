/**
 * Sentry Error Tracking Configuration
 *
 * This module initializes Sentry for error tracking and performance monitoring.
 * Sentry is optional - the application works without SENTRY_DSN configured.
 *
 * Configuration:
 * - Set SENTRY_DSN environment variable to enable Sentry
 * - In production, also set SENTRY_RELEASE for release tracking
 * 
 * NOTE: @sentry/node is an optional dependency. If not installed,
 * all functions become no-ops and the app runs normally.
 */

import { Express, ErrorRequestHandler } from "express";
import { logger } from "../utils/logger";

// Check if Sentry is enabled
const SENTRY_DSN = process.env.SENTRY_DSN;
const SENTRY_ENABLED = !!SENTRY_DSN;

// Sentry module - will be null if not installed
let Sentry: any = null;

/**
 * Initialize Sentry error tracking
 * Call this early in the application lifecycle, before other middleware
 */
export function initializeSentry(): void {
  if (!SENTRY_ENABLED) {
    logger.info("Sentry disabled (no SENTRY_DSN configured)");
    return;
  }

  try {
    // Dynamic import to handle missing package gracefully
    Sentry = require("@sentry/node");
    
    Sentry.init({
      dsn: SENTRY_DSN,
      environment: process.env.NODE_ENV || "development",
      release: process.env.SENTRY_RELEASE || process.env.npm_package_version || "1.0.0",
      tracesSampleRate: process.env.NODE_ENV === "production" ? 0.1 : 1.0,
      profilesSampleRate: process.env.NODE_ENV === "production" ? 0.1 : 1.0,
      enabled: true,
      includeLocalVariables: true,
      beforeSend(event: any) {
        if (event.request?.headers) {
          delete event.request.headers["authorization"];
          delete event.request.headers["cookie"];
          delete event.request.headers["x-csrf-token"];
        }
        if (event.request?.data) {
          const sensitiveFields = ["password", "currentPassword", "newPassword", "token", "secret"];
          for (const field of sensitiveFields) {
            if (typeof event.request.data === "object" && event.request.data !== null) {
              if (field in event.request.data) {
                (event.request.data as Record<string, unknown>)[field] = "[FILTERED]";
              }
            }
          }
        }
        return event;
      },
      ignoreErrors: ["401", "Unauthorized", "ValidationError", "ETIMEDOUT", "ECONNRESET"],
      integrations: [
        Sentry.httpIntegration({ tracing: true }),
        Sentry.expressIntegration(),
      ],
    });

    logger.info("Sentry initialized successfully", {
      environment: process.env.NODE_ENV,
      release: process.env.SENTRY_RELEASE || "1.0.0",
    });
  } catch (error) {
    // Package not installed or initialization failed - disable Sentry
    Sentry = null;
    logger.info("Sentry not available (package not installed or init failed)");
  }
}

/**
 * Setup Sentry request handler middleware
 */
export function setupSentryRequestHandler(app: Express): void {
  if (!Sentry) {
    return;
  }

  try {
    app.use(Sentry.expressIntegration().setupExpressErrorHandler(app));
    logger.debug("Sentry request handler middleware added");
  } catch (error) {
    logger.debug("Could not setup Sentry request handler");
  }
}

/**
 * Sentry error handler middleware
 */
export function getSentryErrorHandler(): ErrorRequestHandler {
  if (!Sentry) {
    return ((_err, _req, _res, next) => {
      next();
    }) as ErrorRequestHandler;
  }

  try {
    return Sentry.expressErrorHandler() as unknown as ErrorRequestHandler;
  } catch {
    return ((_err, _req, _res, next) => {
      next();
    }) as ErrorRequestHandler;
  }
}

/**
 * Manually capture an exception with Sentry
 */
export function captureException(error: Error, context?: Record<string, unknown>): string | null {
  if (!Sentry) {
    return null;
  }

  return Sentry.captureException(error, { extra: context });
}

/**
 * Manually capture a message with Sentry
 */
export function captureMessage(
  message: string,
  level: "fatal" | "error" | "warning" | "log" | "info" | "debug" = "info"
): string | null {
  if (!Sentry) {
    return null;
  }

  return Sentry.captureMessage(message, level);
}

/**
 * Set user context for better error tracking
 */
export function setUserContext(user: { id: string; email?: string; role?: string }): void {
  if (!Sentry) {
    return;
  }

  Sentry.setUser({
    id: user.id,
    email: user.email,
  });
}

/**
 * Clear user context on logout
 */
export function clearUserContext(): void {
  if (!Sentry) {
    return;
  }

  Sentry.setUser(null);
}

/**
 * Add breadcrumb for debugging
 */
export function addBreadcrumb(
  message: string,
  category: string,
  data?: Record<string, unknown>
): void {
  if (!Sentry) {
    return;
  }

  Sentry.addBreadcrumb({
    message,
    category,
    data,
    level: "info",
  });
}

// Export Sentry status check
export function isSentryEnabled(): boolean {
  return !!Sentry;
}
