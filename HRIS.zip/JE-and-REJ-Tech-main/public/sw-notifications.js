/**
 * Service Worker for Push Notifications
 * Handles incoming push events and notification clicks
 */

// Listen for push events from the Web Push API
self.addEventListener("push", (event) => {
  if (!event.data) return;

  try {
    const data = event.data.json();

    const options = {
      body: data.body || "You have a new notification",
      icon: data.icon || "/icons/notification-icon.png",
      badge: data.badge || "/icons/badge-icon.png",
      tag: data.data?.notificationId || "notification",
      renotify: true,
      data: {
        url: data.data?.url || "/",
        notificationId: data.data?.notificationId,
        category: data.data?.category,
      },
      actions: [
        { action: "open", title: "Open" },
        { action: "dismiss", title: "Dismiss" },
      ],
      vibrate: [200, 100, 200],
      requireInteraction: data.data?.category === "disciplinary" || data.data?.category === "urgent",
    };

    event.waitUntil(
      self.registration.showNotification(data.title || "ElectroManage", options)
    );
  } catch (err) {
    // Fallback for non-JSON push data
    event.waitUntil(
      self.registration.showNotification("ElectroManage", {
        body: event.data.text(),
        icon: "/icons/notification-icon.png",
      })
    );
  }
});

// Handle notification clicks
self.addEventListener("notificationclick", (event) => {
  event.notification.close();

  if (event.action === "dismiss") return;

  const url = event.notification.data?.url || "/";

  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      // Focus an existing window if available
      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && "focus" in client) {
          client.focus();
          client.navigate(url);
          return;
        }
      }
      // Open a new window if none exists
      return self.clients.openWindow(url);
    })
  );
});

// Handle notification close
self.addEventListener("notificationclose", (event) => {
  // Could track dismissed notifications here if needed
});

// Service Worker activation - claim all clients
self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});
