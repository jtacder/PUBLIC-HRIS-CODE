import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import {
  Bell,
  Send,
  BarChart3,
  Mail,
  Smartphone,
  Monitor,
  CheckCircle,
  AlertCircle,
  Loader2,
  Users,
  Search,
  BellRing,
  BellOff,
  TestTube,
} from "lucide-react";

interface NotificationStats {
  total: number;
  unread: number;
  pushSent: number;
  emailSent: number;
  categoryBreakdown: Array<{
    category: string;
    count: number;
    unread: number;
  }>;
}

interface AdminNotification {
  notification: {
    id: string;
    recipientId: string;
    title: string;
    message: string;
    category: string;
    priority: string;
    isRead: boolean;
    pushSent: boolean;
    emailSent: boolean;
    createdAt: string;
  };
  recipient: {
    id: string;
    firstName: string;
    lastName: string;
  } | null;
}

interface EmployeePushStatus {
  id: string;
  firstName: string;
  lastName: string;
  employeeNo: string;
  role: string;
  department: string | null;
  email: string | null;
  notificationsEnabled: boolean;
  hasPushEnabled: boolean;
  pushSubscriptionCount: number;
  totalSubscriptions: number;
  preferences: Record<string, Record<string, boolean>> | null;
}

const categoryLabels: Record<string, string> = {
  leave: "Leave Requests",
  payroll: "Payroll",
  attendance: "Attendance",
  tasks: "Tasks",
  expenses: "Expenses",
  cash_advance: "Cash Advances",
  disciplinary: "Disciplinary",
  projects: "Projects",
  permissions: "Permissions",
  system: "System",
  devotional: "Devotional",
};

const priorityColors: Record<string, string> = {
  urgent: "bg-red-500 text-white",
  high: "bg-orange-500 text-white",
  normal: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  low: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400",
};

export default function NotificationManagementPage() {
  const { toast } = useToast();
  const [broadcastOpen, setBroadcastOpen] = useState(false);
  const [broadcastData, setBroadcastData] = useState({
    title: "",
    message: "",
    category: "system" as string,
    priority: "normal" as string,
  });
  const [categoryFilter, setCategoryFilter] = useState<string>("all");

  // Fetch stats
  const { data: stats, isLoading: statsLoading } = useQuery<NotificationStats>({
    queryKey: ["/api/notifications/admin/stats"],
  });

  // Fetch notifications
  const filterParams = categoryFilter !== "all" ? `?category=${categoryFilter}&limit=50` : "?limit=50";
  const { data: adminNotifications, isLoading: notifLoading } = useQuery<AdminNotification[]>({
    queryKey: [`/api/notifications/admin/all${filterParams}`],
  });

  // Broadcast mutation
  const broadcastMutation = useMutation({
    mutationFn: async (data: typeof broadcastData) => {
      const res = await apiRequest("POST", "/api/notifications/admin/broadcast", data);
      return res.json();
    },
    onSuccess: (result) => {
      toast({
        title: "Broadcast Sent",
        description: `Notification sent to ${result.recipientCount} employees.`,
      });
      setBroadcastOpen(false);
      setBroadcastData({ title: "", message: "", category: "system", priority: "normal" });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/admin/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/admin/all"] });
    },
    onError: () => {
      toast({
        title: "Broadcast Failed",
        description: "Failed to send broadcast notification.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Notification Center</h1>
          <p className="text-muted-foreground">
            Monitor delivery status, manage employee push settings, and send announcements
          </p>
        </div>
        <Dialog open={broadcastOpen} onOpenChange={setBroadcastOpen}>
          <DialogTrigger asChild>
            <Button>
              <Send className="mr-2 h-4 w-4" />
              Broadcast
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Send Broadcast Notification</DialogTitle>
              <DialogDescription>
                Send a notification to all active employees
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <label className="text-sm font-medium">Title</label>
                <Input
                  value={broadcastData.title}
                  onChange={(e) => setBroadcastData({ ...broadcastData, title: e.target.value })}
                  placeholder="Notification title"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Message</label>
                <Textarea
                  value={broadcastData.message}
                  onChange={(e) => setBroadcastData({ ...broadcastData, message: e.target.value })}
                  placeholder="Notification message"
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Category</label>
                  <Select
                    value={broadcastData.category}
                    onValueChange={(v) => setBroadcastData({ ...broadcastData, category: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(categoryLabels).map(([key, label]) => (
                        <SelectItem key={key} value={key}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium">Priority</label>
                  <Select
                    value={broadcastData.priority}
                    onValueChange={(v) => setBroadcastData({ ...broadcastData, priority: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setBroadcastOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={() => broadcastMutation.mutate(broadcastData)}
                disabled={!broadcastData.title || !broadcastData.message || broadcastMutation.isPending}
              >
                {broadcastMutation.isPending ? (
                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Sending...</>
                ) : (
                  <><Send className="mr-2 h-4 w-4" />Send to All</>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">
            <BarChart3 className="mr-2 h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="push-settings">
            <Smartphone className="mr-2 h-4 w-4" />
            Employee Push Settings
          </TabsTrigger>
          <TabsTrigger value="history">
            <Bell className="mr-2 h-4 w-4" />
            Notification History
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          {/* Stats Cards */}
          {statsLoading ? (
            <div className="grid gap-4 md:grid-cols-4">
              {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-24" />)}
            </div>
          ) : stats ? (
            <div className="grid gap-4 md:grid-cols-4">
              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-bold">{stats.total}</p>
                      <p className="text-sm text-muted-foreground">Total Notifications</p>
                    </div>
                    <Bell className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-bold">{stats.unread}</p>
                      <p className="text-sm text-muted-foreground">Unread</p>
                    </div>
                    <AlertCircle className="h-8 w-8 text-orange-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-bold">{stats.pushSent}</p>
                      <p className="text-sm text-muted-foreground">Push Sent</p>
                    </div>
                    <Smartphone className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-bold">{stats.emailSent}</p>
                      <p className="text-sm text-muted-foreground">Emails Sent</p>
                    </div>
                    <Mail className="h-8 w-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : null}

          {/* Category Breakdown */}
          {stats?.categoryBreakdown && stats.categoryBreakdown.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  Category Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2 md:grid-cols-3 lg:grid-cols-4">
                  {stats.categoryBreakdown.map((cat) => (
                    <div
                      key={cat.category}
                      className="flex items-center justify-between p-3 rounded-lg border"
                    >
                      <div>
                        <p className="text-sm font-medium">
                          {categoryLabels[cat.category] || cat.category}
                        </p>
                        <p className="text-xs text-muted-foreground">{cat.unread} unread</p>
                      </div>
                      <Badge variant="secondary">{cat.count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Employee Push Settings Tab */}
        <TabsContent value="push-settings">
          <EmployeePushSettingsPanel />
        </TabsContent>

        {/* Notification History Tab */}
        <TabsContent value="history">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm">Recent Notifications</CardTitle>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {Object.entries(categoryLabels).map(([key, label]) => (
                      <SelectItem key={key} value={key}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {notifLoading ? (
                <Skeleton className="h-48" />
              ) : !adminNotifications || adminNotifications.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No notifications found</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Recipient</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Delivery</TableHead>
                      <TableHead>Sent</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {adminNotifications.map((item) => (
                      <TableRow key={item.notification.id}>
                        <TableCell className="font-medium text-sm">
                          {item.recipient
                            ? `${item.recipient.firstName} ${item.recipient.lastName}`
                            : "Unknown"}
                        </TableCell>
                        <TableCell className="max-w-xs truncate text-sm">
                          {item.notification.title}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs">
                            {categoryLabels[item.notification.category] || item.notification.category}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={`text-xs ${priorityColors[item.notification.priority] || ""}`}>
                            {item.notification.priority}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {item.notification.isRead ? (
                            <Badge variant="secondary" className="text-xs">
                              <CheckCircle className="h-3 w-3 mr-1" />Read
                            </Badge>
                          ) : (
                            <Badge className="text-xs bg-yellow-100 text-yellow-800">Unread</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <span title="In-app"><Monitor className={`h-3.5 w-3.5 ${item.notification.isRead ? "text-green-500" : "text-blue-500"}`} /></span>
                            {item.notification.pushSent && (
                              <span title="Push sent"><Smartphone className="h-3.5 w-3.5 text-green-500" /></span>
                            )}
                            {item.notification.emailSent && (
                              <span title="Email sent"><Mail className="h-3.5 w-3.5 text-green-500" /></span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(item.notification.createdAt), { addSuffix: true })}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ============================================
// EMPLOYEE PUSH SETTINGS PANEL (Admin)
// ============================================

function EmployeePushSettingsPanel() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch employee push status
  const { data: employees, isLoading } = useQuery<EmployeePushStatus[]>({
    queryKey: ["/api/notifications/admin/employees-push-status"],
  });

  // Enable push mutation
  const enablePushMutation = useMutation({
    mutationFn: async (employeeId: string) => {
      const res = await apiRequest("POST", `/api/notifications/admin/enable-push-for-employee/${employeeId}`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Push Enabled", description: "Push notifications have been enabled for this employee." });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/admin/employees-push-status"] });
    },
    onError: () => {
      toast({ title: "Failed", description: "Failed to enable push notifications.", variant: "destructive" });
    },
  });

  // Disable push mutation
  const disablePushMutation = useMutation({
    mutationFn: async (employeeId: string) => {
      const res = await apiRequest("POST", `/api/notifications/admin/disable-push-for-employee/${employeeId}`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Push Disabled", description: "Push notifications have been disabled for this employee." });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/admin/employees-push-status"] });
    },
    onError: () => {
      toast({ title: "Failed", description: "Failed to disable push notifications.", variant: "destructive" });
    },
  });

  // Test push mutation
  const testPushMutation = useMutation({
    mutationFn: async (employeeId: string) => {
      const res = await apiRequest("POST", `/api/notifications/admin/send-test-push/${employeeId}`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Test Sent", description: "A test notification has been sent to this employee." });
    },
    onError: () => {
      toast({ title: "Failed", description: "Failed to send test notification.", variant: "destructive" });
    },
  });

  const filteredEmployees = employees?.filter(emp => {
    if (!searchQuery) return true;
    const search = searchQuery.toLowerCase();
    return (
      emp.firstName.toLowerCase().includes(search) ||
      emp.lastName.toLowerCase().includes(search) ||
      emp.employeeNo.toLowerCase().includes(search) ||
      (emp.department?.toLowerCase().includes(search)) ||
      emp.role.toLowerCase().includes(search)
    );
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  const pushEnabledCount = employees?.filter(e => e.hasPushEnabled).length ?? 0;
  const subscribedCount = employees?.filter(e => e.pushSubscriptionCount > 0).length ?? 0;

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{employees?.length ?? 0}</p>
                <p className="text-sm text-muted-foreground">Total Employees</p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{pushEnabledCount}</p>
                <p className="text-sm text-muted-foreground">Push Preferences ON</p>
              </div>
              <BellRing className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{subscribedCount}</p>
                <p className="text-sm text-muted-foreground">Devices Subscribed</p>
              </div>
              <Smartphone className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Info Card */}
      <Card>
        <CardContent className="py-3">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium">How Push Notifications Work</p>
              <p className="text-muted-foreground mt-1">
                <strong>Push Preferences</strong> controls whether push notifications are sent when events occur.
                You can enable/disable this per employee here.
                <strong> Device Subscription</strong> is separate - each employee must click "Enable" on their
                profile's notification settings to allow their browser to receive push notifications on that device.
                Even if push preferences are ON, the employee won't receive notifications until they subscribe their device.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Employee Table */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm">Employee Push Notification Settings</CardTitle>
              <CardDescription>
                Manage push notification preferences per employee
              </CardDescription>
            </div>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search employees..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {!filteredEmployees || filteredEmployees.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Users className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>{searchQuery ? "No employees match your search" : "No active employees found"}</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Notifications</TableHead>
                  <TableHead>Push Prefs</TableHead>
                  <TableHead>Device Subscribed</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEmployees.map((emp) => (
                  <TableRow key={emp.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium text-sm">
                          {emp.firstName} {emp.lastName}
                        </p>
                        <p className="text-xs text-muted-foreground">{emp.employeeNo}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <Badge variant="outline" className="text-xs">{emp.role}</Badge>
                        {emp.department && (
                          <p className="text-xs text-muted-foreground mt-0.5">{emp.department}</p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {emp.notificationsEnabled ? (
                        <Badge variant="secondary" className="text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Enabled
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400">
                          <BellOff className="h-3 w-3 mr-1" />
                          Disabled
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={emp.hasPushEnabled}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            enablePushMutation.mutate(emp.id);
                          } else {
                            disablePushMutation.mutate(emp.id);
                          }
                        }}
                        disabled={enablePushMutation.isPending || disablePushMutation.isPending}
                        className="scale-90"
                      />
                    </TableCell>
                    <TableCell>
                      {emp.pushSubscriptionCount > 0 ? (
                        <Badge variant="secondary" className="text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                          <Smartphone className="h-3 w-3 mr-1" />
                          {emp.pushSubscriptionCount} device{emp.pushSubscriptionCount > 1 ? "s" : ""}
                        </Badge>
                      ) : (
                        <span className="text-xs text-muted-foreground">No devices</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => testPushMutation.mutate(emp.id)}
                        disabled={testPushMutation.isPending}
                        title="Send test notification"
                      >
                        {testPushMutation.isPending ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <TestTube className="h-3.5 w-3.5" />
                        )}
                        <span className="ml-1.5 text-xs">Test</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
