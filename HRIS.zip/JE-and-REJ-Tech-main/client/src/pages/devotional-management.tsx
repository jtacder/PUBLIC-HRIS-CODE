import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { usePagination } from "@/hooks/use-pagination";
import { TablePagination } from "@/components/ui/table-pagination";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BookOpen,
  Plus,
  Pencil,
  Trash2,
  Upload,
  Download,
  Search,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  FileJson,
  AlertCircle,
  CheckCircle2,
} from "lucide-react";

// Types
interface Devotional {
  id: string;
  dayNumber: number;
  verse: string;
  reference: string;
  baseExcerpt: string;
  theme: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

// Form schema
const devotionalSchema = z.object({
  dayNumber: z.coerce.number().min(1).max(365),
  verse: z.string().min(10, "Verse must be at least 10 characters"),
  reference: z.string().min(3, "Reference is required (e.g., Proverbs 3:5-6)"),
  baseExcerpt: z.string().min(50, "Excerpt should be at least 50 characters"),
  theme: z.string().optional(),
});

type DevotionalForm = z.infer<typeof devotionalSchema>;

// API functions
async function fetchDevotionals(): Promise<Devotional[]> {
  const response = await fetch("/api/devotionals/admin/all", {
    credentials: "include",
  });
  if (!response.ok) throw new Error("Failed to fetch devotionals");
  return response.json();
}

async function createDevotional(data: DevotionalForm): Promise<Devotional> {
  const response = await apiRequest("POST", "/api/devotionals/admin/create", data);
  return response.json();
}

async function updateDevotional(id: string, data: Partial<DevotionalForm>): Promise<Devotional> {
  const response = await apiRequest("PUT", `/api/devotionals/admin/${id}`, data);
  return response.json();
}

async function deleteDevotional(id: string): Promise<void> {
  await apiRequest("DELETE", `/api/devotionals/admin/${id}`);
}

async function bulkCreateDevotionals(devotionals: DevotionalForm[]): Promise<{ created: number; skipped: number; errors: string[] }> {
  const response = await apiRequest("POST", "/api/devotionals/admin/bulk", { devotionals });
  return response.json();
}

export default function DevotionalManagementPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // State
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [selectedDevotional, setSelectedDevotional] = useState<Devotional | null>(null);
  const [bulkImportText, setBulkImportText] = useState("");

  // Queries
  const { data: devotionals, isLoading, error } = useQuery<Devotional[]>({
    queryKey: ["/api/devotionals/admin/all"],
    queryFn: fetchDevotionals,
  });

  // Mutations
  const createMutation = useMutation({
    mutationFn: createDevotional,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devotionals/admin/all"] });
      setIsAddDialogOpen(false);
      toast({ title: "Success", description: "Devotional created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<DevotionalForm> }) => updateDevotional(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devotionals/admin/all"] });
      setIsEditDialogOpen(false);
      setSelectedDevotional(null);
      toast({ title: "Success", description: "Devotional updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: deleteDevotional,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devotionals/admin/all"] });
      setDeleteConfirmId(null);
      toast({ title: "Success", description: "Devotional deleted successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const bulkMutation = useMutation({
    mutationFn: bulkCreateDevotionals,
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/devotionals/admin/all"] });
      setIsBulkImportOpen(false);
      setBulkImportText("");
      toast({
        title: "Bulk Import Complete",
        description: `Created: ${result.created}, Skipped: ${result.skipped}${result.errors.length > 0 ? `, Errors: ${result.errors.length}` : ""}`,
      });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  // Form
  const form = useForm<DevotionalForm>({
    resolver: zodResolver(devotionalSchema),
    defaultValues: {
      dayNumber: 1,
      verse: "",
      reference: "",
      baseExcerpt: "",
      theme: "",
    },
  });

  // Filter and paginate
  const filteredDevotionals = devotionals?.filter((d) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      d.dayNumber.toString().includes(query) ||
      d.verse.toLowerCase().includes(query) ||
      d.reference.toLowerCase().includes(query) ||
      d.theme?.toLowerCase().includes(query)
    );
  }) || [];

  // Pagination
  const pagination = usePagination(filteredDevotionals);

  // Handlers
  const handleAdd = () => {
    form.reset({
      dayNumber: 1,
      verse: "",
      reference: "",
      baseExcerpt: "",
      theme: "",
    });
    setIsAddDialogOpen(true);
  };

  const handleEdit = (devotional: Devotional) => {
    setSelectedDevotional(devotional);
    form.reset({
      dayNumber: devotional.dayNumber,
      verse: devotional.verse,
      reference: devotional.reference,
      baseExcerpt: devotional.baseExcerpt,
      theme: devotional.theme || "",
    });
    setIsEditDialogOpen(true);
  };

  const handleSubmitAdd = (data: DevotionalForm) => {
    createMutation.mutate(data);
  };

  const handleSubmitEdit = (data: DevotionalForm) => {
    if (selectedDevotional) {
      updateMutation.mutate({ id: selectedDevotional.id, data });
    }
  };

  const handleBulkImport = () => {
    try {
      const parsed = JSON.parse(bulkImportText);
      const devotionalArray = Array.isArray(parsed) ? parsed : [parsed];
      bulkMutation.mutate(devotionalArray);
    } catch {
      toast({ title: "Error", description: "Invalid JSON format", variant: "destructive" });
    }
  };

  const handleExportTemplate = () => {
    const template = [
      {
        dayNumber: 1,
        verse: "Trust in the LORD with all your heart...",
        reference: "Proverbs 3:5-6 (NIV)",
        baseExcerpt: "A 150-word reflection on the verse...",
        theme: "Trust",
      },
    ];
    const blob = new Blob([JSON.stringify(template, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "devotional-template.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  // Stats
  const totalDays = 365;
  const filledDays = devotionals?.length || 0;
  const coverage = Math.round((filledDays / totalDays) * 100);

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <p className="text-lg font-medium">Failed to load devotionals</p>
          <p className="text-sm text-muted-foreground">Please try again later</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-amber-500" />
            Devotional Management
          </h1>
          <p className="text-muted-foreground">
            Manage the 365-day devotional content for all employees
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setIsBulkImportOpen(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Bulk Import
          </Button>
          <Button onClick={handleAdd}>
            <Plus className="h-4 w-4 mr-2" />
            Add Devotional
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Content Coverage
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{coverage}%</div>
            <p className="text-xs text-muted-foreground">
              {filledDays} of {totalDays} days filled
            </p>
            <div className="mt-2 h-2 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full bg-amber-500 transition-all"
                style={{ width: `${coverage}%` }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Missing Days
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalDays - filledDays}</div>
            <p className="text-xs text-muted-foreground">Days need content</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleExportTemplate}>
              <Download className="h-4 w-4 mr-1" />
              Template
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Search and Table */}
      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <CardTitle>All Devotionals</CardTitle>
            <div className="relative w-full md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by day, verse, theme..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  pagination.resetPagination();
                }}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filteredDevotionals.length === 0 ? (
            <div className="text-center py-12">
              <BookOpen className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
              <p className="text-lg font-medium">No devotionals found</p>
              <p className="text-sm text-muted-foreground mb-4">
                {searchQuery ? "Try a different search" : "Start by adding your first devotional"}
              </p>
              {!searchQuery && (
                <Button onClick={handleAdd}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add First Devotional
                </Button>
              )}
            </div>
          ) : (
            <>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-20">Day</TableHead>
                    <TableHead>Reference</TableHead>
                    <TableHead className="hidden md:table-cell">Theme</TableHead>
                    <TableHead className="hidden lg:table-cell">Verse (Preview)</TableHead>
                    <TableHead className="w-24">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pagination.paginatedData.map((devotional) => (
                    <TableRow key={devotional.id}>
                      <TableCell>
                        <Badge variant="outline" className="font-mono">
                          {devotional.dayNumber}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium">
                        {devotional.reference}
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        {devotional.theme ? (
                          <Badge variant="secondary">{devotional.theme}</Badge>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell max-w-xs truncate text-sm text-muted-foreground">
                        {devotional.verse.slice(0, 60)}...
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(devotional)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setDeleteConfirmId(devotional.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <TablePagination
                currentPage={pagination.currentPage}
                pageSize={pagination.pageSize}
                totalPages={pagination.totalPages}
                totalItems={pagination.totalItems}
                startIndex={pagination.startIndex}
                endIndex={pagination.endIndex}
                canGoNext={pagination.canGoNext}
                canGoPrevious={pagination.canGoPrevious}
                onPageChange={pagination.goToPage}
                onPageSizeChange={pagination.setPageSize}
                onNextPage={pagination.goToNextPage}
                onPreviousPage={pagination.goToPreviousPage}
                onFirstPage={pagination.goToFirstPage}
                onLastPage={pagination.goToLastPage}
              />
            </>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Dialog */}
      <Dialog
        open={isAddDialogOpen || isEditDialogOpen}
        onOpenChange={(open) => {
          if (!open) {
            setIsAddDialogOpen(false);
            setIsEditDialogOpen(false);
            setSelectedDevotional(null);
          }
        }}
      >
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-amber-500" />
              {isEditDialogOpen ? "Edit Devotional" : "Add New Devotional"}
            </DialogTitle>
            <DialogDescription>
              {isEditDialogOpen
                ? "Update the devotional content below"
                : "Create a new devotional entry for the 365-day plan"}
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(isEditDialogOpen ? handleSubmitEdit : handleSubmitAdd)}
              className="space-y-4"
            >
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="dayNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Day Number (1-365)</FormLabel>
                      <FormControl>
                        <Input type="number" min={1} max={365} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="theme"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Theme (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Trust, Integrity, Hope" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="reference"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Scripture Reference</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Proverbs 3:5-6 (NIV)" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="verse"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Scripture Verse</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Enter the full scripture text..."
                        className="min-h-[100px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="baseExcerpt"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reflection/Excerpt (~150 words)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Write the daily reflection connecting the verse to professional life..."
                        className="min-h-[150px]"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Include context, key insight, workplace application, and encouragement
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsAddDialogOpen(false);
                    setIsEditDialogOpen(false);
                  }}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                >
                  {createMutation.isPending || updateMutation.isPending ? (
                    "Saving..."
                  ) : isEditDialogOpen ? (
                    "Update Devotional"
                  ) : (
                    "Create Devotional"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Bulk Import Dialog */}
      <Dialog open={isBulkImportOpen} onOpenChange={setIsBulkImportOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileJson className="h-5 w-5 text-blue-500" />
              Bulk Import Devotionals
            </DialogTitle>
            <DialogDescription>
              Paste JSON array of devotionals to import multiple entries at once
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleExportTemplate}>
                <Download className="h-4 w-4 mr-1" />
                Download Template
              </Button>
            </div>

            <Textarea
              placeholder={`[
  {
    "dayNumber": 1,
    "verse": "Scripture text...",
    "reference": "Book Chapter:Verse (NIV)",
    "baseExcerpt": "150-word reflection...",
    "theme": "Theme"
  }
]`}
              className="min-h-[300px] font-mono text-sm"
              value={bulkImportText}
              onChange={(e) => setBulkImportText(e.target.value)}
            />

            <p className="text-xs text-muted-foreground">
              Existing days will be skipped. Only new day numbers will be created.
            </p>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsBulkImportOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleBulkImport}
              disabled={!bulkImportText.trim() || bulkMutation.isPending}
            >
              {bulkMutation.isPending ? "Importing..." : "Import Devotionals"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteConfirmId} onOpenChange={() => setDeleteConfirmId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Devotional?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete this devotional entry.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteConfirmId && deleteMutation.mutate(deleteConfirmId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
