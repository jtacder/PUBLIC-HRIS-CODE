import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Building2, Users, CalendarClock, Banknote, Shield, Clock, Sparkles, LogIn, ArrowRight, BookOpen } from "lucide-react";
import { AnimatedBackground } from "@/components/background/AnimatedBackground";

export default function LandingPage() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Animated Background - Electrical theme with subtle cables */}
      <AnimatedBackground variant="electrical" />

      {/* Navigation - Enhanced glassmorphism */}
      <nav
        className="fixed top-0 left-0 right-0 z-50"
        style={{
          background: "rgba(8, 8, 14, 0.85)",
          backdropFilter: "blur(16px) saturate(1.2)",
          WebkitBackdropFilter: "blur(16px) saturate(1.2)",
          borderBottom: "1px solid rgba(0, 168, 255, 0.1)",
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#00a8ff] to-[#0052cc] shadow-lg shadow-[#00a8ff]/20">
                  <Building2 className="h-5 w-5 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-amber-400 flex items-center justify-center">
                  <Sparkles className="h-2 w-2 text-amber-800" />
                </div>
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold text-white">JE & REJ TECH</span>
                <span className="text-[10px] text-[#00a8ff] -mt-1">CORP</span>
              </div>
            </div>
            <Button
              asChild
              className="bg-[#00a8ff]/10 hover:bg-[#00a8ff]/20 text-white border border-[#00a8ff]/20 hover:border-[#00a8ff]/40 backdrop-blur-sm transition-all"
              data-testid="button-login"
            >
              <a href="/login" className="flex items-center gap-2">
                <LogIn className="h-4 w-4" />
                Sign In
              </a>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section - Centered CTA */}
      <section aria-labelledby="hero-heading" className="relative min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          {/* Company Badge - Refined */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00a8ff]/8 backdrop-blur-sm border border-[#00a8ff]/15 text-[#00a8ff]/90 text-sm font-medium mb-8">
            <Building2 className="h-4 w-4" />
            Employee Portal & Workforce Management
          </div>

          {/* Main Heading */}
          <h1 id="hero-heading" className="text-4xl sm:text-5xl lg:text-7xl font-bold tracking-tight text-white mb-6">
            <span className="bg-gradient-to-r from-white via-[#00a8ff]/90 to-white bg-clip-text text-transparent">
              JE & REJ TECH CORP
            </span>
          </h1>

          <p className="text-xl sm:text-2xl text-[#00a8ff]/80 font-light mb-4">
            Employee Portal
          </p>

          <p className="text-base sm:text-lg text-slate-400 max-w-2xl mx-auto mb-10">
            Complete workforce management system with attendance tracking,
            automated payroll, and daily spiritual growth through our integrated devotional program.
          </p>

          {/* Main CTA Button - Premium styling with subtle glow */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Button
              size="lg"
              asChild
              className="text-lg px-10 py-7 bg-gradient-to-r from-[#00a8ff] to-[#0052cc] hover:from-[#0080ff] hover:to-[#0052cc] shadow-xl shadow-[#00a8ff]/20 transition-all duration-300 hover:shadow-[#00a8ff]/30 hover:-translate-y-0.5 group"
              data-testid="button-get-started"
            >
              <a href="/login" className="flex items-center gap-3">
                <LogIn className="h-5 w-5" />
                Sign In to Portal
                <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </a>
            </Button>
          </div>

          {/* Feature Pills - Consistent with login page */}
          <div className="flex flex-wrap justify-center items-center gap-4 text-sm">
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-slate-300">
              <Shield className="h-4 w-4 text-emerald-400" />
              <span>Secure Access</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-slate-300">
              <Clock className="h-4 w-4 text-[#ffc107]" />
              <span>Real-time Attendance</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-slate-300">
              <BookOpen className="h-4 w-4 text-[#00a8ff]" />
              <span>Daily Devotionals</span>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 rounded-full border-2 border-white/30 flex items-start justify-center p-2">
            <div className="w-1 h-2 rounded-full bg-white/50 animate-pulse" />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section aria-labelledby="features-heading" className="relative py-24 px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-900/50 to-slate-900/80" />

        <div className="relative max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 id="features-heading" className="text-3xl sm:text-4xl font-bold mb-4 text-white">
              Complete Workforce Solution
            </h2>
            <p className="text-lg text-slate-400 max-w-2xl mx-auto">
              Everything you need to manage your team efficiently
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="bg-[#0d0d14]/80 border-[#00a8ff]/10 backdrop-blur-sm hover:bg-[#0d0d14]/90 hover:border-[#00a8ff]/20 transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-6 space-y-4">
                <div className="h-12 w-12 rounded-xl bg-[#00a8ff]/15 flex items-center justify-center">
                  <Users className="h-6 w-6 text-[#00a8ff]" />
                </div>
                <h3 className="text-xl font-semibold text-white">Employee Management</h3>
                <p className="text-slate-400">
                  Complete 201 file management. Track employee details, government IDs,
                  and employment history in one place.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#0d0d14]/80 border-[#ffc107]/10 backdrop-blur-sm hover:bg-[#0d0d14]/90 hover:border-[#ffc107]/20 transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-6 space-y-4">
                <div className="h-12 w-12 rounded-xl bg-[#ffc107]/15 flex items-center justify-center">
                  <CalendarClock className="h-6 w-6 text-[#ffc107]" />
                </div>
                <h3 className="text-xl font-semibold text-white">Smart Attendance</h3>
                <p className="text-slate-400">
                  Photo verification with GPS tracking. Know exactly when and where
                  your team clocks in and out.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#0d0d14]/80 border-emerald-500/10 backdrop-blur-sm hover:bg-[#0d0d14]/90 hover:border-emerald-500/20 transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-6 space-y-4">
                <div className="h-12 w-12 rounded-xl bg-emerald-500/15 flex items-center justify-center">
                  <Banknote className="h-6 w-6 text-emerald-400" />
                </div>
                <h3 className="text-xl font-semibold text-white">Philippine Payroll</h3>
                <p className="text-slate-400">
                  Automated SSS, PhilHealth, Pag-IBIG, and withholding tax calculations
                  using official tables.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Devotional Highlight Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="relative max-w-4xl mx-auto">
          <Card className="bg-gradient-to-br from-amber-500/10 to-blue-500/10 border-amber-500/20 backdrop-blur-sm overflow-hidden">
            <CardContent className="p-8 sm:p-12">
              <div className="flex flex-col lg:flex-row items-center gap-8">
                <div className="flex-shrink-0">
                  <div className="h-20 w-20 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/30">
                    <BookOpen className="h-10 w-10 text-white" />
                  </div>
                </div>
                <div className="text-center lg:text-left">
                  <h3 className="text-2xl font-bold text-white mb-3">
                    Daily Devotional Program
                  </h3>
                  <p className="text-slate-300 mb-4">
                    Start each workday with spiritual inspiration. Our integrated 365-day
                    devotional plan helps employees grow in faith while excelling in their careers.
                  </p>
                  <div className="flex flex-wrap justify-center lg:justify-start gap-3 text-sm">
                    <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300">Year 1: Foundation</span>
                    <span className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300">Year 2: Growth</span>
                    <span className="px-3 py-1 rounded-full bg-green-500/20 text-green-300">Year 3: Mastery</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6 text-white">
            Ready to Access Your Portal?
          </h2>
          <p className="text-lg text-slate-400 mb-8">
            Sign in to manage your work, track attendance, and receive your daily devotional.
          </p>
          <Button
            size="lg"
            asChild
            className="text-lg px-8 py-6 bg-gradient-to-r from-[#00a8ff] to-[#0052cc] hover:from-[#0080ff] hover:to-[#0052cc] shadow-xl shadow-[#00a8ff]/20 hover:shadow-[#00a8ff]/30 transition-all hover:-translate-y-0.5"
            data-testid="button-cta-get-started"
          >
            <a href="/login" className="flex items-center gap-2">
              <LogIn className="h-5 w-5" />
              Sign In Now
            </a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative border-t border-[#00a8ff]/10 py-8 px-4 sm:px-6 lg:px-8 bg-[#08080c]/50">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-[#00a8ff] to-[#0052cc] flex items-center justify-center">
              <Building2 className="h-4 w-4 text-white" />
            </div>
            <span className="font-semibold text-white">JE & REJ TECH CORP</span>
          </div>
          <p className="text-sm text-slate-500">
            &copy; {new Date().getFullYear()} JE & REJ TECH CORP. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
