import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { PhotoUploader } from "@/components/photo-uploader";
import { getPhotoDisplayUrl, isPdfKey, isObjectStorageKey } from "@/lib/photo-url";
import { useAuth } from "@/hooks/use-auth";
import { usePagination } from "@/hooks/use-pagination";
import { TablePagination } from "@/components/ui/table-pagination";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  Plus,
  Receipt,
  CheckCircle,
  XCircle,
  Clock,
  DollarSign,
  Search,
  Filter,
  Wallet,
  Paperclip,
  Eye,
  FileText,
} from "lucide-react";
import type { Expense, Employee, Project } from "@shared/schema";

const statusConfig: Record<string, { label: string; color: string; icon: any }> = {
  Pending: {
    label: "Pending",
    color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
    icon: Clock,
  },
  Approved: {
    label: "Approved",
    color: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
    icon: CheckCircle,
  },
  Rejected: {
    label: "Rejected",
    color: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
    icon: XCircle,
  },
  Reimbursed: {
    label: "Reimbursed",
    color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
    icon: Wallet,
  },
};

const categoryLabels: Record<string, string> = {
  Material: "Material",
  Equipment: "Equipment",
  Transport: "Transport",
  Food: "Food & Meals",
  Fuel: "Fuel",
  Utilities: "Utilities",
  Communication: "Communication",
  Safety: "Safety Equipment",
  Other: "Other",
};

export default function ExpensesPage() {
  const { toast } = useToast();
  const { user, isSuperadmin, isAdmin: isLegacyAdmin } = useAuth();

  // Check if user can approve/reject expenses (only Admin/HR/superadmin)
  const canApproveExpenses = isSuperadmin || isLegacyAdmin || user?.role === "ADMIN" || user?.role === "HR";
  // Check if user is an Engineer (they can only see their own expenses)
  const isEngineer = user?.role === "ENGINEER";

  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [viewReceiptUrl, setViewReceiptUrl] = useState<string | null>(null);
  const [newExpense, setNewExpense] = useState({
    projectId: "",
    category: "",
    description: "",
    amount: "",
    expenseDate: new Date().toISOString().slice(0, 10),
    requesterId: user?.employeeId || "",
    notes: "",
    receiptUrl: "",
  });

  const { data: expenses = [], isLoading } = useQuery<Expense[]>({
    queryKey: ["/api/expenses"],
  });

  const { data: employees = [] } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const createExpenseMutation = useMutation({
    mutationFn: async (data: typeof newExpense) => {
      const response = await apiRequest("POST", "/api/expenses", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsAddDialogOpen(false);
      setNewExpense({
        projectId: "",
        category: "",
        description: "",
        amount: "",
        expenseDate: new Date().toISOString().slice(0, 10),
        requesterId: "",
        notes: "",
        receiptUrl: "",
      });
      toast({
        title: "Expense Submitted",
        description: "Your expense request has been submitted for approval.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit expense. Please try again.",
        variant: "destructive",
      });
    },
  });

  const approveExpenseMutation = useMutation({
    mutationFn: async (expenseId: string) => {
      const response = await apiRequest("PATCH", `/api/expenses/${expenseId}/approve`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Expense Approved",
        description: "The expense has been approved.",
      });
    },
  });

  const rejectExpenseMutation = useMutation({
    mutationFn: async (expenseId: string) => {
      const response = await apiRequest("PATCH", `/api/expenses/${expenseId}/reject`, {
        rejectionReason: "Not approved",
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Expense Rejected",
        description: "The expense has been rejected.",
      });
    },
  });

  const getEmployeeName = (employeeId: string) => {
    const employee = employees.find((e) => e.id === employeeId);
    return employee ? `${employee.firstName} ${employee.lastName}` : "Unknown";
  };

  const getProjectName = (projectId: string | null | undefined) => {
    if (!projectId) return "-";
    const project = projects.find((p) => p.id === projectId);
    return project?.name || "-";
  };

  const filteredExpenses = expenses.filter((expense) => {
    const matchesSearch =
      expense.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      getEmployeeName(expense.requesterId).toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus =
      statusFilter === "all" || expense.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Pagination
  const pagination = usePagination(filteredExpenses);

  const stats = {
    total: expenses.length,
    pending: expenses.filter((e) => e.status === "Pending").length,
    approved: expenses.filter((e) => e.status === "Approved").length,
    totalAmount: expenses
      .filter((e) => e.status === "Approved" || e.status === "Reimbursed")
      .reduce((sum, e) => sum + parseFloat(e.amount), 0),
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-page-title">
            {isEngineer ? "My Expenses" : "Expense Management"}
          </h1>
          <p className="text-muted-foreground">
            {isEngineer
              ? "Submit and track your project expenses"
              : "Submit, approve, and track project expenses"}
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-expense">
              <Plus className="mr-2 h-4 w-4" />
              Submit Expense
            </Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-hidden flex flex-col">
            <DialogHeader className="flex-shrink-0">
              <DialogTitle>Submit New Expense</DialogTitle>
              <DialogDescription>
                Submit a project expense for approval.
              </DialogDescription>
            </DialogHeader>
            <div className="flex-1 overflow-y-auto space-y-4 py-4 pr-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="project">Project</Label>
                  <Select
                    value={newExpense.projectId}
                    onValueChange={(value) =>
                      setNewExpense({ ...newExpense, projectId: value })
                    }
                  >
                    <SelectTrigger data-testid="select-project">
                      <SelectValue placeholder="Select project" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map((project) => (
                        <SelectItem key={project.id} value={project.id}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Category *</Label>
                  <Select
                    value={newExpense.category}
                    onValueChange={(value) =>
                      setNewExpense({ ...newExpense, category: value })
                    }
                  >
                    <SelectTrigger data-testid="select-category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(categoryLabels).map(([value, label]) => (
                        <SelectItem key={value} value={value}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description *</Label>
                <Input
                  id="description"
                  value={newExpense.description}
                  onChange={(e) =>
                    setNewExpense({ ...newExpense, description: e.target.value })
                  }
                  placeholder="Brief description of the expense"
                  data-testid="input-description"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount (PHP) *</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={newExpense.amount}
                    onChange={(e) =>
                      setNewExpense({ ...newExpense, amount: e.target.value })
                    }
                    placeholder="0.00"
                    data-testid="input-amount"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="expenseDate">Expense Date *</Label>
                  <Input
                    id="expenseDate"
                    type="date"
                    value={newExpense.expenseDate}
                    onChange={(e) =>
                      setNewExpense({ ...newExpense, expenseDate: e.target.value })
                    }
                    data-testid="input-expense-date"
                  />
                </div>
              </div>

              {/* Engineers can only submit expenses for themselves */}
              {isEngineer ? (
                <div className="space-y-2">
                  <Label htmlFor="requester">Requester</Label>
                  <Input
                    value={`${user?.firstName} ${user?.lastName}`}
                    disabled
                    className="bg-muted"
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <Label htmlFor="requester">Requester *</Label>
                  <Select
                    value={newExpense.requesterId}
                    onValueChange={(value) =>
                      setNewExpense({ ...newExpense, requesterId: value })
                    }
                  >
                    <SelectTrigger data-testid="select-requester">
                      <SelectValue placeholder="Who spent this?" />
                    </SelectTrigger>
                    <SelectContent>
                      {employees.map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.firstName} {emp.lastName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={newExpense.notes}
                  onChange={(e) =>
                    setNewExpense({ ...newExpense, notes: e.target.value })
                  }
                  placeholder="Additional notes or justification..."
                  data-testid="input-notes"
                />
              </div>

              <div className="space-y-2">
                <Label>Receipt (Optional)</Label>
                <PhotoUploader
                  value={newExpense.receiptUrl || undefined}
                  onChange={(value) =>
                    setNewExpense({ ...newExpense, receiptUrl: (value as string) || "" })
                  }
                  accept={["image/jpeg", "image/png", "image/webp", "application/pdf"]}
                  maxSizeMB={5}
                  showCamera={true}
                  placeholder="Upload receipt image or PDF"
                />
              </div>
            </div>
            <DialogFooter className="flex-shrink-0 pt-4 border-t">
              <Button
                variant="outline"
                onClick={() => setIsAddDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  // For Engineers, ensure their own employeeId is used
                  const expenseData = isEngineer
                    ? { ...newExpense, requesterId: user?.employeeId || "" }
                    : newExpense;
                  createExpenseMutation.mutate(expenseData);
                }}
                disabled={
                  !newExpense.category ||
                  !newExpense.description ||
                  !newExpense.amount ||
                  (!isEngineer && !newExpense.requesterId) ||
                  createExpenseMutation.isPending
                }
                data-testid="button-submit-expense"
              >
                {createExpenseMutation.isPending ? "Submitting..." : "Submit Expense"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Receipt className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Expenses</p>
              <p className="text-2xl font-bold" data-testid="text-total-expenses">
                {stats.total}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-yellow-100 text-yellow-600 dark:bg-yellow-900/20">
              <Clock className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Pending Approval</p>
              <p className="text-2xl font-bold" data-testid="text-pending-expenses">
                {stats.pending}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100 text-blue-600 dark:bg-blue-900/20">
              <CheckCircle className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Approved</p>
              <p className="text-2xl font-bold" data-testid="text-approved-expenses">
                {stats.approved}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-100 text-green-600 dark:bg-green-900/20">
              <DollarSign className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Approved</p>
              <p className="text-2xl font-bold" data-testid="text-total-amount">
                PHP {stats.totalAmount.toLocaleString()}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="flex flex-col gap-4 p-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search expenses..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              aria-label="Search expenses"
              data-testid="input-search"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-40" data-testid="select-status-filter">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="Pending">Pending</SelectItem>
              <SelectItem value="Approved">Approved</SelectItem>
              <SelectItem value="Rejected">Rejected</SelectItem>
              <SelectItem value="Reimbursed">Reimbursed</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Expenses Table */}
      <Card>
        <CardHeader>
          <CardTitle>{isEngineer ? "My Expense Submissions" : "All Expenses"}</CardTitle>
          <CardDescription>
            {filteredExpenses.length} expense{filteredExpenses.length !== 1 ? "s" : ""} found
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredExpenses.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Receipt className="h-12 w-12 text-muted-foreground/50" />
              <h3 className="mt-4 text-lg font-semibold">No expenses found</h3>
              <p className="text-sm text-muted-foreground">
                {searchQuery || statusFilter !== "all"
                  ? "Try adjusting your filters"
                  : "Submit your first expense request"}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Project</TableHead>
                    {!isEngineer && <TableHead>Requester</TableHead>}
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead>Receipt</TableHead>
                    <TableHead>Status</TableHead>
                    {canApproveExpenses && <TableHead>Actions</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pagination.paginatedData.map((expense) => {
                    const StatusIcon = statusConfig[expense.status]?.icon || Clock;
                    return (
                      <TableRow key={expense.id} data-testid={`row-expense-${expense.id}`}>
                        <TableCell>
                          {format(new Date(expense.expenseDate), "MMM d, yyyy")}
                        </TableCell>
                        <TableCell>
                          <div className="max-w-[200px] truncate" title={expense.description}>
                            {expense.description}
                          </div>
                        </TableCell>
                        <TableCell>
                          {categoryLabels[expense.category] || expense.category}
                        </TableCell>
                        <TableCell>{getProjectName(expense.projectId)}</TableCell>
                        {!isEngineer && <TableCell>{getEmployeeName(expense.requesterId)}</TableCell>}
                        <TableCell className="text-right font-medium">
                          PHP {parseFloat(expense.amount).toLocaleString()}
                        </TableCell>
                        <TableCell>
                          {expense.receiptUrl ? (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                              onClick={() => {
                                const url = getPhotoDisplayUrl(expense.receiptUrl);
                                if (url) {
                                  if (isPdfKey(expense.receiptUrl) || isObjectStorageKey(expense.receiptUrl) && expense.receiptUrl?.endsWith('.pdf')) {
                                    window.open(url, '_blank');
                                  } else {
                                    setViewReceiptUrl(url);
                                  }
                                }
                              }}
                            >
                              {isPdfKey(expense.receiptUrl) ? (
                                <FileText className="h-4 w-4" />
                              ) : (
                                <Eye className="h-4 w-4" />
                              )}
                            </Button>
                          ) : (
                            <span className="text-muted-foreground text-sm">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="secondary"
                            className={statusConfig[expense.status]?.color || ""}
                          >
                            <StatusIcon className="mr-1 h-3 w-3" />
                            {statusConfig[expense.status]?.label || expense.status}
                          </Badge>
                        </TableCell>
                        {canApproveExpenses && (
                          <TableCell>
                            {expense.status === "Pending" && (
                              <div className="flex items-center gap-1">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 text-green-600 hover:text-green-700 hover:bg-green-50"
                                  onClick={() => approveExpenseMutation.mutate(expense.id)}
                                  disabled={approveExpenseMutation.isPending}
                                  data-testid={`button-approve-${expense.id}`}
                                >
                                  <CheckCircle className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                                  onClick={() => rejectExpenseMutation.mutate(expense.id)}
                                  disabled={rejectExpenseMutation.isPending}
                                  data-testid={`button-reject-${expense.id}`}
                                >
                                  <XCircle className="h-4 w-4" />
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        )}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              <TablePagination
                currentPage={pagination.currentPage}
                pageSize={pagination.pageSize}
                totalPages={pagination.totalPages}
                totalItems={pagination.totalItems}
                startIndex={pagination.startIndex}
                endIndex={pagination.endIndex}
                canGoNext={pagination.canGoNext}
                canGoPrevious={pagination.canGoPrevious}
                onPageChange={pagination.goToPage}
                onPageSizeChange={pagination.setPageSize}
                onNextPage={pagination.goToNextPage}
                onPreviousPage={pagination.goToPreviousPage}
                onFirstPage={pagination.goToFirstPage}
                onLastPage={pagination.goToLastPage}
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Receipt Image Viewer Dialog */}
      <Dialog open={!!viewReceiptUrl} onOpenChange={() => setViewReceiptUrl(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] p-0 overflow-hidden">
          <DialogHeader className="p-4 pb-0">
            <DialogTitle>Receipt Image</DialogTitle>
          </DialogHeader>
          <div className="p-4 flex items-center justify-center overflow-auto">
            {viewReceiptUrl && (
              <img
                src={viewReceiptUrl}
                alt="Receipt"
                className="max-w-full max-h-[70vh] object-contain rounded-lg"
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
