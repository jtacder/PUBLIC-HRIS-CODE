import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { getPhotoDisplayUrl } from "@/lib/photo-url";
import { useToast } from "@/hooks/use-toast";
import { PhotoUploader } from "@/components/photo-uploader";
import { useNotificationPreferences, useUpdatePreferences } from "@/hooks/use-notifications";
import { usePushNotifications } from "@/hooks/use-push-notifications";
import { Switch } from "@/components/ui/switch";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  User,
  FileText,
  Briefcase,
  DollarSign,
  AlertTriangle,
  Calendar,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  Shield,
  Wallet,
  TrendingDown,
  CheckCircle2,
  Clock,
  XCircle,
  Palmtree,
  Stethoscope,
  CalendarOff,
  Camera,
  Loader2,
  Bell,
  BellOff,
  Smartphone,
  MailIcon,
  Monitor,
} from "lucide-react";
import type { Employee, DisciplinaryAction, PayrollRecord, EmployeeDocument, CashAdvance } from "@shared/schema";
import { getInitials } from "@/lib/utils";

interface Employee201File {
  employee: Employee;
  documents: EmployeeDocument[];
  disciplinaryHistory: DisciplinaryAction[];
  payrollHistory: PayrollRecord[];
  cashAdvances: CashAdvance[];
}

interface LeaveBalanceBreakdown {
  total: number;
  used: number;
  remaining: number;
  breakdown: Array<{
    leaveTypeId: string;
    leaveTypeName: string;
    allocated: number;
    used: number;
    remaining: number;
    isPaid: boolean;
  }>;
}

const formatCurrency = (amount: string | number | null | undefined) => {
  const value = typeof amount === "string" ? parseFloat(amount) : amount || 0;
  return new Intl.NumberFormat('en-PH', {
    style: 'currency',
    currency: 'PHP',
    minimumFractionDigits: 2
  }).format(value);
};

const getCashAdvanceStatusBadge = (status: string) => {
  switch (status) {
    case "Pending":
      return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
    case "Approved":
      return <Badge variant="secondary" className="bg-blue-100 text-blue-800"><CheckCircle2 className="h-3 w-3 mr-1" />Approved</Badge>;
    case "Disbursed":
      return <Badge variant="secondary" className="bg-green-100 text-green-800"><TrendingDown className="h-3 w-3 mr-1" />Disbursed</Badge>;
    case "Fully_Paid":
      return <Badge variant="default"><CheckCircle2 className="h-3 w-3 mr-1" />Fully Paid</Badge>;
    case "Rejected":
      return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

const statusColors: Record<string, string> = {
  Active: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  Probationary: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  Suspended: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  Terminated: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
};

const getLeaveIcon = (leaveTypeName: string) => {
  const name = leaveTypeName.toLowerCase();
  if (name.includes('vacation') || name.includes('vl')) {
    return <Palmtree className="h-4 w-4 text-green-500" />;
  }
  if (name.includes('sick') || name.includes('sl')) {
    return <Stethoscope className="h-4 w-4 text-red-500" />;
  }
  return <CalendarOff className="h-4 w-4 text-gray-500" />;
};

export default function MyProfilePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isPhotoDialogOpen, setIsPhotoDialogOpen] = useState(false);
  const [newPhotoUrl, setNewPhotoUrl] = useState<string | null>(null);

  const { data: employeeFile, isLoading, error } = useQuery<Employee201File>({
    queryKey: [`/api/employees/${user?.employeeId}/complete-file`],
    enabled: !!user?.employeeId,
  });

  const { data: leaveBalance } = useQuery<LeaveBalanceBreakdown>({
    queryKey: ["/api/my/leave-balance"],
    enabled: !!user?.employeeId,
  });

  const updatePhotoMutation = useMutation({
    mutationFn: async (profilePhotoUrl: string) => {
      const response = await apiRequest("PATCH", "/api/my/profile-photo", { profilePhotoUrl });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/employees/${user?.employeeId}/complete-file`] });
      setIsPhotoDialogOpen(false);
      setNewPhotoUrl(null);
      toast({
        title: "Photo Updated",
        description: "Your profile photo has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile photo. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handlePhotoSave = () => {
    if (newPhotoUrl) {
      updatePhotoMutation.mutate(newPhotoUrl);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  if (error || !employeeFile) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">My Profile</h1>
          <p className="text-muted-foreground">Your 201 employee file</p>
        </div>
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <User className="h-12 w-12 text-muted-foreground/50" />
            <h3 className="mt-4 text-lg font-semibold">Unable to load profile</h3>
            <p className="text-sm text-muted-foreground">
              {error instanceof Error ? error.message : "Please try again later or contact HR"}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <div className="relative group">
          <Avatar className="h-16 w-16 border">
            <AvatarImage src={getPhotoDisplayUrl(employeeFile.employee.profilePhotoUrl) || undefined} />
            <AvatarFallback className="text-xl">
              {getInitials(employeeFile.employee.firstName, employeeFile.employee.lastName)}
            </AvatarFallback>
          </Avatar>
          <button
            onClick={() => {
              setNewPhotoUrl(null);
              setIsPhotoDialogOpen(true);
            }}
            className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
            aria-label="Change profile photo"
          >
            <Camera className="h-6 w-6 text-white" />
          </button>
        </div>
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-page-title">
            {employeeFile.employee.firstName} {employeeFile.employee.lastName}
          </h1>
          <p className="text-muted-foreground">
            {employeeFile.employee.employeeNo} - {employeeFile.employee.position || employeeFile.employee.role}
          </p>
          <Badge
            variant="secondary"
            className={statusColors[employeeFile.employee.status] || ""}
          >
            {employeeFile.employee.status}
          </Badge>
        </div>
      </div>

      {/* Profile Photo Upload Dialog */}
      <Dialog open={isPhotoDialogOpen} onOpenChange={setIsPhotoDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Update Profile Photo</DialogTitle>
            <DialogDescription>
              Upload a new profile photo. The image will be compressed automatically.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <PhotoUploader
              value={newPhotoUrl || undefined}
              onChange={(value) => setNewPhotoUrl(value as string | null)}
              accept={["image/jpeg", "image/png", "image/webp"]}
              maxSizeMB={5}
              showCamera={true}
              isAvatar={true}
              placeholder="Click or drag to upload"
            />
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsPhotoDialogOpen(false);
                setNewPhotoUrl(null);
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handlePhotoSave}
              disabled={!newPhotoUrl || updatePhotoMutation.isPending}
            >
              {updatePhotoMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Photo"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Tabs defaultValue={new URLSearchParams(window.location.search).get("tab") || "personal"} className="space-y-4">
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="personal">
            <User className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Personal</span>
          </TabsTrigger>
          <TabsTrigger value="employment">
            <Briefcase className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Employment</span>
          </TabsTrigger>
          <TabsTrigger value="leaves">
            <Calendar className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Leaves</span>
          </TabsTrigger>
          <TabsTrigger value="payroll">
            <DollarSign className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Payroll</span>
          </TabsTrigger>
          <TabsTrigger value="cash-advances">
            <Wallet className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Cash Adv</span>
          </TabsTrigger>
          <TabsTrigger value="disciplinary">
            <AlertTriangle className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Records</span>
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <Bell className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Alerts</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="personal" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{employeeFile.employee.email || "Not provided"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{employeeFile.employee.phone || "Not provided"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{employeeFile.employee.address || "Not provided"}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Emergency Contact</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span>{employeeFile.employee.emergencyContactName || "Not provided"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{employeeFile.employee.emergencyContactPhone || "Not provided"}</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Government IDs</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 text-sm md:grid-cols-2">
              <div className="flex items-center gap-2">
                <CreditCard className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">SSS Number</p>
                  <p>{employeeFile.employee.sssNo || "Not provided"}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">PhilHealth</p>
                  <p>{employeeFile.employee.philhealthNo || "Not provided"}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <CreditCard className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Pag-IBIG</p>
                  <p>{employeeFile.employee.pagibigNo || "Not provided"}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">TIN</p>
                  <p>{employeeFile.employee.tinNo || "Not provided"}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="employment" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Employment Details</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 text-sm md:grid-cols-2">
              <div>
                <p className="text-xs text-muted-foreground">Position</p>
                <p className="font-medium">{employeeFile.employee.position || "N/A"}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Department</p>
                <p className="font-medium">{employeeFile.employee.department || "N/A"}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Role</p>
                <p className="font-medium">{employeeFile.employee.role}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Status</p>
                <Badge
                  variant="secondary"
                  className={statusColors[employeeFile.employee.status] || ""}
                >
                  {employeeFile.employee.status}
                </Badge>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Start Date</p>
                <p className="font-medium">
                  {employeeFile.employee.startDate
                    ? format(new Date(employeeFile.employee.startDate), "MMMM d, yyyy")
                    : "N/A"}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Base Rate</p>
                <p className="font-medium">
                  PHP {parseFloat(employeeFile.employee.baseRate || "0").toLocaleString()} /{" "}
                  {employeeFile.employee.rateType}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Documents</CardTitle>
            </CardHeader>
            <CardContent>
              {employeeFile.documents.length === 0 ? (
                <p className="text-sm text-muted-foreground">No documents uploaded</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Document</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Uploaded</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employeeFile.documents.map((doc) => (
                      <TableRow key={doc.id}>
                        <TableCell>{doc.documentName}</TableCell>
                        <TableCell>{doc.documentType}</TableCell>
                        <TableCell>
                          {doc.createdAt ? format(new Date(doc.createdAt), "MMM d, yyyy") : "-"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leaves" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Leave Balance Summary</CardTitle>
              <CardDescription>Your leave allocation for this year</CardDescription>
            </CardHeader>
            <CardContent>
              {leaveBalance?.breakdown && leaveBalance.breakdown.length > 0 ? (
                <div className="space-y-4">
                  {leaveBalance.breakdown.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 rounded-lg border">
                      <div className="flex items-center gap-3">
                        {getLeaveIcon(item.leaveTypeName)}
                        <div>
                          <p className="font-medium">{item.leaveTypeName}</p>
                          <p className="text-xs text-muted-foreground">
                            {item.isPaid ? "Paid leave" : "Unpaid leave"}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-lg">{item.remaining} days</p>
                        <p className="text-xs text-muted-foreground">
                          {item.used} used / {item.allocated} allocated
                        </p>
                      </div>
                    </div>
                  ))}
                  <div className="flex items-center justify-between p-3 rounded-lg bg-primary/10 border border-primary/20">
                    <p className="font-semibold">Total Remaining</p>
                    <p className="font-bold text-xl text-primary">{leaveBalance.remaining} days</p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No leave allocations found</p>
                  <p className="text-sm">Contact HR to set up your leave balance</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payroll" className="pt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Recent Payroll History</CardTitle>
            </CardHeader>
            <CardContent>
              {employeeFile.payrollHistory.length === 0 ? (
                <p className="text-sm text-muted-foreground">No payroll records found</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Cutoff</TableHead>
                      <TableHead className="text-right">Gross</TableHead>
                      <TableHead className="text-right">Deductions</TableHead>
                      <TableHead className="text-right">Net Pay</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employeeFile.payrollHistory.map((record) => (
                      <TableRow key={record.id}>
                        <TableCell>
                          {format(new Date(record.cutoffStart), "MMM d")} -{" "}
                          {format(new Date(record.cutoffEnd), "MMM d, yyyy")}
                        </TableCell>
                        <TableCell className="text-right">
                          {formatCurrency(record.grossPay)}
                        </TableCell>
                        <TableCell className="text-right">
                          {formatCurrency(record.totalDeductions)}
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          {formatCurrency(record.netPay)}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{record.status}</Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cash-advances" className="space-y-4">
          {employeeFile.cashAdvances && employeeFile.cashAdvances.length > 0 && (
            <div className="grid gap-4 md:grid-cols-3">
              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-bold">
                        {formatCurrency(
                          employeeFile.cashAdvances
                            .filter(ca => ca.status === "Disbursed")
                            .reduce((sum, ca) => sum + parseFloat(String(ca.remainingBalance) || "0"), 0)
                        )}
                      </p>
                      <p className="text-sm text-muted-foreground">Total Outstanding</p>
                    </div>
                    <Wallet className="h-8 w-8 text-orange-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-bold">
                        {employeeFile.cashAdvances.filter(ca => ca.status === "Disbursed").length}
                      </p>
                      <p className="text-sm text-muted-foreground">Active Advances</p>
                    </div>
                    <TrendingDown className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-bold">
                        {formatCurrency(
                          employeeFile.cashAdvances
                            .filter(ca => ca.status === "Disbursed" && ca.deductionPerCutoff)
                            .reduce((sum, ca) => sum + parseFloat(String(ca.deductionPerCutoff) || "0"), 0)
                        )}
                      </p>
                      <p className="text-sm text-muted-foreground">Deduction/Cutoff</p>
                    </div>
                    <DollarSign className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Cash Advance History</CardTitle>
              <CardDescription>All your cash advance requests and their status</CardDescription>
            </CardHeader>
            <CardContent>
              {!employeeFile.cashAdvances || employeeFile.cashAdvances.length === 0 ? (
                <div className="flex flex-col items-center py-8 text-center">
                  <Wallet className="h-8 w-8 text-muted-foreground/50" />
                  <p className="mt-2 font-medium">No Cash Advances</p>
                  <p className="text-sm text-muted-foreground">
                    You have no cash advance records
                  </p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date Requested</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead className="text-right">Remaining</TableHead>
                      <TableHead className="text-right">Per Cutoff</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Reason</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employeeFile.cashAdvances.map((advance) => (
                      <TableRow key={advance.id}>
                        <TableCell>
                          {advance.createdAt
                            ? format(new Date(advance.createdAt), "MMM d, yyyy")
                            : "-"}
                        </TableCell>
                        <TableCell className="text-right font-semibold">
                          {formatCurrency(advance.amount)}
                        </TableCell>
                        <TableCell className="text-right">
                          {advance.remainingBalance
                            ? formatCurrency(advance.remainingBalance)
                            : "-"}
                        </TableCell>
                        <TableCell className="text-right">
                          {advance.deductionPerCutoff
                            ? formatCurrency(advance.deductionPerCutoff)
                            : "-"}
                        </TableCell>
                        <TableCell>{getCashAdvanceStatusBadge(advance.status)}</TableCell>
                        <TableCell className="max-w-xs truncate text-sm text-muted-foreground">
                          {advance.reason || "-"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="disciplinary" className="pt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Disciplinary History</CardTitle>
            </CardHeader>
            <CardContent>
              {employeeFile.disciplinaryHistory.length === 0 ? (
                <div className="flex flex-col items-center py-8 text-center">
                  <Shield className="h-8 w-8 text-green-500" />
                  <p className="mt-2 font-medium">Clean Record</p>
                  <p className="text-sm text-muted-foreground">
                    No disciplinary actions on file
                  </p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Violation</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Sanction</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employeeFile.disciplinaryHistory.map((action) => (
                      <TableRow key={action.id}>
                        <TableCell>
                          {format(new Date(action.incidentDate), "MMM d, yyyy")}
                        </TableCell>
                        <TableCell>{action.violationType.replace(/_/g, " ")}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{action.status.replace(/_/g, " ")}</Badge>
                        </TableCell>
                        <TableCell>{action.sanction || "-"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4">
          <NotificationPreferencesPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ============================================
// NOTIFICATION PREFERENCES PANEL
// ============================================

const channelInfo = {
  in_app: { label: "In-App", icon: Monitor, description: "Bell icon notifications" },
  push: { label: "Push", icon: Smartphone, description: "Browser push notifications" },
  email: { label: "Email", icon: MailIcon, description: "Email notifications" },
};

function NotificationPreferencesPanel() {
  const { toast } = useToast();
  const { data: prefs, isLoading } = useNotificationPreferences();
  const updatePrefs = useUpdatePreferences();
  const pushNotif = usePushNotifications();

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-20" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  if (!prefs) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <BellOff className="h-8 w-8 mx-auto text-muted-foreground/50" />
          <p className="mt-2 text-sm text-muted-foreground">Unable to load notification preferences</p>
        </CardContent>
      </Card>
    );
  }

  const handleMasterToggle = (enabled: boolean) => {
    updatePrefs.mutate(
      { enabled },
      {
        onSuccess: () => {
          toast({
            title: enabled ? "Notifications Enabled" : "Notifications Disabled",
            description: enabled
              ? "You will receive notifications based on your preferences."
              : "All notifications have been turned off.",
          });
        },
      }
    );
  };

  const handleCategoryToggle = (category: string, channel: string, value: boolean) => {
    const updatedPrefs = { ...prefs.preferences };
    if (!updatedPrefs[category]) {
      updatedPrefs[category] = { in_app: true, push: false, email: false };
    }
    updatedPrefs[category] = { ...updatedPrefs[category], [channel]: value };

    updatePrefs.mutate(
      { preferences: updatedPrefs },
      {
        onSuccess: () => {
          toast({ title: "Preference Updated", description: "Your notification preference has been saved." });
        },
      }
    );
  };

  const handlePushSubscribe = () => {
    pushNotif.subscribe();
    toast({
      title: "Enabling Push Notifications",
      description: "Please allow notifications when your browser prompts you.",
    });
  };

  const handlePushUnsubscribe = () => {
    pushNotif.unsubscribe();
    toast({
      title: "Push Notifications Disabled",
      description: "You will no longer receive browser push notifications on this device.",
    });
  };

  const categories = prefs.categories || {};

  return (
    <div className="space-y-4">
      {/* Master Toggle */}
      <Card>
        <CardContent className="flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-full ${prefs.enabled ? "bg-primary/10" : "bg-muted"}`}>
              {prefs.enabled ? (
                <Bell className="h-5 w-5 text-primary" />
              ) : (
                <BellOff className="h-5 w-5 text-muted-foreground" />
              )}
            </div>
            <div>
              <p className="font-semibold">Notifications</p>
              <p className="text-xs text-muted-foreground">
                {prefs.enabled ? "Notifications are active" : "All notifications are paused"}
              </p>
            </div>
          </div>
          <Switch
            checked={prefs.enabled}
            onCheckedChange={handleMasterToggle}
            disabled={updatePrefs.isPending}
          />
        </CardContent>
      </Card>

      {/* Push Notification Subscription */}
      {prefs.enabled && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Smartphone className="h-4 w-4" />
              Browser Push Notifications
            </CardTitle>
            <CardDescription>
              Receive notifications even when the app is not open in your browser
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {!pushNotif.isSupported ? (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted">
                <BellOff className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Not Supported</p>
                  <p className="text-xs text-muted-foreground">
                    Your browser does not support push notifications. Try using Chrome, Edge, or Firefox.
                  </p>
                </div>
              </div>
            ) : !pushNotif.isEnabled ? (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted">
                <BellOff className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Push Not Configured</p>
                  <p className="text-xs text-muted-foreground">
                    Push notifications are not configured on the server. Contact your administrator.
                  </p>
                </div>
              </div>
            ) : pushNotif.permission === "denied" ? (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-destructive/10 border border-destructive/20">
                <BellOff className="h-5 w-5 text-destructive" />
                <div>
                  <p className="text-sm font-medium text-destructive">Notifications Blocked</p>
                  <p className="text-xs text-muted-foreground">
                    You have blocked notifications for this site. To enable them, click the lock icon
                    in your browser's address bar, find "Notifications", and change it to "Allow".
                  </p>
                </div>
              </div>
            ) : pushNotif.isSubscribed ? (
              <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-900">
                <div className="flex items-center gap-3">
                  <div className="p-1.5 rounded-full bg-green-100 dark:bg-green-900">
                    <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">Push Notifications Active</p>
                    <p className="text-xs text-muted-foreground">
                      This device is receiving push notifications
                    </p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handlePushUnsubscribe}
                  disabled={pushNotif.isUnsubscribing}
                >
                  {pushNotif.isUnsubscribing ? (
                    <><Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />Disabling...</>
                  ) : (
                    "Disable"
                  )}
                </Button>
              </div>
            ) : (
              <div className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className="p-1.5 rounded-full bg-muted">
                    <Smartphone className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">Enable Push Notifications</p>
                    <p className="text-xs text-muted-foreground">
                      Get notified on this device even when the app is closed
                    </p>
                  </div>
                </div>
                <Button
                  size="sm"
                  onClick={handlePushSubscribe}
                  disabled={pushNotif.isSubscribing}
                >
                  {pushNotif.isSubscribing ? (
                    <><Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />Enabling...</>
                  ) : (
                    "Enable"
                  )}
                </Button>
              </div>
            )}
            {pushNotif.error && (
              <p className="text-xs text-destructive">
                {pushNotif.error instanceof Error ? pushNotif.error.message : "Failed to update push notification settings"}
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Category Preferences */}
      {prefs.enabled && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Category Preferences</CardTitle>
            <CardDescription>
              Choose which notifications you want to receive and how
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              {/* Channel headers */}
              <div className="grid grid-cols-[1fr_80px_80px_80px] gap-2 pb-2 border-b text-xs font-medium text-muted-foreground">
                <div>Category</div>
                {Object.entries(channelInfo).map(([key, info]) => (
                  <div key={key} className="text-center flex flex-col items-center gap-0.5">
                    <info.icon className="h-3.5 w-3.5" />
                    <span>{info.label}</span>
                  </div>
                ))}
              </div>

              {/* Category rows */}
              {Object.entries(categories).map(([category, info]) => {
                const categoryPrefs = prefs.preferences[category] || { in_app: true, push: false, email: false };
                return (
                  <div
                    key={category}
                    className="grid grid-cols-[1fr_80px_80px_80px] gap-2 py-3 border-b last:border-b-0 items-center"
                  >
                    <div>
                      <p className="text-sm font-medium">{info.label}</p>
                      <p className="text-xs text-muted-foreground">{info.description}</p>
                    </div>
                    {Object.keys(channelInfo).map((channel) => (
                      <div key={channel} className="flex justify-center">
                        <Switch
                          checked={categoryPrefs[channel] ?? false}
                          onCheckedChange={(value) => handleCategoryToggle(category, channel, value)}
                          disabled={updatePrefs.isPending}
                          className="scale-90"
                        />
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
