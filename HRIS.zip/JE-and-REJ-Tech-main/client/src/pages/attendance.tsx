import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { usePagination } from "@/hooks/use-pagination";
import { getPhotoDisplayUrl } from "@/lib/photo-url";
import { TablePagination } from "@/components/ui/table-pagination";

type AttendanceFilter = "all" | "late" | "ot" | "undertime";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { SearchableEmployeeSelect } from "@/components/searchable-employee-select";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CalendarClock,
  Camera,
  Info,
  MapPin,
  Clock,
  CheckCircle,
  XCircle,
  RefreshCw,
  Wifi,
  WifiOff,
  Loader2,
  QrCode,
  ScanLine,
  Pencil,
  Trash2,
  MoreHorizontal,
  Plus,
  ExternalLink,
  MapPinOff,
  AlertTriangle,
  Copy,
  ImageOff,
} from "lucide-react";
import { 
  formatTime, 
  formatDate, 
  formatDateTime,
  getInitials, 
  getStatusColorClass 
} from "@/lib/utils";
import { format } from "date-fns";
import { QRScanner } from "@/components/qr-scanner";
import { BulkAttendanceUpload } from "@/components/bulk-attendance-upload";
import type { Employee, AttendanceLog } from "@shared/schema";

type LocationState = "searching" | "success" | "error";
type ClockStep = "scan" | "photo" | "success";
type ClockAction = "in" | "out";

// Interface for clock-in status check response
interface ClockInStatus {
  employeeId: string;
  employeeName: string;
  employeeNo: string;
  isDayOff: boolean;
  isOnLeave: boolean;
  leaveTypeName: string | null;
  scheduledWorkDays: string[];
  todayName: string;
  requiresConfirmation: boolean;
  message: string | null;
}

// Convert datetime-local value to ISO string with Philippine timezone
function toPhilippineISOString(datetimeLocal: string): string {
  if (!datetimeLocal) return "";
  // datetime-local format is "YYYY-MM-DDTHH:mm"
  // Append Philippine timezone offset (+08:00)
  return `${datetimeLocal}:00+08:00`;
}

// Convert a UTC timestamp to Philippine timezone datetime-local format
// date.getTime() returns UTC milliseconds, so we just add 8 hours to get PHT
function toPhilippineDatetimeLocal(isoString: string | Date | null): string {
  if (!isoString) return "";
  const date = typeof isoString === "string" ? new Date(isoString) : isoString;
  if (isNaN(date.getTime())) return "";
  
  // Convert to Philippine time (UTC+8) - add 8 hours to UTC timestamp
  const phtTime = new Date(date.getTime() + (8 * 60 * 60 * 1000));
  
  // Format as YYYY-MM-DDTHH:mm for datetime-local input using UTC methods
  // since phtTime is already shifted to PHT
  const year = phtTime.getUTCFullYear();
  const month = String(phtTime.getUTCMonth() + 1).padStart(2, "0");
  const day = String(phtTime.getUTCDate()).padStart(2, "0");
  const hours = String(phtTime.getUTCHours()).padStart(2, "0");
  const minutes = String(phtTime.getUTCMinutes()).padStart(2, "0");
  
  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

export default function AttendancePage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Filter state for attendance logs
  const [activeFilter, setActiveFilter] = useState<AttendanceFilter>("all");
  const [employeeFilter, setEmployeeFilter] = useState<string>("all");
  
  // React to URL changes for filter (when navigating from dashboard widgets)
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const filterParam = urlParams.get("filter") as AttendanceFilter;
    if (filterParam && ["all", "late", "ot", "undertime"].includes(filterParam)) {
      setActiveFilter(filterParam);
    }
  }, []);
  
  const [step, setStep] = useState<ClockStep>("scan");
  const [clockAction, setClockAction] = useState<ClockAction>("in");
  const [scannedEmployee, setScannedEmployee] = useState<{ token: string; name: string; employeeNo: string; employeeId?: string } | null>(null);
  const [existingLogId, setExistingLogId] = useState<string | null>(null);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationAccuracy, setLocationAccuracy] = useState<number | null>(null);
  const [locationStatus, setLocationStatus] = useState<LocationState>("searching");
  const watchIdRef = useRef<number | null>(null);
  const [isCapturing, setIsCapturing] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [clockedInEmployee, setClockedInEmployee] = useState<{ id: string; firstName: string; lastName: string; employeeNo: string } | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isManualDialogOpen, setIsManualDialogOpen] = useState(false);
  const [selectedLog, setSelectedLog] = useState<AttendanceLog | null>(null);
  const [otApprovalPopover, setOtApprovalPopover] = useState<{ logId: string; minutes: string } | null>(null);
  const [editForm, setEditForm] = useState({
    timeIn: "",
    timeOut: "",
    lateMinutes: "",
    verificationStatus: "",
    otStatus: "Pending" as "Pending" | "Approved" | "Rejected",
    otMinutesApproved: "",
    otReason: "",
    lunchPaid: false,
  });
  const [manualForm, setManualForm] = useState({
    employeeId: "",
    timeIn: "",
    timeOut: "",
    verificationStatus: "Verified",
  });

  // State for day off / leave confirmation dialog
  const [isScheduleConfirmOpen, setIsScheduleConfirmOpen] = useState(false);
  const [clockInStatus, setClockInStatus] = useState<ClockInStatus | null>(null);
  const [pendingQRData, setPendingQRData] = useState<{ token: string; name: string; employeeNo: string } | null>(null);
  const [isCheckingStatus, setIsCheckingStatus] = useState(false);

  // State for geofencing error dialog
  const [isGeofenceErrorOpen, setIsGeofenceErrorOpen] = useState(false);
  const [geofenceError, setGeofenceError] = useState<{ message: string; distance: number; distanceKm?: number } | null>(null);

  // State for schedule override dialog
  const [isScheduleOverrideOpen, setIsScheduleOverrideOpen] = useState(false);
  const [scheduleOverrideForm, setScheduleOverrideForm] = useState({
    scheduledShiftStartOverride: "",
    scheduledShiftEndOverride: "",
  });

  // State for photo preview modal
  const [photoPreview, setPhotoPreview] = useState<{ url: string; employeeName: string; timeIn: string } | null>(null);

  const { data: employees, isLoading: employeesLoading } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const [dateRange, setDateRange] = useState({
    start: new Date().toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0],
  });

  const { data: attendanceLogs, isLoading: attendanceLoading } = useQuery<AttendanceLog[]>({
    queryKey: (user?.role === "ADMIN" || user?.role === "HR") 
      ? [`/api/attendance?startDate=${dateRange.start}&endDate=${dateRange.end}`]
      : ["/api/attendance/today"],
  });

  const employeeMap = new Map(employees?.map(e => [e.id, e]) || []);

  // Filter attendance logs based on active filter and employee filter
  const filteredAttendance = useMemo(() => {
    if (!attendanceLogs) return [];

    let filtered = attendanceLogs;

    // Apply employee filter
    if (employeeFilter !== "all") {
      filtered = filtered.filter(log => log.employeeId === employeeFilter);
    }

    // Apply status filter
    switch (activeFilter) {
      case "late":
        return filtered.filter(log => log.isLate);
      case "ot":
        return filtered.filter(log =>
          log.otStatus === "Pending" &&
          ((log.overtimeMinutes && Number(log.overtimeMinutes) > 0) || log.isOvertimeSession)
        );
      case "undertime":
        return filtered.filter(log =>
          log.undertimeMinutes && Number(log.undertimeMinutes) > 0
        );
      default:
        return filtered;
    }
  }, [attendanceLogs, activeFilter, employeeFilter]);

  // Pagination
  const pagination = usePagination(filteredAttendance);

  // GPS accuracy thresholds
  const EXCELLENT_ACCURACY = 20;    // Ideal GPS accuracy (20m or better)
  const GOOD_ACCURACY = 50;         // Acceptable accuracy for geofencing
  const POOR_ACCURACY = 100;        // Poor accuracy - will trigger warning
  const MAX_SAMPLES = 5;            // Collect multiple samples for better accuracy
  const MAX_WAIT_TIME = 15000;      // Maximum time to wait for better accuracy (15s)

  // Track best GPS reading
  const bestLocationRef = useRef<{ lat: number; lng: number; accuracy: number } | null>(null);
  const sampleCountRef = useRef(0);
  const startTimeRef = useRef<number>(0);

  // Start GPS tracking with multi-sample accuracy improvement
  const startGPSTracking = () => {
    if (!navigator.geolocation) {
      setLocationStatus("error");
      return;
    }

    setLocationStatus("searching");
    setLocation(null);
    setLocationAccuracy(null);
    bestLocationRef.current = null;
    sampleCountRef.current = 0;
    startTimeRef.current = Date.now();

    // Clear any existing watch
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
    }

    // Use watchPosition to collect multiple samples and pick the best one
    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        const accuracy = position.coords.accuracy;
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        const elapsedTime = Date.now() - startTimeRef.current;
        sampleCountRef.current++;

        // Track the best (most accurate) reading we've received
        if (!bestLocationRef.current || accuracy < bestLocationRef.current.accuracy) {
          bestLocationRef.current = { lat, lng, accuracy };
        }

        // Always update UI with current best reading
        setLocation({ lat: bestLocationRef.current.lat, lng: bestLocationRef.current.lng });
        setLocationAccuracy(bestLocationRef.current.accuracy);

        // Decision logic for when to accept the reading
        const currentBestAccuracy = bestLocationRef.current.accuracy;

        // Excellent accuracy - accept immediately
        if (currentBestAccuracy <= EXCELLENT_ACCURACY) {
          setLocationStatus("success");
          if (watchIdRef.current !== null) {
            navigator.geolocation.clearWatch(watchIdRef.current);
            watchIdRef.current = null;
          }
          return;
        }

        // Good accuracy with enough samples - accept
        if (currentBestAccuracy <= GOOD_ACCURACY && sampleCountRef.current >= 3) {
          setLocationStatus("success");
          if (watchIdRef.current !== null) {
            navigator.geolocation.clearWatch(watchIdRef.current);
            watchIdRef.current = null;
          }
          return;
        }

        // Acceptable accuracy after waiting or max samples - accept with warning
        if (sampleCountRef.current >= MAX_SAMPLES || elapsedTime >= MAX_WAIT_TIME) {
          // Accept what we have, but status reflects accuracy quality
          if (currentBestAccuracy <= POOR_ACCURACY) {
            setLocationStatus("success");
          } else {
            // Poor accuracy but allow clock-in (will be flagged server-side)
            setLocationStatus("success");
          }
          if (watchIdRef.current !== null) {
            navigator.geolocation.clearWatch(watchIdRef.current);
            watchIdRef.current = null;
          }
          return;
        }

        // Still searching for better accuracy
        setLocationStatus("searching");
      },
      (error) => {
        console.error("GPS Error:", error.message);
        // If we have any reading, use it despite the error
        if (bestLocationRef.current) {
          setLocation({ lat: bestLocationRef.current.lat, lng: bestLocationRef.current.lng });
          setLocationAccuracy(bestLocationRef.current.accuracy);
          setLocationStatus("success");
        } else {
          setLocationStatus("error");
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 30000,
        maximumAge: 0 // Always get fresh position
      }
    );
  };

  // Get location on mount
  useEffect(() => {
    startGPSTracking();

    // Cleanup on unmount
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  // Initialize camera when moving to photo step.
  // A short delay is added before calling getUserMedia to give the QR scanner's
  // html5-qrcode library time to fully release the camera device. On desktop
  // systems with a single webcam, starting getUserMedia before the scanner's
  // async stop() completes can result in a locked/degraded camera stream.
  useEffect(() => {
    let stream: MediaStream | null = null;
    let cancelled = false;

    const initCamera = async () => {
      if (step !== "photo") return;

      // Wait briefly for the QR scanner to release the camera
      await new Promise(resolve => setTimeout(resolve, 300));
      if (cancelled) return;

      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "user", width: 640, height: 480 }
        });
        if (cancelled) {
          // Effect was cleaned up while we were awaiting — release immediately
          stream.getTracks().forEach(track => track.stop());
          return;
        }
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => {
            setIsCameraReady(true);
          };
        }
      } catch (err) {
        console.error("Camera error:", err);
        if (!cancelled) {
          setCameraError("Unable to access camera. Please grant camera permissions.");
        }
      }
    };

    initCamera();

    return () => {
      cancelled = true;
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [step]);

  const clockInMutation = useMutation({
    mutationFn: async (data: {
      qrToken: string;
      photoSnapshotUrl: string;
      locationLat: number;
      locationLng: number;
      locationSource: string;
      locationAccuracy?: number;
    }) => {
      const response = await apiRequest("POST", "/api/attendance/clock-in", data);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ predicate: (query) => 
        query.queryKey[0]?.toString().startsWith("/api/attendance") ?? false
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setClockedInEmployee(data.employee);
      setStep("success");
      toast({
        title: "Clocked In Successfully",
        description: `${data.employee.firstName} ${data.employee.lastName} has been clocked in.`,
      });
    },
    onError: (error: any) => {
      // Check if this is a geofencing error
      if (error.code === "OUTSIDE_GEOFENCE") {
        setGeofenceError({
          message: error.message,
          distance: error.distance || 0,
          distanceKm: error.distanceKm,
        });
        setIsGeofenceErrorOpen(true);
      } else {
        toast({
          title: "Clock In Failed",
          description: error.message || "Failed to record attendance. Please try again.",
          variant: "destructive",
        });
      }
      setStep("scan");
      setScannedEmployee(null);
    },
  });

  const clockOutMutation = useMutation({
    mutationFn: async (attendanceId: string) => {
      const response = await apiRequest("POST", "/api/attendance/clock-out", { attendanceId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ predicate: (query) => 
        query.queryKey[0]?.toString().startsWith("/api/attendance") ?? false
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setStep("success");
      toast({
        title: "Clocked Out Successfully",
        description: `${scannedEmployee?.name || "Employee"} has been clocked out.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Clock Out Failed",
        description: error.message || "Failed to clock out. Please try again.",
        variant: "destructive",
      });
      setStep("scan");
      setScannedEmployee(null);
    },
  });

  const updateAttendanceMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const response = await apiRequest("PATCH", `/api/attendance/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ predicate: (query) =>
        query.queryKey[0]?.toString().startsWith("/api/attendance") ?? false
      });
      setIsEditDialogOpen(false);
      setSelectedLog(null);
      toast({
        title: "Attendance Updated",
        description: "Attendance record has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update attendance record.",
        variant: "destructive",
      });
    },
  });

  // Quick OT approval/denial mutation (for table buttons)
  const quickOTMutation = useMutation({
    mutationFn: async ({ id, action, overtimeMinutes }: { id: string; action: "approve" | "deny"; overtimeMinutes: number }) => {
      const data = action === "approve"
        ? { otStatus: "Approved", otMinutesApproved: overtimeMinutes, overtimeApproved: true }
        : { otStatus: "Rejected", otMinutesApproved: 0, overtimeApproved: false };
      const response = await apiRequest("PATCH", `/api/attendance/${id}`, data);
      return response.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ predicate: (query) =>
        query.queryKey[0]?.toString().startsWith("/api/attendance") ?? false
      });
      toast({
        title: variables.action === "approve" ? "OT Approved" : "OT Denied",
        description: variables.action === "approve"
          ? "Overtime has been approved successfully."
          : "Overtime has been denied.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update OT status.",
        variant: "destructive",
      });
    },
  });

  const deleteAttendanceMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/attendance/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ predicate: (query) => 
        query.queryKey[0]?.toString().startsWith("/api/attendance") ?? false
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsDeleteDialogOpen(false);
      setSelectedLog(null);
      toast({
        title: "Attendance Deleted",
        description: "Attendance record has been deleted successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete attendance record.",
        variant: "destructive",
      });
    },
  });

  const createManualAttendanceMutation = useMutation({
    mutationFn: async (data: {
      employeeId: string;
      timeIn: string;
      timeOut?: string;
      verificationStatus: string;
    }) => {
      const response = await apiRequest("POST", "/api/attendance/manual", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ predicate: (query) => 
        query.queryKey[0]?.toString().startsWith("/api/attendance") ?? false
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsManualDialogOpen(false);
      setManualForm({
        employeeId: "",
        timeIn: "",
        timeOut: "",
        verificationStatus: "Verified",
      });
      toast({
        title: "Attendance Created",
        description: "Manual attendance record has been created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create attendance record.",
        variant: "destructive",
      });
    },
  });

  const scheduleOverrideMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: { scheduledShiftStartOverride: string; scheduledShiftEndOverride: string } }) => {
      const response = await apiRequest("PATCH", `/api/attendance/${id}/schedule-override`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ predicate: (query) =>
        query.queryKey[0]?.toString().startsWith("/api/attendance") ?? false
      });
      setIsScheduleOverrideOpen(false);
      setSelectedLog(null);
      setScheduleOverrideForm({
        scheduledShiftStartOverride: "",
        scheduledShiftEndOverride: "",
      });
      toast({
        title: "Schedule Updated",
        description: "Schedule override has been applied and late/OT recalculated.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to apply schedule override.",
        variant: "destructive",
      });
    },
  });

  const handleScheduleOverride = (log: AttendanceLog) => {
    setSelectedLog(log);
    // Pre-fill with current override values or original schedule
    setScheduleOverrideForm({
      scheduledShiftStartOverride: log.scheduledShiftStartOverride || log.scheduledShiftStart || "08:00",
      scheduledShiftEndOverride: log.scheduledShiftEndOverride || log.scheduledShiftEnd || "17:00",
    });
    setIsScheduleOverrideOpen(true);
  };

  const handleSaveScheduleOverride = () => {
    if (!selectedLog) return;
    scheduleOverrideMutation.mutate({
      id: selectedLog.id,
      data: scheduleOverrideForm,
    });
  };

  const handleEditLog = (log: AttendanceLog) => {
    setSelectedLog(log);
    setEditForm({
      timeIn: toPhilippineDatetimeLocal(log.timeIn),
      timeOut: toPhilippineDatetimeLocal(log.timeOut),
      lateMinutes: log.lateMinutes?.toString() || "0",
      verificationStatus: log.verificationStatus || "Pending",
      otStatus: (log.otStatus as "Pending" | "Approved" | "Rejected") || "Pending",
      otMinutesApproved: log.otMinutesApproved?.toString() || log.overtimeMinutes?.toString() || "0",
      otReason: log.otReason || "",
      lunchPaid: log.lunchPaid ?? false,
    });
    setIsEditDialogOpen(true);
  };

  const handleDeleteLog = (log: AttendanceLog) => {
    setSelectedLog(log);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (selectedLog) {
      deleteAttendanceMutation.mutate(selectedLog.id);
    }
  };

  const handleSaveEdit = () => {
    if (!selectedLog) return;

    updateAttendanceMutation.mutate({
      id: selectedLog.id,
      data: {
        timeIn: editForm.timeIn ? toPhilippineISOString(editForm.timeIn) : null,
        timeOut: editForm.timeOut ? toPhilippineISOString(editForm.timeOut) : null,
        lateMinutes: parseInt(editForm.lateMinutes) || 0,
        verificationStatus: editForm.verificationStatus,
        lunchPaid: editForm.lunchPaid,
      },
    });
  };

  // Helper function to proceed with clock-in/out after confirmation
  const proceedToPhotoStep = useCallback((qrData: { token: string; name: string; employeeNo: string }, isClockOut: boolean, logId: string | null, empToken: string) => {
    if (isClockOut && logId) {
      setClockAction("out");
      setExistingLogId(logId);
      setScannedEmployee({ ...qrData, token: empToken });
    } else {
      setClockAction("in");
      setExistingLogId(null);
      setScannedEmployee({ ...qrData, token: empToken });
    }
    setStep("photo");
    setIsCameraReady(false);
    setCameraError(null);
  }, []);

  // Handle confirmation dialog result - proceed with clock-in
  const handleScheduleConfirm = useCallback(() => {
    if (pendingQRData) {
      const employee = employees?.find(e => e.qrToken === pendingQRData.token);
      const targetEmployee = employee || employees?.find(e => e.employeeNo === pendingQRData.employeeNo);
      const empToken = targetEmployee?.qrToken || pendingQRData.token;

      proceedToPhotoStep(pendingQRData, false, null, empToken);
    }
    setIsScheduleConfirmOpen(false);
    setPendingQRData(null);
    setClockInStatus(null);
  }, [pendingQRData, employees, proceedToPhotoStep]);

  // Handle confirmation dialog cancel
  const handleScheduleCancel = useCallback(() => {
    setIsScheduleConfirmOpen(false);
    setPendingQRData(null);
    setClockInStatus(null);
  }, []);

  const handleQRScanSuccess = useCallback(async (qrData: { token: string; name: string; employeeNo: string }) => {
    // Check if this employee already has an active clock-in today (no clock-out yet)
    // Find employee by token
    const employee = employees?.find(e => e.qrToken === qrData.token);

    // If not found by token, try finding by employeeNo in qrData
    const targetEmployee = employee || employees?.find(e => e.employeeNo === qrData.employeeNo);
    const empToken = targetEmployee?.qrToken || qrData.token;

    if (targetEmployee) {
      const existingLog = attendanceLogs?.find(log =>
        log.employeeId === targetEmployee.id && !log.timeOut
      );

      if (existingLog) {
        // Employee has an active clock-in, show clock-out option (no need to check status)
        proceedToPhotoStep(qrData, true, existingLog.id, empToken);
        return;
      }
    }

    // For clock-in: Check schedule status (day off / leave)
    setIsCheckingStatus(true);
    try {
      const response = await fetch(`/api/attendance/clock-in-status/${encodeURIComponent(empToken)}`, {
        credentials: "include",
      });

      if (response.ok) {
        const status: ClockInStatus = await response.json();

        if (status.requiresConfirmation) {
          // Show confirmation dialog
          setClockInStatus(status);
          setPendingQRData(qrData);
          setIsScheduleConfirmOpen(true);
          setIsCheckingStatus(false);
          return;
        }
      }
      // If no confirmation needed or status check failed, proceed normally
    } catch (error) {
      console.error("Error checking clock-in status:", error);
      // On error, allow proceeding (fail open)
    }
    setIsCheckingStatus(false);

    // Proceed with clock-in
    proceedToPhotoStep(qrData, false, null, empToken);
  }, [employees, attendanceLogs, proceedToPhotoStep]);

  const captureAndClock = useCallback(() => {
    if (!videoRef.current || !canvasRef.current || !scannedEmployee) {
      return;
    }

    setIsCapturing(true);

    const canvas = canvasRef.current;
    const video = videoRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.drawImage(video, 0, 0);
      const imageData = canvas.toDataURL("image/jpeg", 0.8);
      setCapturedImage(imageData);

      if (clockAction === "out" && existingLogId) {
        // Clock out - just needs the attendance ID
        clockOutMutation.mutate(existingLogId);
      } else if (location) {
        // Clock in - needs photo, location, etc.
        clockInMutation.mutate({
          qrToken: scannedEmployee.token,
          photoSnapshotUrl: imageData,
          locationLat: location.lat,
          locationLng: location.lng,
          locationSource: "GPS",
          locationAccuracy: locationAccuracy || undefined,
        });
      }
    }

    setIsCapturing(false);
  }, [scannedEmployee, location, locationAccuracy, clockInMutation, clockOutMutation, clockAction, existingLogId]);

  const resetClock = () => {
    setStep("scan");
    setScannedEmployee(null);
    setCapturedImage(null);
    setClockedInEmployee(null);
    setIsCameraReady(false);
    setCameraError(null);
    setClockAction("in");
    setExistingLogId(null);
  };

  const canCapturePhoto = isCameraReady && (clockAction === "out" || location) && !clockInMutation.isPending && !clockOutMutation.isPending;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Attendance</h1>
          <p className="text-muted-foreground">
            Scan QR code badge to clock in/out with photo verification
          </p>
        </div>
        {(user?.role === "ADMIN" || user?.role === "HR") && (
          <div className="flex items-center gap-2">
            <BulkAttendanceUpload />
            <Button
              onClick={() => setIsManualDialogOpen(true)}
              variant="outline"
              size="sm"
              data-testid="button-add-manual-attendance"
            >
              <Plus className="mr-2 h-4 w-4" />
              Manual Entry
            </Button>
          </div>
        )}
      </div>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {step === "scan" && <QrCode className="h-5 w-5" />}
              {step === "photo" && <Camera className="h-5 w-5" />}
              {step === "success" && <CheckCircle className="h-5 w-5 text-green-500" />}
              {step === "scan" && "Scan QR Badge"}
              {step === "photo" && (clockAction === "out" ? "Confirm Clock Out" : "Take Photo")}
              {step === "success" && (clockAction === "out" ? "Clock Out Complete" : "Clock In Complete")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {step === "scan" && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-sm mb-4">
                  {location ? (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Badge 
                          variant="outline" 
                          className="gap-1.5 cursor-help text-green-600 border-green-200 dark:border-green-800"
                          data-testid="badge-gps-status"
                        >
                          <MapPin className="h-3 w-3" />
                          GPS Located
                          <Info className="h-3 w-3 text-muted-foreground" />
                        </Badge>
                      </TooltipTrigger>
                      <TooltipContent side="bottom" className="text-xs max-w-[280px]">
                        <div className="space-y-2">
                          <p className="font-medium flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            Your Location
                          </p>
                          <div className="space-y-1 font-mono text-[11px]">
                            <div className="flex justify-between gap-3">
                              <span className="text-muted-foreground">Latitude:</span>
                              <span data-testid="text-gps-lat">{location.lat.toFixed(7)}</span>
                            </div>
                            <div className="flex justify-between gap-3">
                              <span className="text-muted-foreground">Longitude:</span>
                              <span data-testid="text-gps-lng">{location.lng.toFixed(7)}</span>
                            </div>
                          </div>
                          {locationAccuracy && (
                            <div data-testid="text-gps-accuracy">
                              <p className={`text-xs ${
                                locationAccuracy <= 20 ? "text-green-600 dark:text-green-400" :
                                locationAccuracy <= 50 ? "text-blue-600 dark:text-blue-400" :
                                locationAccuracy <= 100 ? "text-yellow-600 dark:text-yellow-400" :
                                "text-red-600 dark:text-red-400"
                              }`}>
                                Accuracy: ±{Math.round(locationAccuracy)}m
                                {locationAccuracy <= 20 && " (Excellent)"}
                                {locationAccuracy > 20 && locationAccuracy <= 50 && " (Good)"}
                                {locationAccuracy > 50 && locationAccuracy <= 100 && " (Fair)"}
                                {locationAccuracy > 100 && " (Poor - may be cell tower)"}
                              </p>
                              {locationAccuracy > 100 && (
                                <p className="text-[10px] text-orange-600 dark:text-orange-400 mt-1">
                                  Try moving outdoors for better GPS signal
                                </p>
                              )}
                            </div>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            className="w-full h-7 text-xs"
                            onClick={(e) => {
                              e.stopPropagation();
                              navigator.clipboard.writeText(`${location.lat.toFixed(7)}, ${location.lng.toFixed(7)}`);
                              toast({ title: "Copied", description: "Coordinates copied to clipboard" });
                            }}
                          >
                            <Copy className="h-3 w-3 mr-1" />
                            Copy Coordinates
                          </Button>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  ) : locationStatus === "error" ? (
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="gap-1.5 text-destructive border-destructive/30" data-testid="badge-gps-error">
                        <WifiOff className="h-3 w-3" />
                        Location unavailable
                      </Badge>
                      <Button variant="ghost" size="sm" onClick={startGPSTracking} data-testid="button-gps-retry">
                        Retry
                      </Button>
                    </div>
                  ) : (
                    <Badge variant="outline" className="gap-1.5 text-muted-foreground" data-testid="badge-gps-pending">
                      <MapPin className="h-3 w-3" />
                      Location Services
                    </Badge>
                  )}
                </div>
                
                <QRScanner
                  onScanSuccess={handleQRScanSuccess}
                  isProcessing={isCheckingStatus}
                  scannedEmployee={scannedEmployee ? { name: scannedEmployee.name, employeeNo: scannedEmployee.employeeNo } : null}
                />
                {isCheckingStatus && (
                  <div className="flex items-center justify-center gap-2 py-2 text-sm text-muted-foreground">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Checking schedule...
                  </div>
                )}
              </div>
            )}

            {step === "photo" && scannedEmployee && (
              <div className="space-y-4">
                <Card className={clockAction === "out" 
                  ? "bg-orange-50 dark:bg-orange-950/30 border-orange-200 dark:border-orange-800"
                  : "bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800"
                }>
                  <CardContent className="p-3 flex items-center gap-3">
                    <CheckCircle className={`h-5 w-5 shrink-0 ${clockAction === "out" ? "text-orange-500" : "text-green-500"}`} />
                    <div className="flex-1">
                      <p className="font-medium">{scannedEmployee.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Employee: {scannedEmployee.employeeNo}
                      </p>
                    </div>
                    <Badge variant={clockAction === "out" ? "destructive" : "default"}>
                      {clockAction === "out" ? "Clock Out" : "Clock In"}
                    </Badge>
                  </CardContent>
                </Card>

                <div className="relative bg-black rounded-lg overflow-hidden mx-auto" style={{ width: "100%", maxWidth: "400px", minHeight: "300px" }}>
                  {cameraError ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-4 text-center">
                      <XCircle className="h-12 w-12 mb-3 text-red-400" />
                      <p className="text-sm">{cameraError}</p>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => window.location.reload()}
                        className="mt-4"
                      >
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Reload Page
                      </Button>
                    </div>
                  ) : (
                    <>
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover"
                      />
                      <canvas ref={canvasRef} className="hidden" />
                      
                      {!isCameraReady && !capturedImage && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-white">
                          <Loader2 className="h-8 w-8 animate-spin" />
                        </div>
                      )}
                      
                      {capturedImage && (
                        <div className="absolute inset-0">
                          <img src={capturedImage} alt="Captured photo for attendance verification" className="w-full h-full object-cover" />
                          <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                            <Loader2 className="h-12 w-12 animate-spin text-white" />
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </div>

                <div className="flex gap-3">
                  <Button 
                    variant="outline" 
                    className="flex-1" 
                    onClick={resetClock}
                    disabled={isCapturing || clockInMutation.isPending || clockOutMutation.isPending}
                  >
                    Cancel
                  </Button>
                  <Button 
                    className="flex-1" 
                    onClick={captureAndClock}
                    disabled={!canCapturePhoto || isCapturing}
                  >
                    {isCapturing || clockInMutation.isPending || clockOutMutation.isPending ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Camera className="h-4 w-4 mr-2" />
                    )}
                    {clockAction === "out" ? "Confirm Clock Out" : "Capture & Clock In"}
                  </Button>
                </div>
              </div>
            )}

            {step === "success" && (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="h-20 w-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle className="h-10 w-10 text-green-600 dark:text-green-400" />
                </div>
                <h2 className="text-2xl font-bold mb-2">Success!</h2>
                <p className="text-muted-foreground mb-8 max-w-xs">
                  {clockAction === "out" 
                    ? `Good job! You have successfully clocked out.`
                    : `Welcome! ${clockedInEmployee?.firstName || "Employee"}, you have successfully clocked in.`
                  }
                </p>
                <Button onClick={resetClock} className="w-full max-w-xs">
                  <ScanLine className="h-4 w-4 mr-2" />
                  Ready for Next Scan
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-col gap-4 space-y-0 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle className="text-lg font-medium">Attendance Logs</CardTitle>
            <div className="flex flex-wrap items-center gap-2">
              {(user?.role === "ADMIN" || user?.role === "HR") && (
                <>
                  <SearchableEmployeeSelect
                    employees={employees || []}
                    value={employeeFilter}
                    onValueChange={setEmployeeFilter}
                    placeholder="Filter by employee..."
                    allowAll
                    allLabel="All Employees"
                    className="h-8 w-[180px] text-xs"
                    data-testid="filter-attendance-employee"
                  />
                  <div className="flex items-center gap-1">
                    <Label htmlFor="startDateLogs" className="text-xs">From:</Label>
                    <Input
                      id="startDateLogs"
                      type="date"
                      className="h-8 w-[130px] text-xs"
                      value={dateRange.start}
                      onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
                      data-testid="input-date-start"
                    />
                  </div>
                  <div className="flex items-center gap-1">
                    <Label htmlFor="endDateLogs" className="text-xs">To:</Label>
                    <Input
                      id="endDateLogs"
                      type="date"
                      className="h-8 w-[130px] text-xs"
                      value={dateRange.end}
                      onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
                      data-testid="input-date-end"
                    />
                  </div>
                </>
              )}
              <Select value={activeFilter} onValueChange={(val) => setActiveFilter(val as AttendanceFilter)}>
                <SelectTrigger className="h-8 w-[130px] text-xs" data-testid="select-attendance-filter">
                  <SelectValue placeholder="Filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Logs</SelectItem>
                  <SelectItem value="late">Lateness</SelectItem>
                  <SelectItem value="undertime">Undertime</SelectItem>
                  <SelectItem value="ot">Pending OT</SelectItem>
                </SelectContent>
              </Select>
              <Button 
                variant="ghost" 
                size="icon"
                aria-label="Refresh attendance data"
                onClick={() => queryClient.invalidateQueries({ predicate: (query) => query.queryKey[0]?.toString().startsWith("/api/attendance") ?? false })}
                data-testid="button-refresh-attendance"
              >
                <RefreshCw className="h-4 w-4" aria-hidden="true" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {attendanceLoading ? (
              <div className="p-4 space-y-4">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="flex items-center gap-3">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                    <Skeleton className="h-6 w-16" />
                  </div>
                ))}
              </div>
            ) : filteredAttendance.length === 0 ? (
              <div className="p-12 text-center text-muted-foreground italic">
                No attendance logs found for the selected date and filter.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead className="text-center w-16">Photo</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Time In</TableHead>
                      <TableHead>Time Out</TableHead>
                      <TableHead>Total Hours</TableHead>
                      <TableHead>Late</TableHead>
                      <TableHead>Undertime</TableHead>
                      <TableHead>OT</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-center">Location</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pagination.paginatedData.map((log) => {
                      const employee = employeeMap.get(log.employeeId);
                      return (
                        <TableRow key={log.id} data-testid={`attendance-row-${log.id}`}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={getPhotoDisplayUrl(employee?.profilePhotoUrl) || undefined} />
                                <AvatarFallback>{getInitials(employee?.firstName, employee?.lastName)}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-sm font-medium">{employee?.firstName} {employee?.lastName}</p>
                                <p className="text-xs text-muted-foreground">{employee?.employeeNo}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            {log.photoSnapshotUrl ? (
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <button
                                      type="button"
                                      className="inline-block rounded overflow-hidden border border-border hover:border-primary transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
                                      onClick={() => {
                                        const photoUrl = getPhotoDisplayUrl(log.photoSnapshotUrl);
                                        if (photoUrl) {
                                          setPhotoPreview({
                                            url: photoUrl,
                                            employeeName: `${employee?.firstName || ""} ${employee?.lastName || ""}`.trim() || "Employee",
                                            timeIn: formatDateTime(log.timeIn),
                                          });
                                        }
                                      }}
                                      aria-label="View clock-in photo"
                                    >
                                      <img
                                        src={getPhotoDisplayUrl(log.photoSnapshotUrl) || undefined}
                                        alt="Clock-in photo"
                                        className="h-10 w-10 object-cover"
                                        loading="lazy"
                                      />
                                    </button>
                                  </TooltipTrigger>
                                  <TooltipContent side="right" className="text-xs">
                                    Click to view full photo
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            ) : (
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <span className="inline-flex items-center justify-center h-10 w-10 rounded bg-muted">
                                      <ImageOff className="h-4 w-4 text-muted-foreground/50" />
                                    </span>
                                  </TooltipTrigger>
                                  <TooltipContent side="right" className="text-xs">
                                    No photo captured
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            )}
                          </TableCell>
                          <TableCell className="text-sm">
                            {formatDate(log.timeIn)}
                          </TableCell>
                          <TableCell className="text-sm font-mono">
                            {formatTime(log.timeIn)}
                          </TableCell>
                          <TableCell className="text-sm font-mono">
                            {log.timeOut ? formatTime(log.timeOut) : (
                              <Badge variant="outline" className="text-orange-600 border-orange-300">Active</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-sm font-medium">
                            {log.totalHours ? (
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <span className="cursor-help underline decoration-dotted">
                                      {Number(log.totalHours).toFixed(2)}h
                                    </span>
                                  </TooltipTrigger>
                                  <TooltipContent className="text-xs">
                                    <div className="space-y-1">
                                      {(() => {
                                        const totalHours = Number(log.totalHours);
                                        const lunchHours = (log.lunchDeductionMinutes || 0) / 60;
                                        const grossHours = totalHours + lunchHours;
                                        return (
                                          <>
                                            <div className="flex justify-between gap-4">
                                              <span className="text-muted-foreground">Gross Hours:</span>
                                              <span className="font-medium">{grossHours.toFixed(2)}h</span>
                                            </div>
                                            {lunchHours > 0 && (
                                              <div className="flex justify-between gap-4">
                                                <span className="text-muted-foreground">Lunch Break:</span>
                                                <span className="text-red-500">-{lunchHours.toFixed(2)}h</span>
                                              </div>
                                            )}
                                            <div className="flex justify-between gap-4 pt-1 border-t">
                                              <span className="text-muted-foreground font-semibold">Net Paid:</span>
                                              <span className="font-bold">{totalHours.toFixed(2)}h</span>
                                            </div>
                                          </>
                                        );
                                      })()}
                                    </div>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            ) : "-"}
                          </TableCell>
                          <TableCell>
                            {log.isLate && log.lateMinutes ? (
                              <Badge variant="destructive" className="text-xs">
                                {log.lateMinutes}m
                              </Badge>
                            ) : (
                              <span className="text-muted-foreground text-xs">-</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {/* Undertime should never show when there's overtime - they are mutually exclusive */}
                            {log.undertimeMinutes && Number(log.undertimeMinutes) > 0 && 
                             !(log.overtimeMinutes && Number(log.overtimeMinutes) > 0) ? (
                              <Badge variant="secondary" className="text-xs bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400">
                                {log.undertimeMinutes}m
                              </Badge>
                            ) : (
                              <span className="text-muted-foreground text-xs">-</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {log.overtimeMinutes && Number(log.overtimeMinutes) > 0 ? (() => {
                              // When approved, display otMinutesApproved; otherwise show raw overtimeMinutes
                              const displayMinutes = log.otStatus === "Approved" && log.otMinutesApproved != null
                                ? Number(log.otMinutesApproved)
                                : Number(log.overtimeMinutes);
                              const isPending = log.otStatus === "Pending" || !log.otStatus;
                              const canApprove = (user?.role === "ADMIN" || user?.role === "HR") && isPending;
                              return (
                                <div className="flex flex-col gap-1">
                                  <Badge variant="secondary" className={`text-xs ${
                                    log.otStatus === "Approved" ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400" :
                                    log.otStatus === "Rejected" ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400" :
                                    "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
                                  }`}>
                                    {Math.floor(displayMinutes / 60)}h {displayMinutes % 60}m
                                  </Badge>
                                  {canApprove ? (
                                    <div className="flex gap-1">
                                      <Popover
                                        open={otApprovalPopover?.logId === log.id}
                                        onOpenChange={(open) => {
                                          if (open) {
                                            setOtApprovalPopover({ logId: log.id, minutes: log.overtimeMinutes?.toString() || "0" });
                                          } else {
                                            setOtApprovalPopover(null);
                                          }
                                        }}
                                      >
                                        <TooltipProvider>
                                          <Tooltip>
                                            <TooltipTrigger asChild>
                                              <PopoverTrigger asChild>
                                                <Button
                                                  variant="ghost"
                                                  size="icon"
                                                  className="h-5 w-5 hover:bg-green-100 dark:hover:bg-green-900/30"
                                                  disabled={quickOTMutation.isPending}
                                                  aria-label="Approve OT"
                                                >
                                                  <CheckCircle className="h-3.5 w-3.5 text-green-600" />
                                                </Button>
                                              </PopoverTrigger>
                                            </TooltipTrigger>
                                            <TooltipContent side="bottom" className="text-xs">
                                              Approve OT
                                            </TooltipContent>
                                          </Tooltip>
                                        </TooltipProvider>
                                        <PopoverContent className="w-56 p-3" align="start">
                                          <div className="space-y-3">
                                            <p className="text-sm font-medium">Approve OT</p>
                                            <div className="space-y-2">
                                              <Label htmlFor={`ot-minutes-${log.id}`} className="text-xs">Minutes to approve</Label>
                                              <div className="flex gap-2">
                                                <Input
                                                  id={`ot-minutes-${log.id}`}
                                                  type="number"
                                                  min="0"
                                                  max={log.overtimeMinutes?.toString()}
                                                  value={otApprovalPopover?.minutes || ""}
                                                  onChange={(e) => setOtApprovalPopover(prev =>
                                                    prev ? { ...prev, minutes: e.target.value } : null
                                                  )}
                                                  className="h-8 text-sm"
                                                  placeholder="0"
                                                />
                                                <Button
                                                  type="button"
                                                  variant="outline"
                                                  size="sm"
                                                  className="h-8 text-xs whitespace-nowrap"
                                                  onClick={() => setOtApprovalPopover(prev =>
                                                    prev ? { ...prev, minutes: log.overtimeMinutes?.toString() || "0" } : null
                                                  )}
                                                >
                                                  Full
                                                </Button>
                                              </div>
                                              {otApprovalPopover?.minutes && (
                                                <p className="text-xs text-muted-foreground">
                                                  = {Math.floor(Number(otApprovalPopover.minutes) / 60)}h {Number(otApprovalPopover.minutes) % 60}m
                                                </p>
                                              )}
                                            </div>
                                            <div className="flex gap-2 pt-1">
                                              <Button
                                                size="sm"
                                                className="flex-1 h-7 text-xs"
                                                disabled={quickOTMutation.isPending || !otApprovalPopover?.minutes}
                                                onClick={() => {
                                                  quickOTMutation.mutate({
                                                    id: log.id,
                                                    action: "approve",
                                                    overtimeMinutes: Number(otApprovalPopover?.minutes) || 0
                                                  });
                                                  setOtApprovalPopover(null);
                                                }}
                                              >
                                                {quickOTMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : "Approve"}
                                              </Button>
                                              <Button
                                                size="sm"
                                                variant="outline"
                                                className="h-7 text-xs"
                                                onClick={() => setOtApprovalPopover(null)}
                                              >
                                                Cancel
                                              </Button>
                                            </div>
                                          </div>
                                        </PopoverContent>
                                      </Popover>
                                      <TooltipProvider>
                                        <Tooltip>
                                          <TooltipTrigger asChild>
                                            <Button
                                              variant="ghost"
                                              size="icon"
                                              className="h-5 w-5 hover:bg-red-100 dark:hover:bg-red-900/30"
                                              onClick={() => quickOTMutation.mutate({
                                                id: log.id,
                                                action: "deny",
                                                overtimeMinutes: 0
                                              })}
                                              disabled={quickOTMutation.isPending}
                                              aria-label="Deny OT"
                                            >
                                              <XCircle className="h-3.5 w-3.5 text-red-600" />
                                            </Button>
                                          </TooltipTrigger>
                                          <TooltipContent side="bottom" className="text-xs">
                                            Deny OT
                                          </TooltipContent>
                                        </Tooltip>
                                      </TooltipProvider>
                                    </div>
                                  ) : (
                                    <span className="text-[10px] text-muted-foreground">{log.otStatus}</span>
                                  )}
                                </div>
                              );
                            })() : (
                              <span className="text-muted-foreground text-xs">-</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className={`text-xs ${getStatusColorClass(log.verificationStatus)}`}>
                              {log.verificationStatus}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            {log.locationLat && log.locationLng ? (
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-8 w-8"
                                      onClick={() => {
                                        const url = `https://www.google.com/maps?q=${log.locationLat},${log.locationLng}`;
                                        window.open(url, "_blank", "noopener,noreferrer");
                                      }}
                                      aria-label="View location on Google Maps"
                                    >
                                      <MapPin className="h-4 w-4 text-blue-600" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent side="left" className="text-xs">
                                    <div className="space-y-1">
                                      <p className="font-medium">Clock-in Location</p>
                                      <div className="font-mono text-[10px] space-y-0.5">
                                        <p>Lat: {Number(log.locationLat).toFixed(6)}</p>
                                        <p>Lng: {Number(log.locationLng).toFixed(6)}</p>
                                      </div>
                                      {log.distanceFromSite && (
                                        <p className="text-muted-foreground">
                                          {Number(log.distanceFromSite) >= 1000
                                            ? `${(Number(log.distanceFromSite) / 1000).toFixed(1)} KM from site`
                                            : `${Math.round(Number(log.distanceFromSite))}m from site`}
                                        </p>
                                      )}
                                      {(log as any).locationAccuracy && (
                                        <p className={`text-[10px] ${
                                          Number((log as any).locationAccuracy) <= 50
                                            ? "text-green-600"
                                            : Number((log as any).locationAccuracy) <= 100
                                              ? "text-yellow-600"
                                              : "text-red-600"
                                        }`}>
                                          GPS accuracy: ±{Math.round(Number((log as any).locationAccuracy))}m
                                        </p>
                                      )}
                                      <p className="text-blue-500 flex items-center gap-1 pt-1">
                                        <ExternalLink className="h-3 w-3" />
                                        Click to view on Google Maps
                                      </p>
                                    </div>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            ) : (
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <span className="inline-flex items-center justify-center h-8 w-8">
                                      <MapPinOff className="h-4 w-4 text-muted-foreground/50" />
                                    </span>
                                  </TooltipTrigger>
                                  <TooltipContent side="left" className="text-xs">
                                    <p>No location data recorded</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            )}
                          </TableCell>
                          <TableCell>
                            {(user?.role === "ADMIN" || user?.role === "HR") && (
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Attendance actions">
                                    <MoreHorizontal className="h-4 w-4" aria-hidden="true" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => handleScheduleOverride(log)}>
                                    <CalendarClock className="mr-2 h-4 w-4" />
                                    Sched Change
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleEditLog(log)}>
                                    <Pencil className="mr-2 h-4 w-4" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleDeleteLog(log)} className="text-destructive">
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
                <TablePagination
                  currentPage={pagination.currentPage}
                  pageSize={pagination.pageSize}
                  totalPages={pagination.totalPages}
                  totalItems={pagination.totalItems}
                  startIndex={pagination.startIndex}
                  endIndex={pagination.endIndex}
                  canGoNext={pagination.canGoNext}
                  canGoPrevious={pagination.canGoPrevious}
                  onPageChange={pagination.goToPage}
                  onPageSizeChange={pagination.setPageSize}
                  onNextPage={pagination.goToNextPage}
                  onPreviousPage={pagination.goToPreviousPage}
                  onFirstPage={pagination.goToFirstPage}
                  onLastPage={pagination.goToLastPage}
                />
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Manual Entry Dialog */}
      <Dialog open={isManualDialogOpen} onOpenChange={setIsManualDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Manual Attendance Entry</DialogTitle>
            <DialogDescription>
              Manually record attendance for an employee.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="employeeId">Employee</Label>
              <SearchableEmployeeSelect
                employees={employees || []}
                value={manualForm.employeeId}
                onValueChange={(val) => setManualForm(prev => ({ ...prev, employeeId: val }))}
                placeholder="Select employee..."
                data-testid="select-employee-manual"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="manualTimeIn">Time In</Label>
                <Input 
                  id="manualTimeIn" 
                  type="datetime-local" 
                  value={manualForm.timeIn}
                  onChange={(e) => setManualForm(prev => ({ ...prev, timeIn: e.target.value }))}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="manualTimeOut">Time Out (Optional)</Label>
                <Input 
                  id="manualTimeOut" 
                  type="datetime-local" 
                  value={manualForm.timeOut}
                  onChange={(e) => setManualForm(prev => ({ ...prev, timeOut: e.target.value }))}
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="manualStatus">Verification Status</Label>
              <Select 
                value={manualForm.verificationStatus} 
                onValueChange={(val) => setManualForm(prev => ({ ...prev, verificationStatus: val }))}
              >
                <SelectTrigger id="manualStatus">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Verified">Verified</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Off-site">Off-site</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsManualDialogOpen(false)}>Cancel</Button>
            <Button 
              onClick={() => createManualAttendanceMutation.mutate({
                ...manualForm,
                timeIn: toPhilippineISOString(manualForm.timeIn),
                timeOut: manualForm.timeOut ? toPhilippineISOString(manualForm.timeOut) : undefined,
              })}
              disabled={!manualForm.employeeId || !manualForm.timeIn || createManualAttendanceMutation.isPending}
            >
              {createManualAttendanceMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Create Entry
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Attendance Record</DialogTitle>
            <DialogDescription>
              Update timing or verification status for this attendance log.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-6 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="timeIn">Time In</Label>
                <Input 
                  id="timeIn" 
                  type="datetime-local" 
                  value={editForm.timeIn}
                  onChange={(e) => setEditForm(prev => ({ ...prev, timeIn: e.target.value }))}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="timeOut">Time Out</Label>
                <Input 
                  id="timeOut" 
                  type="datetime-local" 
                  value={editForm.timeOut}
                  onChange={(e) => setEditForm(prev => ({ ...prev, timeOut: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="lateMinutes">Late Minutes (Manual Override)</Label>
                <Input 
                  id="lateMinutes" 
                  type="number" 
                  value={editForm.lateMinutes}
                  onChange={(e) => setEditForm(prev => ({ ...prev, lateMinutes: e.target.value }))}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="status">Verification Status</Label>
                <Select 
                  value={editForm.verificationStatus} 
                  onValueChange={(val) => setEditForm(prev => ({ ...prev, verificationStatus: val }))}
                >
                  <SelectTrigger id="status">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Verified">Verified</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Off-site">Off-site</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex items-center space-x-2 p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-md">
              <Checkbox
                id="lunchPaid"
                checked={editForm.lunchPaid}
                onCheckedChange={(checked) => setEditForm(prev => ({ ...prev, lunchPaid: checked === true }))}
                data-testid="checkbox-lunch-paid"
              />
              <div className="grid gap-1">
                <Label htmlFor="lunchPaid" className="text-sm font-medium cursor-pointer">
                  Lunch is Paid
                </Label>
                <p className="text-xs text-muted-foreground">
                  Check this box if the employee's lunch break should be paid (skips the 1-hour deduction for 5+ hour shifts).
                </p>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancel</Button>
            <Button 
              onClick={handleSaveEdit}
              disabled={updateAttendanceMutation.isPending}
            >
              {updateAttendanceMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this attendance record. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground">
              Delete Record
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Day Off / Leave Confirmation Dialog */}
      <AlertDialog open={isScheduleConfirmOpen} onOpenChange={setIsScheduleConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Info className="h-5 w-5 text-amber-500" />
              Schedule Notice
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-3">
                <p className="text-base text-foreground font-medium">
                  {clockInStatus?.employeeName}
                </p>
                {clockInStatus?.isDayOff && (
                  <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800">
                    <CalendarClock className="h-5 w-5 text-amber-600 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-medium text-amber-800 dark:text-amber-200">Day Off</p>
                      <p className="text-sm text-amber-700 dark:text-amber-300">
                        Today ({clockInStatus?.todayName}) is not in your scheduled work days.
                      </p>
                      {clockInStatus?.scheduledWorkDays && clockInStatus.scheduledWorkDays.length > 0 && (
                        <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">
                          Your schedule: {clockInStatus.scheduledWorkDays.join(", ")}
                        </p>
                      )}
                    </div>
                  </div>
                )}
                {clockInStatus?.isOnLeave && (
                  <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800">
                    <Clock className="h-5 w-5 text-blue-600 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-medium text-blue-800 dark:text-blue-200">On Approved Leave</p>
                      <p className="text-sm text-blue-700 dark:text-blue-300">
                        You have approved {clockInStatus?.leaveTypeName || "leave"} today.
                      </p>
                    </div>
                  </div>
                )}
                <p className="text-sm text-muted-foreground mt-2">
                  Would you like to clock in anyway? This may be for overtime or emergency coverage.
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={handleScheduleCancel}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleScheduleConfirm} className="bg-primary">
              Clock In Anyway
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Geofencing Error Dialog */}
      <Dialog open={isGeofenceErrorOpen} onOpenChange={setIsGeofenceErrorOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <div className="flex items-center gap-3 text-destructive">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-destructive/10">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <DialogTitle className="text-xl">Outside Assigned Location</DialogTitle>
            </div>
            <DialogDescription className="pt-4 space-y-4">
              <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-4">
                <p className="text-sm text-foreground leading-relaxed">
                  You are logging in outside of your assigned location.
                </p>
                {geofenceError && (
                  <p className="mt-2 text-lg font-semibold text-destructive">
                    You are{" "}
                    {geofenceError.distance >= 1000
                      ? `${(geofenceError.distance / 1000).toFixed(1)} KM`
                      : `${Math.round(geofenceError.distance)} meters`}{" "}
                    away
                  </p>
                )}
              </div>
              <div className="flex items-start gap-2 text-sm text-muted-foreground">
                <Info className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <p>
                  If this is a mistake, please contact HR to update your Location assignment.
                </p>
              </div>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => {
                setIsGeofenceErrorOpen(false);
                setGeofenceError(null);
              }}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Schedule Override Dialog */}
      <Dialog open={isScheduleOverrideOpen} onOpenChange={setIsScheduleOverrideOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarClock className="h-5 w-5" />
              Schedule Change Override
            </DialogTitle>
            <DialogDescription>
              Override the scheduled shift for this attendance entry. This will recalculate late status and overtime based on the new schedule.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            {selectedLog && (
              <div className="rounded-lg border bg-muted/50 p-3 text-sm">
                <p className="font-medium">
                  {employeeMap.get(selectedLog.employeeId)?.firstName}{" "}
                  {employeeMap.get(selectedLog.employeeId)?.lastName}
                </p>
                <p className="text-muted-foreground">
                  {formatDate(selectedLog.timeIn)} - {formatTime(selectedLog.timeIn)}
                  {selectedLog.timeOut && ` to ${formatTime(selectedLog.timeOut)}`}
                </p>
                {(selectedLog.scheduledShiftStart || selectedLog.scheduledShiftEnd) && (
                  <p className="text-muted-foreground text-xs mt-1">
                    Original Schedule: {selectedLog.scheduledShiftStart || "N/A"} - {selectedLog.scheduledShiftEnd || "N/A"}
                  </p>
                )}
                {selectedLog.scheduledShiftStartOverride && (
                  <p className="text-blue-600 dark:text-blue-400 text-xs mt-1">
                    Current Override: {selectedLog.scheduledShiftStartOverride} - {selectedLog.scheduledShiftEndOverride}
                  </p>
                )}
              </div>
            )}
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="schedTimeIn">Scheduled Time In</Label>
                <Input
                  id="schedTimeIn"
                  type="time"
                  value={scheduleOverrideForm.scheduledShiftStartOverride}
                  onChange={(e) => setScheduleOverrideForm(prev => ({
                    ...prev,
                    scheduledShiftStartOverride: e.target.value
                  }))}
                  data-testid="input-schedule-time-in"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="schedTimeOut">Scheduled Time Out</Label>
                <Input
                  id="schedTimeOut"
                  type="time"
                  value={scheduleOverrideForm.scheduledShiftEndOverride}
                  onChange={(e) => setScheduleOverrideForm(prev => ({
                    ...prev,
                    scheduledShiftEndOverride: e.target.value
                  }))}
                  data-testid="input-schedule-time-out"
                />
              </div>
            </div>
            <div className="rounded-lg border border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/30 p-3">
              <div className="flex items-start gap-2">
                <Info className="h-4 w-4 mt-0.5 text-blue-600 dark:text-blue-400 shrink-0" />
                <div className="text-sm text-blue-800 dark:text-blue-200">
                  <p className="font-medium">How this works:</p>
                  <ul className="mt-1 list-disc list-inside text-xs space-y-0.5">
                    <li>Late status will be recalculated based on the new scheduled time in</li>
                    <li>Overtime/undertime will be recalculated based on the new schedule</li>
                    <li>This override only affects this specific attendance entry</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsScheduleOverrideOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleSaveScheduleOverride}
              disabled={!scheduleOverrideForm.scheduledShiftStartOverride || !scheduleOverrideForm.scheduledShiftEndOverride || scheduleOverrideMutation.isPending}
              data-testid="button-save-schedule-override"
            >
              {scheduleOverrideMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Apply Override
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Photo Preview Dialog */}
      <Dialog open={!!photoPreview} onOpenChange={(open) => !open && setPhotoPreview(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Camera className="h-5 w-5" />
              Clock-in Photo
            </DialogTitle>
            <DialogDescription>
              {photoPreview?.employeeName} - {photoPreview?.timeIn}
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-center py-4">
            {photoPreview?.url && (
              <img
                src={photoPreview.url}
                alt={`Clock-in photo for ${photoPreview.employeeName}`}
                className="max-w-full max-h-[60vh] rounded-lg object-contain border"
              />
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPhotoPreview(null)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ArrowRight(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M5 12h14" />
      <path d="m12 5 7 7-7 7" />
    </svg>
  );
}
