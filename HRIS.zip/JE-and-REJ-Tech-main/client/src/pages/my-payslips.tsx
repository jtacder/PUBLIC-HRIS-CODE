import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { usePagination } from "@/hooks/use-pagination";
import { TablePagination } from "@/components/ui/table-pagination";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { 
  Wallet, 
  FileText,
  Calendar,
  Eye,
} from "lucide-react";
import { formatDate } from "@/lib/utils";
import { useState } from "react";
import type { PayrollRecord, Employee } from "@shared/schema";

export default function MyPayslipsPage() {
  const { user } = useAuth();
  const [selectedPayslip, setSelectedPayslip] = useState<PayrollRecord | null>(null);

  const { data: employee } = useQuery<Employee>({
    queryKey: ["/api/employees", user?.employeeId],
    enabled: !!user?.employeeId,
  });

  const { data: payslips, isLoading } = useQuery<PayrollRecord[]>({
    queryKey: ["/api/my/payslips"],
    enabled: !!user?.employeeId,
  });

  // Pagination
  const pagination = usePagination(payslips || []);

  const formatCurrency = (amount: string | number | null | undefined) => {
    const value = typeof amount === "string" ? parseFloat(amount) : amount || 0;
    return new Intl.NumberFormat('en-PH', {
      style: 'currency',
      currency: 'PHP',
      minimumFractionDigits: 2
    }).format(value);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Paid":
        return <Badge variant="default">Paid</Badge>;
      case "Processing":
        return <Badge variant="secondary">Processing</Badge>;
      case "Draft":
        return <Badge variant="outline">Draft</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-20" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">My Payslips</h1>
        <p className="text-muted-foreground">View your pay history and payslip details</p>
      </div>

      {payslips && payslips.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wallet className="h-5 w-5" />
              Payroll History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Pay Period</TableHead>
                  <TableHead className="text-right">Gross Pay</TableHead>
                  <TableHead className="text-right">Deductions</TableHead>
                  <TableHead className="text-right">Net Pay</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pagination.paginatedData.map((payslip) => {
                  const deductions = parseFloat(payslip.totalDeductions || "0");
                  
                  return (
                    <TableRow key={payslip.id} data-testid={`row-payslip-${payslip.id}`}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          {formatDate(payslip.cutoffStart)} - {formatDate(payslip.cutoffEnd)}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">{formatCurrency(payslip.grossPay)}</TableCell>
                      <TableCell className="text-right text-red-600">
                        -{formatCurrency(deductions)}
                      </TableCell>
                      <TableCell className="text-right font-semibold text-green-600">
                        {formatCurrency(payslip.netPay)}
                      </TableCell>
                      <TableCell>{getStatusBadge(payslip.status)}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setSelectedPayslip(payslip)}
                          data-testid={`button-view-payslip-${payslip.id}`}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
            <TablePagination
              currentPage={pagination.currentPage}
              pageSize={pagination.pageSize}
              totalPages={pagination.totalPages}
              totalItems={pagination.totalItems}
              startIndex={pagination.startIndex}
              endIndex={pagination.endIndex}
              canGoNext={pagination.canGoNext}
              canGoPrevious={pagination.canGoPrevious}
              onPageChange={pagination.goToPage}
              onPageSizeChange={pagination.setPageSize}
              onNextPage={pagination.goToNextPage}
              onPreviousPage={pagination.goToPreviousPage}
              onFirstPage={pagination.goToFirstPage}
              onLastPage={pagination.goToLastPage}
            />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="font-medium text-lg mb-2">No Payslips Yet</h3>
            <p className="text-muted-foreground">
              Your payslips will appear here once processed.
            </p>
          </CardContent>
        </Card>
      )}

      <Dialog open={!!selectedPayslip} onOpenChange={() => setSelectedPayslip(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Payslip Details
            </DialogTitle>
          </DialogHeader>
          {selectedPayslip && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Pay Period</span>
                <span className="font-medium">
                  {formatDate(selectedPayslip.cutoffStart)} - {formatDate(selectedPayslip.cutoffEnd)}
                </span>
              </div>
              <Separator />
              
              <div className="space-y-2">
                <h4 className="font-semibold">Earnings</h4>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Basic Pay</span>
                  <span>{formatCurrency(selectedPayslip.basicPay)}</span>
                </div>
                {parseFloat(selectedPayslip.regularOTPay || "0") > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Overtime Pay</span>
                    <span>{formatCurrency(selectedPayslip.regularOTPay)}</span>
                  </div>
                )}
                {parseFloat(selectedPayslip.holidayOTPay || "0") > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Holiday OT Pay</span>
                    <span>{formatCurrency(selectedPayslip.holidayOTPay)}</span>
                  </div>
                )}
                {parseFloat(selectedPayslip.allowances || "0") > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Allowances</span>
                    <span>{formatCurrency(selectedPayslip.allowances)}</span>
                  </div>
                )}
                {parseFloat((selectedPayslip as any).colaAllowance || "0") > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">COLA</span>
                    <span>{formatCurrency((selectedPayslip as any).colaAllowance)}</span>
                  </div>
                )}
                <div className="flex justify-between font-semibold border-t pt-2">
                  <span>Gross Pay</span>
                  <span>{formatCurrency(selectedPayslip.grossPay)}</span>
                </div>
              </div>

              <Separator />
              
              <div className="space-y-2">
                <h4 className="font-semibold text-red-600">Deductions</h4>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">SSS</span>
                  <span className="text-red-600">-{formatCurrency(selectedPayslip.sssDeduction)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">PhilHealth</span>
                  <span className="text-red-600">-{formatCurrency(selectedPayslip.philhealthDeduction)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Pag-IBIG</span>
                  <span className="text-red-600">-{formatCurrency(selectedPayslip.pagibigDeduction)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Withholding Tax</span>
                  <span className="text-red-600">-{formatCurrency(selectedPayslip.taxDeduction)}</span>
                </div>
                {parseFloat(selectedPayslip.lateDeduction || "0") > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Late Deductions</span>
                    <span className="text-red-600">-{formatCurrency(selectedPayslip.lateDeduction)}</span>
                  </div>
                )}
                {parseFloat(selectedPayslip.undertimeDeduction || "0") > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Undertime Deductions</span>
                    <span className="text-red-600">-{formatCurrency(selectedPayslip.undertimeDeduction)}</span>
                  </div>
                )}
                {parseFloat(selectedPayslip.cashAdvanceDeduction || "0") > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Cash Advance</span>
                    <span className="text-red-600">-{formatCurrency(selectedPayslip.cashAdvanceDeduction)}</span>
                  </div>
                )}
                {parseFloat(selectedPayslip.sssLoanDeduction || "0") > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">SSS Loan</span>
                    <span className="text-red-600">-{formatCurrency(selectedPayslip.sssLoanDeduction)}</span>
                  </div>
                )}
                {parseFloat(selectedPayslip.pagibigLoanDeduction || "0") > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Pag-IBIG Loan</span>
                    <span className="text-red-600">-{formatCurrency(selectedPayslip.pagibigLoanDeduction)}</span>
                  </div>
                )}
                {parseFloat(selectedPayslip.bankLoanDeduction || "0") > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Bank Loan</span>
                    <span className="text-red-600">-{formatCurrency(selectedPayslip.bankLoanDeduction)}</span>
                  </div>
                )}
                {parseFloat(selectedPayslip.otherDeductionAmount || "0") > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Other Deductions</span>
                    <span className="text-red-600">-{formatCurrency(selectedPayslip.otherDeductionAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between font-semibold border-t pt-2 text-red-600">
                  <span>Total Deductions</span>
                  <span>-{formatCurrency(selectedPayslip.totalDeductions)}</span>
                </div>
              </div>

              <Separator />

              <div className="flex justify-between text-lg font-bold">
                <span>Net Pay</span>
                <span className="text-green-600">{formatCurrency(selectedPayslip.netPay)}</span>
              </div>

              {parseFloat(selectedPayslip.mealAllowanceTotal || "0") > 0 && (
                <>
                  <Separator />
                  <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-amber-700 dark:text-amber-400">Meal Allowance</span>
                      <span className="text-sm font-semibold text-amber-700 dark:text-amber-400">{formatCurrency(selectedPayslip.mealAllowanceTotal)}</span>
                    </div>
                    <p className="text-xs text-amber-600/70 dark:text-amber-400/70 mt-1">
                      Daily provision — not included in Net Pay
                    </p>
                  </div>
                </>
              )}

              <div className="flex justify-between pt-2">
                <span className="text-muted-foreground">Status</span>
                {getStatusBadge(selectedPayslip.status)}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
