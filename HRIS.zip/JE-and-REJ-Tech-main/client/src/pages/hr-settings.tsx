import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import {
  Clock,
  Plus,
  Trash2,
  CalendarDays,
  Palmtree,
  Coins,
  Users,
  Gift,
} from "lucide-react";
import { ThirteenthMonthTab } from "@/components/thirteenth-month-tab";
import type {
  PayrollCutoff,
  LeaveTypeRecord,
  Holiday,
  EmployeeLeaveAllocation,
  Employee,
} from "@shared/schema";

export default function HRSettingsPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("cutoffs");
  
  const [isCutoffDialogOpen, setIsCutoffDialogOpen] = useState(false);
  const [isLeaveTypeDialogOpen, setIsLeaveTypeDialogOpen] = useState(false);
  const [isHolidayDialogOpen, setIsHolidayDialogOpen] = useState(false);
  const [isLeaveAllocationDialogOpen, setIsLeaveAllocationDialogOpen] = useState(false);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  const [newCutoff, setNewCutoff] = useState({
    name: "",
    startDay: "",
    endDay: "",
    payoutDay: "",
  });

  const [newLeaveType, setNewLeaveType] = useState({
    name: "",
    code: "",
    annualAllocation: "",
    accrualMode: "annual" as "annual" | "monthly" | "none",
    isPaid: true,
    requiresApproval: true,
  });

  const [newHoliday, setNewHoliday] = useState({
    name: "",
    date: "",
    type: "Regular" as "Regular" | "Special",
    year: new Date().getFullYear(),
  });

  const [newLeaveAllocation, setNewLeaveAllocation] = useState({
    employeeId: "",
    leaveTypeId: "",
    year: new Date().getFullYear().toString(),
    totalAllocated: "",
    used: "0",
  });

  const { data: employees = [] } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const { data: cutoffs = [], isLoading: loadingCutoffs } = useQuery<PayrollCutoff[]>({
    queryKey: ["/api/settings/payroll-cutoffs"],
  });

  const { data: leaveTypes = [], isLoading: loadingLeaveTypes } = useQuery<LeaveTypeRecord[]>({
    queryKey: ["/api/settings/leave-types"],
  });

  const { data: holidays = [], isLoading: loadingHolidays } = useQuery<Holiday[]>({
    queryKey: ["/api/settings/holidays"],
  });

  const { data: leaveAllocations = [], isLoading: loadingAllocations } = useQuery<EmployeeLeaveAllocation[]>({
    queryKey: ["/api/leave-allocations", { year: selectedYear }],
  });

  const createCutoffMutation = useMutation({
    mutationFn: async (data: typeof newCutoff) => {
      const response = await apiRequest("POST", "/api/settings/payroll-cutoffs", {
        name: data.name,
        startDay: parseInt(data.startDay),
        endDay: parseInt(data.endDay),
        payoutDay: parseInt(data.payoutDay),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings/payroll-cutoffs"] });
      setIsCutoffDialogOpen(false);
      setNewCutoff({ name: "", startDay: "", endDay: "", payoutDay: "" });
      toast({ title: "Cutoff Created", description: "Payroll cutoff has been added." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create cutoff.", variant: "destructive" });
    },
  });

  const deleteCutoffMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/settings/payroll-cutoffs/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings/payroll-cutoffs"] });
      toast({ title: "Deleted", description: "Payroll cutoff has been removed." });
    },
  });

  const createLeaveTypeMutation = useMutation({
    mutationFn: async (data: typeof newLeaveType) => {
      const response = await apiRequest("POST", "/api/settings/leave-types", {
        name: data.name,
        code: data.code,
        annualAllocation: parseInt(data.annualAllocation) || 0,
        accrualMode: data.accrualMode,
        isPaid: data.isPaid,
        requiresApproval: data.requiresApproval,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings/leave-types"] });
      setIsLeaveTypeDialogOpen(false);
      setNewLeaveType({ name: "", code: "", annualAllocation: "", accrualMode: "annual", isPaid: true, requiresApproval: true });
      toast({ title: "Leave Type Created", description: "Leave type has been added." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create leave type.", variant: "destructive" });
    },
  });

  const deleteLeaveTypeMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/settings/leave-types/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings/leave-types"] });
      toast({ title: "Deleted", description: "Leave type has been removed." });
    },
  });

  const createHolidayMutation = useMutation({
    mutationFn: async (data: typeof newHoliday) => {
      const response = await apiRequest("POST", "/api/settings/holidays", {
        name: data.name,
        date: data.date,
        type: data.type,
        year: data.year,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings/holidays"] });
      setIsHolidayDialogOpen(false);
      setNewHoliday({ name: "", date: "", type: "Regular", year: new Date().getFullYear() });
      toast({ title: "Holiday Created", description: "Holiday has been added." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create holiday.", variant: "destructive" });
    },
  });

  const deleteHolidayMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/settings/holidays/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings/holidays"] });
      toast({ title: "Deleted", description: "Holiday has been removed." });
    },
  });

  const createLeaveAllocationMutation = useMutation({
    mutationFn: async (data: typeof newLeaveAllocation) => {
      const response = await apiRequest("POST", "/api/leave-allocations", {
        employeeId: data.employeeId,
        leaveTypeId: data.leaveTypeId,
        year: parseInt(data.year),
        totalAllocated: data.totalAllocated,
        used: data.used || "0",
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leave-allocations"] });
      setIsLeaveAllocationDialogOpen(false);
      setNewLeaveAllocation({
        employeeId: "",
        leaveTypeId: "",
        year: new Date().getFullYear().toString(),
        totalAllocated: "",
        used: "0",
      });
      toast({ title: "Created", description: "Leave allocation created successfully." });
    },
  });

  const deleteLeaveAllocationMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/leave-allocations/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leave-allocations"] });
      toast({ title: "Deleted", description: "Leave allocation has been removed." });
    },
  });

  const bulkAllocateMutation = useMutation({
    mutationFn: async (data: { year: number; proRateNewHires: boolean }) => {
      const response = await apiRequest("POST", "/api/leave-allocations/bulk-allocate", data);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/leave-allocations"] });
      toast({
        title: "Bulk Allocation Complete",
        description: `Created: ${data.results.created}, Skipped: ${data.results.skipped}, Errors: ${data.results.errors}`,
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to perform bulk allocation.", variant: "destructive" });
    },
  });

  const processAccrualsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/leave-allocations/process-accruals", {});
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/leave-allocations"] });
      toast({
        title: "Accrual Processing Complete",
        description: `Processed: ${data.results.processed}, Skipped: ${data.results.skipped}`,
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to process accruals.", variant: "destructive" });
    },
  });

  const processCarryoverMutation = useMutation({
    mutationFn: async (data: { fromYear: number; maxCarryoverDays: number }) => {
      const response = await apiRequest("POST", "/api/leave-allocations/process-carryover", data);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/leave-allocations"] });
      toast({
        title: "Carryover Complete",
        description: `Processed: ${data.results.processed}, Skipped: ${data.results.skipped}`,
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to process carryover.", variant: "destructive" });
    },
  });

  const getEmployeeName = (employeeId: string) => {
    const employee = employees.find(e => e.id === employeeId);
    if (!employee) return "Unknown";
    return `${employee.firstName} ${employee.lastName}`;
  };

  const getLeaveTypeName = (leaveTypeId: string) => {
    const leaveType = leaveTypes.find(lt => lt.id === leaveTypeId);
    return leaveType?.name || "Unknown";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">HR Settings</h1>
          <p className="text-muted-foreground">
            Configure payroll cutoffs, leave types, and company holidays
          </p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-6 lg:w-auto lg:inline-flex">
          <TabsTrigger value="cutoffs" className="flex items-center gap-2" data-testid="tab-cutoffs">
            <Clock className="h-4 w-4" />
            <span className="hidden sm:inline">Payroll Cutoffs</span>
            <span className="sm:hidden">Cutoffs</span>
          </TabsTrigger>
          <TabsTrigger value="contributions" className="flex items-center gap-2" data-testid="tab-contributions">
            <Coins className="h-4 w-4" />
            <span className="hidden sm:inline">Contributions</span>
            <span className="sm:hidden">Contrib</span>
          </TabsTrigger>
          <TabsTrigger value="leave-types" className="flex items-center gap-2" data-testid="tab-leave-types">
            <CalendarDays className="h-4 w-4" />
            <span className="hidden sm:inline">Leave Types</span>
            <span className="sm:hidden">Leaves</span>
          </TabsTrigger>
          <TabsTrigger value="holidays" className="flex items-center gap-2" data-testid="tab-holidays">
            <Palmtree className="h-4 w-4" />
            Holidays
          </TabsTrigger>
          <TabsTrigger value="allocations" className="flex items-center gap-2" data-testid="tab-allocations">
            <Users className="h-4 w-4" />
            <span className="hidden sm:inline">Leave Allocations</span>
            <span className="sm:hidden">Allocations</span>
          </TabsTrigger>
          <TabsTrigger value="13th-month" className="flex items-center gap-2" data-testid="tab-13th-month">
            <Gift className="h-4 w-4" />
            <span className="hidden sm:inline">13th Month</span>
            <span className="sm:hidden">13th</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="cutoffs" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
              <div>
                <CardTitle>Payroll Cutoff Schedules</CardTitle>
                <CardDescription>
                  Define payroll periods for semi-monthly or monthly payroll processing
                </CardDescription>
              </div>
              <Dialog open={isCutoffDialogOpen} onOpenChange={setIsCutoffDialogOpen}>
                <Button onClick={() => setIsCutoffDialogOpen(true)} data-testid="button-add-cutoff">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Cutoff
                </Button>
                <DialogContent className="max-w-lg">
                  <DialogHeader>
                    <DialogTitle>Add Payroll Cutoff</DialogTitle>
                    <DialogDescription>
                      Configure a new payroll cutoff schedule
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="cutoffName">Cutoff Name</Label>
                      <Input
                        id="cutoffName"
                        value={newCutoff.name}
                        onChange={(e) => setNewCutoff({ ...newCutoff, name: e.target.value })}
                        placeholder="e.g., First Cutoff (1st-15th)"
                        data-testid="input-cutoff-name"
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="startDay">Start Day</Label>
                        <Input
                          id="startDay"
                          type="number"
                          min="1"
                          max="31"
                          value={newCutoff.startDay}
                          onChange={(e) => setNewCutoff({ ...newCutoff, startDay: e.target.value })}
                          placeholder="1"
                          data-testid="input-start-day"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="endDay">End Day</Label>
                        <Input
                          id="endDay"
                          type="number"
                          min="1"
                          max="31"
                          value={newCutoff.endDay}
                          onChange={(e) => setNewCutoff({ ...newCutoff, endDay: e.target.value })}
                          placeholder="15"
                          data-testid="input-end-day"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="payoutDay">Payout Day</Label>
                        <Input
                          id="payoutDay"
                          type="number"
                          min="1"
                          max="31"
                          value={newCutoff.payoutDay}
                          onChange={(e) => setNewCutoff({ ...newCutoff, payoutDay: e.target.value })}
                          placeholder="20"
                          data-testid="input-payout-day"
                        />
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsCutoffDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button
                      onClick={() => createCutoffMutation.mutate(newCutoff)}
                      disabled={!newCutoff.name || !newCutoff.startDay || createCutoffMutation.isPending}
                      data-testid="button-save-cutoff"
                    >
                      {createCutoffMutation.isPending ? "Saving..." : "Save Cutoff"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {loadingCutoffs ? (
                <div className="space-y-3">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              ) : cutoffs.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No payroll cutoffs configured. Add one to get started.
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Period</TableHead>
                      <TableHead>Payout Day</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="w-20">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cutoffs.map((cutoff) => (
                      <TableRow key={cutoff.id} data-testid={`row-cutoff-${cutoff.id}`}>
                        <TableCell className="font-medium">{cutoff.name}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          Day {cutoff.startDay} - {cutoff.endDay}
                        </TableCell>
                        <TableCell>Day {cutoff.payoutDay}</TableCell>
                        <TableCell>
                          <Badge variant={cutoff.isActive ? "default" : "secondary"}>
                            {cutoff.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => deleteCutoffMutation.mutate(cutoff.id)}
                            data-testid={`button-delete-cutoff-${cutoff.id}`}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contributions" className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  SSS Contributions (2024-2025)
                </CardTitle>
                <CardDescription>
                  Social Security System contribution rates based on monthly salary credit
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-sm space-y-3">
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Contribution Rate</span>
                    <span className="font-medium">14% of MSC</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Employee Share</span>
                    <span className="font-medium">4.5%</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Employer Share</span>
                    <span className="font-medium">9.5%</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Min Monthly Salary Credit</span>
                    <span className="font-medium">PHP 4,000</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-muted-foreground">Max Monthly Salary Credit</span>
                    <span className="font-medium">PHP 30,000</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  PhilHealth Contributions (2024)
                </CardTitle>
                <CardDescription>
                  Philippine Health Insurance Corporation contribution rates
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-sm space-y-3">
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Contribution Rate</span>
                    <span className="font-medium">5% of Basic Salary</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Employee Share</span>
                    <span className="font-medium">2.5%</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Employer Share</span>
                    <span className="font-medium">2.5%</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Min Monthly Premium</span>
                    <span className="font-medium">PHP 500</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-muted-foreground">Max Monthly Premium</span>
                    <span className="font-medium">PHP 5,000</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  Pag-IBIG Contributions (2024)
                </CardTitle>
                <CardDescription>
                  Home Development Mutual Fund contribution rates
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-sm space-y-3">
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Employee Rate (up to PHP 1,500)</span>
                    <span className="font-medium">1%</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Employee Rate (over PHP 1,500)</span>
                    <span className="font-medium">2%</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Employer Rate</span>
                    <span className="font-medium">2%</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-muted-foreground">Max Monthly Contribution</span>
                    <span className="font-medium">PHP 200 (Employee + Employer)</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  Overtime Rates
                </CardTitle>
                <CardDescription>
                  Premium rates for overtime and holiday work
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-sm space-y-3">
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Regular OT (after 8 hrs)</span>
                    <span className="font-medium">+25% of hourly rate</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Rest Day Work</span>
                    <span className="font-medium">+30% of daily rate</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Rest Day OT</span>
                    <span className="font-medium">+30% of OT rate</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Regular Holiday Work</span>
                    <span className="font-medium">200% of daily rate</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Special Holiday Work</span>
                    <span className="font-medium">130% of daily rate</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-muted-foreground">Night Shift Differential</span>
                    <span className="font-medium">+10% (10PM-6AM)</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="leave-types" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
              <div>
                <CardTitle>Leave Types</CardTitle>
                <CardDescription>
                  Configure available leave types for employees
                </CardDescription>
              </div>
              <Dialog open={isLeaveTypeDialogOpen} onOpenChange={setIsLeaveTypeDialogOpen}>
                <Button onClick={() => setIsLeaveTypeDialogOpen(true)} data-testid="button-add-leave-type">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Leave Type
                </Button>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Leave Type</DialogTitle>
                    <DialogDescription>
                      Create a new leave type for employees
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="leaveTypeName">Name</Label>
                        <Input
                          id="leaveTypeName"
                          value={newLeaveType.name}
                          onChange={(e) => setNewLeaveType({ ...newLeaveType, name: e.target.value })}
                          placeholder="e.g., Vacation Leave"
                          data-testid="input-leave-type-name"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="leaveTypeCode">Code</Label>
                        <Input
                          id="leaveTypeCode"
                          value={newLeaveType.code}
                          onChange={(e) => setNewLeaveType({ ...newLeaveType, code: e.target.value })}
                          placeholder="e.g., VL"
                          data-testid="input-leave-type-code"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="annualAllocation">Annual Allocation (Days)</Label>
                        <Input
                          id="annualAllocation"
                          type="number"
                          value={newLeaveType.annualAllocation}
                          onChange={(e) => setNewLeaveType({ ...newLeaveType, annualAllocation: e.target.value })}
                          placeholder="15"
                          data-testid="input-annual-allocation"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="accrualMode">Accrual Mode</Label>
                        <Select
                          value={newLeaveType.accrualMode}
                          onValueChange={(value: "annual" | "monthly" | "none") =>
                            setNewLeaveType({ ...newLeaveType, accrualMode: value })
                          }
                        >
                          <SelectTrigger data-testid="select-accrual-mode">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="annual">Annual (Full at year start)</SelectItem>
                            <SelectItem value="monthly">Monthly (Earned per month)</SelectItem>
                            <SelectItem value="none">None (Manual only)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-6">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id="isPaid"
                          checked={newLeaveType.isPaid}
                          onCheckedChange={(checked) => 
                            setNewLeaveType({ ...newLeaveType, isPaid: checked === true })
                          }
                          data-testid="checkbox-is-paid"
                        />
                        <Label htmlFor="isPaid" className="text-sm cursor-pointer">Paid Leave</Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id="requiresApproval"
                          checked={newLeaveType.requiresApproval}
                          onCheckedChange={(checked) => 
                            setNewLeaveType({ ...newLeaveType, requiresApproval: checked === true })
                          }
                          data-testid="checkbox-requires-approval"
                        />
                        <Label htmlFor="requiresApproval" className="text-sm cursor-pointer">Requires Approval</Label>
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsLeaveTypeDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button
                      onClick={() => createLeaveTypeMutation.mutate(newLeaveType)}
                      disabled={!newLeaveType.name || !newLeaveType.code || createLeaveTypeMutation.isPending}
                      data-testid="button-save-leave-type"
                    >
                      {createLeaveTypeMutation.isPending ? "Saving..." : "Save Leave Type"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {loadingLeaveTypes ? (
                <div className="space-y-3">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              ) : leaveTypes.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No leave types configured. Add one to get started.
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Code</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Days/Year</TableHead>
                      <TableHead>Accrual</TableHead>
                      <TableHead>Options</TableHead>
                      <TableHead className="w-20">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {leaveTypes.map((lt) => (
                      <TableRow key={lt.id} data-testid={`row-leave-type-${lt.id}`}>
                        <TableCell>
                          <Badge variant="secondary">{lt.code}</Badge>
                        </TableCell>
                        <TableCell className="font-medium">{lt.name}</TableCell>
                        <TableCell>{lt.annualAllocation}</TableCell>
                        <TableCell>
                          <Badge variant={
                            (lt as any).accrualMode === "monthly" ? "default" :
                            (lt as any).accrualMode === "none" ? "secondary" : "outline"
                          }>
                            {(lt as any).accrualMode === "monthly" ? "Monthly" :
                             (lt as any).accrualMode === "none" ? "Manual" : "Annual"}
                          </Badge>
                        </TableCell>
                        <TableCell className="flex flex-wrap gap-1">
                          {lt.isPaid && <Badge variant="outline">Paid</Badge>}
                          {lt.requiresApproval && <Badge variant="outline">Approval</Badge>}
                        </TableCell>
                        <TableCell>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => deleteLeaveTypeMutation.mutate(lt.id)}
                            data-testid={`button-delete-leave-type-${lt.id}`}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="holidays" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
              <div>
                <CardTitle>Company Holidays</CardTitle>
                <CardDescription>
                  Manage regular and special holidays for payroll computation
                </CardDescription>
              </div>
              <Dialog open={isHolidayDialogOpen} onOpenChange={setIsHolidayDialogOpen}>
                <Button onClick={() => setIsHolidayDialogOpen(true)} data-testid="button-add-holiday">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Holiday
                </Button>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Holiday</DialogTitle>
                    <DialogDescription>
                      Add a new company holiday
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="holidayName">Holiday Name</Label>
                      <Input
                        id="holidayName"
                        value={newHoliday.name}
                        onChange={(e) => setNewHoliday({ ...newHoliday, name: e.target.value })}
                        placeholder="e.g., New Year's Day"
                        data-testid="input-holiday-name"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="holidayDate">Date</Label>
                        <Input
                          id="holidayDate"
                          type="date"
                          value={newHoliday.date}
                          onChange={(e) => {
                            const date = e.target.value;
                            const year = date ? new Date(date).getFullYear() : new Date().getFullYear();
                            setNewHoliday({ ...newHoliday, date, year });
                          }}
                          data-testid="input-holiday-date"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="holidayType">Type</Label>
                        <Select
                          value={newHoliday.type}
                          onValueChange={(value: "Regular" | "Special") => 
                            setNewHoliday({ ...newHoliday, type: value })
                          }
                        >
                          <SelectTrigger data-testid="select-holiday-type">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Regular">Regular Holiday</SelectItem>
                            <SelectItem value="Special">Special Non-Working</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsHolidayDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button
                      onClick={() => createHolidayMutation.mutate(newHoliday)}
                      disabled={!newHoliday.name || !newHoliday.date || createHolidayMutation.isPending}
                      data-testid="button-save-holiday"
                    >
                      {createHolidayMutation.isPending ? "Saving..." : "Save Holiday"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {loadingHolidays ? (
                <div className="space-y-3">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              ) : holidays.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No holidays configured. Add holidays for accurate payroll computation.
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="w-20">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {holidays.map((holiday) => (
                      <TableRow key={holiday.id} data-testid={`row-holiday-${holiday.id}`}>
                        <TableCell className="font-medium">
                          {format(new Date(holiday.date), "MMM d, yyyy")}
                        </TableCell>
                        <TableCell>{holiday.name}</TableCell>
                        <TableCell>
                          <Badge variant={holiday.type === "Regular" ? "default" : "secondary"}>
                            {holiday.type}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => deleteHolidayMutation.mutate(holiday.id)}
                            data-testid={`button-delete-holiday-${holiday.id}`}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="allocations" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-col gap-4 space-y-0">
              <div className="flex flex-row items-center justify-between gap-2">
                <div>
                  <CardTitle>Leave Allocations</CardTitle>
                  <CardDescription>
                    Assign annual leave balances to employees. Use bulk allocation to auto-assign based on leave type settings.
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Select
                    value={selectedYear.toString()}
                    onValueChange={(value) => setSelectedYear(parseInt(value))}
                  >
                    <SelectTrigger className="w-32" data-testid="select-allocation-year">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[...Array(5)].map((_, i) => {
                        const year = new Date().getFullYear() - 2 + i;
                        return (
                          <SelectItem key={year} value={year.toString()}>
                            {year}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                  <Dialog open={isLeaveAllocationDialogOpen} onOpenChange={setIsLeaveAllocationDialogOpen}>
                    <Button onClick={() => setIsLeaveAllocationDialogOpen(true)} data-testid="button-add-allocation">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Allocation
                    </Button>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Leave Allocation</DialogTitle>
                      <DialogDescription>
                        Assign leave balance to an employee for the year
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="allocationEmployee">Employee</Label>
                        <Select
                          value={newLeaveAllocation.employeeId}
                          onValueChange={(value) =>
                            setNewLeaveAllocation({ ...newLeaveAllocation, employeeId: value })
                          }
                        >
                          <SelectTrigger data-testid="select-allocation-employee">
                            <SelectValue placeholder="Select employee" />
                          </SelectTrigger>
                          <SelectContent>
                            {employees.map((employee) => (
                              <SelectItem key={employee.id} value={employee.id}>
                                {employee.firstName} {employee.lastName}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="allocationLeaveType">Leave Type</Label>
                        <Select
                          value={newLeaveAllocation.leaveTypeId}
                          onValueChange={(value) =>
                            setNewLeaveAllocation({ ...newLeaveAllocation, leaveTypeId: value })
                          }
                        >
                          <SelectTrigger data-testid="select-allocation-leave-type">
                            <SelectValue placeholder="Select leave type" />
                          </SelectTrigger>
                          <SelectContent>
                            {leaveTypes.map((lt) => (
                              <SelectItem key={lt.id} value={lt.id}>
                                {lt.name} ({lt.code})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="allocationYear">Year</Label>
                          <Input
                            id="allocationYear"
                            type="number"
                            value={newLeaveAllocation.year}
                            onChange={(e) =>
                              setNewLeaveAllocation({ ...newLeaveAllocation, year: e.target.value })
                            }
                            placeholder="2026"
                            data-testid="input-allocation-year"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="totalAllocated">Total Days</Label>
                          <Input
                            id="totalAllocated"
                            type="number"
                            step="0.5"
                            value={newLeaveAllocation.totalAllocated}
                            onChange={(e) =>
                              setNewLeaveAllocation({ ...newLeaveAllocation, totalAllocated: e.target.value })
                            }
                            placeholder="15"
                            data-testid="input-total-allocated"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="usedDays">Used Days</Label>
                          <Input
                            id="usedDays"
                            type="number"
                            step="0.5"
                            value={newLeaveAllocation.used}
                            onChange={(e) =>
                              setNewLeaveAllocation({ ...newLeaveAllocation, used: e.target.value })
                            }
                            placeholder="0"
                            data-testid="input-used-days"
                          />
                        </div>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button
                        variant="outline"
                        onClick={() => setIsLeaveAllocationDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={() => createLeaveAllocationMutation.mutate(newLeaveAllocation)}
                        disabled={
                          !newLeaveAllocation.employeeId ||
                          !newLeaveAllocation.leaveTypeId ||
                          !newLeaveAllocation.totalAllocated ||
                          createLeaveAllocationMutation.isPending
                        }
                        data-testid="button-save-allocation"
                      >
                        {createLeaveAllocationMutation.isPending ? "Saving..." : "Save Allocation"}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
              </div>
              <div className="flex flex-wrap gap-2 pt-2 border-t">
                <Button
                  variant="outline"
                  onClick={() => bulkAllocateMutation.mutate({ year: selectedYear, proRateNewHires: true })}
                  disabled={bulkAllocateMutation.isPending}
                  data-testid="button-bulk-allocate"
                >
                  {bulkAllocateMutation.isPending ? "Allocating..." : `Bulk Allocate ${selectedYear}`}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => processAccrualsMutation.mutate()}
                  disabled={processAccrualsMutation.isPending}
                  data-testid="button-process-accruals"
                >
                  {processAccrualsMutation.isPending ? "Processing..." : "Process Monthly Accruals"}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => processCarryoverMutation.mutate({ fromYear: selectedYear - 1, maxCarryoverDays: 5 })}
                  disabled={processCarryoverMutation.isPending}
                  data-testid="button-process-carryover"
                >
                  {processCarryoverMutation.isPending ? "Processing..." : `Carryover from ${selectedYear - 1}`}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loadingAllocations ? (
                <div className="space-y-3">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              ) : leaveAllocations.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No leave allocations found for {selectedYear}. Add allocations to track employee leave balances.
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead>Leave Type</TableHead>
                      <TableHead>Year</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Accrued</TableHead>
                      <TableHead>Used</TableHead>
                      <TableHead>Remaining</TableHead>
                      <TableHead className="w-20">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {leaveAllocations.map((allocation) => (
                      <TableRow key={allocation.id} data-testid={`row-allocation-${allocation.id}`}>
                        <TableCell className="font-medium">
                          {getEmployeeName(allocation.employeeId)}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">
                            {getLeaveTypeName(allocation.leaveTypeId)}
                          </Badge>
                        </TableCell>
                        <TableCell>{allocation.year}</TableCell>
                        <TableCell>{allocation.totalAllocated} days</TableCell>
                        <TableCell className="text-blue-600">
                          {(allocation as any).accruedToDate || allocation.totalAllocated} days
                        </TableCell>
                        <TableCell>{allocation.used} days</TableCell>
                        <TableCell>
                          <span className="font-medium text-green-600">
                            {allocation.remaining} days
                          </span>
                        </TableCell>
                        <TableCell>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => deleteLeaveAllocationMutation.mutate(allocation.id)}
                            data-testid={`button-delete-allocation-${allocation.id}`}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="13th-month" className="space-y-4">
          <ThirteenthMonthTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
