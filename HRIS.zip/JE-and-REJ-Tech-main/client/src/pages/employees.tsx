import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm, UseFormReturn } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { usePagination } from "@/hooks/use-pagination";
import { TablePagination } from "@/components/ui/table-pagination";
import { getPhotoDisplayUrl } from "@/lib/photo-url";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Users,
  Plus,
  Search,
  Key,
  QrCode,
  Download,
  Loader2,
  MoreHorizontal,
  Pencil,
  Trash2,
  EyeOff,
  Eye,
  Shield,
} from "lucide-react";
import {
  formatCurrency,
  formatDate,
  getInitials,
  getStatusColorClass,
  getRoleDisplayName
} from "@/lib/utils";
import { BulkEmployeeUpload } from "@/components/bulk-employee-upload";
import type { Employee } from "@shared/schema";

const employeeFormSchema = z.object({
  // Personal Information
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  middleName: z.string().optional(),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  phone: z.string().optional(),
  address: z.string().optional(),
  birthDate: z.string().optional(),
  gender: z.string().optional(),
  civilStatus: z.string().optional(),
  nationality: z.string().optional(),
  // Emergency Contact
  emergencyContactName: z.string().optional(),
  emergencyContactPhone: z.string().optional(),
  emergencyContactRelation: z.string().optional(),
  // Employment Details
  role: z.enum(["ADMIN", "HR", "ENGINEER", "WORKER"]),
  position: z.string().optional(),
  department: z.string().optional(),
  employeeNo: z.string().optional(),
  status: z.enum(["Active", "Probationary", "Suspended", "Terminated", "Inactive"]),
  startDate: z.string().optional(),
  // Compensation
  rateType: z.enum(["daily", "monthly"]),
  baseRate: z.string().min(1, "Base rate is required"),
  colaAllowance: z.string().optional(), // Monthly COLA (Cost of Living Allowance)
  // Government IDs
  sssNo: z.string().optional(),
  tinNo: z.string().optional(),
  philhealthNo: z.string().optional(),
  pagibigNo: z.string().optional(),
  // Banking
  bankName: z.string().optional(),
  bankAccountNo: z.string().optional(),
  // Work Schedule
  shiftStartTime: z.string().optional(),
  shiftEndTime: z.string().optional(),
  shiftWorkDays: z.string().optional(),
  // Deduction Flags
  enableSSSDeduction: z.boolean().optional(),
  enablePhilhealthDeduction: z.boolean().optional(),
  enablePagibigDeduction: z.boolean().optional(),
  enableTaxWithholding: z.boolean().optional(),
  // Geofencing Override
  allowAnywhereLogin: z.boolean().optional(),
});

type EmployeeFormData = z.infer<typeof employeeFormSchema>;

const defaultFormValues: EmployeeFormData = {
  // Personal Information
  firstName: "",
  lastName: "",
  middleName: "",
  email: "",
  phone: "",
  address: "",
  birthDate: "",
  gender: "",
  civilStatus: "",
  nationality: "Filipino",
  // Emergency Contact
  emergencyContactName: "",
  emergencyContactPhone: "",
  emergencyContactRelation: "",
  // Employment Details
  role: "WORKER",
  position: "",
  department: "",
  employeeNo: "",
  status: "Active",
  startDate: new Date().toISOString().split("T")[0],
  // Compensation
  rateType: "daily",
  baseRate: "",
  colaAllowance: "",
  // Government IDs
  sssNo: "",
  tinNo: "",
  philhealthNo: "",
  pagibigNo: "",
  // Banking
  bankName: "",
  bankAccountNo: "",
  // Work Schedule
  shiftStartTime: "08:00",
  shiftEndTime: "17:00",
  shiftWorkDays: "Mon,Tue,Wed,Thu,Fri",
  // Deduction Flags
  enableSSSDeduction: true,
  enablePhilhealthDeduction: true,
  enablePagibigDeduction: true,
  enableTaxWithholding: false,
  // Geofencing Override
  allowAnywhereLogin: false,
};

// EmployeeFormFields extracted outside the main component to prevent focus loss.
// When defined inside, React recreates the component on each render, causing inputs to lose focus.
function EmployeeFormFields({ form }: { form: UseFormReturn<EmployeeFormData> }) {
  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-muted-foreground">Personal Information</h3>
        <div className="grid gap-4 sm:grid-cols-3">
          <FormField
            control={form.control}
            name="firstName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>First Name</FormLabel>
                <FormControl>
                  <Input placeholder="Juan" {...field} data-testid="input-first-name" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="middleName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Middle Name</FormLabel>
                <FormControl>
                  <Input placeholder="Santos" {...field} data-testid="input-middle-name" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="lastName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Last Name</FormLabel>
                <FormControl>
                  <Input placeholder="Dela Cruz" {...field} data-testid="input-last-name" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input type="email" placeholder="juan@email.com" {...field} data-testid="input-email" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Phone</FormLabel>
                <FormControl>
                  <Input placeholder="+63 917 123 4567" {...field} data-testid="input-phone" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <FormField
          control={form.control}
          name="address"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Address</FormLabel>
              <FormControl>
                <Input placeholder="123 Main St, Manila" {...field} data-testid="input-address" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="grid gap-4 sm:grid-cols-4">
          <FormField
            control={form.control}
            name="birthDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Birth Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} data-testid="input-birth-date" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="gender"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Gender</FormLabel>
                <Select onValueChange={field.onChange} value={field.value || ""}>
                  <FormControl>
                    <SelectTrigger data-testid="select-gender">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="Male">Male</SelectItem>
                    <SelectItem value="Female">Female</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="civilStatus"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Civil Status</FormLabel>
                <Select onValueChange={field.onChange} value={field.value || ""}>
                  <FormControl>
                    <SelectTrigger data-testid="select-civil-status">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="Single">Single</SelectItem>
                    <SelectItem value="Married">Married</SelectItem>
                    <SelectItem value="Widowed">Widowed</SelectItem>
                    <SelectItem value="Separated">Separated</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="nationality"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nationality</FormLabel>
                <FormControl>
                  <Input placeholder="Filipino" {...field} data-testid="input-nationality" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-medium text-muted-foreground">Emergency Contact</h3>
        <div className="grid gap-4 sm:grid-cols-3">
          <FormField
            control={form.control}
            name="emergencyContactName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Contact Name</FormLabel>
                <FormControl>
                  <Input placeholder="Maria Dela Cruz" {...field} data-testid="input-emergency-name" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="emergencyContactPhone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Contact Phone</FormLabel>
                <FormControl>
                  <Input placeholder="+63 917 987 6543" {...field} data-testid="input-emergency-phone" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="emergencyContactRelation"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Relationship</FormLabel>
                <FormControl>
                  <Input placeholder="Spouse" {...field} data-testid="input-emergency-relation" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-medium text-muted-foreground">Employment Details</h3>
        <div className="grid gap-4 sm:grid-cols-3">
          <FormField
            control={form.control}
            name="employeeNo"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Employee ID</FormLabel>
                <FormControl>
                  <Input placeholder="EMP-001" {...field} data-testid="input-employee-no" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="role"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Role</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-role">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="ADMIN">Admin</SelectItem>
                    <SelectItem value="HR">HR</SelectItem>
                    <SelectItem value="ENGINEER">Engineer</SelectItem>
                    <SelectItem value="WORKER">Worker</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="position"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Position</FormLabel>
                <FormControl>
                  <Input placeholder="Electrician" {...field} data-testid="input-position" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <div className="grid gap-4 sm:grid-cols-3">
          <FormField
            control={form.control}
            name="department"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Department</FormLabel>
                <FormControl>
                  <Input placeholder="Operations" {...field} data-testid="input-department" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Probationary">Probationary</SelectItem>
                    <SelectItem value="Suspended">Suspended</SelectItem>
                    <SelectItem value="Terminated">Terminated</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="startDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Start Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} data-testid="input-start-date" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-medium text-muted-foreground">Compensation</h3>
        <div className="grid gap-4 sm:grid-cols-3">
          <FormField
            control={form.control}
            name="rateType"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Rate Type</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-rate-type">
                      <SelectValue placeholder="Select rate type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="baseRate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Base Rate (PHP)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="500" {...field} data-testid="input-base-rate" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="colaAllowance"
            render={({ field }) => (
              <FormItem>
                <FormLabel>COLA (Monthly)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="0" {...field} data-testid="input-cola-allowance" />
                </FormControl>
                <FormMessage />
                <p className="text-xs text-muted-foreground">Cost of Living Allowance (tax-exempt)</p>
              </FormItem>
            )}
          />
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-medium text-muted-foreground">Banking Information</h3>
        <div className="grid gap-4 sm:grid-cols-2">
          <FormField
            control={form.control}
            name="bankName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bank Name</FormLabel>
                <FormControl>
                  <Input placeholder="BDO, BPI, Metrobank, etc." {...field} data-testid="input-bank-name" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="bankAccountNo"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bank Account Number</FormLabel>
                <FormControl>
                  <Input placeholder="001234567890" {...field} data-testid="input-bank-account" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-medium text-muted-foreground">Government IDs & Deductions</h3>
        <p className="text-xs text-muted-foreground">Enable checkbox to apply deductions for each contribution</p>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <FormField
              control={form.control}
              name="sssNo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>SSS Number</FormLabel>
                  <div className="flex items-center gap-2">
                    <FormControl>
                      <Input placeholder="00-0000000-0" {...field} data-testid="input-sss" className="flex-1" />
                    </FormControl>
                    <FormField
                      control={form.control}
                      name="enableSSSDeduction"
                      render={({ field: checkField }) => (
                        <FormItem className="flex items-center space-x-1 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={checkField.value}
                              onCheckedChange={checkField.onChange}
                              data-testid="checkbox-enable-sss"
                            />
                          </FormControl>
                          <FormLabel className="text-xs font-normal cursor-pointer">Deduct</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="space-y-2">
            <FormField
              control={form.control}
              name="tinNo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>TIN</FormLabel>
                  <div className="flex items-center gap-2">
                    <FormControl>
                      <Input placeholder="000-000-000-000" {...field} data-testid="input-tin" className="flex-1" />
                    </FormControl>
                    <FormField
                      control={form.control}
                      name="enableTaxWithholding"
                      render={({ field: checkField }) => (
                        <FormItem className="flex items-center space-x-1 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={checkField.value}
                              onCheckedChange={checkField.onChange}
                              data-testid="checkbox-enable-tax"
                            />
                          </FormControl>
                          <FormLabel className="text-xs font-normal cursor-pointer">Withhold</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="space-y-2">
            <FormField
              control={form.control}
              name="philhealthNo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>PhilHealth Number</FormLabel>
                  <div className="flex items-center gap-2">
                    <FormControl>
                      <Input placeholder="00-000000000-0" {...field} data-testid="input-philhealth" className="flex-1" />
                    </FormControl>
                    <FormField
                      control={form.control}
                      name="enablePhilhealthDeduction"
                      render={({ field: checkField }) => (
                        <FormItem className="flex items-center space-x-1 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={checkField.value}
                              onCheckedChange={checkField.onChange}
                              data-testid="checkbox-enable-philhealth"
                            />
                          </FormControl>
                          <FormLabel className="text-xs font-normal cursor-pointer">Deduct</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="space-y-2">
            <FormField
              control={form.control}
              name="pagibigNo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Pag-IBIG Number</FormLabel>
                  <div className="flex items-center gap-2">
                    <FormControl>
                      <Input placeholder="0000-0000-0000" {...field} data-testid="input-pagibig" className="flex-1" />
                    </FormControl>
                    <FormField
                      control={form.control}
                      name="enablePagibigDeduction"
                      render={({ field: checkField }) => (
                        <FormItem className="flex items-center space-x-1 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={checkField.value}
                              onCheckedChange={checkField.onChange}
                              data-testid="checkbox-enable-pagibig"
                            />
                          </FormControl>
                          <FormLabel className="text-xs font-normal cursor-pointer">Deduct</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-medium text-muted-foreground">Work Schedule</h3>
        <div className="grid gap-4 sm:grid-cols-2">
          <FormField
            control={form.control}
            name="shiftStartTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Shift Start</FormLabel>
                <FormControl>
                  <Input type="time" {...field} data-testid="input-shift-start" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="shiftEndTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Shift End</FormLabel>
                <FormControl>
                  <Input type="time" {...field} data-testid="input-shift-end" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <FormField
          control={form.control}
          name="shiftWorkDays"
          render={({ field }) => {
            const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
            const selectedDays = field.value ? field.value.split(",").map(d => d.trim()) : [];
            const toggleDay = (day: string) => {
              const newDays = selectedDays.includes(day)
                ? selectedDays.filter(d => d !== day)
                : [...selectedDays, day];
              const orderedDays = days.filter(d => newDays.includes(d));
              field.onChange(orderedDays.join(","));
            };
            return (
              <FormItem>
                <FormLabel>Work Days</FormLabel>
                <FormControl>
                  <div className="flex flex-wrap gap-2" data-testid="input-work-days">
                    {days.map((day) => (
                      <label
                        key={day}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md border cursor-pointer text-sm transition-colors ${
                          selectedDays.includes(day)
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-background hover:bg-muted border-input"
                        }`}
                      >
                        <Checkbox
                          checked={selectedDays.includes(day)}
                          onCheckedChange={() => toggleDay(day)}
                          className="sr-only"
                        />
                        {day}
                      </label>
                    ))}
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            );
          }}
        />
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-medium text-muted-foreground">Attendance Settings</h3>
        <FormField
          control={form.control}
          name="allowAnywhereLogin"
          render={({ field }) => (
            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
              <FormControl>
                <Checkbox
                  checked={field.value}
                  onCheckedChange={field.onChange}
                  data-testid="checkbox-allow-anywhere-login"
                />
              </FormControl>
              <div className="space-y-1 leading-none">
                <FormLabel className="cursor-pointer">
                  Allow Login from Anywhere
                </FormLabel>
                <p className="text-xs text-muted-foreground">
                  When enabled, this employee can clock in from any location without geofencing restrictions.
                  Useful for roaming employees, supervisors, or those working at multiple sites.
                </p>
              </div>
            </FormItem>
          )}
        />
      </div>

    </div>
  );
}

export default function EmployeesPage() {
  const { toast } = useToast();
  const { isSuperadmin } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [showInactive, setShowInactive] = useState(false);
  const [showSystemAccounts, setShowSystemAccounts] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeactivateDialogOpen, setIsDeactivateDialogOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false);
  const [passwordEmployeeId, setPasswordEmployeeId] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [isQRDialogOpen, setIsQRDialogOpen] = useState(false);
  const [qrEmployee, setQREmployee] = useState<Employee | null>(null);
  const [qrCodeData, setQRCodeData] = useState<string | null>(null);
  const [isLoadingQR, setIsLoadingQR] = useState(false);

  // Include hidden employees only if superadmin and toggle is on
  const includeHidden = isSuperadmin && showSystemAccounts;

  const { data: employees, isLoading } = useQuery<Employee[]>({
    queryKey: ["/api/employees", { includeHidden }],
    queryFn: async () => {
      const url = includeHidden ? "/api/employees?includeHidden=true" : "/api/employees";
      const response = await fetch(url, { credentials: "include" });
      if (!response.ok) throw new Error("Failed to fetch employees");
      return response.json();
    },
  });

  // Mutation for toggling hidden status (superadmin only)
  const toggleHiddenMutation = useMutation({
    mutationFn: async ({ id, isHidden }: { id: string; isHidden: boolean }) => {
      return apiRequest("PATCH", `/api/employees/toggle-hidden/${id}`, { isHidden });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Visibility Updated",
        description: "Employee visibility has been updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update employee visibility.",
        variant: "destructive",
      });
    },
  });

  const handleShowQR = async (employee: Employee) => {
    setQREmployee(employee);
    setIsQRDialogOpen(true);
    setIsLoadingQR(true);
    setQRCodeData(null);
    
    try {
      const response = await fetch(`/api/employees/${employee.id}/qr-code`, {
        credentials: "include",
      });
      if (!response.ok) {
        throw new Error("Failed to generate QR code");
      }
      const data = await response.json();
      setQRCodeData(data.qrCode);
    } catch (error: any) {
      toast({
        title: "QR Code Error",
        description: error.message || "Failed to generate QR code",
        variant: "destructive",
      });
    } finally {
      setIsLoadingQR(false);
    }
  };

  const handleDownloadQR = async () => {
    if (!qrEmployee) return;
    
    try {
      const response = await fetch(`/api/employees/${qrEmployee.id}/qr-code/download`, {
        credentials: "include",
      });
      if (!response.ok) {
        throw new Error("Failed to download QR code");
      }
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${qrEmployee.lastName}_${qrEmployee.firstName}_QR.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "QR Code Downloaded",
        description: "The QR code has been saved to your device.",
      });
    } catch (error: any) {
      toast({
        title: "Download Error",
        description: error.message || "Failed to download QR code",
        variant: "destructive",
      });
    }
  };

  const createForm = useForm<EmployeeFormData>({
    resolver: zodResolver(employeeFormSchema),
    defaultValues: defaultFormValues,
  });

  const editForm = useForm<EmployeeFormData>({
    resolver: zodResolver(employeeFormSchema),
    defaultValues: defaultFormValues,
  });

  useEffect(() => {
    if (selectedEmployee && isEditDialogOpen) {
      editForm.reset({
        // Personal Information
        firstName: selectedEmployee.firstName,
        lastName: selectedEmployee.lastName,
        middleName: selectedEmployee.middleName || "",
        email: selectedEmployee.email || "",
        phone: selectedEmployee.phone || "",
        address: selectedEmployee.address || "",
        birthDate: selectedEmployee.birthDate ? new Date(selectedEmployee.birthDate).toISOString().split("T")[0] : "",
        gender: selectedEmployee.gender || "",
        civilStatus: selectedEmployee.civilStatus || "",
        nationality: selectedEmployee.nationality || "Filipino",
        // Emergency Contact
        emergencyContactName: selectedEmployee.emergencyContactName || "",
        emergencyContactPhone: selectedEmployee.emergencyContactPhone || "",
        emergencyContactRelation: selectedEmployee.emergencyContactRelation || "",
        // Employment Details
        role: selectedEmployee.role as any,
        position: selectedEmployee.position || "",
        department: selectedEmployee.department || "",
        employeeNo: selectedEmployee.employeeNo || "",
        status: selectedEmployee.status as any || "Active",
        startDate: selectedEmployee.startDate ? new Date(selectedEmployee.startDate).toISOString().split("T")[0] : "",
        // Compensation
        rateType: selectedEmployee.rateType as any || "daily",
        baseRate: selectedEmployee.baseRate?.toString() || "",
        colaAllowance: (selectedEmployee as any).colaAllowance?.toString() || "",
        // Government IDs
        sssNo: selectedEmployee.sssNo || "",
        tinNo: selectedEmployee.tinNo || "",
        philhealthNo: selectedEmployee.philhealthNo || "",
        pagibigNo: selectedEmployee.pagibigNo || "",
        // Banking
        bankName: selectedEmployee.bankName || "",
        bankAccountNo: selectedEmployee.bankAccountNo || "",
        // Work Schedule
        shiftStartTime: selectedEmployee.shiftStartTime || "08:00",
        shiftEndTime: selectedEmployee.shiftEndTime || "17:00",
        shiftWorkDays: Array.isArray(selectedEmployee.shiftWorkDays) ? selectedEmployee.shiftWorkDays.join(",") : "Mon,Tue,Wed,Thu,Fri",
        // Deduction Flags
        enableSSSDeduction: selectedEmployee.enableSSSDeduction ?? true,
        enablePhilhealthDeduction: selectedEmployee.enablePhilhealthDeduction ?? true,
        enablePagibigDeduction: selectedEmployee.enablePagibigDeduction ?? true,
        enableTaxWithholding: selectedEmployee.enableTaxWithholding ?? false,
        // Geofencing Override
        allowAnywhereLogin: selectedEmployee.allowAnywhereLogin ?? false,
      });
    }
  }, [selectedEmployee, isEditDialogOpen, editForm]);

  const createMutation = useMutation({
    mutationFn: async (data: EmployeeFormData) => {
      const payload = {
        ...data,
        shiftWorkDays: data.shiftWorkDays ? data.shiftWorkDays.split(',').map(d => d.trim()) : [],
      };
      return apiRequest("POST", "/api/employees", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsCreateDialogOpen(false);
      createForm.reset(defaultFormValues);
      toast({
        title: "Employee Added",
        description: "New employee has been successfully added.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add employee. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: EmployeeFormData }) => {
      const payload = {
        ...data,
        shiftWorkDays: data.shiftWorkDays ? data.shiftWorkDays.split(',').map(d => d.trim()) : [],
      };
      return apiRequest("PATCH", `/api/employees/${id}`, payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setIsEditDialogOpen(false);
      setSelectedEmployee(null);
      toast({
        title: "Employee Updated",
        description: "Employee information has been updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update employee. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deactivateMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("PATCH", `/api/employees/${id}/deactivate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsDeactivateDialogOpen(false);
      setSelectedEmployee(null);
      toast({
        title: "Employee Deactivated",
        description: "Employee has been deactivated. Their records are preserved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to deactivate employee.",
        variant: "destructive",
      });
    },
  });

  const reactivateMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("PATCH", `/api/employees/${id}/reactivate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Employee Reactivated",
        description: "Employee has been reactivated and is now active.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to reactivate employee.",
        variant: "destructive",
      });
    },
  });

  const setPasswordMutation = useMutation({
    mutationFn: async ({ employeeId, password }: { employeeId: string; password: string }) => {
      return apiRequest("POST", "/api/auth/set-password", { employeeId, password });
    },
    onSuccess: () => {
      setIsPasswordDialogOpen(false);
      setNewPassword("");
      setPasswordEmployeeId(null);
      toast({
        title: "Password Set",
        description: "Employee can now log in with their email and the new password.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to set password.",
        variant: "destructive",
      });
    },
  });

  const onCreateSubmit = (data: EmployeeFormData) => {
    createMutation.mutate(data);
  };

  const onEditSubmit = (data: EmployeeFormData) => {
    if (selectedEmployee) {
      updateMutation.mutate({ id: selectedEmployee.id, data });
    }
  };

  const handleEdit = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsEditDialogOpen(true);
  };

  const handleDeactivate = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsDeactivateDialogOpen(true);
  };

  const handleSetPassword = () => {
    if (passwordEmployeeId && newPassword.length >= 6) {
      setPasswordMutation.mutate({ employeeId: passwordEmployeeId, password: newPassword });
    }
  };

  const filteredEmployees = employees?.filter((employee) => {
    // Filter by inactive status - hide inactive by default, show all when toggle is on
    const isInactive = employee.status === "Inactive";
    if (!showInactive && isInactive) return false;

    // Filter by search query
    const searchLower = searchQuery.toLowerCase();
    return (
      employee.firstName.toLowerCase().includes(searchLower) ||
      employee.lastName.toLowerCase().includes(searchLower) ||
      employee.email?.toLowerCase().includes(searchLower) ||
      employee.role.toLowerCase().includes(searchLower)
    );
  }) || [];

  // Pagination
  const pagination = usePagination(filteredEmployees);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Employees</h1>
          <p className="text-muted-foreground">
            Manage your workforce and employee records
          </p>
        </div>
        <div className="flex gap-2">
          <BulkEmployeeUpload />
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-employee" onClick={() => createForm.reset(defaultFormValues)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Employee
              </Button>
            </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Employee</DialogTitle>
              <DialogDescription>
                Create a new employee record with their personal and employment details.
              </DialogDescription>
            </DialogHeader>
            <Form {...createForm}>
              <form onSubmit={createForm.handleSubmit(onCreateSubmit)}>
                <EmployeeFormFields form={createForm} />
                <DialogFooter className="mt-6">
                  <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending} data-testid="button-save-employee">
                    {createMutation.isPending ? "Adding..." : "Add Employee"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Employees</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{employees?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active</CardTitle>
            <div className="h-2 w-2 rounded-full bg-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {employees?.filter(e => e.status?.toLowerCase() === "active").length || 0}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Office Staff</CardTitle>
            <div className="h-2 w-2 rounded-full bg-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {employees?.filter(e => e.role === "ADMIN" || e.role === "HR").length || 0}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Skilled Workers</CardTitle>
            <div className="h-2 w-2 rounded-full bg-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {employees?.filter(e => e.role === "WORKER").length || 0}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Engineers</CardTitle>
            <div className="h-2 w-2 rounded-full bg-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {employees?.filter(e => e.role === "ENGINEER").length || 0}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Inactive</CardTitle>
            <div className="h-2 w-2 rounded-full bg-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {employees?.filter(e => e.status === "Inactive").length || 0}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search employees by name, email, or role..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                aria-label="Search employees by name, email, or role"
                data-testid="input-search-employees"
              />
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="show-inactive"
                  checked={showInactive}
                  onCheckedChange={(checked) => setShowInactive(checked === true)}
                  data-testid="checkbox-show-inactive"
                />
                <label
                  htmlFor="show-inactive"
                  className="text-sm font-medium cursor-pointer"
                >
                  Include Inactive
                </label>
              </div>
              {isSuperadmin && (
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="show-system-accounts"
                    checked={showSystemAccounts}
                    onCheckedChange={(checked) => setShowSystemAccounts(checked === true)}
                    data-testid="checkbox-show-system-accounts"
                  />
                  <label
                    htmlFor="show-system-accounts"
                    className="text-sm font-medium cursor-pointer flex items-center gap-1"
                  >
                    <Shield className="h-3 w-3" />
                    System Accounts
                  </label>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Employee Table */}
      <Card>
        <CardHeader>
          <CardTitle>{showInactive ? "All Employees" : "Active Employees"}</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filteredEmployees.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Rate</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead className="w-[80px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pagination.paginatedData.map((employee) => (
                    <TableRow key={employee.id} data-testid={`employee-row-${employee.id}`}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={getPhotoDisplayUrl(employee.profilePhotoUrl) || undefined} />
                            <AvatarFallback>
                              {getInitials(employee.firstName, employee.lastName)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">
                              {employee.firstName} {employee.lastName}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {employee.email || "No email"}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{getRoleDisplayName(employee.role)}</p>
                          <p className="text-sm text-muted-foreground">{employee.position}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-mono font-medium">
                            {formatCurrency(employee.baseRate)}
                          </p>
                          <p className="text-xs text-muted-foreground capitalize">
                            {employee.rateType}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className={getStatusColorClass(employee.status)}>
                            {employee.status}
                          </Badge>
                          {(employee as any).isHidden && (
                            <Badge variant="outline" className="text-amber-600 border-amber-600">
                              <EyeOff className="h-3 w-3 mr-1" />
                              Hidden
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {employee.startDate ? formatDate(employee.startDate) : "-"}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" aria-label={`Actions for ${employee.firstName} ${employee.lastName}`} data-testid={`button-employee-menu-${employee.id}`}>
                              <MoreHorizontal className="h-4 w-4" aria-hidden="true" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleShowQR(employee)}>
                              <QrCode className="mr-2 h-4 w-4" />
                              QR Badge
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => {
                                if (!employee.email) {
                                  toast({
                                    title: "Email Required",
                                    description: "Please add an email address first.",
                                    variant: "destructive",
                                  });
                                  return;
                                }
                                setPasswordEmployeeId(employee.id);
                                setIsPasswordDialogOpen(true);
                              }}
                            >
                              <Key className="mr-2 h-4 w-4" />
                              Set Password
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => handleEdit(employee)}>
                              <Pencil className="mr-2 h-4 w-4" />
                              Edit Employee
                            </DropdownMenuItem>
                            {isSuperadmin && (
                              <DropdownMenuItem
                                onClick={() => toggleHiddenMutation.mutate({
                                  id: employee.id,
                                  isHidden: !(employee as any).isHidden,
                                })}
                              >
                                {(employee as any).isHidden ? (
                                  <>
                                    <Eye className="mr-2 h-4 w-4" />
                                    Show in Employee List
                                  </>
                                ) : (
                                  <>
                                    <EyeOff className="mr-2 h-4 w-4" />
                                    Hide from Employee List
                                  </>
                                )}
                              </DropdownMenuItem>
                            )}
                            {employee.status === "Inactive" ? (
                              <DropdownMenuItem
                                onClick={() => reactivateMutation.mutate(employee.id)}
                              >
                                <Users className="mr-2 h-4 w-4" />
                                Reactivate Employee
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem
                                onClick={() => handleDeactivate(employee)}
                                className="text-destructive"
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Deactivate Employee
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <TablePagination
                currentPage={pagination.currentPage}
                pageSize={pagination.pageSize}
                totalPages={pagination.totalPages}
                totalItems={pagination.totalItems}
                startIndex={pagination.startIndex}
                endIndex={pagination.endIndex}
                canGoNext={pagination.canGoNext}
                canGoPrevious={pagination.canGoPrevious}
                onPageChange={pagination.goToPage}
                onPageSizeChange={pagination.setPageSize}
                onNextPage={pagination.goToNextPage}
                onPreviousPage={pagination.goToPreviousPage}
                onFirstPage={pagination.goToFirstPage}
                onLastPage={pagination.goToLastPage}
              />
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <Users className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-1">No employees found</h3>
              <p className="text-muted-foreground mb-4">
                {searchQuery ? "Try a different search term" : "Get started by adding your first employee"}
              </p>
              {!searchQuery && (
                <Button onClick={() => setIsCreateDialogOpen(true)} data-testid="button-add-first-employee">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Employee
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Employee</DialogTitle>
            <DialogDescription>
              Update {selectedEmployee?.firstName} {selectedEmployee?.lastName}'s information.
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)}>
              <EmployeeFormFields form={editForm} />
              <DialogFooter className="mt-6">
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={updateMutation.isPending} data-testid="button-update-employee">
                  {updateMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Deactivate Confirmation */}
      <AlertDialog open={isDeactivateDialogOpen} onOpenChange={setIsDeactivateDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Deactivate Employee?</AlertDialogTitle>
            <AlertDialogDescription>
              This will deactivate {selectedEmployee?.firstName} {selectedEmployee?.lastName}. Their records will be preserved and you can reactivate them later.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => selectedEmployee && deactivateMutation.mutate(selectedEmployee.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deactivateMutation.isPending ? "Deactivating..." : "Deactivate"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Set Password Dialog */}
      <Dialog open={isPasswordDialogOpen} onOpenChange={(open) => {
        setIsPasswordDialogOpen(open);
        if (!open) {
          setNewPassword("");
          setPasswordEmployeeId(null);
        }
      }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Set Employee Password</DialogTitle>
            <DialogDescription>
              Set a temporary password for the employee. They will be prompted to change it on first login.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">New Password</label>
              <Input
                type="password"
                placeholder="Enter new password (min 6 characters)"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                data-testid="input-new-password"
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button
                variant="outline"
                onClick={() => setIsPasswordDialogOpen(false)}
                data-testid="button-cancel-password"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSetPassword}
                disabled={newPassword.length < 6 || setPasswordMutation.isPending}
                data-testid="button-confirm-password"
              >
                <Key className="h-4 w-4 mr-2" />
                {setPasswordMutation.isPending ? "Setting..." : "Set Password"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* QR Code Dialog */}
      <Dialog open={isQRDialogOpen} onOpenChange={(open) => {
        setIsQRDialogOpen(open);
        if (!open) {
          setQRCodeData(null);
          setQREmployee(null);
        }
      }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <QrCode className="h-5 w-5" />
              Employee QR Badge
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            {qrEmployee && (
              <div className="text-center space-y-2">
                <p className="font-semibold text-lg">
                  {qrEmployee.firstName} {qrEmployee.lastName}
                </p>
                <p className="text-sm text-muted-foreground">
                  {qrEmployee.position || qrEmployee.role} | Employee ID: {qrEmployee.employeeNo || "Not Assigned"}
                </p>
              </div>
            )}
            
            <div className="flex justify-center min-h-[200px] items-center">
              {isLoadingQR ? (
                <div className="flex flex-col items-center gap-3">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">Generating QR code...</p>
                </div>
              ) : qrCodeData ? (
                <div className="bg-white p-4 rounded-lg">
                  <img 
                    src={qrCodeData} 
                    alt={`QR Code badge for ${qrEmployee?.firstName} ${qrEmployee?.lastName}`}
                    className="w-64 h-64"
                  />
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">Failed to load QR code</p>
              )}
            </div>
            
            <p className="text-xs text-center text-muted-foreground">
              Print this QR code on the employee's ID badge for clock-in/clock-out
            </p>
            
            <div className="flex gap-2 justify-center">
              <Button
                variant="outline"
                onClick={() => setIsQRDialogOpen(false)}
              >
                Close
              </Button>
              <Button
                onClick={handleDownloadQR}
                disabled={!qrCodeData}
                data-testid="button-download-qr"
              >
                <Download className="h-4 w-4 mr-2" />
                Download QR Code
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
