import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { History, User, FileText, Users, Banknote, Filter, ChevronDown } from "lucide-react";
import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Button } from "@/components/ui/button";

interface AuditLog {
  id: string;
  userId: string | null;
  userName: string | null;
  action: string;
  entityType: string;
  entityId: string | null;
  oldValues: Record<string, unknown> | null;
  newValues: Record<string, unknown> | null;
  ipAddress: string | null;
  userAgent: string | null;
  createdAt: string;
}

const actionColors: Record<string, string> = {
  CREATE: "bg-green-500/10 text-green-600 dark:text-green-400",
  UPDATE: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
  DELETE: "bg-red-500/10 text-red-600 dark:text-red-400",
  GENERATE: "bg-purple-500/10 text-purple-600 dark:text-purple-400",
  APPROVE: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
  RELEASE: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
};

const entityIcons: Record<string, typeof User> = {
  Employee: Users,
  Payroll: Banknote,
  PayrollRecord: Banknote,
};

function getActionColor(action: string): string {
  const key = Object.keys(actionColors).find((k) => action.toUpperCase().includes(k));
  return key ? actionColors[key] : "bg-muted text-muted-foreground";
}

function formatActionText(action: string): string {
  return action
    .replace(/_/g, " ")
    .toLowerCase()
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function AuditLogItem({ log }: { log: AuditLog }) {
  const [isOpen, setIsOpen] = useState(false);
  const IconComponent = entityIcons[log.entityType] || FileText;
  const hasDetails = log.oldValues || log.newValues;

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <div className="flex items-start gap-4 p-4 border-b last:border-b-0 hover:bg-muted/30 transition-colors">
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-muted flex items-center justify-center">
          <IconComponent className="w-5 h-5 text-muted-foreground" />
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge className={getActionColor(log.action)} variant="secondary">
              {formatActionText(log.action)}
            </Badge>
            <span className="text-sm text-muted-foreground">{log.entityType}</span>
            {log.entityId && (
              <span className="text-xs text-muted-foreground font-mono truncate max-w-32">
                #{log.entityId.slice(0, 8)}
              </span>
            )}
          </div>
          
          <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
            <span>
              {log.createdAt
                ? format(new Date(log.createdAt), "MMM d, yyyy 'at' h:mm a")
                : "Unknown date"}
            </span>
            {(log.userName || log.userId) && (
              <>
                <span>by</span>
                <span className="font-medium">
                  {log.userName || `User #${log.userId?.slice(0, 8)}`}
                </span>
              </>
            )}
          </div>

          {hasDetails && (
            <CollapsibleTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="mt-2 h-7 px-2 text-xs"
                data-testid={`button-expand-log-${log.id}`}
              >
                <ChevronDown className={`w-3 h-3 mr-1 transition-transform ${isOpen ? "rotate-180" : ""}`} />
                {isOpen ? "Hide details" : "View changes"}
              </Button>
            </CollapsibleTrigger>
          )}
        </div>
      </div>

      <CollapsibleContent>
        <div className="px-4 pb-4 pt-0 ml-14">
          <div className="grid gap-4 md:grid-cols-2">
            {log.oldValues && Object.keys(log.oldValues).length > 0 && (
              <div className="p-3 rounded-md bg-red-500/5 border border-red-500/20">
                <h4 className="text-xs font-medium text-red-600 dark:text-red-400 mb-2">Before</h4>
                <pre className="text-xs overflow-auto max-h-40 text-muted-foreground">
                  {JSON.stringify(log.oldValues, null, 2)}
                </pre>
              </div>
            )}
            {log.newValues && Object.keys(log.newValues).length > 0 && (
              <div className="p-3 rounded-md bg-green-500/5 border border-green-500/20">
                <h4 className="text-xs font-medium text-green-600 dark:text-green-400 mb-2">After</h4>
                <pre className="text-xs overflow-auto max-h-40 text-muted-foreground">
                  {JSON.stringify(log.newValues, null, 2)}
                </pre>
              </div>
            )}
          </div>
          {log.ipAddress && (
            <p className="text-xs text-muted-foreground mt-2">
              IP: {log.ipAddress}
            </p>
          )}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

export default function AuditLogsPage() {
  const [entityFilter, setEntityFilter] = useState<string>("all");

  const { data: logs, isLoading } = useQuery<AuditLog[]>({
    queryKey: ["/api/audit-logs", entityFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (entityFilter && entityFilter !== "all") {
        params.set("entityType", entityFilter);
      }
      const response = await fetch(`/api/audit-logs?${params.toString()}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch audit logs");
      return response.json();
    },
  });

  const entityTypes = ["all", "Employee", "Payroll", "PayrollRecord"];

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <History className="w-6 h-6" />
            Audit Trail
          </h1>
          <p className="text-muted-foreground">
            Track all changes to employee records and payroll data
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <Select value={entityFilter} onValueChange={setEntityFilter}>
            <SelectTrigger className="w-40" data-testid="select-entity-filter">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              {entityTypes.map((type) => (
                <SelectItem key={type} value={type} data-testid={`option-filter-${type}`}>
                  {type === "all" ? "All Types" : type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>
            Showing the most recent {logs?.length || 0} audit log entries
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-4 space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center gap-4">
                  <Skeleton className="w-10 h-10 rounded-full" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-48" />
                  </div>
                </div>
              ))}
            </div>
          ) : logs && logs.length > 0 ? (
            <div className="divide-y">
              {logs.map((log) => (
                <AuditLogItem key={log.id} log={log} />
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-muted-foreground">
              <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No audit logs found</p>
              <p className="text-sm">Activity will appear here as changes are made</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
