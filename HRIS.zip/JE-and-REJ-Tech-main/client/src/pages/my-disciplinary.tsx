import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  AlertTriangle,
  FileText,
  Calendar,
  Eye,
  Clock,
  CheckCircle2,
  Send,
} from "lucide-react";
import { formatDate } from "@/lib/utils";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import type { DisciplinaryAction } from "@shared/schema";

const explanationSchema = z.object({
  explanation: z.string().min(1, "Explanation is required").min(10, "Explanation must be at least 10 characters"),
});

export default function MyDisciplinaryPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedAction, setSelectedAction] = useState<DisciplinaryAction | null>(null);
  const [explanationDialogOpen, setExplanationDialogOpen] = useState(false);
  const [actionForExplanation, setActionForExplanation] = useState<DisciplinaryAction | null>(null);

  const { data: disciplinaryActions, isLoading } = useQuery<DisciplinaryAction[]>({
    queryKey: ["/api/my/disciplinary"],
    enabled: !!user?.employeeId,
  });

  const form = useForm<z.infer<typeof explanationSchema>>({
    resolver: zodResolver(explanationSchema),
    defaultValues: {
      explanation: "",
    },
  });

  const submitExplanationMutation = useMutation({
    mutationFn: async ({ id, explanation }: { id: string; explanation: string }) => {
      const response = await apiRequest("POST", `/api/disciplinary/${id}/explanation`, { explanation });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my/disciplinary"] });
      toast({
        title: "Success",
        description: "Your explanation has been submitted successfully.",
      });
      setExplanationDialogOpen(false);
      setActionForExplanation(null);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmitExplanation = (values: z.infer<typeof explanationSchema>) => {
    if (actionForExplanation) {
      submitExplanationMutation.mutate({
        id: actionForExplanation.id,
        explanation: values.explanation,
      });
    }
  };

  const openExplanationDialog = (action: DisciplinaryAction) => {
    setActionForExplanation(action);
    setExplanationDialogOpen(true);
    form.reset();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Issued":
        return <Badge variant="destructive">Requires Response</Badge>;
      case "Explanation_Received":
        return <Badge variant="secondary">Under Review</Badge>;
      case "Under_Review":
        return <Badge variant="secondary">Under Review</Badge>;
      case "Resolved":
        return <Badge variant="default">Resolved</Badge>;
      case "Escalated":
        return <Badge variant="destructive">Escalated</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "Written_Warning":
        return "Written Warning";
      case "Final_Warning":
        return "Final Warning";
      case "Suspension":
        return "Suspension";
      case "Termination":
        return "Termination";
      default:
        return type;
    }
  };

  const pendingCount = disciplinaryActions?.filter(
    a => a.status === "Issued" || a.status === "Explanation_Received" || a.status === "Under_Review"
  ).length || 0;

  const resolvedCount = disciplinaryActions?.filter(a => a.status === "Resolved").length || 0;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">My Disciplinary Records</h1>
        <p className="text-muted-foreground">View your NTEs and disciplinary actions</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold text-yellow-600">{pendingCount}</p>
                <p className="text-sm text-muted-foreground">Pending/Active</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold text-green-600">{resolvedCount}</p>
                <p className="text-sm text-muted-foreground">Resolved</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {disciplinaryActions && disciplinaryActions.length > 0 ? (
        <div className="space-y-4">
          {disciplinaryActions.map((action) => (
            <Card 
              key={action.id} 
              className={action.status === "Issued" ? "border-destructive" : ""}
              data-testid={`card-disciplinary-${action.id}`}
            >
              <CardContent className="pt-6">
                <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-3">
                      <AlertTriangle className={`h-5 w-5 ${
                        action.status === "Resolved" ? "text-green-500" : "text-yellow-500"
                      }`} />
                      <h3 className="font-semibold text-lg">{getTypeLabel(action.violationType)}</h3>
                      {getStatusBadge(action.status)}
                    </div>
                    <p className="text-muted-foreground">{action.description}</p>
                    <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        Issued: {action.nteIssuedDate ? formatDate(action.nteIssuedDate) : "N/A"}
                      </span>
                      {action.responseDeadline && (
                        <span className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          Response Due: {formatDate(action.responseDeadline)}
                        </span>
                      )}
                    </div>
                    {action.status === "Issued" && (
                      <div className="mt-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                        <p className="text-sm text-yellow-800 dark:text-yellow-200 mb-3">
                          <strong>Action Required:</strong> Please submit your written explanation before the deadline.
                        </p>
                        <Button
                          onClick={() => openExplanationDialog(action)}
                          size="sm"
                          className="bg-yellow-600 hover:bg-yellow-700"
                          data-testid={`button-submit-response-${action.id}`}
                        >
                          <Send className="h-4 w-4 mr-2" />
                          Submit Response
                        </Button>
                      </div>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSelectedAction(action)}
                    data-testid={`button-view-disciplinary-${action.id}`}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <CheckCircle2 className="h-12 w-12 mx-auto mb-4 text-green-500" />
            <h3 className="font-medium text-lg mb-2">No Disciplinary Records</h3>
            <p className="text-muted-foreground">
              You have a clean record. Keep up the good work!
            </p>
          </CardContent>
        </Card>
      )}

      <Dialog open={!!selectedAction} onOpenChange={() => setSelectedAction(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Disciplinary Details
            </DialogTitle>
          </DialogHeader>
          {selectedAction && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Type</span>
                <span className="font-medium">{getTypeLabel(selectedAction.violationType)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Status</span>
                {getStatusBadge(selectedAction.status)}
              </div>
              <Separator />

              <div className="space-y-2">
                <h4 className="font-semibold">Description</h4>
                <p className="text-muted-foreground">{selectedAction.description}</p>
              </div>

              <Separator />

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Incident Date</span>
                  <span>{formatDate(selectedAction.incidentDate)}</span>
                </div>
                {selectedAction.nteIssuedDate && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">NTE Issued Date</span>
                    <span>{formatDate(selectedAction.nteIssuedDate)}</span>
                  </div>
                )}
                {selectedAction.responseDeadline && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Response Deadline</span>
                    <span>{formatDate(selectedAction.responseDeadline)}</span>
                  </div>
                )}
                {selectedAction.resolvedAt && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Resolved Date</span>
                    <span>{formatDate(selectedAction.resolvedAt)}</span>
                  </div>
                )}
              </div>

              {selectedAction.employeeExplanation && (
                <>
                  <Separator />
                  <div className="space-y-2">
                    <h4 className="font-semibold">Your Explanation</h4>
                    <p className="text-muted-foreground bg-muted p-3 rounded-lg">
                      {selectedAction.employeeExplanation}
                    </p>
                  </div>
                </>
              )}

              {selectedAction.resolution && (
                <>
                  <Separator />
                  <div className="space-y-2">
                    <h4 className="font-semibold">Resolution</h4>
                    <p className="text-muted-foreground">{selectedAction.resolution}</p>
                  </div>
                </>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={explanationDialogOpen} onOpenChange={setExplanationDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Send className="h-5 w-5" />
              Submit Your Explanation
            </DialogTitle>
            <DialogDescription>
              Please provide a detailed explanation regarding this disciplinary action. This will be reviewed by HR.
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmitExplanation)} className="space-y-4">
              <FormField
                control={form.control}
                name="explanation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Your Explanation</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Provide your detailed explanation here..."
                        className="min-h-[200px]"
                        {...field}
                        disabled={submitExplanationMutation.isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setExplanationDialogOpen(false)}
                  disabled={submitExplanationMutation.isPending}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={submitExplanationMutation.isPending}
                  data-testid="button-confirm-submit-explanation"
                >
                  {submitExplanationMutation.isPending ? "Submitting..." : "Submit Explanation"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
