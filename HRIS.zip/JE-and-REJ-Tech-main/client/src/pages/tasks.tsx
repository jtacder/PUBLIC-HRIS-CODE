import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { PhotoUploader } from "@/components/photo-uploader";
import { getPhotoDisplayUrl } from "@/lib/photo-url";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { SearchableEmployeeSelect } from "@/components/searchable-employee-select";
import {
  Plus,
  CheckCircle2,
  Circle,
  AlertCircle,
  Clock,
  MoreHorizontal,
  Pencil,
  Trash2,
  User,
  Eye,
  MessageSquare,
  Send,
  Calendar,
  FolderKanban,
  Image as ImageIcon,
  Paperclip,
} from "lucide-react";

/**
 * Parse stored photo URLs - handles single URL, JSON array, or already parsed array
 */
function parsePhotoUrls(value: string | null | undefined): string[] {
  if (!value) return [];
  // If it's already a JSON array
  if (value.startsWith("[")) {
    try {
      return JSON.parse(value);
    } catch {
      return [value];
    }
  }
  // Single URL
  return [value];
}
import { format } from "date-fns";
import { getInitials } from "@/lib/utils";
import type { Task, Project, Employee } from "@shared/schema";

interface TaskComment {
  id: string;
  taskId: string;
  authorId: string;
  content: string;
  attachmentUrl?: string;
  createdAt: string;
}

interface TaskWithComments extends Task {
  comments?: TaskComment[];
}

const statusConfig = {
  Todo: {
    label: "To Do",
    icon: Circle,
    color: "bg-slate-100 dark:bg-slate-800",
    badge: "bg-slate-500",
  },
  In_Progress: {
    label: "In Progress",
    icon: Clock,
    color: "bg-blue-50 dark:bg-blue-950/30",
    badge: "bg-blue-500",
  },
  Blocked: {
    label: "Blocked",
    icon: AlertCircle,
    color: "bg-red-50 dark:bg-red-950/30",
    badge: "bg-red-500",
  },
  Done: {
    label: "Done",
    icon: CheckCircle2,
    color: "bg-green-50 dark:bg-green-950/30",
    badge: "bg-green-500",
  },
};

const priorityColors = {
  Low: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200",
  Medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  High: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
  Critical: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
};

type TaskStatus = keyof typeof statusConfig;

interface TaskFormData {
  title: string;
  description: string;
  poNumber: string;
  projectId: string;
  assignedToId: string;
  priority: string;
  dueDate: string;
  status: string;
  completionPhotos: string[];
}

const emptyTaskForm: TaskFormData = {
  title: "",
  description: "",
  poNumber: "",
  projectId: "",
  assignedToId: "",
  priority: "Medium",
  dueDate: "",
  status: "Todo",
  completionPhotos: [],
};

interface KanbanColumnProps {
  status: TaskStatus;
  tasks: Task[];
  onStatusChange: (taskId: string, newStatus: TaskStatus) => void;
  onEdit: (task: Task) => void;
  onDelete: (task: Task) => void;
  onViewDetails: (task: Task) => void;
  projects: Project[];
  employees: Employee[];
}

function KanbanColumn({
  status,
  tasks,
  onStatusChange,
  onEdit,
  onDelete,
  onViewDetails,
  projects,
  employees
}: KanbanColumnProps) {
  const config = statusConfig[status];

  return (
    <div className={`flex flex-col rounded-lg ${config.color} min-h-[500px]`}>
      <div className="flex items-center gap-2 border-b p-3">
        <div className={`h-2 w-2 rounded-full ${config.badge}`} />
        <h3 className="font-medium">{config.label}</h3>
        <Badge variant="secondary" className="ml-auto">
          {tasks.length}
        </Badge>
      </div>
      <div className="flex-1 space-y-2 p-2 overflow-y-auto">
        {tasks.map((task) => (
          <Card
            key={task.id}
            className="cursor-pointer hover-elevate"
            data-testid={`card-task-${task.id}`}
          >
            <CardContent className="p-3 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <p
                  className="font-medium text-sm line-clamp-2 cursor-pointer hover:text-primary"
                  onClick={() => onViewDetails(task)}
                >
                  {task.title}
                </p>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 shrink-0"
                      aria-label="Task actions"
                      data-testid={`button-task-menu-${task.id}`}
                    >
                      <MoreHorizontal className="h-4 w-4" aria-hidden="true" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => onViewDetails(task)}>
                      <Eye className="mr-2 h-4 w-4" />
                      View Details
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => onStatusChange(task.id, "Todo")}>
                      <Circle className="mr-2 h-4 w-4" />
                      Move to To Do
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onStatusChange(task.id, "In_Progress")}>
                      <Clock className="mr-2 h-4 w-4" />
                      Move to In Progress
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onStatusChange(task.id, "Blocked")}>
                      <AlertCircle className="mr-2 h-4 w-4" />
                      Move to Blocked
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onStatusChange(task.id, "Done")}>
                      <CheckCircle2 className="mr-2 h-4 w-4" />
                      Move to Done
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => onEdit(task)}>
                      <Pencil className="mr-2 h-4 w-4" />
                      Edit Task
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => onDelete(task)}
                      className="text-destructive"
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Delete Task
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              {task.description && (
                <p className="text-xs text-muted-foreground line-clamp-2">
                  {task.description}
                </p>
              )}
              <div className="flex items-center gap-2 flex-wrap">
                {task.priority && (
                  <Badge
                    variant="secondary"
                    className={`text-[10px] ${priorityColors[task.priority as keyof typeof priorityColors] || ""}`}
                  >
                    {task.priority}
                  </Badge>
                )}
                {task.projectId && (
                  <Badge variant="outline" className="text-[10px]">
                    {projects.find((p) => p.id === task.projectId)?.name || "Project"}
                  </Badge>
                )}
                {task.dueDate && (
                  <Badge variant="outline" className="text-[10px]">
                    {format(new Date(task.dueDate), "MMM d")}
                  </Badge>
                )}
              </div>
              {task.assignedToId && (
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <User className="h-3 w-3" />
                  <span>
                    {employees.find((e) => e.id === task.assignedToId)?.firstName || "Assigned"}
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
        {tasks.length === 0 && (
          <div className="flex items-center justify-center h-24 text-sm text-muted-foreground">
            No tasks
          </div>
        )}
      </div>
    </div>
  );
}

export default function TasksPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [location, setLocation] = useLocation();
  const [selectedProject, setSelectedProject] = useState<string>("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [taskForm, setTaskForm] = useState<TaskFormData>(emptyTaskForm);
  const [newComment, setNewComment] = useState("");
  const [commentAttachment, setCommentAttachment] = useState<string | null>(null);
  const [viewingPhoto, setViewingPhoto] = useState<string | null>(null);

  const { data: tasks = [], isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  // Handle opening task from URL query parameter (e.g., /tasks?taskId=xxx)
  useEffect(() => {
    if (tasks.length > 0) {
      const params = new URLSearchParams(window.location.search);
      const taskId = params.get("taskId");
      if (taskId) {
        const task = tasks.find(t => t.id === taskId);
        if (task) {
          setSelectedTask(task);
          setIsDetailsDialogOpen(true);
          // Clear the query param after opening
          setLocation("/tasks", { replace: true });
        }
      }
    }
  }, [tasks, setLocation]);

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: employees = [] } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  // Fetch task details with comments when details dialog is open
  const { data: taskDetails, isLoading: detailsLoading } = useQuery<TaskWithComments>({
    queryKey: [`/api/tasks/${selectedTask?.id}`],
    enabled: !!selectedTask && isDetailsDialogOpen,
  });

  const createTaskMutation = useMutation({
    mutationFn: async (data: TaskFormData) => {
      // Send photos as completionPhotos array
      const payload = {
        ...data,
        poNumber: data.poNumber || null,
        completionPhotos: data.completionPhotos.length > 0 ? data.completionPhotos : undefined,
      };
      const response = await apiRequest("POST", "/api/tasks", payload);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsAddDialogOpen(false);
      setTaskForm(emptyTaskForm);
      toast({ title: "Task Created", description: "New task has been added successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create task.", variant: "destructive" });
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<TaskFormData> }) => {
      // Send photos as completionPhotos array
      const payload = {
        ...data,
        poNumber: data.poNumber !== undefined ? (data.poNumber || null) : undefined,
        completionPhotos: data.completionPhotos && data.completionPhotos.length > 0 ? data.completionPhotos : undefined,
      };
      const response = await apiRequest("PATCH", `/api/tasks/${id}`, payload);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: [`/api/tasks/${selectedTask?.id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsEditDialogOpen(false);
      setSelectedTask(null);
      toast({ title: "Task Updated", description: "Task has been updated successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update task.", variant: "destructive" });
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/tasks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsDeleteDialogOpen(false);
      setSelectedTask(null);
      toast({ title: "Task Deleted", description: "Task has been removed." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete task.", variant: "destructive" });
    },
  });

  const addCommentMutation = useMutation({
    mutationFn: async ({ taskId, content, authorId, attachmentUrl }: { taskId: string; content: string; authorId: string; attachmentUrl?: string }) => {
      const response = await apiRequest("POST", `/api/tasks/${taskId}/comments`, {
        content,
        authorId,
        attachmentUrl,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/tasks/${selectedTask?.id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      setNewComment("");
      setCommentAttachment(null);
      toast({ title: "Comment Added", description: "Your comment has been posted." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add comment.", variant: "destructive" });
    },
  });

  const handleStatusChange = (taskId: string, newStatus: TaskStatus) => {
    updateTaskMutation.mutate({ id: taskId, data: { status: newStatus } });
  };

  const handleEdit = (task: Task) => {
    setSelectedTask(task);
    setTaskForm({
      title: task.title,
      description: task.description || "",
      poNumber: (task as any).poNumber || "",
      projectId: task.projectId || "",
      assignedToId: task.assignedToId || "",
      priority: task.priority || "Medium",
      dueDate: task.dueDate ? format(new Date(task.dueDate), "yyyy-MM-dd") : "",
      status: task.status,
      completionPhotos: parsePhotoUrls(task.completionPhotoUrl),
    });
    setIsEditDialogOpen(true);
  };

  const handleDelete = (task: Task) => {
    setSelectedTask(task);
    setIsDeleteDialogOpen(true);
  };

  const handleViewDetails = (task: Task) => {
    setSelectedTask(task);
    setNewComment("");
    setIsDetailsDialogOpen(true);
  };

  const handleAddComment = () => {
    if (!selectedTask || (!newComment.trim() && !commentAttachment) || !user?.employeeId) return;
    addCommentMutation.mutate({
      taskId: selectedTask.id,
      content: newComment.trim() || "Photo attachment",
      authorId: user.employeeId,
      attachmentUrl: commentAttachment || undefined,
    });
  };

  const filteredTasks =
    selectedProject === "all"
      ? tasks
      : tasks.filter((t) => t.projectId === selectedProject);

  const tasksByStatus: Record<TaskStatus, Task[]> = {
    Todo: filteredTasks.filter((t) => t.status === "Todo"),
    In_Progress: filteredTasks.filter((t) => t.status === "In_Progress"),
    Blocked: filteredTasks.filter((t) => t.status === "Blocked"),
    Done: filteredTasks.filter((t) => t.status === "Done"),
  };

  const getEmployeeName = (employeeId: string) => {
    const emp = employees.find(e => e.id === employeeId);
    return emp ? `${emp.firstName} ${emp.lastName}` : "Unknown";
  };

  if (tasksLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-[500px]" />
          ))}
        </div>
      </div>
    );
  }

  const taskFormFields = (
    <div className="space-y-4 py-4">
      <div className="space-y-2">
        <Label htmlFor="title">Task Title *</Label>
        <Input
          id="title"
          value={taskForm.title}
          onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })}
          placeholder="e.g., Install main panel"
          data-testid="input-task-title"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={taskForm.description}
          onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })}
          placeholder="Task details..."
          data-testid="input-task-description"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="poNumber">P.O. Number (Optional)</Label>
        <Input
          id="poNumber"
          value={taskForm.poNumber}
          onChange={(e) => setTaskForm({ ...taskForm, poNumber: e.target.value })}
          placeholder="e.g., PO-2025-001"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="project">Project</Label>
          <Select
            value={taskForm.projectId}
            onValueChange={(value) => setTaskForm({ ...taskForm, projectId: value })}
          >
            <SelectTrigger data-testid="select-task-project">
              <SelectValue placeholder="Select project" />
            </SelectTrigger>
            <SelectContent>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="assignee">Assign To</Label>
          <SearchableEmployeeSelect
            employees={employees}
            value={taskForm.assignedToId}
            onValueChange={(value) => setTaskForm({ ...taskForm, assignedToId: value })}
            placeholder="Select employee..."
            allowUnassigned={true}
            data-testid="select-task-assignee"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="priority">Priority</Label>
          <Select
            value={taskForm.priority}
            onValueChange={(value) => setTaskForm({ ...taskForm, priority: value })}
          >
            <SelectTrigger data-testid="select-task-priority">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Low">Low</SelectItem>
              <SelectItem value="Medium">Medium</SelectItem>
              <SelectItem value="High">High</SelectItem>
              <SelectItem value="Critical">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="dueDate">Due Date</Label>
          <Input
            id="dueDate"
            type="date"
            value={taskForm.dueDate}
            onChange={(e) => setTaskForm({ ...taskForm, dueDate: e.target.value })}
            data-testid="input-task-due-date"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="status">Status</Label>
        <Select
          value={taskForm.status}
          onValueChange={(value) => setTaskForm({ ...taskForm, status: value })}
        >
          <SelectTrigger data-testid="select-task-status">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Todo">To Do</SelectItem>
            <SelectItem value="In_Progress">In Progress</SelectItem>
            <SelectItem value="Blocked">Blocked</SelectItem>
            <SelectItem value="Done">Done</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Task Photos (Optional)</Label>
        <PhotoUploader
          value={taskForm.completionPhotos}
          onChange={(value) => setTaskForm({ ...taskForm, completionPhotos: (value as string[]) || [] })}
          multiple={true}
          maxFiles={5}
          accept={["image/jpeg", "image/png", "image/webp"]}
          maxSizeMB={5}
          showCamera={true}
          placeholder="Upload photos for this task"
        />
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-page-title">
            Task Board
          </h1>
          <p className="text-muted-foreground">
            Kanban view of project tasks and assignments
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedProject} onValueChange={setSelectedProject}>
            <SelectTrigger className="w-48" data-testid="select-project-filter">
              <SelectValue placeholder="Filter by project" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Projects</SelectItem>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-task" onClick={() => setTaskForm(emptyTaskForm)}>
                <Plus className="mr-2 h-4 w-4" />
                Add Task
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Task</DialogTitle>
                <DialogDescription>
                  Add a new task to the board.
                </DialogDescription>
              </DialogHeader>
              {taskFormFields}
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={() => createTaskMutation.mutate(taskForm)}
                  disabled={!taskForm.title || !taskForm.projectId || createTaskMutation.isPending}
                  data-testid="button-save-task"
                >
                  {createTaskMutation.isPending ? "Creating..." : "Create Task"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Kanban Board */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-4">
        {(Object.keys(statusConfig) as TaskStatus[]).map((status) => (
          <KanbanColumn
            key={status}
            status={status}
            tasks={tasksByStatus[status]}
            onStatusChange={handleStatusChange}
            onEdit={handleEdit}
            onDelete={handleDelete}
            onViewDetails={handleViewDetails}
            projects={projects}
            employees={employees}
          />
        ))}
      </div>

      {/* Task Details Dialog with Comments */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              Task Details
            </DialogTitle>
            <DialogDescription>
              View task information and comments
            </DialogDescription>
          </DialogHeader>

          {detailsLoading ? (
            <div className="space-y-4 py-4">
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-32 w-full" />
            </div>
          ) : taskDetails ? (
            <>
              {/* Scrollable content area */}
              <div className="flex-1 overflow-y-auto space-y-4 py-2 pr-2">
                {/* Task Info */}
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold">{taskDetails.title}</h3>
                    {taskDetails.description && (
                      <p className="text-sm text-muted-foreground mt-1">{taskDetails.description}</p>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Badge
                        variant="secondary"
                        className={statusConfig[taskDetails.status as TaskStatus]?.badge || ""}
                      >
                        {statusConfig[taskDetails.status as TaskStatus]?.label || taskDetails.status}
                      </Badge>
                      {taskDetails.priority && (
                        <Badge
                          variant="secondary"
                          className={priorityColors[taskDetails.priority as keyof typeof priorityColors] || ""}
                        >
                          {taskDetails.priority}
                        </Badge>
                      )}
                    </div>

                    <div className="flex items-center gap-2 text-muted-foreground">
                      <FolderKanban className="h-4 w-4" />
                      <span>{projects.find(p => p.id === taskDetails.projectId)?.name || "No project"}</span>
                    </div>

                    {(taskDetails as any).poNumber && (
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <span className="text-xs font-medium">P.O:</span>
                        <span className="font-mono text-xs">{(taskDetails as any).poNumber}</span>
                      </div>
                    )}

                    <div className="flex items-center gap-2 text-muted-foreground">
                      <User className="h-4 w-4" />
                      <span>{taskDetails.assignedToId ? getEmployeeName(taskDetails.assignedToId) : "Unassigned"}</span>
                    </div>

                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>{taskDetails.dueDate ? format(new Date(taskDetails.dueDate), "MMM d, yyyy") : "No due date"}</span>
                    </div>
                  </div>

                  {/* Task Photos */}
                  {taskDetails.completionPhotoUrl && parsePhotoUrls(taskDetails.completionPhotoUrl).length > 0 && (
                    <div className="mt-4">
                      <div className="flex items-center gap-2 mb-2">
                        <ImageIcon className="h-4 w-4" />
                        <span className="text-sm font-medium">Task Photos</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {parsePhotoUrls(taskDetails.completionPhotoUrl).map((url, idx) => (
                          <button
                            key={idx}
                            onClick={() => setViewingPhoto(getPhotoDisplayUrl(url))}
                            className="w-16 h-16 rounded-lg overflow-hidden border hover:border-primary transition-colors"
                          >
                            <img
                              src={getPhotoDisplayUrl(url) || ""}
                              alt={`Task photo ${idx + 1}`}
                              className="w-full h-full object-cover"
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <Separator />

                {/* Comments Section */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <MessageSquare className="h-4 w-4" />
                    <h4 className="font-medium">Comments ({taskDetails.comments?.length || 0})</h4>
                  </div>

                  {taskDetails.comments && taskDetails.comments.length > 0 ? (
                    <div className="space-y-3">
                      {taskDetails.comments.map((comment) => (
                        <div key={comment.id} className="flex gap-3">
                          <Avatar className="h-8 w-8 flex-shrink-0">
                            <AvatarFallback className="text-xs">
                              {getInitials(getEmployeeName(comment.authorId))}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-sm font-medium">{getEmployeeName(comment.authorId)}</span>
                              <span className="text-xs text-muted-foreground">
                                {format(new Date(comment.createdAt), "MMM d, yyyy h:mm a")}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1 break-words">{comment.content}</p>
                            {/* Comment Attachment */}
                            {comment.attachmentUrl && parsePhotoUrls(comment.attachmentUrl).length > 0 && (
                              <div className="flex flex-wrap gap-2 mt-2">
                                {parsePhotoUrls(comment.attachmentUrl).map((url, idx) => (
                                  <button
                                    key={idx}
                                    onClick={() => setViewingPhoto(getPhotoDisplayUrl(url))}
                                    className="w-16 h-16 rounded-lg overflow-hidden border hover:border-primary transition-colors"
                                  >
                                    <img
                                      src={getPhotoDisplayUrl(url) || ""}
                                      alt={`Attachment ${idx + 1}`}
                                      className="w-full h-full object-cover"
                                    />
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">No comments yet</p>
                      <p className="text-xs">Be the first to comment</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Fixed Add Comment section */}
              <div className="flex-shrink-0 pt-4 border-t space-y-3">
                {/* Comment Attachment Preview */}
                {commentAttachment && (
                  <div className="relative inline-block">
                    <img
                      src={commentAttachment}
                      alt="Attachment preview"
                      className="w-16 h-16 rounded object-cover border"
                    />
                    <button
                      onClick={() => setCommentAttachment(null)}
                      className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 text-xs"
                    >
                      ×
                    </button>
                  </div>
                )}
                <div className="flex gap-2">
                  <div className="flex-1 relative">
                    <Textarea
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      placeholder="Add a comment..."
                      className="min-h-[60px] resize-none pr-10"
                      data-testid="input-new-comment"
                    />
                    {/* Attachment button */}
                    <label className="absolute right-2 bottom-2 cursor-pointer text-muted-foreground hover:text-foreground transition-colors">
                      <Paperclip className="h-5 w-5" />
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        className="hidden"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = (ev) => {
                              setCommentAttachment(ev.target?.result as string);
                            };
                            reader.readAsDataURL(file);
                          }
                          e.target.value = "";
                        }}
                      />
                    </label>
                  </div>
                  <Button
                    size="icon"
                    onClick={handleAddComment}
                    disabled={(!newComment.trim() && !commentAttachment) || addCommentMutation.isPending}
                    data-testid="button-add-comment"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="py-8 text-center text-muted-foreground">
              Failed to load task details
            </div>
          )}

          <DialogFooter className="flex-shrink-0 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsDetailsDialogOpen(false)}>
              Close
            </Button>
            <Button
              onClick={() => {
                setIsDetailsDialogOpen(false);
                if (selectedTask) handleEdit(selectedTask);
              }}
            >
              <Pencil className="mr-2 h-4 w-4" />
              Edit Task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Task</DialogTitle>
            <DialogDescription>
              Update task details and assignment.
            </DialogDescription>
          </DialogHeader>
          {taskFormFields}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => selectedTask && updateTaskMutation.mutate({ id: selectedTask.id, data: taskForm })}
              disabled={!taskForm.title || updateTaskMutation.isPending}
              data-testid="button-update-task"
            >
              {updateTaskMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Task?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete "{selectedTask?.title}". This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => selectedTask && deleteTaskMutation.mutate(selectedTask.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteTaskMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Photo Viewer Dialog */}
      <Dialog open={!!viewingPhoto} onOpenChange={() => setViewingPhoto(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] p-0 overflow-hidden">
          <DialogHeader className="p-4 pb-0">
            <DialogTitle>Photo</DialogTitle>
          </DialogHeader>
          <div className="p-4 flex items-center justify-center overflow-auto">
            {viewingPhoto && (
              <img
                src={viewingPhoto}
                alt="Full size"
                className="max-w-full max-h-[70vh] object-contain rounded-lg"
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
