import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { format, addDays, differenceInDays } from "date-fns";
import { usePagination } from "@/hooks/use-pagination";
import { TablePagination } from "@/components/ui/table-pagination";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { SearchableEmployeeSelect } from "@/components/searchable-employee-select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  Plus,
  AlertTriangle,
  FileText,
  Clock,
  CheckCircle,
  XCircle,
  Search,
  AlertCircle,
  MoreHorizontal,
  Eye,
  CheckCircle2,
  Edit,
} from "lucide-react";
import type { DisciplinaryAction, Employee } from "@shared/schema";

const statusConfig: Record<string, { label: string; color: string; icon: any }> = {
  Issued: {
    label: "NTE Issued",
    color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
    icon: AlertTriangle,
  },
  Explanation_Received: {
    label: "Response Received",
    color: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
    icon: FileText,
  },
  Under_Review: {
    label: "Under Review",
    color: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
    icon: Clock,
  },
  Resolved: {
    label: "Resolved",
    color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
    icon: CheckCircle,
  },
  Escalated: {
    label: "Escalated",
    color: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
    icon: XCircle,
  },
};

const violationTypes = [
  { value: "Tardiness", label: "Tardiness" },
  { value: "Absenteeism", label: "Absenteeism" },
  { value: "Safety_Violation", label: "Safety Violation" },
  { value: "Misconduct", label: "Misconduct" },
  { value: "Insubordination", label: "Insubordination" },
  { value: "Policy_Violation", label: "Policy Violation" },
  { value: "Other", label: "Other" },
];

const sanctionTypes = [
  { value: "None", label: "None" },
  { value: "Verbal Warning", label: "Verbal Warning" },
  { value: "Written Warning", label: "Written Warning" },
  { value: "Suspension", label: "Suspension" },
  { value: "Termination", label: "Termination" },
];

const resolveNTESchema = z.object({
  resolution: z.string().min(10, "Resolution notes must be at least 10 characters"),
  sanction: z.string().optional(),
  sanctionDays: z.number().min(1, "Suspension days must be at least 1").optional(),
}).refine((data) => {
  if (data.sanction === "Suspension" && !data.sanctionDays) {
    return false;
  }
  return true;
}, {
  message: "Suspension days are required when sanction is Suspension",
  path: ["sanctionDays"],
});

const updateStatusSchema = z.object({
  status: z.string().min(1, "Status is required"),
  remarks: z.string().optional(),
});

export default function DisciplinaryPage() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isResolveDialogOpen, setIsResolveDialogOpen] = useState(false);
  const [isUpdateStatusDialogOpen, setIsUpdateStatusDialogOpen] = useState(false);
  const [isViewDetailsDialogOpen, setIsViewDetailsDialogOpen] = useState(false);
  const [selectedAction, setSelectedAction] = useState<DisciplinaryAction | null>(null);
  const [newNTE, setNewNTE] = useState({
    employeeId: "",
    violationType: "",
    incidentDate: "",
    description: "",
    issuerId: "",
  });

  const resolveForm = useForm<z.infer<typeof resolveNTESchema>>({
    resolver: zodResolver(resolveNTESchema),
    defaultValues: {
      resolution: "",
      sanction: "None",
      sanctionDays: undefined,
    },
  });

  const updateStatusForm = useForm<z.infer<typeof updateStatusSchema>>({
    resolver: zodResolver(updateStatusSchema),
    defaultValues: {
      status: "",
      remarks: "",
    },
  });

  const { data: disciplinaryActions = [], isLoading } = useQuery<DisciplinaryAction[]>({
    queryKey: ["/api/disciplinary"],
  });

  const { data: employees = [] } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const createNTEMutation = useMutation({
    mutationFn: async (data: typeof newNTE) => {
      const response = await apiRequest("POST", "/api/disciplinary", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/disciplinary"] });
      setIsCreateDialogOpen(false);
      setNewNTE({
        employeeId: "",
        violationType: "",
        incidentDate: "",
        description: "",
        issuerId: "",
      });
      toast({
        title: "NTE Created",
        description: "Notice to Explain has been issued to the employee.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create NTE. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resolveNTEMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: z.infer<typeof resolveNTESchema> }) => {
      const response = await apiRequest("POST", `/api/disciplinary/${id}/resolve`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/disciplinary"] });
      setIsResolveDialogOpen(false);
      setSelectedAction(null);
      resolveForm.reset();
      toast({
        title: "NTE Resolved",
        description: "The disciplinary action has been resolved successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to resolve NTE. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: z.infer<typeof updateStatusSchema> }) => {
      const response = await apiRequest("PATCH", `/api/disciplinary/${id}`, { status: data.status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/disciplinary"] });
      setIsUpdateStatusDialogOpen(false);
      setSelectedAction(null);
      updateStatusForm.reset();
      toast({
        title: "Status Updated",
        description: "The case status has been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update status. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getEmployeeName = (employeeId: string) => {
    const employee = employees.find((e) => e.id === employeeId);
    return employee ? `${employee.firstName} ${employee.lastName}` : "Unknown";
  };

  const handleViewDetails = (action: DisciplinaryAction) => {
    setSelectedAction(action);
    setIsViewDetailsDialogOpen(true);
  };

  const handleResolve = (action: DisciplinaryAction) => {
    setSelectedAction(action);
    resolveForm.reset({
      resolution: "",
      sanction: "None",
      sanctionDays: undefined,
    });
    setIsResolveDialogOpen(true);
  };

  const handleUpdateStatus = (action: DisciplinaryAction) => {
    setSelectedAction(action);
    updateStatusForm.reset({
      status: action.status,
      remarks: "",
    });
    setIsUpdateStatusDialogOpen(true);
  };

  const onResolveSubmit = (data: z.infer<typeof resolveNTESchema>) => {
    if (!selectedAction) return;
    resolveNTEMutation.mutate({ id: selectedAction.id, data });
  };

  const onUpdateStatusSubmit = (data: z.infer<typeof updateStatusSchema>) => {
    if (!selectedAction) return;
    updateStatusMutation.mutate({ id: selectedAction.id, data });
  };

  const filteredActions = disciplinaryActions.filter((action) => {
    const employeeName = getEmployeeName(action.employeeId).toLowerCase();
    const matchesSearch = employeeName.includes(searchQuery.toLowerCase());
    const matchesStatus =
      statusFilter === "all" || action.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Pagination
  const pagination = usePagination(filteredActions);

  const stats = {
    total: disciplinaryActions.length,
    pending: disciplinaryActions.filter(
      (a) => a.status === "Issued" || a.status === "Explanation_Received"
    ).length,
    underReview: disciplinaryActions.filter((a) => a.status === "Under_Review")
      .length,
    resolved: disciplinaryActions.filter((a) => a.status === "Resolved").length,
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-page-title">
            Disciplinary Management
          </h1>
          <p className="text-muted-foreground">
            NTE (Notice to Explain) workflow and disciplinary tracking
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-issue-nte">
              <Plus className="mr-2 h-4 w-4" />
              Issue NTE
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Issue Notice to Explain</DialogTitle>
              <DialogDescription>
                Create a new NTE for an employee. They will have 5 days to respond.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="employee">Employee *</Label>
                <SearchableEmployeeSelect
                  employees={employees.filter((e) => e.status === "Active" || e.status === "Probationary")}
                  value={newNTE.employeeId}
                  onValueChange={(value) => setNewNTE({ ...newNTE, employeeId: value })}
                  placeholder="Select employee..."
                  data-testid="select-employee"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="violationType">Violation Type *</Label>
                  <Select
                    value={newNTE.violationType}
                    onValueChange={(value) =>
                      setNewNTE({ ...newNTE, violationType: value })
                    }
                  >
                    <SelectTrigger data-testid="select-violation-type">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {violationTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="incidentDate">Incident Date *</Label>
                  <Input
                    id="incidentDate"
                    type="date"
                    value={newNTE.incidentDate}
                    onChange={(e) =>
                      setNewNTE({ ...newNTE, incidentDate: e.target.value })
                    }
                    data-testid="input-incident-date"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  value={newNTE.description}
                  onChange={(e) =>
                    setNewNTE({ ...newNTE, description: e.target.value })
                  }
                  placeholder="Describe the incident and violation in detail..."
                  rows={4}
                  data-testid="input-description"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="issuer">Issued By *</Label>
                <Select
                  value={newNTE.issuerId}
                  onValueChange={(value) =>
                    setNewNTE({ ...newNTE, issuerId: value })
                  }
                >
                  <SelectTrigger data-testid="select-issuer">
                    <SelectValue placeholder="Select issuer" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees
                      .filter((e) => e.role === "ADMIN" || e.role === "HR" || e.role === "ENGINEER")
                      .map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.firstName} {emp.lastName} ({emp.role})
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsCreateDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={() => createNTEMutation.mutate(newNTE)}
                disabled={
                  !newNTE.employeeId ||
                  !newNTE.violationType ||
                  !newNTE.incidentDate ||
                  !newNTE.description ||
                  !newNTE.issuerId ||
                  createNTEMutation.isPending
                }
                data-testid="button-submit-nte"
              >
                {createNTEMutation.isPending ? "Creating..." : "Issue NTE"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <AlertTriangle className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Cases</p>
              <p className="text-2xl font-bold" data-testid="text-total-cases">
                {stats.total}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-yellow-100 text-yellow-600 dark:bg-yellow-900/20">
              <Clock className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Pending Response</p>
              <p className="text-2xl font-bold" data-testid="text-pending-cases">
                {stats.pending}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-purple-100 text-purple-600 dark:bg-purple-900/20">
              <FileText className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Under Review</p>
              <p className="text-2xl font-bold" data-testid="text-review-cases">
                {stats.underReview}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-100 text-green-600 dark:bg-green-900/20">
              <CheckCircle className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Resolved</p>
              <p className="text-2xl font-bold" data-testid="text-resolved-cases">
                {stats.resolved}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="flex flex-col gap-4 p-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by employee name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              aria-label="Search by employee name"
              data-testid="input-search"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-48" data-testid="select-status-filter">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="Issued">NTE Issued</SelectItem>
              <SelectItem value="Explanation_Received">Response Received</SelectItem>
              <SelectItem value="Under_Review">Under Review</SelectItem>
              <SelectItem value="Resolved">Resolved</SelectItem>
              <SelectItem value="Escalated">Escalated</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Cases Table */}
      <Card>
        <CardHeader>
          <CardTitle>Disciplinary Cases</CardTitle>
          <CardDescription>
            {filteredActions.length} case{filteredActions.length !== 1 ? "s" : ""} found
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredActions.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <AlertCircle className="h-12 w-12 text-muted-foreground/50" />
              <h3 className="mt-4 text-lg font-semibold">No cases found</h3>
              <p className="text-sm text-muted-foreground">
                {searchQuery || statusFilter !== "all"
                  ? "Try adjusting your filters"
                  : "No disciplinary cases have been filed"}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Violation</TableHead>
                    <TableHead>Incident Date</TableHead>
                    <TableHead>Deadline</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Sanction</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pagination.paginatedData.map((action) => {
                    const deadline = action.responseDeadline
                      ? new Date(action.responseDeadline)
                      : null;
                    const daysLeft = deadline
                      ? differenceInDays(deadline, new Date())
                      : null;
                    const isOverdue = daysLeft !== null && daysLeft < 0;
                    const StatusIcon = statusConfig[action.status]?.icon || AlertTriangle;

                    return (
                      <TableRow key={action.id} data-testid={`row-case-${action.id}`}>
                        <TableCell>
                          <div className="font-medium">
                            {getEmployeeName(action.employeeId)}
                          </div>
                        </TableCell>
                        <TableCell>
                          {action.violationType.replace(/_/g, " ")}
                        </TableCell>
                        <TableCell>
                          {format(new Date(action.incidentDate), "MMM d, yyyy")}
                        </TableCell>
                        <TableCell>
                          {deadline ? (
                            <div className="flex items-center gap-1">
                              <span
                                className={
                                  isOverdue ? "text-red-600" : ""
                                }
                              >
                                {format(deadline, "MMM d, yyyy")}
                              </span>
                              {action.status === "Issued" && daysLeft !== null && (
                                <Badge
                                  variant="outline"
                                  className={
                                    isOverdue
                                      ? "text-red-600 border-red-300"
                                      : daysLeft <= 2
                                      ? "text-yellow-600 border-yellow-300"
                                      : ""
                                  }
                                >
                                  {isOverdue
                                    ? "Overdue"
                                    : `${daysLeft}d left`}
                                </Badge>
                              )}
                            </div>
                          ) : (
                            "-"
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="secondary"
                            className={statusConfig[action.status]?.color || ""}
                          >
                            <StatusIcon className="mr-1 h-3 w-3" />
                            {statusConfig[action.status]?.label || action.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {action.sanction || (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            {action.status === "Issued" && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleViewDetails(action)}
                                data-testid={`button-view-details-${action.id}`}
                              >
                                <Eye className="mr-1 h-4 w-4" />
                                View Details
                              </Button>
                            )}
                            {action.status === "Explanation_Received" && (
                              <Button
                                variant="default"
                                size="sm"
                                onClick={() => handleResolve(action)}
                                data-testid={`button-resolve-${action.id}`}
                              >
                                <CheckCircle2 className="mr-1 h-4 w-4" />
                                Resolve
                              </Button>
                            )}
                            {action.status === "Resolved" && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleViewDetails(action)}
                                data-testid={`button-view-resolved-${action.id}`}
                              >
                                <Eye className="mr-1 h-4 w-4" />
                                View Details
                              </Button>
                            )}
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  data-testid={`button-actions-menu-${action.id}`}
                                >
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleViewDetails(action)}>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View Details
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem onClick={() => handleUpdateStatus(action)}>
                                  <Edit className="mr-2 h-4 w-4" />
                                  Update Status
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              <TablePagination
                currentPage={pagination.currentPage}
                pageSize={pagination.pageSize}
                totalPages={pagination.totalPages}
                totalItems={pagination.totalItems}
                startIndex={pagination.startIndex}
                endIndex={pagination.endIndex}
                canGoNext={pagination.canGoNext}
                canGoPrevious={pagination.canGoPrevious}
                onPageChange={pagination.goToPage}
                onPageSizeChange={pagination.setPageSize}
                onNextPage={pagination.goToNextPage}
                onPreviousPage={pagination.goToPreviousPage}
                onFirstPage={pagination.goToFirstPage}
                onLastPage={pagination.goToLastPage}
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Resolve NTE Dialog */}
      <Dialog open={isResolveDialogOpen} onOpenChange={setIsResolveDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Resolve NTE</DialogTitle>
            <DialogDescription>
              Review the employee's explanation and provide your resolution.
            </DialogDescription>
          </DialogHeader>
          {selectedAction && (
            <div className="space-y-4">
              <div className="rounded-lg border p-4 bg-muted/50">
                <h4 className="text-sm font-medium mb-2">Employee Details</h4>
                <p className="text-sm">
                  <span className="font-medium">Name:</span> {getEmployeeName(selectedAction.employeeId)}
                </p>
                <p className="text-sm">
                  <span className="font-medium">Violation:</span> {selectedAction.violationType.replace(/_/g, " ")}
                </p>
                <p className="text-sm">
                  <span className="font-medium">Incident Date:</span> {format(new Date(selectedAction.incidentDate), "MMM d, yyyy")}
                </p>
              </div>

              {selectedAction.employeeExplanation && (
                <div className="rounded-lg border p-4">
                  <h4 className="text-sm font-medium mb-2">Employee's Explanation</h4>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                    {selectedAction.employeeExplanation}
                  </p>
                  {selectedAction.explanationDate && (
                    <p className="text-xs text-muted-foreground mt-2">
                      Submitted on {format(new Date(selectedAction.explanationDate), "MMM d, yyyy 'at' h:mm a")}
                    </p>
                  )}
                </div>
              )}

              <Form {...resolveForm}>
                <form onSubmit={resolveForm.handleSubmit(onResolveSubmit)} className="space-y-4">
                  <FormField
                    control={resolveForm.control}
                    name="resolution"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>HR Resolution Notes *</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder="Provide your resolution notes and decision..."
                            rows={5}
                            data-testid="input-resolution"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={resolveForm.control}
                    name="sanction"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sanction Type</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-sanction">
                              <SelectValue placeholder="Select sanction type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {sanctionTypes.map((type) => (
                              <SelectItem key={type.value} value={type.value}>
                                {type.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {resolveForm.watch("sanction") === "Suspension" && (
                    <FormField
                      control={resolveForm.control}
                      name="sanctionDays"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Suspension Days *</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min={1}
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                              data-testid="input-suspension-days"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsResolveDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={resolveNTEMutation.isPending}
                      data-testid="button-submit-resolve"
                    >
                      {resolveNTEMutation.isPending ? "Submitting..." : "Submit Resolution"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Update Status Dialog */}
      <Dialog open={isUpdateStatusDialogOpen} onOpenChange={setIsUpdateStatusDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Case Status</DialogTitle>
            <DialogDescription>
              Manually update the status of this disciplinary case.
            </DialogDescription>
          </DialogHeader>
          {selectedAction && (
            <Form {...updateStatusForm}>
              <form onSubmit={updateStatusForm.handleSubmit(onUpdateStatusSubmit)} className="space-y-4">
                <div className="rounded-lg border p-3 bg-muted/50">
                  <p className="text-sm">
                    <span className="font-medium">Employee:</span> {getEmployeeName(selectedAction.employeeId)}
                  </p>
                  <p className="text-sm">
                    <span className="font-medium">Current Status:</span>{" "}
                    <Badge variant="secondary" className={statusConfig[selectedAction.status]?.color || ""}>
                      {statusConfig[selectedAction.status]?.label || selectedAction.status}
                    </Badge>
                  </p>
                </div>

                <FormField
                  control={updateStatusForm.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>New Status *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-new-status">
                            <SelectValue placeholder="Select new status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Issued">NTE Issued</SelectItem>
                          <SelectItem value="Explanation_Received">Response Received</SelectItem>
                          <SelectItem value="Under_Review">Under Review</SelectItem>
                          <SelectItem value="Resolved">Resolved</SelectItem>
                          <SelectItem value="Escalated">Escalated</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={updateStatusForm.control}
                  name="remarks"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Remarks</FormLabel>
                      <FormControl>
                        <Textarea
                          {...field}
                          placeholder="Add any remarks or notes about this status change..."
                          rows={3}
                          data-testid="input-status-remarks"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsUpdateStatusDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={updateStatusMutation.isPending}
                    data-testid="button-submit-status"
                  >
                    {updateStatusMutation.isPending ? "Updating..." : "Update Status"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          )}
        </DialogContent>
      </Dialog>

      {/* View Details Dialog */}
      <Dialog open={isViewDetailsDialogOpen} onOpenChange={setIsViewDetailsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>NTE Details</DialogTitle>
            <DialogDescription>
              Complete details of this disciplinary action.
            </DialogDescription>
          </DialogHeader>
          {selectedAction && (
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Employee</p>
                  <p className="text-sm">{getEmployeeName(selectedAction.employeeId)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <Badge variant="secondary" className={statusConfig[selectedAction.status]?.color || ""}>
                    {statusConfig[selectedAction.status]?.label || selectedAction.status}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Violation Type</p>
                  <p className="text-sm">{selectedAction.violationType.replace(/_/g, " ")}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Incident Date</p>
                  <p className="text-sm">{format(new Date(selectedAction.incidentDate), "MMM d, yyyy")}</p>
                </div>
                {selectedAction.nteIssuedDate && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">NTE Issued Date</p>
                    <p className="text-sm">{format(new Date(selectedAction.nteIssuedDate), "MMM d, yyyy")}</p>
                  </div>
                )}
                {selectedAction.responseDeadline && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Response Deadline</p>
                    <p className="text-sm">{format(new Date(selectedAction.responseDeadline), "MMM d, yyyy")}</p>
                  </div>
                )}
              </div>

              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">Description</p>
                <div className="rounded-lg border p-3 bg-muted/50">
                  <p className="text-sm whitespace-pre-wrap">{selectedAction.description}</p>
                </div>
              </div>

              {selectedAction.employeeExplanation && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Employee's Explanation</p>
                  <div className="rounded-lg border p-3 bg-muted/50">
                    <p className="text-sm whitespace-pre-wrap">{selectedAction.employeeExplanation}</p>
                    {selectedAction.explanationDate && (
                      <p className="text-xs text-muted-foreground mt-2">
                        Submitted on {format(new Date(selectedAction.explanationDate), "MMM d, yyyy 'at' h:mm a")}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {selectedAction.resolution && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">HR Resolution</p>
                  <div className="rounded-lg border p-3 bg-muted/50">
                    <p className="text-sm whitespace-pre-wrap">{selectedAction.resolution}</p>
                    {selectedAction.resolvedAt && (
                      <p className="text-xs text-muted-foreground mt-2">
                        Resolved on {format(new Date(selectedAction.resolvedAt), "MMM d, yyyy 'at' h:mm a")}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {selectedAction.sanction && (
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Sanction</p>
                    <p className="text-sm font-medium">{selectedAction.sanction}</p>
                  </div>
                  {selectedAction.sanctionDays && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Suspension Days</p>
                      <p className="text-sm font-medium">{selectedAction.sanctionDays} days</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setIsViewDetailsDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
