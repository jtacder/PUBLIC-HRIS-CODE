import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { getPhotoDisplayUrl } from "@/lib/photo-url";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Clock,
  Calendar,
  Wallet,
  CheckSquare,
  TrendingUp,
  AlertTriangle,
  Timer,
  CalendarX,
  Camera,
  Send,
  Palmtree,
  Stethoscope,
  CalendarOff,
  CheckCircle,
  LogIn,
  LogOut,
} from "lucide-react";
import { Link } from "wouter";
import { getInitials, formatTime } from "@/lib/utils";
import { DevotionalWidget } from "@/components/devotional";
import type { Employee, AttendanceLog } from "@shared/schema";

interface DashboardStats {
  cutoffPeriod: {
    start: string;
    end: string;
    name: string;
  };
  totalAttendance: number;
  totalAbsences: number;
  totalLateMinutes: number;
  totalLateHours: number;
  totalOTHours: number;
  expectedSalary: number;
  pendingTasks: number;
  pendingNTEs: number;
}

interface LeaveBalanceBreakdown {
  year?: number;
  total: number;
  used: number;
  remaining: number;
  breakdown: Array<{
    leaveTypeId: string;
    leaveTypeName: string;
    leaveTypeCode?: string;
    accrualMode?: "annual" | "monthly" | "none";
    totalAllocated?: number;
    accruedToDate?: number;
    availableBalance?: number;
    allocated: number; // For backward compatibility
    used: number;
    remaining: number;
    isPaid: boolean;
    hasAllocation?: boolean;
  }>;
}

export default function EmployeeDashboardPage() {
  const { user } = useAuth();
  const [showLeaveDetails, setShowLeaveDetails] = useState(false);

  const { data: employee, isLoading: employeeLoading } = useQuery<Employee>({
    queryKey: ["/api/employees", user?.employeeId],
    enabled: !!user?.employeeId,
  });

  const { data: dashboardStats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/my/dashboard"],
    enabled: !!user?.employeeId,
  });

  const { data: myAttendance } = useQuery<AttendanceLog[]>({
    queryKey: ["/api/my/attendance"],
    enabled: !!user?.employeeId,
  });

  const { data: myLeaveBalance } = useQuery<LeaveBalanceBreakdown>({
    queryKey: ["/api/my/leave-balance"],
    enabled: !!user?.employeeId,
  });

  const todayDate = new Date().toLocaleDateString('en-PH', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const todayAttendance = myAttendance?.find(a => {
    const logDate = new Date(a.timeIn).toDateString();
    return logDate === new Date().toDateString();
  });

  const formatCutoffPeriod = () => {
    if (!dashboardStats?.cutoffPeriod) return "Current Cutoff";
    const { name, start, end } = dashboardStats.cutoffPeriod;
    const startDate = new Date(start);
    const endDate = new Date(end);
    const dateRange = `${startDate.toLocaleDateString('en-PH', { month: 'short', day: 'numeric' })} - ${endDate.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })}`;
    return name ? `${name} (${dateRange})` : dateRange;
  };

  const getLeaveIcon = (leaveTypeName: string) => {
    const name = leaveTypeName.toLowerCase();
    if (name.includes('vacation') || name.includes('vl')) {
      return <Palmtree className="h-4 w-4 text-green-500" />;
    }
    if (name.includes('sick') || name.includes('sl')) {
      return <Stethoscope className="h-4 w-4 text-red-500" />;
    }
    return <CalendarOff className="h-4 w-4 text-gray-500" />;
  };

  // Get time-based greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  // Calculate attendance progress for the cutoff
  const attendanceProgress = useMemo(() => {
    if (!dashboardStats?.cutoffPeriod) return 0;
    const start = new Date(dashboardStats.cutoffPeriod.start);
    const end = new Date(dashboardStats.cutoffPeriod.end);
    const today = new Date();
    const totalDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    const daysPassed = Math.min(Math.ceil((today.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)), totalDays);
    // Assuming weekdays only (rough estimate)
    const workDays = Math.ceil(daysPassed * (5/7));
    return workDays > 0 ? Math.min((dashboardStats.totalAttendance / workDays) * 100, 100) : 0;
  }, [dashboardStats]);

  if (employeeLoading || statsLoading) {
    return (
      <div className="space-y-6">
        <div className="employee-welcome-card p-6 rounded-lg">
          <div className="flex items-center gap-4">
            <Skeleton className="h-16 w-16 rounded-full" />
            <div className="space-y-2">
              <Skeleton className="h-8 w-48" />
              <Skeleton className="h-4 w-32" />
            </div>
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="skeleton-card">
              <Skeleton className="h-32" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 has-mobile-action-bar">
      {/* Enhanced Welcome Card */}
      <div className="employee-welcome-card p-6 rounded-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16 ring-2 ring-primary/20">
              <AvatarImage src={getPhotoDisplayUrl(employee?.profilePhotoUrl) || undefined} />
              <AvatarFallback className="text-lg bg-primary/10 text-primary">
                {getInitials(`${user?.firstName} ${user?.lastName}`)}
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-2xl font-bold tracking-tight" data-testid="text-welcome">
                {getGreeting()}, {user?.firstName}!
              </h1>
              <p className="text-muted-foreground">{todayDate}</p>
              <div className="flex items-center gap-2 mt-2 flex-wrap">
                <Badge variant="outline">{employee?.position || user?.role}</Badge>
                <Badge variant="secondary">{formatCutoffPeriod()}</Badge>
              </div>
            </div>
          </div>

          {/* Today's Clock Status - Prominent */}
          <div className={`clock-status ${todayAttendance ? 'clocked-in' : 'not-clocked-in'}`}>
            {todayAttendance ? (
              <>
                <CheckCircle className="h-8 w-8 text-green-500" />
                <div>
                  <p className="font-medium text-green-600">Clocked In</p>
                  <p className="text-sm text-muted-foreground">
                    {formatTime(todayAttendance.timeIn)}
                    {todayAttendance.timeOut && (
                      <span> - {formatTime(todayAttendance.timeOut)}</span>
                    )}
                  </p>
                </div>
              </>
            ) : (
              <>
                <Clock className="h-8 w-8 text-amber-500 animate-pulse" />
                <div>
                  <p className="font-medium text-amber-600">Not Clocked In</p>
                  <Link href="/attendance" className="text-sm text-primary hover:underline">
                    Clock in now →
                  </Link>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Quick Action Chips - Mobile Horizontal Scroll */}
      <div className="flex gap-2 overflow-x-auto pb-2 md:hidden -mx-4 px-4">
        <Link href="/attendance" className={`quick-action-chip ${!todayAttendance ? 'primary' : ''}`}>
          <Camera className="h-4 w-4" />
          {todayAttendance ? 'Clock Out' : 'Clock In'}
        </Link>
        <Link href="/my-tasks" className="quick-action-chip">
          <CheckSquare className="h-4 w-4" />
          Tasks
          {(dashboardStats?.pendingTasks || 0) > 0 && (
            <Badge variant="secondary" className="ml-1 h-5 px-1.5">{dashboardStats?.pendingTasks}</Badge>
          )}
        </Link>
        <Link href="/my-requests" className="quick-action-chip">
          <Send className="h-4 w-4" />
          Requests
        </Link>
        <Link href="/my-payslips" className="quick-action-chip">
          <Wallet className="h-4 w-4" />
          Payslips
        </Link>
      </div>

      {/* Stats Cards - Improved Layout */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-3" role="region" aria-label="Your cutoff statistics">
        {/* Attendance Card - Featured */}
        <Card className="dashboard-card col-span-2 lg:col-span-1 border-green-500/20" data-testid="card-attendance" role="article" aria-labelledby="attendance-card-title">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Attendance (Cutoff)</CardTitle>
            <div className="icon-container icon-container-sm bg-green-500/10">
              <Clock className="h-4 w-4 text-green-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold text-green-600 stat-value">
                {dashboardStats?.totalAttendance ?? 0}
              </span>
              <span className="text-sm text-muted-foreground">days</span>
            </div>
            <Progress value={attendanceProgress} className="mt-3 h-2" />
            <p className="text-xs text-muted-foreground mt-2">
              {todayAttendance ? (
                <span className="text-green-600 flex items-center gap-1">
                  <CheckCircle className="h-3 w-3" /> Clocked in today
                </span>
              ) : (
                <span className="text-amber-600">Not yet clocked in today</span>
              )}
            </p>
          </CardContent>
        </Card>

        {/* Absences Card */}
        <Card className={`dashboard-card ${(dashboardStats?.totalAbsences ?? 0) > 0 ? 'alert-card alert-danger' : ''}`} data-testid="card-absences">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Absences</CardTitle>
            <div className={`icon-container icon-container-sm ${(dashboardStats?.totalAbsences ?? 0) > 0 ? 'bg-red-500/10' : 'bg-green-500/10'}`}>
              <CalendarX className={`h-4 w-4 ${(dashboardStats?.totalAbsences ?? 0) > 0 ? 'text-red-500' : 'text-green-500'}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold stat-value ${(dashboardStats?.totalAbsences ?? 0) > 0 ? 'text-red-600' : 'text-green-600'}`}>
              {dashboardStats?.totalAbsences ?? 0} <span className="text-sm font-normal text-muted-foreground">days</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {(dashboardStats?.totalAbsences ?? 0) === 0 ? (
                <span className="text-green-600">Perfect attendance!</span>
              ) : (
                "Missed work days"
              )}
            </p>
          </CardContent>
        </Card>

        {/* Late Hours Card */}
        <Card className={`dashboard-card ${(dashboardStats?.totalLateHours ?? 0) > 0 ? 'alert-card alert-warning' : ''}`} data-testid="card-late-hours">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Late Hours</CardTitle>
            <div className={`icon-container icon-container-sm ${(dashboardStats?.totalLateHours ?? 0) > 0 ? 'bg-yellow-500/10' : 'bg-green-500/10'}`}>
              <Timer className={`h-4 w-4 ${(dashboardStats?.totalLateHours ?? 0) > 0 ? 'text-yellow-500' : 'text-green-500'}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold stat-value ${(dashboardStats?.totalLateHours ?? 0) > 0 ? 'text-yellow-600' : 'text-green-600'}`}>
              {dashboardStats?.totalLateHours ?? 0} <span className="text-sm font-normal text-muted-foreground">hrs</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {(dashboardStats?.totalLateMinutes ?? 0) > 0
                ? `${dashboardStats?.totalLateMinutes} minutes total`
                : <span className="text-green-600">Always on time!</span>
              }
            </p>
          </CardContent>
        </Card>

        {/* Overtime Card */}
        <Card className="dashboard-card border-blue-500/20" data-testid="card-overtime">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overtime</CardTitle>
            <div className="icon-container icon-container-sm bg-blue-500/10">
              <TrendingUp className="h-4 w-4 text-blue-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600 stat-value">
              {dashboardStats?.totalOTHours ?? 0} <span className="text-sm font-normal text-muted-foreground">hrs</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Approved OT hours
            </p>
          </CardContent>
        </Card>

        {/* Pending NTEs Card */}
        <Card className={`dashboard-card ${(dashboardStats?.pendingNTEs ?? 0) > 0 ? 'alert-card alert-danger' : ''}`} data-testid="card-pending-ntes">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending NTEs</CardTitle>
            <div className={`icon-container icon-container-sm ${(dashboardStats?.pendingNTEs ?? 0) > 0 ? 'bg-red-500/10' : 'bg-green-500/10'}`}>
              <AlertTriangle className={`h-4 w-4 ${(dashboardStats?.pendingNTEs ?? 0) > 0 ? 'text-red-500' : 'text-green-500'}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold stat-value ${(dashboardStats?.pendingNTEs ?? 0) > 0 ? 'text-red-600' : 'text-green-600'}`}>
              {dashboardStats?.pendingNTEs ?? 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {(dashboardStats?.pendingNTEs ?? 0) > 0 ? (
                <span className="text-red-600">Needs your attention</span>
              ) : (
                <span className="text-green-600">All clear!</span>
              )}
            </p>
          </CardContent>
        </Card>

        {/* Leave Balance Card - Clickable */}
        <Card
          data-testid="card-leave-balance"
          className="dashboard-card clickable border-primary/20"
          onClick={() => setShowLeaveDetails(true)}
        >
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Leave Balance</CardTitle>
            <div className="icon-container icon-container-sm bg-primary/10">
              <Calendar className="h-4 w-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold stat-value">{myLeaveBalance?.remaining ?? 0} <span className="text-sm font-normal text-muted-foreground">days</span></div>
            <Progress
              value={myLeaveBalance?.total ? ((myLeaveBalance.remaining / myLeaveBalance.total) * 100) : 0}
              className="mt-2 h-1.5"
            />
            <p className="text-xs text-muted-foreground mt-2">
              {myLeaveBalance?.used ?? 0} used of {myLeaveBalance?.total ?? 0} total
            </p>
            {myLeaveBalance?.breakdown && myLeaveBalance.breakdown.length > 0 && (
              <div className="mt-2 flex gap-1 flex-wrap">
                {myLeaveBalance.breakdown.slice(0, 2).map((item, idx) => (
                  <Badge key={idx} variant="outline" className="text-[10px] px-1.5 py-0">
                    {item.leaveTypeName.substring(0, 2).toUpperCase()}: {item.remaining}
                  </Badge>
                ))}
              </div>
            )}
            <p className="text-xs text-primary mt-2 font-medium">View details →</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions - Desktop Only */}
      <div className="hidden md:grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Link href="/attendance">
          <Card className="dashboard-card clickable">
            <CardContent className="flex flex-col items-center justify-center p-6 text-center">
              <div className="icon-container icon-container-lg bg-primary/10 mb-3">
                <Camera className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Clock In/Out</h3>
              <p className="text-sm text-muted-foreground">Record your attendance</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/my-tasks">
          <Card className="dashboard-card clickable">
            <CardContent className="flex flex-col items-center justify-center p-6 text-center relative">
              <div className="icon-container icon-container-lg bg-primary/10 mb-3">
                <CheckSquare className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">My Tasks</h3>
              <p className="text-sm text-muted-foreground">View assigned tasks</p>
              {(dashboardStats?.pendingTasks || 0) > 0 && (
                <Badge className="absolute top-3 right-3" variant="destructive">
                  {dashboardStats?.pendingTasks}
                </Badge>
              )}
            </CardContent>
          </Card>
        </Link>

        <Link href="/my-requests">
          <Card className="dashboard-card clickable">
            <CardContent className="flex flex-col items-center justify-center p-6 text-center">
              <div className="icon-container icon-container-lg bg-primary/10 mb-3">
                <Send className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">My Requests</h3>
              <p className="text-sm text-muted-foreground">Leave & cash advance</p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/my-payslips">
          <Card className="dashboard-card clickable">
            <CardContent className="flex flex-col items-center justify-center p-6 text-center">
              <div className="icon-container icon-container-lg bg-primary/10 mb-3">
                <Wallet className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">My Payslips</h3>
              <p className="text-sm text-muted-foreground">View pay history</p>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Leave Balance Details Dialog */}
      <Dialog open={showLeaveDetails} onOpenChange={setShowLeaveDetails}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Leave Balance Details
            </DialogTitle>
            <DialogDescription>
              Your leave allocation breakdown for this year
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            {myLeaveBalance?.breakdown && myLeaveBalance.breakdown.length > 0 ? (
              <>
                {myLeaveBalance.breakdown.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex items-center gap-3">
                      {getLeaveIcon(item.leaveTypeName)}
                      <div>
                        <p className="font-medium">{item.leaveTypeName}</p>
                        <p className="text-xs text-muted-foreground">
                          {item.isPaid ? "Paid leave" : "Unpaid leave"}
                          {item.accrualMode === "monthly" && " • Monthly accrual"}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg">{item.remaining}</p>
                      <p className="text-xs text-muted-foreground">
                        {item.used} used / {item.allocated} {item.accrualMode === "monthly" ? "accrued" : "allocated"}
                      </p>
                      {item.accrualMode === "monthly" && item.totalAllocated && (
                        <p className="text-xs text-blue-500">
                          of {item.totalAllocated} annual
                        </p>
                      )}
                    </div>
                  </div>
                ))}
                <div className="flex items-center justify-between p-3 rounded-lg bg-primary/10 border border-primary/20">
                  <p className="font-semibold">Total Remaining</p>
                  <p className="font-bold text-xl text-primary">{myLeaveBalance.remaining} days</p>
                </div>
              </>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Calendar className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No leave allocations found</p>
                <p className="text-sm">Contact HR to set up your leave balance</p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Daily Devotional Widget */}
      <DevotionalWidget autoShow={true} />

      {/* Mobile Floating Action Bar */}
      <nav className="mobile-action-bar md:hidden" role="navigation" aria-label="Quick actions">
        <div className="flex justify-around">
          <Link href="/attendance" className="action-item" aria-label={todayAttendance ? 'Clock Out' : 'Clock In'}>
            <Camera aria-hidden="true" />
            <span>{todayAttendance ? 'Clock Out' : 'Clock In'}</span>
          </Link>
          <Link href="/my-tasks" className="action-item" aria-label="View my tasks">
            <CheckSquare aria-hidden="true" />
            <span>Tasks</span>
          </Link>
          <Link href="/my-requests" className="action-item" aria-label="View my requests">
            <Send aria-hidden="true" />
            <span>Requests</span>
          </Link>
          <Link href="/my-payslips" className="action-item" aria-label="View my payslips">
            <Wallet aria-hidden="true" />
            <span>Payslips</span>
          </Link>
        </div>
      </nav>
    </div>
  );
}
