import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Clock,
  Edit2,
  GanttChart,
  Plus,
  Search,
  Users,
  X,
} from "lucide-react";

// Types
interface ScheduleEmployee {
  id: string;
  firstName: string;
  lastName: string;
  employeeNo: string | null;
  department: string | null;
  position: string | null;
  status: string;
  shiftStartTime: string | null;
  shiftEndTime: string | null;
  shiftWorkDays: string[] | null;
  profilePhotoUrl: string | null;
  projectAssignments: ProjectAssignmentWithDetails[];
}

interface ProjectAssignmentWithDetails {
  id: string;
  projectId: string;
  employeeId: string;
  role: string | null;
  startDate: string | null;
  endDate: string | null;
  isActive: boolean | null;
  createdAt: string | null;
  projectName: string;
  projectCode: string | null;
  projectStatus: string | null;
}

interface ScheduleProject {
  id: string;
  name: string;
  code: string | null;
  status: string;
  isOffice: boolean | null;
  startDate: string | null;
  deadline: string | null;
  locationName: string | null;
  assignments: Array<{
    id: string;
    projectId: string;
    employeeId: string;
    role: string | null;
    isActive: boolean | null;
    employee: {
      id: string;
      firstName: string;
      lastName: string;
      employeeNo: string | null;
      department: string | null;
    } | null;
  }>;
}

const DAYS_OF_WEEK = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"] as const;

// Philippine timezone offset
const PHT_OFFSET_MS = 8 * 60 * 60 * 1000;

function getPHTDate(date: Date): Date {
  return new Date(date.getTime() + PHT_OFFSET_MS);
}

function getPHTToday(): Date {
  return getPHTDate(new Date());
}

function getPHTDayAbbrev(date: Date): string {
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const pht = getPHTDate(date);
  return dayNames[pht.getUTCDay()];
}

function formatDateStr(date: Date): string {
  const pht = getPHTDate(date);
  const y = pht.getUTCFullYear();
  const m = String(pht.getUTCMonth() + 1).padStart(2, "0");
  const d = String(pht.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

// Get calendar days for a month (includes padding days from prev/next months)
function getCalendarDays(year: number, month: number): Date[] {
  const firstDay = new Date(Date.UTC(year, month, 1));
  const lastDay = new Date(Date.UTC(year, month + 1, 0));

  // Monday = 0 in our calendar
  let startDayOfWeek = firstDay.getUTCDay() - 1;
  if (startDayOfWeek < 0) startDayOfWeek = 6;

  const days: Date[] = [];

  // Padding from previous month
  for (let i = startDayOfWeek - 1; i >= 0; i--) {
    const d = new Date(Date.UTC(year, month, 1));
    d.setUTCDate(d.getUTCDate() - i - 1);
    days.push(d);
  }

  // Current month days
  for (let d = 1; d <= lastDay.getUTCDate(); d++) {
    days.push(new Date(Date.UTC(year, month, d)));
  }

  // Padding for next month (fill to complete last row)
  while (days.length % 7 !== 0) {
    const last = days[days.length - 1];
    const next = new Date(last);
    next.setUTCDate(next.getUTCDate() + 1);
    days.push(next);
  }

  return days;
}

export default function ScheduleManagementPage() {
  const { hasPermission, isSuperadmin, isAdmin: isLegacyAdmin } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const canEdit = isSuperadmin || isLegacyAdmin || hasPermission("schedules.edit");

  // State
  const [activeTab, setActiveTab] = useState("calendar");
  const [searchTerm, setSearchTerm] = useState("");
  const [projectFilter, setProjectFilter] = useState("all");

  // Calendar state
  const today = getPHTToday();
  const [calendarYear, setCalendarYear] = useState(today.getUTCFullYear());
  const [calendarMonth, setCalendarMonth] = useState(today.getUTCMonth());
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<Date | null>(null);

  // Edit schedule dialog state
  const [editScheduleEmployee, setEditScheduleEmployee] = useState<ScheduleEmployee | null>(null);
  const [editShiftStart, setEditShiftStart] = useState("");
  const [editShiftEnd, setEditShiftEnd] = useState("");
  const [editWorkDays, setEditWorkDays] = useState<string[]>([]);
  const [editAssignProjectId, setEditAssignProjectId] = useState("");
  const [editAssignRole, setEditAssignRole] = useState("");

  // Data fetching
  const { data: employees = [], isLoading: loadingEmployees } = useQuery<ScheduleEmployee[]>({
    queryKey: ["/api/schedule-management/employees"],
  });

  const { data: projects = [], isLoading: loadingProjects } = useQuery<ScheduleProject[]>({
    queryKey: ["/api/schedule-management/projects"],
  });

  // Mutations
  const updateScheduleMutation = useMutation({
    mutationFn: async ({
      employeeId,
      data,
    }: {
      employeeId: string;
      data: { shiftStartTime: string; shiftEndTime: string; shiftWorkDays: string[] };
    }) => {
      return apiRequest("PATCH", `/api/schedule-management/employees/${employeeId}/schedule`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedule-management/employees"] });
      setEditScheduleEmployee(null);
      toast({ title: "Schedule Updated", description: "Employee schedule has been updated." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update schedule.", variant: "destructive" });
    },
  });

  const assignMutation = useMutation({
    mutationFn: async (data: { projectId: string; employeeId: string; role?: string }) => {
      return apiRequest("POST", `/api/schedule-management/projects/${data.projectId}/assign`, {
        employeeId: data.employeeId,
        role: data.role || null,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedule-management/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/schedule-management/projects"] });
      setEditAssignProjectId("");
      setEditAssignRole("");
      toast({ title: "Assigned", description: "Employee has been assigned to the project." });
    },
    onError: (error: Error) => {
      const message = error.message.includes("409")
        ? "Employee is already assigned to this project."
        : "Failed to assign employee.";
      toast({ title: "Error", description: message, variant: "destructive" });
    },
  });

  const unassignMutation = useMutation({
    mutationFn: async ({ projectId, assignmentId }: { projectId: string; assignmentId: string }) => {
      return apiRequest("DELETE", `/api/schedule-management/projects/${projectId}/assignments/${assignmentId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedule-management/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/schedule-management/projects"] });
      toast({ title: "Removed", description: "Employee has been removed from the project." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to remove assignment.", variant: "destructive" });
    },
  });

  // Computed values
  const filteredEmployees = useMemo(() => {
    return employees.filter((e) => {
      const matchesSearch =
        !searchTerm ||
        `${e.firstName} ${e.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (e.employeeNo || "").toLowerCase().includes(searchTerm.toLowerCase());
      const matchesProject =
        projectFilter === "all" ||
        e.projectAssignments.some((a) => a.projectId === projectFilter);
      return matchesSearch && matchesProject;
    });
  }, [employees, searchTerm, projectFilter]);

  const calendarDays = useMemo(
    () => getCalendarDays(calendarYear, calendarMonth),
    [calendarYear, calendarMonth]
  );

  const monthLabel = new Date(Date.UTC(calendarYear, calendarMonth, 1)).toLocaleString("en-US", {
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  });

  // Live data for edit dialog (refreshes when queries update)
  const currentEditEmployee = editScheduleEmployee
    ? employees.find((e) => e.id === editScheduleEmployee.id)
    : null;
  const currentAssignments = currentEditEmployee?.projectAssignments || editScheduleEmployee?.projectAssignments || [];
  const availableProjects = projects.filter(
    (p) => !currentAssignments.some((a) => a.projectId === p.id)
  );

  // Handlers
  function openEditSchedule(emp: ScheduleEmployee) {
    setEditScheduleEmployee(emp);
    setEditShiftStart(emp.shiftStartTime || "08:00");
    setEditShiftEnd(emp.shiftEndTime || "17:00");
    setEditWorkDays(
      Array.isArray(emp.shiftWorkDays)
        ? emp.shiftWorkDays
        : ["Mon", "Tue", "Wed", "Thu", "Fri"]
    );
    setEditAssignProjectId("");
    setEditAssignRole("");
  }

  function handleSaveSchedule() {
    if (!editScheduleEmployee) return;
    updateScheduleMutation.mutate({
      employeeId: editScheduleEmployee.id,
      data: {
        shiftStartTime: editShiftStart,
        shiftEndTime: editShiftEnd,
        shiftWorkDays: editWorkDays,
      },
    });
  }

  function toggleWorkDay(day: string) {
    setEditWorkDays((prev) => {
      const newDays = prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day];
      return DAYS_OF_WEEK.filter((d) => newDays.includes(d));
    });
  }

  function navigateMonth(delta: number) {
    let newMonth = calendarMonth + delta;
    let newYear = calendarYear;
    if (newMonth < 0) {
      newMonth = 11;
      newYear -= 1;
    } else if (newMonth > 11) {
      newMonth = 0;
      newYear += 1;
    }
    setCalendarMonth(newMonth);
    setCalendarYear(newYear);
  }

  function goToToday() {
    const now = getPHTToday();
    setCalendarYear(now.getUTCFullYear());
    setCalendarMonth(now.getUTCMonth());
  }

  // Check if an employee works on a given date
  function employeeWorksOnDate(emp: ScheduleEmployee, date: Date): boolean {
    const dayAbbrev = getPHTDayAbbrev(date);
    const workDays = Array.isArray(emp.shiftWorkDays) ? emp.shiftWorkDays : [];
    return workDays.includes(dayAbbrev);
  }

  // Get employees working on a specific date
  function getEmployeesForDate(date: Date): ScheduleEmployee[] {
    return filteredEmployees.filter((emp) => employeeWorksOnDate(emp, date));
  }

  // Gantt view: get weeks for the current month
  const ganttWeeks = useMemo(() => {
    const weeks: Date[][] = [];
    for (let i = 0; i < calendarDays.length; i += 7) {
      weeks.push(calendarDays.slice(i, i + 7));
    }
    return weeks;
  }, [calendarDays]);

  const isLoading = loadingEmployees || loadingProjects;

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="text-muted-foreground">Loading schedule data...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Schedule Management</h1>
          <p className="text-sm text-muted-foreground">
            Manage employee work schedules and project assignments
          </p>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-4">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={projectFilter} onValueChange={setProjectFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Projects" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Projects</SelectItem>
                {projects.map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.code ? `[${p.code}] ` : ""}
                    {p.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex items-center text-sm text-muted-foreground">
              <Users className="mr-2 h-4 w-4" />
              {filteredEmployees.length} employee{filteredEmployees.length !== 1 ? "s" : ""}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="calendar">
            <CalendarDays className="mr-2 h-4 w-4" />
            Calendar
          </TabsTrigger>
          <TabsTrigger value="gantt">
            <GanttChart className="mr-2 h-4 w-4" />
            Gantt View
          </TabsTrigger>
          <TabsTrigger value="employees">
            <Users className="mr-2 h-4 w-4" />
            Employee Schedules
          </TabsTrigger>
        </TabsList>

        {/* Calendar View */}
        <TabsContent value="calendar" className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={() => navigateMonth(-1)}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <h2 className="min-w-[180px] text-center text-lg font-semibold">{monthLabel}</h2>
              <Button variant="outline" size="icon" onClick={() => navigateMonth(1)}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            <Button variant="outline" size="sm" onClick={goToToday}>
              Today
            </Button>
          </div>

          <div className="flex gap-4">
            {/* Calendar Grid */}
            <div className={`transition-all ${selectedCalendarDate ? "w-3/5" : "w-full"}`}>
              <div className="overflow-x-auto rounded-lg border bg-card">
                <div className="grid grid-cols-7 border-b bg-muted/50">
                  {DAYS_OF_WEEK.map((day) => (
                    <div
                      key={day}
                      className="px-2 py-2 text-center text-xs font-medium text-muted-foreground"
                    >
                      {day}
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-7">
                  {calendarDays.map((date, idx) => {
                    const isCurrentMonth = date.getUTCMonth() === calendarMonth;
                    const todayStr = formatDateStr(new Date());
                    const dateStr = formatDateStr(date);
                    const isToday = dateStr === todayStr;
                    const isSelected =
                      selectedCalendarDate !== null &&
                      formatDateStr(selectedCalendarDate) === dateStr;
                    const workingEmployees = getEmployeesForDate(date);
                    const count = workingEmployees.length;

                    return (
                      <div
                        key={idx}
                        onClick={() => setSelectedCalendarDate(date)}
                        className={`min-h-[56px] cursor-pointer border-b border-r p-2 transition-colors hover:bg-muted/50 ${
                          !isCurrentMonth ? "bg-muted/30" : ""
                        } ${isToday ? "bg-primary/5 ring-1 ring-inset ring-primary/20" : ""} ${
                          isSelected ? "bg-primary/10 ring-2 ring-inset ring-primary" : ""
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span
                            className={`text-xs font-medium ${
                              isToday
                                ? "flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground"
                                : !isCurrentMonth
                                  ? "text-muted-foreground/50"
                                  : "text-foreground"
                            }`}
                          >
                            {date.getUTCDate()}
                          </span>
                          {count > 0 && (
                            <Badge variant="secondary" className="h-5 text-[10px]">
                              {count}
                            </Badge>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Side Panel */}
            {selectedCalendarDate && (
              <div className="w-2/5 rounded-lg border bg-card">
                <div className="flex items-center justify-between border-b p-3">
                  <div>
                    <h3 className="text-sm font-semibold">
                      {selectedCalendarDate.toLocaleDateString("en-US", {
                        weekday: "long",
                        month: "long",
                        day: "numeric",
                        year: "numeric",
                        timeZone: "UTC",
                      })}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {getEmployeesForDate(selectedCalendarDate).length} employee
                      {getEmployeesForDate(selectedCalendarDate).length !== 1 ? "s" : ""} scheduled
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7"
                    onClick={() => setSelectedCalendarDate(null)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <div className="max-h-[500px] overflow-y-auto">
                  {getEmployeesForDate(selectedCalendarDate).length === 0 ? (
                    <p className="p-4 text-center text-sm text-muted-foreground">
                      No employees scheduled
                    </p>
                  ) : (
                    <div className="divide-y">
                      {getEmployeesForDate(selectedCalendarDate).map((emp) => (
                        <div key={emp.id} className="p-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="text-sm font-medium">
                                {emp.firstName} {emp.lastName}
                              </div>
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Clock className="h-3 w-3" />
                                {emp.shiftStartTime || "?"} - {emp.shiftEndTime || "?"}
                              </div>
                            </div>
                          </div>
                          {emp.projectAssignments.length > 0 && (
                            <div className="mt-1.5 flex flex-wrap gap-1">
                              {emp.projectAssignments.map((a) => (
                                <Badge key={a.id} variant="outline" className="text-[10px]">
                                  {a.projectCode || a.projectName}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Gantt View */}
        <TabsContent value="gantt" className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={() => navigateMonth(-1)}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <h2 className="min-w-[180px] text-center text-lg font-semibold">{monthLabel}</h2>
              <Button variant="outline" size="icon" onClick={() => navigateMonth(1)}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            <Button variant="outline" size="sm" onClick={goToToday}>
              Today
            </Button>
          </div>

          <div className="overflow-x-auto rounded-lg border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="sticky left-0 z-10 min-w-[180px] bg-card">
                    Employee
                  </TableHead>
                  {calendarDays
                    .filter((d) => d.getUTCMonth() === calendarMonth)
                    .map((date, idx) => {
                      const dayAbbrev = getPHTDayAbbrev(date);
                      const todayStr = formatDateStr(new Date());
                      const dateStr = formatDateStr(date);
                      const isToday = dateStr === todayStr;
                      const isWeekend = dayAbbrev === "Sat" || dayAbbrev === "Sun";

                      return (
                        <TableHead
                          key={idx}
                          className={`min-w-[36px] px-1 text-center text-xs ${
                            isToday ? "bg-primary/10" : isWeekend ? "bg-muted/50" : ""
                          }`}
                        >
                          <div>{date.getUTCDate()}</div>
                          <div className="text-[10px] text-muted-foreground">{dayAbbrev}</div>
                        </TableHead>
                      );
                    })}
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEmployees.map((emp) => (
                  <TableRow key={emp.id}>
                    <TableCell className="sticky left-0 z-10 bg-card">
                      <div className="flex items-center gap-2">
                        <div>
                          <div className="text-sm font-medium">
                            {emp.firstName} {emp.lastName}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {emp.shiftStartTime || "?"}-{emp.shiftEndTime || "?"}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    {calendarDays
                      .filter((d) => d.getUTCMonth() === calendarMonth)
                      .map((date, idx) => {
                        const works = employeeWorksOnDate(emp, date);
                        const todayStr = formatDateStr(new Date());
                        const dateStr = formatDateStr(date);
                        const isToday = dateStr === todayStr;

                        return (
                          <TableCell
                            key={idx}
                            className={`px-1 text-center ${isToday ? "bg-primary/5" : ""}`}
                          >
                            {works ? (
                              <div
                                className="mx-auto h-5 w-5 rounded bg-primary/80"
                                title={`${emp.firstName} ${emp.lastName}: ${emp.shiftStartTime}-${emp.shiftEndTime}`}
                              />
                            ) : (
                              <div className="mx-auto h-5 w-5 rounded bg-muted/30" />
                            )}
                          </TableCell>
                        );
                      })}
                  </TableRow>
                ))}
                {filteredEmployees.length === 0 && (
                  <TableRow>
                    <TableCell
                      colSpan={calendarDays.filter((d) => d.getUTCMonth() === calendarMonth).length + 1}
                      className="py-8 text-center text-muted-foreground"
                    >
                      No employees match the current filters.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <div className="h-3 w-3 rounded bg-primary/80" />
              Working
            </div>
            <div className="flex items-center gap-1.5">
              <div className="h-3 w-3 rounded bg-muted/30" />
              Off
            </div>
          </div>
        </TabsContent>

        {/* Employee Schedules List */}
        <TabsContent value="employees" className="space-y-4">
          <div className="rounded-lg border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Shift</TableHead>
                  <TableHead>Work Days</TableHead>
                  <TableHead>Projects</TableHead>
                  {canEdit && <TableHead className="w-[80px]">Actions</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEmployees.map((emp) => (
                  <TableRow key={emp.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {emp.firstName} {emp.lastName}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {emp.employeeNo || "No ID"}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm">{emp.department || "-"}</span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                        <span className="text-sm">
                          {emp.shiftStartTime || "?"} - {emp.shiftEndTime || "?"}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {DAYS_OF_WEEK.map((day) => {
                          const workDays = Array.isArray(emp.shiftWorkDays)
                            ? emp.shiftWorkDays
                            : [];
                          const isWorking = workDays.includes(day);
                          return (
                            <span
                              key={day}
                              className={`inline-flex h-6 w-7 items-center justify-center rounded text-[10px] font-medium ${
                                isWorking
                                  ? "bg-primary text-primary-foreground"
                                  : "bg-muted text-muted-foreground/50"
                              }`}
                            >
                              {day[0]}
                            </span>
                          );
                        })}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {emp.projectAssignments.length === 0 ? (
                          <span className="text-xs text-muted-foreground">None</span>
                        ) : (
                          emp.projectAssignments.map((a) => (
                            <Badge key={a.id} variant="outline" className="text-xs">
                              {a.projectCode || a.projectName}
                            </Badge>
                          ))
                        )}
                      </div>
                    </TableCell>
                    {canEdit && (
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEditSchedule(emp)}
                          title="Edit Schedule"
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
                {filteredEmployees.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={canEdit ? 6 : 5} className="py-8 text-center text-muted-foreground">
                      No employees match the current filters.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit Schedule Dialog */}
      <Dialog
        open={!!editScheduleEmployee}
        onOpenChange={(open) => {
          if (!open) setEditScheduleEmployee(null);
        }}
      >
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Work Schedule</DialogTitle>
            <DialogDescription>
              {editScheduleEmployee
                ? `${editScheduleEmployee.firstName} ${editScheduleEmployee.lastName}`
                : ""}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="edit-shift-start">Shift Start</Label>
                <Input
                  id="edit-shift-start"
                  type="time"
                  value={editShiftStart}
                  onChange={(e) => setEditShiftStart(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-shift-end">Shift End</Label>
                <Input
                  id="edit-shift-end"
                  type="time"
                  value={editShiftEnd}
                  onChange={(e) => setEditShiftEnd(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Work Days</Label>
              <div className="flex flex-wrap gap-2">
                {DAYS_OF_WEEK.map((day) => (
                  <label
                    key={day}
                    className={`flex cursor-pointer items-center gap-1.5 rounded-md border px-3 py-1.5 text-sm transition-colors ${
                      editWorkDays.includes(day)
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-input bg-background hover:bg-muted"
                    }`}
                  >
                    <Checkbox
                      checked={editWorkDays.includes(day)}
                      onCheckedChange={() => toggleWorkDay(day)}
                      className="sr-only"
                    />
                    {day}
                  </label>
                ))}
              </div>
            </div>

            {/* Project Assignments Section */}
            {canEdit && (
              <div className="space-y-2">
                <Label>Project Assignments</Label>
                <div className="rounded-md border">
                  {currentAssignments.length === 0 ? (
                    <p className="p-3 text-sm text-muted-foreground">No projects assigned</p>
                  ) : (
                    <div className="divide-y">
                      {currentAssignments.map((a) => (
                        <div key={a.id} className="flex items-center justify-between px-3 py-2">
                          <div className="min-w-0 flex-1">
                            <span className="text-sm">
                              {a.projectCode ? `[${a.projectCode}] ` : ""}
                              {a.projectName}
                            </span>
                            {a.role && (
                              <span className="ml-2 text-xs text-muted-foreground">
                                ({a.role})
                              </span>
                            )}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 flex-shrink-0"
                            disabled={unassignMutation.isPending}
                            onClick={() =>
                              unassignMutation.mutate({
                                projectId: a.projectId,
                                assignmentId: a.id,
                              })
                            }
                          >
                            <X className="h-3.5 w-3.5 text-destructive" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                  {/* Inline assign to project */}
                  {availableProjects.length > 0 && (
                    <div className="space-y-2 border-t p-2">
                      <div className="flex gap-2">
                        <Select value={editAssignProjectId} onValueChange={setEditAssignProjectId}>
                          <SelectTrigger className="h-8 flex-1 text-xs">
                            <SelectValue placeholder="Select project..." />
                          </SelectTrigger>
                          <SelectContent>
                            {availableProjects.map((p) => (
                              <SelectItem key={p.id} value={p.id}>
                                {p.code ? `[${p.code}] ` : ""}
                                {p.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input
                          placeholder="Role (optional)"
                          value={editAssignRole}
                          onChange={(e) => setEditAssignRole(e.target.value)}
                          className="h-8 flex-1 text-xs"
                        />
                        <Button
                          size="sm"
                          className="h-8 px-2"
                          disabled={!editAssignProjectId || assignMutation.isPending}
                          onClick={() => {
                            if (editScheduleEmployee && editAssignProjectId) {
                              assignMutation.mutate({
                                projectId: editAssignProjectId,
                                employeeId: editScheduleEmployee.id,
                                role: editAssignRole || undefined,
                              });
                            }
                          }}
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditScheduleEmployee(null)}>
              Cancel
            </Button>
            <Button
              onClick={handleSaveSchedule}
              disabled={updateScheduleMutation.isPending || editWorkDays.length === 0}
            >
              {updateScheduleMutation.isPending ? "Saving..." : "Save Schedule"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
