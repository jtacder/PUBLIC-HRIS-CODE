import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { usePagination } from "@/hooks/use-pagination";
import { TablePagination } from "@/components/ui/table-pagination";
import {
  useRoles,
  useEmployeesWithRoles,
  useAllPermissions,
  useGroupedPermissions,
  useRoleWithPermissions,
  useEmployeePermissions,
  useRoleMutations,
  useUserPermissionMutations,
  type Role,
  type EmployeeWithRole,
  type Permission,
} from "@/hooks/use-permissions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Crown,
  Shield,
  Users,
  Search,
  Settings,
  Plus,
  Edit,
  Trash2,
  Check,
  X,
  ChevronRight,
  Loader2,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function PermissionManagementPage() {
  const { isSuperadmin } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("roles");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [selectedEmployee, setSelectedEmployee] = useState<EmployeeWithRole | null>(null);
  const [showRoleDialog, setShowRoleDialog] = useState(false);
  const [showUserDialog, setShowUserDialog] = useState(false);
  const [showNewRoleDialog, setShowNewRoleDialog] = useState(false);

  const { data: roles, isLoading: rolesLoading } = useRoles();
  const { data: employees, isLoading: employeesLoading } = useEmployeesWithRoles();
  const { data: groupedPermissions } = useGroupedPermissions();

  // Filter employees based on search
  const filteredEmployees = employees?.filter(
    (emp) =>
      emp.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      emp.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      emp.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      emp.position?.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  // Pagination
  const pagination = usePagination(filteredEmployees);

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Permission Management</h1>
          <p className="text-muted-foreground">
            Manage roles and permissions for your organization
          </p>
        </div>
        {isSuperadmin && (
          <Button onClick={() => setShowNewRoleDialog(true)}>
            <Plus className="h-4 w-4 mr-2" />
            New Role
          </Button>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 max-w-md">
          <TabsTrigger value="roles" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Roles
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Users
          </TabsTrigger>
        </TabsList>

        {/* Roles Tab */}
        <TabsContent value="roles" className="space-y-4">
          {rolesLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {roles?.map((role) => (
                <RoleCard
                  key={role.id}
                  role={role}
                  onManage={() => {
                    setSelectedRole(role);
                    setShowRoleDialog(true);
                  }}
                />
              ))}
            </div>
          )}
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search employees..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {employeesLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Position</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Additional Permissions</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pagination.paginatedData.map((employee) => (
                    <TableRow key={employee.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">
                            {employee.firstName} {employee.lastName}
                          </div>
                          <div className="text-sm text-muted-foreground">{employee.email}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {employee.position || "-"}
                          {employee.department && (
                            <span className="text-muted-foreground"> / {employee.department}</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {employee.assignedRole ? (
                          <Badge
                            variant={employee.assignedRole.isSuperadmin ? "default" : "secondary"}
                            className="flex items-center gap-1 w-fit"
                          >
                            {employee.assignedRole.isSuperadmin && <Crown className="h-3 w-3" />}
                            {employee.assignedRole.displayName}
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-muted-foreground">
                            No role assigned
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {employee.individualPermissionCount > 0 ? (
                          <Badge variant="outline">
                            +{employee.individualPermissionCount} additional
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground text-sm">-</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setSelectedEmployee(employee);
                            setShowUserDialog(true);
                          }}
                        >
                          <Settings className="h-4 w-4 mr-1" />
                          Manage
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <TablePagination
                currentPage={pagination.currentPage}
                pageSize={pagination.pageSize}
                totalPages={pagination.totalPages}
                totalItems={pagination.totalItems}
                startIndex={pagination.startIndex}
                endIndex={pagination.endIndex}
                canGoNext={pagination.canGoNext}
                canGoPrevious={pagination.canGoPrevious}
                onPageChange={pagination.goToPage}
                onPageSizeChange={pagination.setPageSize}
                onNextPage={pagination.goToNextPage}
                onPreviousPage={pagination.goToPreviousPage}
                onFirstPage={pagination.goToFirstPage}
                onLastPage={pagination.goToLastPage}
              />
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Role Management Dialog */}
      {selectedRole && (
        <RolePermissionDialog
          role={selectedRole}
          open={showRoleDialog}
          onOpenChange={setShowRoleDialog}
          groupedPermissions={groupedPermissions}
        />
      )}

      {/* User Permission Dialog */}
      {selectedEmployee && (
        <UserPermissionDialog
          employee={selectedEmployee}
          open={showUserDialog}
          onOpenChange={setShowUserDialog}
          roles={roles || []}
          groupedPermissions={groupedPermissions}
        />
      )}

      {/* New Role Dialog */}
      <NewRoleDialog
        open={showNewRoleDialog}
        onOpenChange={setShowNewRoleDialog}
        groupedPermissions={groupedPermissions}
      />
    </div>
  );
}

// Role Card Component
function RoleCard({ role, onManage }: { role: Role; onManage: () => void }) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {role.isSuperadmin ? (
              <Crown className="h-5 w-5 text-yellow-500" />
            ) : (
              <Shield className="h-5 w-5 text-blue-500" />
            )}
            <CardTitle className="text-lg">{role.displayName}</CardTitle>
          </div>
          {role.isSystemRole && (
            <Badge variant="outline" className="text-xs">
              System
            </Badge>
          )}
        </div>
        <CardDescription className="text-sm">{role.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            <Users className="h-4 w-4 inline mr-1" />
            {role.employeeCount || 0} users
          </div>
          <Button variant="outline" size="sm" onClick={onManage}>
            <Settings className="h-4 w-4 mr-1" />
            Manage
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Role Permission Dialog
function RolePermissionDialog({
  role,
  open,
  onOpenChange,
  groupedPermissions,
}: {
  role: Role;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  groupedPermissions?: Record<string, Record<string, Permission[]>>;
}) {
  const { toast } = useToast();
  const { isSuperadmin } = useAuth();
  const { data: roleData, isLoading } = useRoleWithPermissions(role.id);
  const { updateRolePermissions, deleteRole } = useRoleMutations();
  const [selectedPermissions, setSelectedPermissions] = useState<Set<string>>(new Set());
  const [initialized, setInitialized] = useState(false);

  // Initialize selected permissions from role data
  if (roleData && !initialized) {
    setSelectedPermissions(new Set(roleData.permissions.map((p) => p.id)));
    setInitialized(true);
  }

  // Reset when dialog closes
  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      setInitialized(false);
    }
    onOpenChange(newOpen);
  };

  const togglePermission = (permissionId: string) => {
    const newSet = new Set(selectedPermissions);
    if (newSet.has(permissionId)) {
      newSet.delete(permissionId);
    } else {
      newSet.add(permissionId);
    }
    setSelectedPermissions(newSet);
  };

  const handleSave = async () => {
    try {
      await updateRolePermissions.mutateAsync({
        roleId: role.id,
        permissionIds: Array.from(selectedPermissions),
      });
      toast({ title: "Success", description: "Role permissions updated successfully" });
      handleOpenChange(false);
    } catch (error) {
      toast({ title: "Error", description: "Failed to update role permissions", variant: "destructive" });
    }
  };

  const handleDelete = async () => {
    if (!confirm(`Are you sure you want to delete the "${role.displayName}" role?`)) return;

    try {
      await deleteRole.mutateAsync(role.id);
      toast({ title: "Success", description: "Role deleted successfully" });
      handleOpenChange(false);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete role",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {role.isSuperadmin ? (
              <Crown className="h-5 w-5 text-yellow-500" />
            ) : (
              <Shield className="h-5 w-5 text-blue-500" />
            )}
            {role.displayName}
          </DialogTitle>
          <DialogDescription>
            {role.isSuperadmin
              ? "Superadmin has full access to all features and cannot be modified."
              : "Configure which permissions this role has access to."}
          </DialogDescription>
        </DialogHeader>

        {role.isSuperadmin ? (
          <div className="py-8 text-center text-muted-foreground">
            <Crown className="h-16 w-16 mx-auto mb-4 text-yellow-500" />
            <p>Superadmin role has unrestricted access to all system features.</p>
            <p className="text-sm mt-2">This role cannot be modified for security reasons.</p>
          </div>
        ) : isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <ScrollArea className="h-[50vh] pr-4">
            <PermissionMatrix
              groupedPermissions={groupedPermissions}
              selectedPermissions={selectedPermissions}
              onToggle={togglePermission}
              disabled={!isSuperadmin}
            />
          </ScrollArea>
        )}

        <DialogFooter className="flex justify-between">
          <div>
            {isSuperadmin && !role.isSystemRole && (
              <Button variant="destructive" onClick={handleDelete} disabled={deleteRole.isPending}>
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Role
              </Button>
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => handleOpenChange(false)}>
              Cancel
            </Button>
            {isSuperadmin && !role.isSuperadmin && (
              <Button onClick={handleSave} disabled={updateRolePermissions.isPending}>
                {updateRolePermissions.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Save Changes
              </Button>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// User Permission Dialog
function UserPermissionDialog({
  employee,
  open,
  onOpenChange,
  roles,
  groupedPermissions,
}: {
  employee: EmployeeWithRole;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  roles: Role[];
  groupedPermissions?: Record<string, Record<string, Permission[]>>;
}) {
  const { toast } = useToast();
  const { isSuperadmin } = useAuth();
  const { data: permissionDetails, isLoading } = useEmployeePermissions(employee.id);
  const { changeUserRole, updateUserPermissions } = useUserPermissionMutations();
  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(employee.roleId);
  const [selectedPermissions, setSelectedPermissions] = useState<Set<string>>(new Set());
  const [initialized, setInitialized] = useState(false);

  // Check if a role is selected (not "none")
  const hasRoleSelected = selectedRoleId !== null && selectedRoleId !== "none";

  // Get the selected role details
  const selectedRole = roles.find(r => r.id === selectedRoleId);

  // Initialize from permission details
  if (permissionDetails && !initialized) {
    setSelectedPermissions(new Set(permissionDetails.individualPermissions.map((p) => p.id)));
    setInitialized(true);
  }

  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      setInitialized(false);
      setSelectedRoleId(employee.roleId);
    }
    onOpenChange(newOpen);
  };

  // When role changes, clear individual permissions since backend will clear them too
  const handleRoleChange = (value: string) => {
    const newRoleId = value === "none" ? null : value;
    setSelectedRoleId(newRoleId);

    // If selecting a role, clear individual permissions to match backend behavior
    if (newRoleId !== null) {
      setSelectedPermissions(new Set());
    }
  };

  const togglePermission = (permissionId: string) => {
    const newSet = new Set(selectedPermissions);
    if (newSet.has(permissionId)) {
      newSet.delete(permissionId);
    } else {
      newSet.add(permissionId);
    }
    setSelectedPermissions(newSet);
  };

  const handleSave = async () => {
    try {
      // Update role if changed
      if (selectedRoleId !== employee.roleId) {
        await changeUserRole.mutateAsync({
          employeeId: employee.id,
          roleId: selectedRoleId,
        });
        // Note: Backend automatically clears individual permissions when role changes
      }

      // Only update individual permissions if NO role is selected
      // When a role is assigned, permissions come ONLY from the role
      if (!hasRoleSelected) {
        await updateUserPermissions.mutateAsync({
          employeeId: employee.id,
          permissionIds: Array.from(selectedPermissions),
        });
      }

      toast({ title: "Success", description: "User permissions updated successfully" });
      handleOpenChange(false);
    } catch (error) {
      toast({ title: "Error", description: "Failed to update user permissions", variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>
            Manage Permissions: {employee.firstName} {employee.lastName}
          </DialogTitle>
          <DialogDescription>
            {hasRoleSelected
              ? "This user's permissions are determined by their assigned role."
              : "Assign a role or configure individual permissions for this user."}
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-6">
            {/* Role Selection */}
            <div className="space-y-2">
              <Label>Assigned Role</Label>
              <Select
                value={selectedRoleId || "none"}
                onValueChange={handleRoleChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No role assigned</SelectItem>
                  {roles.map((role) => (
                    <SelectItem key={role.id} value={role.id}>
                      <div className="flex items-center gap-2">
                        {role.isSuperadmin && <Crown className="h-4 w-4 text-yellow-500" />}
                        {role.displayName}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                {hasRoleSelected
                  ? "When a role is assigned, all permissions come from the role. Individual permissions are not allowed."
                  : "Select a role to assign predefined permissions, or leave empty to configure individual permissions below."}
              </p>
            </div>

            <Separator />

            {/* Role Permissions Display - Only show when role is selected */}
            {hasRoleSelected && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-blue-500" />
                  <Label className="text-base">Permissions from {selectedRole?.displayName || "Role"}</Label>
                </div>

                {selectedRole?.isSuperadmin ? (
                  <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                    <div className="flex items-center gap-2 text-yellow-800 dark:text-yellow-200">
                      <Crown className="h-5 w-5" />
                      <span className="font-medium">Superadmin Access</span>
                    </div>
                    <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                      This user has unrestricted access to all system features.
                    </p>
                  </div>
                ) : permissionDetails?.rolePermissions && permissionDetails.rolePermissions.length > 0 ? (
                  <ScrollArea className="h-[30vh] border rounded-md p-4 bg-muted/30">
                    <div className="flex flex-wrap gap-2">
                      {permissionDetails.rolePermissions.map((perm) => (
                        <Badge key={perm.id} variant="secondary" className="text-xs">
                          <Check className="h-3 w-3 mr-1" />
                          {perm.name}
                        </Badge>
                      ))}
                    </div>
                  </ScrollArea>
                ) : (
                  <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg p-4">
                    <p className="text-sm text-orange-700 dark:text-orange-300">
                      This role has no permissions assigned. Please contact an administrator to configure the role.
                    </p>
                  </div>
                )}

                <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
                  <p className="text-sm text-blue-700 dark:text-blue-300">
                    <strong>Note:</strong> Individual permissions are disabled when a role is assigned.
                    To grant specific permissions, either modify the role or remove the role assignment.
                  </p>
                </div>
              </div>
            )}

            {/* Individual Permissions - Only show when NO role is selected */}
            {!hasRoleSelected && (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Settings className="h-5 w-5 text-gray-500" />
                  <Label className="text-base">Individual Permissions</Label>
                </div>
                <p className="text-xs text-muted-foreground mb-2">
                  Grant specific permissions to this user. This is only available when no role is assigned.
                </p>
                <ScrollArea className="h-[30vh] border rounded-md p-4">
                  <PermissionMatrix
                    groupedPermissions={groupedPermissions}
                    selectedPermissions={selectedPermissions}
                    onToggle={togglePermission}
                    disabled={!isSuperadmin && permissionDetails?.isSuperadmin}
                  />
                </ScrollArea>
              </div>
            )}
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => handleOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={changeUserRole.isPending || updateUserPermissions.isPending}
          >
            {(changeUserRole.isPending || updateUserPermissions.isPending) && (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            )}
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// New Role Dialog
function NewRoleDialog({
  open,
  onOpenChange,
  groupedPermissions,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  groupedPermissions?: Record<string, Record<string, Permission[]>>;
}) {
  const { toast } = useToast();
  const { createRole } = useRoleMutations();
  const [name, setName] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [description, setDescription] = useState("");
  const [selectedPermissions, setSelectedPermissions] = useState<Set<string>>(new Set());

  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      setName("");
      setDisplayName("");
      setDescription("");
      setSelectedPermissions(new Set());
    }
    onOpenChange(newOpen);
  };

  const togglePermission = (permissionId: string) => {
    const newSet = new Set(selectedPermissions);
    if (newSet.has(permissionId)) {
      newSet.delete(permissionId);
    } else {
      newSet.add(permissionId);
    }
    setSelectedPermissions(newSet);
  };

  const handleCreate = async () => {
    if (!name || !displayName) {
      toast({ title: "Error", description: "Name and display name are required", variant: "destructive" });
      return;
    }

    try {
      await createRole.mutateAsync({
        name: name.toUpperCase().replace(/\s+/g, "_"),
        displayName,
        description,
        permissionIds: Array.from(selectedPermissions),
      });
      toast({ title: "Success", description: "Role created successfully" });
      handleOpenChange(false);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create role",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>Create New Role</DialogTitle>
          <DialogDescription>
            Define a new role with specific permissions for your organization.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Role Name (Internal)</Label>
              <Input
                id="name"
                placeholder="e.g., PAYROLL_OFFICER"
                value={name}
                onChange={(e) => setName(e.target.value.toUpperCase().replace(/\s+/g, "_"))}
              />
              <p className="text-xs text-muted-foreground">Uppercase with underscores only</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="displayName">Display Name</Label>
              <Input
                id="displayName"
                placeholder="e.g., Payroll Officer"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Describe what this role is for..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <Separator />

          <div className="space-y-2">
            <Label>Permissions</Label>
            <ScrollArea className="h-[30vh] border rounded-md p-4">
              <PermissionMatrix
                groupedPermissions={groupedPermissions}
                selectedPermissions={selectedPermissions}
                onToggle={togglePermission}
              />
            </ScrollArea>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => handleOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleCreate} disabled={createRole.isPending}>
            {createRole.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Create Role
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Permission Matrix Component
function PermissionMatrix({
  groupedPermissions,
  selectedPermissions,
  onToggle,
  disabled = false,
  rolePermissionIds,
}: {
  groupedPermissions?: Record<string, Record<string, Permission[]>>;
  selectedPermissions: Set<string>;
  onToggle: (permissionId: string) => void;
  disabled?: boolean;
  rolePermissionIds?: Set<string>;
}) {
  if (!groupedPermissions) {
    return <div className="text-muted-foreground text-center py-4">Loading permissions...</div>;
  }

  const categories = Object.keys(groupedPermissions).sort();

  return (
    <div className="space-y-6">
      {categories.map((category) => (
        <div key={category} className="space-y-3">
          <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">
            {category}
          </h3>
          <div className="space-y-4">
            {Object.entries(groupedPermissions[category]).map(([feature, perms]) => (
              <div key={feature} className="space-y-2">
                <h4 className="font-medium capitalize text-sm">
                  {feature.replace(/_/g, " ")}
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                  {perms.map((perm) => {
                    const isFromRole = rolePermissionIds?.has(perm.id);
                    const isSelected = selectedPermissions.has(perm.id);

                    return (
                      <div
                        key={perm.id}
                        className={`flex items-center space-x-2 p-2 rounded border ${
                          isFromRole
                            ? "bg-muted/50 border-muted"
                            : isSelected
                            ? "bg-primary/5 border-primary/20"
                            : "border-transparent"
                        }`}
                      >
                        <Checkbox
                          id={perm.id}
                          checked={isSelected || isFromRole}
                          onCheckedChange={() => !isFromRole && onToggle(perm.id)}
                          disabled={disabled || isFromRole}
                        />
                        <Label
                          htmlFor={perm.id}
                          className={`text-sm cursor-pointer flex-1 ${
                            isFromRole ? "text-muted-foreground" : ""
                          }`}
                          title={perm.description || undefined}
                        >
                          {perm.name}
                          {isFromRole && (
                            <span className="text-xs text-muted-foreground ml-1">(from role)</span>
                          )}
                        </Label>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
