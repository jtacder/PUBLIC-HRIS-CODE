import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Eye, EyeOff, Phone, Mail, MapPin, Zap, Settings, CheckCircle, Heart, X, ArrowLeft, Loader2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient, getCsrfToken, refreshCsrfToken } from "@/lib/queryClient";
import { AnimatedBackground } from "@/components/background/AnimatedBackground";

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const forgotPasswordSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

type LoginForm = z.infer<typeof loginSchema>;
type ForgotPasswordForm = z.infer<typeof forgotPasswordSchema>;

export default function LoginPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [showDevoModal, setShowDevoModal] = useState(false);
  const [showForgotPasswordDialog, setShowForgotPasswordDialog] = useState(false);
  const [forgotPasswordSent, setForgotPasswordSent] = useState(false);

  useEffect(() => {
    getCsrfToken().catch(() => {});
  }, []);

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const forgotPasswordForm = useForm<ForgotPasswordForm>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
      email: "",
    },
  });

  const forgotPasswordMutation = useMutation({
    mutationFn: async (data: ForgotPasswordForm) => {
      const response = await apiRequest("POST", "/api/auth/forgot-password", data);
      return response.json();
    },
    onSuccess: () => {
      setForgotPasswordSent(true);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send reset email. Please try again.",
        variant: "destructive",
      });
    },
  });

  const loginMutation = useMutation({
    mutationFn: async (data: LoginForm) => {
      const response = await apiRequest("POST", "/api/auth/login", data);
      return response.json();
    },
    onSuccess: async (data) => {
      await refreshCsrfToken();
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({
        title: "Welcome back!",
        description: `Logged in as ${data.user.firstName} ${data.user.lastName}`,
      });
      navigate(data.redirectUrl || "/dashboard");
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message || "Invalid email or password",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: LoginForm) => {
    loginMutation.mutate(data);
  };

  const onForgotPasswordSubmit = (data: ForgotPasswordForm) => {
    forgotPasswordMutation.mutate(data);
  };

  const handleForgotPasswordDialogClose = () => {
    setShowForgotPasswordDialog(false);
    setForgotPasswordSent(false);
    forgotPasswordForm.reset();
  };

  return (
    <div className="relative min-h-screen flex flex-col overflow-hidden">
      {/* Background */}
      <AnimatedBackground variant="electrical" />

      {/* Main Container */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <header className="px-4 md:px-12 py-4 flex flex-col md:flex-row justify-between items-center gap-4 bg-[#0d0d12]/90 backdrop-blur-md border-b border-[#00a8ff]/20">
          <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#00a8ff] to-[#ff3355] opacity-50" />

          <div className="flex items-center gap-4">
            {/* Logo Icon - Static, professional */}
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#00a8ff] to-[#0052cc] flex items-center justify-center shadow-lg shadow-[#00a8ff]/20 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent" />
              <Zap className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-xl md:text-2xl tracking-wider bg-gradient-to-r from-white to-[#00a8ff] bg-clip-text text-transparent" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                JE & REJ TECH
              </h1>
              <span className="text-xs text-[#ff3355] tracking-[4px] uppercase font-semibold">Corporation</span>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-4 md:gap-8 text-sm">
            <a href="tel:0324240278" className="flex items-center gap-2 text-white/70 hover:text-[#00a8ff] transition-colors">
              <Phone className="w-4 h-4 text-[#00a8ff]" />
              (032) 424-0278
            </a>
            <a href="mailto:info@jerejtechcorp.com" className="flex items-center gap-2 text-white/70 hover:text-[#00a8ff] transition-colors">
              <Mail className="w-4 h-4 text-[#00a8ff]" />
              info@jerejtechcorp.com
            </a>
          </div>
        </header>

        {/* Hero Section */}
        <section className="flex-1 flex flex-col lg:flex-row items-center justify-center gap-8 lg:gap-20 px-4 md:px-8 lg:px-16 py-8">
          {/* Hero Content */}
          <div className="flex-1 max-w-xl text-center lg:text-left">
            {/* Tagline - Static badge, no competing animation */}
            <div className="inline-flex items-center gap-3 px-4 py-2 bg-[#00a8ff]/8 border border-[#00a8ff]/15 rounded-full mb-6">
              <Zap className="w-4 h-4 text-[#00a8ff]" />
              <span className="text-sm font-semibold text-[#00a8ff]/90 tracking-wider uppercase">Your Reliable Electrical Service Provider</span>
            </div>

            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight mb-6" style={{ fontFamily: "'Orbitron', sans-serif" }}>
              <span className="block text-white">Excellence in</span>
              <span className="block bg-gradient-to-r from-[#00a8ff] to-[#ff3355] bg-clip-text text-transparent">Engineering & Electrical</span>
              <span className="block text-white/70 text-2xl md:text-3xl font-semibold mt-2">Services</span>
            </h2>

            <p className="text-base md:text-lg text-white/70 leading-relaxed mb-8">
              Over 20 years of consolidated experience in installation, troubleshooting,
              system study, test and commissioning of electrical equipment. From Low Voltage
              to High Voltage systems — we deliver 24/7 Technical Assistance.
            </p>

            {/* Features Row */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-4 mb-8">
              <div className="flex items-center gap-3 px-4 py-3 bg-[#0d0d12]/80 border border-[#00a8ff]/20 rounded-xl hover:border-[#00a8ff] hover:shadow-lg hover:shadow-[#00a8ff]/10 transition-all cursor-default">
                <Zap className="w-6 h-6 text-[#00a8ff]" />
                <span className="font-semibold text-white">High Voltage</span>
              </div>
              <div className="flex items-center gap-3 px-4 py-3 bg-[#0d0d12]/80 border border-[#ff3355]/20 rounded-xl hover:border-[#ff3355] hover:shadow-lg hover:shadow-[#ff3355]/10 transition-all cursor-default">
                <Settings className="w-6 h-6 text-[#ff3355]" />
                <span className="font-semibold text-white">Substation Design</span>
              </div>
              <div className="flex items-center gap-3 px-4 py-3 bg-[#0d0d12]/80 border border-[#00a8ff]/20 rounded-xl hover:border-[#00a8ff] hover:shadow-lg hover:shadow-[#00a8ff]/10 transition-all cursor-default">
                <CheckCircle className="w-6 h-6 text-[#00a8ff]" />
                <span className="font-semibold text-white">24/7 Support</span>
              </div>
            </div>

            {/* Stats Row - Refined glow, professional look */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-8 md:gap-12">
              <div className="text-center lg:text-left">
                <div className="text-4xl md:text-5xl font-bold text-[#00a8ff]" style={{ fontFamily: "'Orbitron', sans-serif", textShadow: "0 0 30px rgba(0, 168, 255, 0.25)" }}>
                  20<span className="text-[#ff3355]">+</span>
                </div>
                <div className="text-xs text-white/50 uppercase tracking-wider mt-1">Years Experience</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-4xl md:text-5xl font-bold text-[#00a8ff]" style={{ fontFamily: "'Orbitron', sans-serif", textShadow: "0 0 30px rgba(0, 168, 255, 0.25)" }}>
                  500<span className="text-[#ff3355]">+</span>
                </div>
                <div className="text-xs text-white/50 uppercase tracking-wider mt-1">Projects Done</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-4xl md:text-5xl font-bold text-[#00a8ff]" style={{ fontFamily: "'Orbitron', sans-serif", textShadow: "0 0 30px rgba(0, 168, 255, 0.25)" }}>
                  24<span className="text-[#ff3355]">/7</span>
                </div>
                <div className="text-xs text-white/50 uppercase tracking-wider mt-1">Tech Support</div>
              </div>
            </div>
          </div>

          {/* Login Card - Enhanced Glassmorphism for Visual Hierarchy */}
          <div className="w-full max-w-md">
            <div
              className="relative overflow-hidden rounded-2xl p-6 md:p-8 shadow-2xl"
              style={{
                background: "rgba(13, 13, 20, 0.92)",
                backdropFilter: "blur(24px) saturate(1.2)",
                WebkitBackdropFilter: "blur(24px) saturate(1.2)",
                border: "1px solid rgba(0, 168, 255, 0.15)",
                boxShadow: `
                  0 0 0 1px rgba(0, 168, 255, 0.08),
                  0 8px 32px rgba(0, 0, 0, 0.4),
                  0 0 80px rgba(0, 168, 255, 0.08),
                  inset 0 1px 0 rgba(255, 255, 255, 0.05)
                `,
              }}
            >
              {/* Top gradient border - Static, elegant */}
              <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#00a8ff] to-transparent opacity-60" />
              <div className="absolute top-[2px] left-1/4 right-1/4 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

              {/* Login Header - Static, clean */}
              <div className="text-center mb-8">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-[#00a8ff]/15 to-[#00a8ff]/5 border border-[#00a8ff]/20 flex items-center justify-center">
                  <svg className="w-8 h-8 text-[#00a8ff]" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                  </svg>
                </div>
                <h3 className="text-xl font-bold bg-gradient-to-r from-white to-[#00a8ff] bg-clip-text text-transparent" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  Employee Portal
                </h3>
                <p className="text-sm text-white/50 mt-1">Sign in to access your dashboard</p>
              </div>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <label className="block text-xs text-white/70 uppercase tracking-wider font-semibold mb-2">
                          Email Address
                        </label>
                        <FormControl>
                          <div className="relative group">
                            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#4a4a5a] group-focus-within:text-[#00a8ff] transition-colors" />
                            <Input
                              type="email"
                              placeholder="Enter your email"
                              className="w-full pl-12 pr-4 py-4 bg-white/5 border border-[#2d2d3a] rounded-xl text-white placeholder:text-white/40 focus:border-[#00a8ff] focus:bg-[#00a8ff]/5 focus:ring-2 focus:ring-[#00a8ff]/20 transition-all"
                              data-testid="input-email"
                              {...field}
                            />
                          </div>
                        </FormControl>
                        <FormMessage className="text-[#ff3355]" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <label className="block text-xs text-white/70 uppercase tracking-wider font-semibold mb-2">
                          Password
                        </label>
                        <FormControl>
                          <div className="relative group">
                            <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#4a4a5a] group-focus-within:text-[#00a8ff] transition-colors" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
                            </svg>
                            <Input
                              type={showPassword ? "text" : "password"}
                              placeholder="Enter your password"
                              className="w-full pl-12 pr-12 py-4 bg-white/5 border border-[#2d2d3a] rounded-xl text-white placeholder:text-white/40 focus:border-[#00a8ff] focus:bg-[#00a8ff]/5 focus:ring-2 focus:ring-[#00a8ff]/20 transition-all"
                              data-testid="input-password"
                              {...field}
                            />
                            <button
                              type="button"
                              onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-4 top-1/2 -translate-y-1/2 text-[#4a4a5a] hover:text-[#00a8ff] transition-colors"
                              data-testid="button-toggle-password"
                            >
                              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                            </button>
                          </div>
                        </FormControl>
                        <FormMessage className="text-[#ff3355]" />
                      </FormItem>
                    )}
                  />

                  {/* Form Options */}
                  <div className="flex justify-between items-center text-sm">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <Checkbox
                        checked={rememberMe}
                        onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                        className="border-[#2d2d3a] data-[state=checked]:bg-[#00a8ff] data-[state=checked]:border-[#00a8ff]"
                      />
                      <span className="text-white/70">Remember me</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowForgotPasswordDialog(true)}
                      className="text-[#ff3355] hover:text-white font-medium transition-colors"
                    >
                      Forgot Password?
                    </button>
                  </div>

                  <Button
                    type="submit"
                    disabled={loginMutation.isPending}
                    className="w-full py-5 bg-gradient-to-r from-[#00a8ff] to-[#0052cc] hover:from-[#0080ff] hover:to-[#0052cc] text-white font-semibold tracking-widest uppercase rounded-xl shadow-lg shadow-[#00a8ff]/30 hover:shadow-[#00a8ff]/50 hover:-translate-y-0.5 transition-all duration-300 relative overflow-hidden group"
                    data-testid="button-login"
                    style={{ fontFamily: "'Orbitron', sans-serif" }}
                  >
                    <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-500" />
                    {loginMutation.isPending ? (
                      <span className="flex items-center justify-center gap-2">
                        <span className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Signing In...
                      </span>
                    ) : (
                      "Sign In"
                    )}
                  </Button>
                </form>
              </Form>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="px-4 md:px-12 py-6 bg-[#0d0d12]/95 border-t border-[#00a8ff]/20 relative">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#00a8ff] to-[#ff3355] opacity-50" />

          <div className="flex flex-col md:flex-row justify-between items-center gap-4 flex-wrap">
            <div className="flex items-center gap-3 text-sm text-white/50">
              <Zap className="w-6 h-6 text-[#00a8ff]" />
              <span>&copy; {new Date().getFullYear()} JE & REJ Tech Corporation. All rights reserved.</span>
            </div>

            <div className="flex gap-6 md:gap-8">
              <a href="#" className="text-sm text-white/50 hover:text-[#00a8ff] transition-colors">Privacy Policy</a>
              <a href="#" className="text-sm text-white/50 hover:text-[#00a8ff] transition-colors">Terms of Service</a>
              <a href="#" className="text-sm text-white/50 hover:text-[#00a8ff] transition-colors">Support</a>
            </div>

            <div className="flex items-center gap-2 text-sm text-white/50">
              <MapPin className="w-4 h-4 text-[#ff3355]" />
              <span>Liloan City, Cebu, Philippines</span>
            </div>
          </div>
        </footer>
      </div>

      {/* Devotional Widget */}
      <div className="fixed bottom-8 right-8 z-50">
        {/* FAB Button - Subtle, non-competing */}
        {!showDevoModal && (
          <button
            onClick={() => setShowDevoModal(true)}
            className="w-14 h-14 rounded-full bg-gradient-to-br from-[#1a237e] to-[#0d47a1] border border-[#ffc107]/30 shadow-lg shadow-[#1a237e]/30 flex items-center justify-center hover:scale-105 hover:border-[#ffc107]/50 hover:shadow-[#ffc107]/20 transition-all duration-300"
          >
            <Heart className="w-6 h-6 text-[#ffc107]" />
          </button>
        )}

        {/* Modal */}
        {showDevoModal && (
          <div className="w-[380px] max-w-[calc(100vw-2rem)] bg-gradient-to-br from-[#1a237e] via-[#0d47a1] to-[#01579b] rounded-2xl border border-[#ffc107]/30 shadow-2xl overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
            {/* Header */}
            <div className="px-5 py-4 bg-black/20 border-b border-[#ffc107]/20 flex justify-between items-center">
              <h4 className="flex items-center gap-2 font-bold text-white" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                <Heart className="w-4 h-4 text-[#ffc107]" />
                Daily Devotional
              </h4>
              <span className="px-3 py-1 bg-[#ffc107]/20 text-[#ffc107] rounded-full text-xs font-semibold tracking-wider">
                DAY 127
              </span>
              <button
                onClick={() => setShowDevoModal(false)}
                className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
              >
                <X className="w-4 h-4 text-white/70" />
              </button>
            </div>

            {/* Content */}
            <div className="p-5">
              <div className="bg-white/10 border-l-4 border-[#ffc107] rounded-r-xl p-4 mb-5">
                <p className="text-white italic leading-relaxed mb-2">
                  "Commit your work to the Lord, and your plans will be established."
                </p>
                <cite className="text-[#ffc107] text-sm font-semibold not-italic">— Proverbs 16:3 (ESV)</cite>
              </div>

              <p className="text-white/90 text-sm leading-relaxed">
                Today's reflection reminds us that excellence in our professional endeavors
                begins with surrendering our efforts to God. As we serve our clients and
                colleagues, let us approach each task with integrity and dedication, knowing
                that our work is an act of worship.
              </p>
            </div>

            {/* Footer */}
            <div className="px-5 py-4 bg-black/15 border-t border-[#ffc107]/10 flex gap-3">
              <button
                onClick={() => setShowDevoModal(false)}
                className="flex-1 py-3 rounded-xl bg-white/10 border border-white/20 text-white/80 font-semibold uppercase tracking-wider text-sm hover:bg-white/15 transition-colors"
              >
                Read Later
              </button>
              <button className="flex-1 py-3 rounded-xl bg-[#ffc107] text-[#1a237e] font-semibold uppercase tracking-wider text-sm hover:bg-[#ffcd38] hover:-translate-y-0.5 hover:shadow-lg hover:shadow-[#ffc107]/40 transition-all">
                Continue Reading
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Forgot Password Dialog */}
      <Dialog open={showForgotPasswordDialog} onOpenChange={handleForgotPasswordDialogClose}>
        <DialogContent className="sm:max-w-md bg-[#0d0d12] border border-[#00a8ff]/20 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold bg-gradient-to-r from-white to-[#00a8ff] bg-clip-text text-transparent" style={{ fontFamily: "'Orbitron', sans-serif" }}>
              {forgotPasswordSent ? "Check Your Email" : "Reset Password"}
            </DialogTitle>
            <DialogDescription className="text-white/60">
              {forgotPasswordSent
                ? "If an account exists with that email, you'll receive a password reset link shortly."
                : "Enter your email address and we'll send you a link to reset your password."}
            </DialogDescription>
          </DialogHeader>

          {forgotPasswordSent ? (
            <div className="space-y-4">
              <div className="flex items-center justify-center py-6">
                <div className="w-16 h-16 rounded-full bg-[#00a8ff]/10 border border-[#00a8ff]/30 flex items-center justify-center">
                  <Mail className="w-8 h-8 text-[#00a8ff]" />
                </div>
              </div>
              <p className="text-sm text-white/70 text-center">
                The reset link will expire in 1 hour. If you don't see the email, check your spam folder.
              </p>
              <Button
                type="button"
                onClick={handleForgotPasswordDialogClose}
                className="w-full py-4 bg-gradient-to-r from-[#00a8ff] to-[#0052cc] hover:from-[#0080ff] hover:to-[#0052cc] text-white font-semibold tracking-widest uppercase rounded-xl"
                style={{ fontFamily: "'Orbitron', sans-serif" }}
              >
                Back to Login
              </Button>
            </div>
          ) : (
            <Form {...forgotPasswordForm}>
              <form onSubmit={forgotPasswordForm.handleSubmit(onForgotPasswordSubmit)} className="space-y-4">
                <FormField
                  control={forgotPasswordForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <label className="block text-xs text-white/70 uppercase tracking-wider font-semibold mb-2">
                        Email Address
                      </label>
                      <FormControl>
                        <div className="relative group">
                          <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#4a4a5a] group-focus-within:text-[#00a8ff] transition-colors" />
                          <Input
                            type="email"
                            placeholder="Enter your email"
                            className="w-full pl-12 pr-4 py-4 bg-white/5 border border-[#2d2d3a] rounded-xl text-white placeholder:text-white/40 focus:border-[#00a8ff] focus:bg-[#00a8ff]/5 focus:ring-2 focus:ring-[#00a8ff]/20 transition-all"
                            {...field}
                          />
                        </div>
                      </FormControl>
                      <FormMessage className="text-[#ff3355]" />
                    </FormItem>
                  )}
                />

                <div className="flex gap-3 pt-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleForgotPasswordDialogClose}
                    className="flex-1 py-4 bg-white/5 border border-[#2d2d3a] text-white/70 hover:bg-white/10 hover:text-white rounded-xl"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={forgotPasswordMutation.isPending}
                    className="flex-1 py-4 bg-gradient-to-r from-[#00a8ff] to-[#0052cc] hover:from-[#0080ff] hover:to-[#0052cc] text-white font-semibold tracking-widest uppercase rounded-xl"
                    style={{ fontFamily: "'Orbitron', sans-serif" }}
                  >
                    {forgotPasswordMutation.isPending ? (
                      <span className="flex items-center justify-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Sending...
                      </span>
                    ) : (
                      "Send Link"
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          )}
        </DialogContent>
      </Dialog>

      {/* Google Fonts */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Rajdhani:wght@300;400;500;600;700&display=swap');
      `}</style>
    </div>
  );
}
