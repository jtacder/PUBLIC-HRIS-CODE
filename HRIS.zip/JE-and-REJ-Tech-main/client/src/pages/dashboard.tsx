import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Users,
  CalendarClock,
  Banknote,
  Clock,
  TrendingUp,
  CheckCircle,
  AlertCircle,
  FolderKanban,
  Receipt,
  AlertTriangle,
  UserX,
  ChevronDown,
  ChevronRight,
  Bell,
  Eye,
} from "lucide-react";
import { Link } from "wouter";
import { formatCurrency } from "@/lib/utils";
import { DevotionalWidget } from "@/components/devotional";
import type { Employee, AttendanceLog } from "@shared/schema";

interface AvailableCutoff {
  id: string;
  name: string;
  startDay: number;
  endDay: number;
  startDate: string;
  endDate: string;
  isCurrent: boolean;
}

interface DashboardStats {
  totalEmployees: number;
  activeEmployees: number;
  todayAttendance: number;
  // New fields for attendance tracking
  dayOffsToday: number;
  onLeaveToday: number;
  expectedPresent: number;
  estimatedBasicPay: string;
  estimatedOTPay: string;
  estimatedTotalPayroll: string;
  cutoffId: string;
  cutoffName: string;
  cutoffStart: string;
  cutoffEnd: string;
  availableCutoffs: AvailableCutoff[];
  totalProjects: number;
  activeProjects: number;
  pendingExpenses: number;
  openNTEs: number;
  pendingOTCount: number;
  lateTodayCount: number;
  notClockedInCount: number;
  notClockedInEmployees: Array<{
    id: string;
    firstName: string;
    lastName: string;
    employeeNo: string;
  }>;
}

export default function DashboardPage() {
  const [selectedCutoffId, setSelectedCutoffId] = useState<string | null>(null);

  const { data: stats, isLoading: statsLoading, isError: statsError, refetch: refetchStats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats", selectedCutoffId],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedCutoffId) {
        params.set("cutoffId", selectedCutoffId);
      }
      const url = `/api/dashboard/stats${params.toString() ? `?${params.toString()}` : ""}`;
      const response = await fetch(url, { credentials: "include" });
      if (!response.ok) throw new Error("Failed to fetch stats");
      return response.json();
    },
    retry: 2,
    // Dashboard stats query is heavy (7 parallel DB queries) - cache for 10 minutes
    // HR users don't need real-time updates; they can manually refresh if needed
    staleTime: 10 * 60 * 1000,
  });

  // Handler for cutoff selection change
  const handleCutoffChange = (cutoffId: string) => {
    setSelectedCutoffId(cutoffId);
  };

  const { data: employees, isLoading: employeesLoading, isError: employeesError, refetch: refetchEmployees } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
    retry: 2,
  });

  const { data: todayAttendance, isLoading: attendanceLoading, isError: attendanceError, refetch: refetchAttendance } = useQuery<AttendanceLog[]>({
    queryKey: ["/api/attendance/today"],
    retry: 2,
  });

  const isLoading = statsLoading || employeesLoading || attendanceLoading;
  const hasError = statsError || employeesError || attendanceError;

  const handleRetry = () => {
    if (statsError) refetchStats();
    if (employeesError) refetchEmployees();
    if (attendanceError) refetchAttendance();
  };

  // Create employee map for quick lookup
  const employeeMap = new Map(employees?.map(e => [e.id, e]) || []);

  // Memoize attendance rate calculation - use expectedPresent (excludes day offs and leave)
  const attendanceRate = useMemo(() => {
    const expected = stats?.expectedPresent || 0;
    if (expected <= 0) return 0;
    return Math.round(((stats?.todayAttendance || 0) / expected) * 100);
  }, [stats?.todayAttendance, stats?.expectedPresent]);

  // Calculate total alerts needing attention
  const totalAlerts = useMemo(() => {
    return (stats?.pendingOTCount || 0) + (stats?.lateTodayCount || 0) + (stats?.notClockedInCount || 0);
  }, [stats?.pendingOTCount, stats?.lateTodayCount, stats?.notClockedInCount]);

  // Get time-based greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  // State for collapsible alerts
  const [alertsExpanded, setAlertsExpanded] = useState(true);
  const [notClockedInExpanded, setNotClockedInExpanded] = useState(false);

  return (
    <div className="space-y-6 has-mobile-action-bar">
      {/* Error Banner */}
      {hasError && (
        <div className="flex items-center justify-between gap-4 p-4 rounded-lg bg-destructive/10 border border-destructive/20">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-destructive" />
            <p className="text-sm font-medium text-destructive">
              Failed to load some dashboard data. Please try again.
            </p>
          </div>
          <button
            onClick={handleRetry}
            className="text-sm font-medium text-destructive hover:underline"
            data-testid="button-retry-dashboard"
          >
            Retry
          </button>
        </div>
      )}

      {/* Page Header with Cutoff Selector */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between" data-tour="dashboard-header">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{getGreeting()}!</h1>
          <p className="text-muted-foreground">
            Here's your workforce overview for today.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {/* Live indicator */}
          <div className="live-indicator hidden sm:flex">
            <span className="live-dot" />
            <span>Live data</span>
          </div>
          {/* Cutoff Selector - Moved to header */}
          {stats?.availableCutoffs && stats.availableCutoffs.length > 0 && (
            <Select
              value={selectedCutoffId || stats?.cutoffId || ""}
              onValueChange={handleCutoffChange}
            >
              <SelectTrigger className="w-[180px] h-9" data-testid="cutoff-selector">
                <SelectValue placeholder="Select cutoff" />
              </SelectTrigger>
              <SelectContent>
                {stats.availableCutoffs.map((cutoff) => (
                  <SelectItem key={cutoff.id} value={cutoff.id}>
                    <div className="flex items-center gap-2">
                      <span>{cutoff.name}</span>
                      {cutoff.isCurrent && (
                        <Badge variant="secondary" className="text-[10px] px-1 py-0">
                          Current
                        </Badge>
                      )}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>
      </div>

      {/* Attention Required Banner - Only shows when there are alerts */}
      {!isLoading && totalAlerts > 0 && (
        <Collapsible open={alertsExpanded} onOpenChange={setAlertsExpanded}>
          <div className="attention-banner" data-tour="attention-banner" role="alert" aria-label={`${totalAlerts} items require your attention`}>
            <CollapsibleTrigger className="flex items-center justify-between w-full" aria-expanded={alertsExpanded} aria-controls="alerts-content">
              <div className="flex items-center gap-3">
                <div className="icon-container icon-container-sm bg-amber-500/10">
                  <Bell className="h-4 w-4 text-amber-500" />
                </div>
                <div className="text-left">
                  <h3 className="text-sm font-semibold">Attention Required</h3>
                  <p className="text-xs text-muted-foreground">{totalAlerts} items need your attention</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{totalAlerts}</Badge>
                {alertsExpanded ? (
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                ) : (
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                )}
              </div>
            </CollapsibleTrigger>
            <CollapsibleContent id="alerts-content" className="mt-3">
              <div className="grid gap-2 sm:grid-cols-3" role="list" aria-label="Attention items">
                {(stats?.pendingOTCount || 0) > 0 && (
                  <Link href="/attendance?filter=ot">
                    <div className="alert-row hover-elevate cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="alert-icon bg-orange-500/10">
                          <Clock className="h-4 w-4 text-orange-500" />
                        </div>
                        <span className="text-sm font-medium">Pending OT</span>
                      </div>
                      <span className="alert-count text-orange-500">{stats?.pendingOTCount}</span>
                    </div>
                  </Link>
                )}
                {(stats?.lateTodayCount || 0) > 0 && (
                  <Link href="/attendance?filter=late">
                    <div className="alert-row hover-elevate cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="alert-icon bg-red-500/10">
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                        </div>
                        <span className="text-sm font-medium">Late Today</span>
                      </div>
                      <span className="alert-count text-red-500">{stats?.lateTodayCount}</span>
                    </div>
                  </Link>
                )}
                {(stats?.notClockedInCount || 0) > 0 && (
                  <div
                    className="alert-row hover-elevate cursor-pointer"
                    onClick={() => setNotClockedInExpanded(!notClockedInExpanded)}
                  >
                    <div className="flex items-center gap-3">
                      <div className="alert-icon bg-yellow-500/10">
                        <UserX className="h-4 w-4 text-yellow-500" />
                      </div>
                      <span className="text-sm font-medium">Not Clocked In</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="alert-count text-yellow-600">{stats?.notClockedInCount}</span>
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>
                )}
              </div>
              {/* Expandable Not Clocked In List */}
              {notClockedInExpanded && stats?.notClockedInEmployees && stats.notClockedInEmployees.length > 0 && (
                <div className="mt-3 p-3 rounded-lg bg-muted/50 max-h-32 overflow-y-auto">
                  <p className="text-xs font-medium text-muted-foreground mb-2">Employees not clocked in:</p>
                  <div className="grid gap-1 sm:grid-cols-2 lg:grid-cols-3">
                    {stats.notClockedInEmployees.map(emp => (
                      <div key={emp.id} className="text-xs py-1">
                        {emp.firstName} {emp.lastName}
                        <span className="text-muted-foreground ml-1">({emp.employeeNo})</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CollapsibleContent>
          </div>
        </Collapsible>
      )}

      {/* Primary Stats Grid - Improved Visual Hierarchy */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4" data-tour="stats-grid" role="region" aria-label="Key performance indicators">
        {/* Attendance Rate - Featured Card */}
        <Card className="dashboard-card col-span-2 lg:col-span-1 border-primary/20" data-tour="stat-attendance-rate" role="article" aria-labelledby="attendance-rate-title">
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle id="attendance-rate-title" className="text-sm font-medium text-muted-foreground">
              Attendance Rate
            </CardTitle>
            <div className="icon-container icon-container-sm bg-primary/10" aria-hidden="true">
              <TrendingUp className="h-4 w-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="skeleton-card" aria-label="Loading attendance rate">
                <Skeleton className="h-10 w-20 mb-2" />
                <Skeleton className="h-2 w-full" />
              </div>
            ) : (
              <>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold stat-value" data-testid="stat-attendance-rate" aria-live="polite">
                    {attendanceRate}%
                  </span>
                  {attendanceRate >= 90 && (
                    <span className="stat-trend up" aria-label="Excellent attendance">
                      <CheckCircle className="h-3 w-3" aria-hidden="true" />
                      Great
                    </span>
                  )}
                </div>
                <Progress
                  value={attendanceRate}
                  className="mt-3 h-2"
                  aria-label={`Attendance rate: ${attendanceRate}%`}
                />
                <p className="text-xs text-muted-foreground mt-2">
                  <span className="sr-only">Details: </span>
                  {stats?.todayAttendance || 0} of {stats?.expectedPresent || 0} expected employees present
                </p>
                {/* Day offs and Leave labels */}
                <div className="flex items-center gap-2 mt-2 text-[10px] text-muted-foreground">
                  {(stats?.dayOffsToday || 0) > 0 && (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800">
                      <CalendarClock className="h-3 w-3" />
                      {stats?.dayOffsToday} Day Off{(stats?.dayOffsToday || 0) > 1 ? 's' : ''}
                    </span>
                  )}
                  {(stats?.onLeaveToday || 0) > 0 && (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400">
                      <Users className="h-3 w-3" />
                      {stats?.onLeaveToday} On Leave
                    </span>
                  )}
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Estimated Payroll - Featured Card */}
        <Card className="dashboard-card col-span-2 lg:col-span-1 border-green-500/20" data-tour="stat-payroll">
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Est. Payroll
            </CardTitle>
            <div className="icon-container icon-container-sm bg-green-500/10">
              <Banknote className="h-4 w-4 text-green-500" />
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="skeleton-card">
                <Skeleton className="h-10 w-32" />
              </div>
            ) : statsError ? (
              <div className="text-sm text-destructive">Error loading</div>
            ) : (
              <>
                <div className="text-3xl font-bold text-green-600 stat-value" data-testid="stat-estimated-total-payroll">
                  {formatCurrency(stats?.estimatedTotalPayroll || 0)}
                </div>
                <div className="flex flex-col gap-1 mt-3 text-xs text-muted-foreground">
                  <div className="flex justify-between items-center">
                    <span>Basic Pay:</span>
                    <span className="font-medium">{formatCurrency(stats?.estimatedBasicPay || 0)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Approved OT:</span>
                    <span className="font-medium text-blue-600">+{formatCurrency(stats?.estimatedOTPay || 0)}</span>
                  </div>
                </div>
                {stats?.cutoffStart && stats?.cutoffEnd && (
                  <p className="text-xs text-muted-foreground mt-2 pt-2 border-t">
                    {(() => {
                      const start = new Date(stats.cutoffStart);
                      const end = new Date(stats.cutoffEnd);
                      if (isNaN(start.getTime()) || isNaN(end.getTime())) return null;
                      return `${start.toLocaleDateString('en-PH', { month: 'short', day: 'numeric' })} - ${end.toLocaleDateString('en-PH', { month: 'short', day: 'numeric' })}`;
                    })()}
                  </p>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* Total Employees */}
        <Card className="dashboard-card" data-tour="stat-total-employees">
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Employees
            </CardTitle>
            <div className="icon-container icon-container-sm bg-primary/10">
              <Users className="h-4 w-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-2xl font-bold stat-value" data-testid="stat-total-employees">
                  {stats?.totalEmployees || 0}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  <span className="text-green-600 font-medium">{stats?.activeEmployees || 0}</span> active
                </p>
              </>
            )}
          </CardContent>
        </Card>

        {/* Late Comers */}
        <Link href="/attendance?filter=late">
          <Card className={`dashboard-card clickable h-full ${(stats?.lateTodayCount || 0) > 0 ? 'alert-card alert-warning' : ''}`} data-tour="stat-late-comers">
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Late Comers
              </CardTitle>
              <div className={`icon-container icon-container-sm ${(stats?.lateTodayCount || 0) > 0 ? 'bg-red-500/10' : 'bg-green-500/10'}`}>
                <AlertTriangle className={`h-4 w-4 ${(stats?.lateTodayCount || 0) > 0 ? 'text-red-500' : 'text-green-500'}`} />
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-20" />
              ) : (
                <>
                  <div className={`text-2xl font-bold stat-value ${(stats?.lateTodayCount || 0) > 0 ? 'text-red-600' : 'text-green-600'}`} data-testid="stat-late-comers">
                    {stats?.lateTodayCount || 0}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {(stats?.lateTodayCount || 0) === 0 ? (
                      <span className="text-green-600">All on time!</span>
                    ) : (
                      "employees late today"
                    )}
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Secondary Stats - Projects, Expenses, NTEs */}
      <div className="grid gap-4 grid-cols-3" data-tour="extended-stats">
        <Card className="dashboard-card" data-tour="stat-projects">
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Active Projects
            </CardTitle>
            <div className="icon-container icon-container-sm bg-purple-500/10">
              <FolderKanban className="h-4 w-4 text-purple-500" />
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-2xl font-bold stat-value" data-testid="stat-active-projects">
                  {stats?.activeProjects || 0}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  of {stats?.totalProjects || 0} total
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Link href="/expenses?status=Pending">
          <Card className={`dashboard-card clickable h-full ${(stats?.pendingExpenses || 0) > 0 ? 'alert-card alert-warning' : ''}`}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Pending Expenses
              </CardTitle>
              <div className="icon-container icon-container-sm bg-orange-500/10">
                <Receipt className="h-4 w-4 text-orange-500" />
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-20" />
              ) : (
                <>
                  <div className={`text-2xl font-bold stat-value ${(stats?.pendingExpenses || 0) > 0 ? 'text-orange-500' : ''}`} data-testid="stat-pending-expenses">
                    {stats?.pendingExpenses || 0}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Awaiting approval
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        </Link>

        <Link href="/disciplinary?status=open">
          <Card className={`dashboard-card clickable h-full ${(stats?.openNTEs || 0) > 0 ? 'alert-card alert-danger' : ''}`}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Open NTEs
              </CardTitle>
              <div className="icon-container icon-container-sm bg-red-500/10">
                <AlertTriangle className="h-4 w-4 text-red-500" />
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-20" />
              ) : (
                <>
                  <div className={`text-2xl font-bold stat-value ${(stats?.openNTEs || 0) > 0 ? 'text-red-500' : ''}`} data-testid="stat-open-ntes">
                    {stats?.openNTEs || 0}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Disciplinary cases
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Quick Actions - Desktop */}
      <div className="hidden md:grid gap-4 md:grid-cols-3" data-tour="quick-actions">
        <Link href="/attendance">
          <Card className="dashboard-card clickable" data-testid="quick-action-view-attendance">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="icon-container icon-container-lg bg-green-500/10">
                <CalendarClock className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <h3 className="font-semibold">View Attendance</h3>
                <p className="text-sm text-muted-foreground">Monitor employee time logs</p>
              </div>
            </CardContent>
          </Card>
        </Link>

        <Link href="/employees">
          <Card className="dashboard-card clickable" data-testid="quick-action-add-employee">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="icon-container icon-container-lg bg-primary/10">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold">Manage Employees</h3>
                <p className="text-sm text-muted-foreground">View and add team members</p>
              </div>
            </CardContent>
          </Card>
        </Link>

        <Link href="/payroll">
          <Card className="dashboard-card clickable" data-testid="quick-action-process-payroll">
            <CardContent className="flex items-center gap-4 p-6">
              <div className="icon-container icon-container-lg bg-amber-500/10">
                <Banknote className="h-6 w-6 text-amber-500" />
              </div>
              <div>
                <h3 className="font-semibold">Process Payroll</h3>
                <p className="text-sm text-muted-foreground">Compute this cutoff</p>
              </div>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Daily Devotional Widget - Shows for all users */}
      <DevotionalWidget autoShow={true} />

      {/* Mobile Floating Action Bar */}
      <nav className="mobile-action-bar md:hidden" role="navigation" aria-label="Quick actions">
        <div className="flex justify-around">
          <Link href="/attendance" className="action-item" aria-label="View Attendance">
            <CalendarClock aria-hidden="true" />
            <span>Attendance</span>
          </Link>
          <Link href="/employees" className="action-item" aria-label="Manage Employees">
            <Users aria-hidden="true" />
            <span>Employees</span>
          </Link>
          <Link href="/payroll" className="action-item" aria-label="Process Payroll">
            <Banknote aria-hidden="true" />
            <span>Payroll</span>
          </Link>
          <Link href="/projects" className="action-item" aria-label="View Projects">
            <FolderKanban aria-hidden="true" />
            <span>Projects</span>
          </Link>
        </div>
      </nav>
    </div>
  );
}
