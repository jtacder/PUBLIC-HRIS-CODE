import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Calendar,
  Wallet,
  Plus,
  Clock,
  CheckCircle2,
  XCircle,
  Send,
  Loader2,
  Landmark,
  Building2,
  Banknote,
  FileText,
  UserPlus,
} from "lucide-react";
import { formatDate } from "@/lib/utils";
import type { LeaveRequest, CashAdvance, LeaveTypeRecord, Loan, LoanType } from "@shared/schema";

const leaveFormSchema = z.object({
  leaveTypeId: z.string().min(1, "Please select a leave type"),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().min(1, "End date is required"),
  totalDays: z.string().min(1, "Total days is required"),
  reason: z.string().optional(),
});

const cashAdvanceFormSchema = z.object({
  amount: z.string().min(1, "Amount is required"),
  reason: z.string().min(1, "Reason is required"),
});

const loanFormSchema = z.object({
  loanType: z.string().min(1, "Please select a loan type"),
  amount: z.string().min(1, "Amount is required"),
  reason: z.string().optional(),
});

type LeaveFormValues = z.infer<typeof leaveFormSchema>;
type CashAdvanceFormValues = z.infer<typeof cashAdvanceFormSchema>;
type LoanFormValues = z.infer<typeof loanFormSchema>;

// Loan type display helpers
const loanTypeLabels: Record<string, string> = {
  SSS_Loan: "SSS Loan",
  Pagibig_Loan: "Pag-IBIG Loan",
  Bank_Loan: "Bank Loan",
};

const loanTypeIcons: Record<string, any> = {
  SSS_Loan: Landmark,
  Pagibig_Loan: Building2,
  Bank_Loan: Banknote,
};

export default function MyRequestsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isLeaveDialogOpen, setIsLeaveDialogOpen] = useState(false);
  const [isCashAdvanceDialogOpen, setIsCashAdvanceDialogOpen] = useState(false);
  const [isLoanDialogOpen, setIsLoanDialogOpen] = useState(false);

  const { data: leaveRequests, isLoading: leaveLoading } = useQuery<LeaveRequest[]>({
    queryKey: ["/api/my/leave-requests"],
    enabled: !!user?.employeeId,
  });

  const { data: cashAdvances, isLoading: cashLoading } = useQuery<CashAdvance[]>({
    queryKey: ["/api/my/cash-advances"],
    enabled: !!user?.employeeId,
  });

  const { data: loans, isLoading: loansLoading } = useQuery<Loan[]>({
    queryKey: ["/api/my/loans"],
    enabled: !!user?.employeeId,
  });

  // Hardcoded loan types (3 preset options)
  const loanTypes = [
    { value: "SSS_Loan", label: "SSS Loan" },
    { value: "Pagibig_Loan", label: "Pag-IBIG Loan" },
    { value: "Bank_Loan", label: "Bank Loan" },
  ];

  const { data: leaveTypes } = useQuery<LeaveTypeRecord[]>({
    queryKey: ["/api/leave-types"],
  });

  // Fetch detailed leave balance by type
  const { data: leaveBalanceData } = useQuery<{
    employeeId: string;
    year: number;
    balances: Array<{
      leaveTypeId: string;
      leaveTypeName: string;
      leaveTypeCode: string;
      isPaid: boolean;
      available: number;
      effectiveAvailable: number;
      used: number;
      pending: number;
      totalAllocated: number;
      hasAllocation: boolean;
    }>;
  }>({
    queryKey: ["/api/leave-requests/balance", user?.employeeId],
    queryFn: async () => {
      if (!user?.employeeId) return null;
      const res = await apiRequest("GET", `/api/leave-requests/balance/${user.employeeId}`);
      return res.json();
    },
    enabled: !!user?.employeeId,
  });

  const leaveForm = useForm<LeaveFormValues>({
    resolver: zodResolver(leaveFormSchema),
    defaultValues: {
      leaveTypeId: "",
      startDate: "",
      endDate: "",
      totalDays: "1",
      reason: "",
    },
  });

  const cashAdvanceForm = useForm<CashAdvanceFormValues>({
    resolver: zodResolver(cashAdvanceFormSchema),
    defaultValues: {
      amount: "",
      reason: "",
    },
  });

  const loanForm = useForm<LoanFormValues>({
    resolver: zodResolver(loanFormSchema),
    defaultValues: {
      loanType: "",
      amount: "",
      reason: "",
    },
  });

  const createLeaveRequestMutation = useMutation({
    mutationFn: async (data: LeaveFormValues) => {
      const response = await apiRequest("POST", "/api/my/leave-requests", data);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to submit leave request");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my/leave-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/leave-requests/balance", user?.employeeId] });
      queryClient.invalidateQueries({ queryKey: ["/api/leave-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsLeaveDialogOpen(false);
      leaveForm.reset();
      toast({
        title: "Leave Request Submitted",
        description: "Your leave request has been submitted for approval.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit leave request.",
        variant: "destructive",
      });
    },
  });

  const createCashAdvanceMutation = useMutation({
    mutationFn: async (data: CashAdvanceFormValues) => {
      const response = await apiRequest("POST", "/api/my/cash-advances", {
        amount: data.amount,
        reason: data.reason,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my/cash-advances"] });
      queryClient.invalidateQueries({ queryKey: ["/api/cash-advances"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsCashAdvanceDialogOpen(false);
      cashAdvanceForm.reset();
      toast({
        title: "Cash Advance Request Submitted",
        description: "Your cash advance request has been submitted for approval.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit cash advance request.",
        variant: "destructive",
      });
    },
  });

  const createLoanMutation = useMutation({
    mutationFn: async (data: LoanFormValues) => {
      const response = await apiRequest("POST", "/api/my/loans", {
        loanType: data.loanType,
        amount: data.amount,
        reason: data.reason,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my/loans"] });
      queryClient.invalidateQueries({ queryKey: ["/api/loans"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsLoanDialogOpen(false);
      loanForm.reset();
      toast({
        title: "Loan Request Submitted",
        description: "Your loan request has been submitted for approval.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit loan request.",
        variant: "destructive",
      });
    },
  });

  const getLeaveTypeName = (typeId: string) => {
    return leaveTypes?.find(t => t.id === typeId)?.name || "Unknown";
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Approved":
        return <Badge variant="default">Approved</Badge>;
      case "Rejected":
        return <Badge variant="destructive">Rejected</Badge>;
      case "Pending":
        return <Badge variant="secondary">Pending</Badge>;
      case "Disbursed":
        return <Badge variant="default">Disbursed</Badge>;
      case "Fully_Paid":
        return <Badge variant="outline">Fully Paid</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatCurrency = (amount: string | number | null | undefined) => {
    const value = typeof amount === "string" ? parseFloat(amount) : amount || 0;
    return new Intl.NumberFormat('en-PH', {
      style: 'currency',
      currency: 'PHP',
      minimumFractionDigits: 2
    }).format(value);
  };

  const calculateDays = (start: string, end: string) => {
    if (!start || !end) return;
    const startDate = new Date(start);
    const endDate = new Date(end);
    const diffTime = Math.abs(endDate.getTime() - startDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    leaveForm.setValue("totalDays", diffDays.toString());
  };

  if (leaveLoading || cashLoading || loansLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-20" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">My Requests</h1>
          <p className="text-muted-foreground">Submit and track leave requests, cash advances, and loans</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{leaveBalance?.remaining ?? 0}</p>
                <p className="text-sm text-muted-foreground">Leave Days Remaining</p>
              </div>
              <Calendar className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">
                  {leaveRequests?.filter(r => r.status === "Pending").length ?? 0}
                </p>
                <p className="text-sm text-muted-foreground">Pending Leave Requests</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">
                  {cashAdvances?.filter(c => c.status === "Pending").length ?? 0}
                </p>
                <p className="text-sm text-muted-foreground">Pending Cash Advances</p>
              </div>
              <Wallet className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">
                  {loans?.filter(l => l.status === "Pending").length ?? 0}
                </p>
                <p className="text-sm text-muted-foreground">Pending Loans</p>
              </div>
              <Landmark className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="leave" className="space-y-4">
        <TabsList>
          <TabsTrigger value="leave" data-testid="tab-leave">
            <Calendar className="h-4 w-4 mr-2" />
            Leave Requests
          </TabsTrigger>
          <TabsTrigger value="cash-advance" data-testid="tab-cash-advance">
            <Wallet className="h-4 w-4 mr-2" />
            Cash Advances
          </TabsTrigger>
          <TabsTrigger value="loans" data-testid="tab-loans">
            <Landmark className="h-4 w-4 mr-2" />
            Loans
          </TabsTrigger>
        </TabsList>

        <TabsContent value="leave" className="space-y-4">
          <div className="flex justify-end">
            <Button onClick={() => setIsLeaveDialogOpen(true)} data-testid="button-new-leave">
              <Plus className="h-4 w-4 mr-2" />
              Request Leave
            </Button>
          </div>

          {leaveRequests && leaveRequests.length > 0 ? (
            <div className="space-y-4">
              {leaveRequests.map((request) => {
                const isSubmittedByHR = (request as any).submittedById && (request as any).submittedById !== request.employeeId;
                return (
                <Card key={request.id} data-testid={`card-leave-${request.id}`}>
                  <CardContent className="pt-6">
                    <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">{getLeaveTypeName(request.leaveTypeId)}</h3>
                          {getStatusBadge(request.status)}
                          {isSubmittedByHR && (
                            <Badge variant="outline" className="text-blue-600 border-blue-300 flex items-center gap-1">
                              <UserPlus className="h-3 w-3" />
                              Filed by HR
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {formatDate(request.startDate)} - {formatDate(request.endDate)} ({request.totalDays} days)
                        </p>
                        {request.reason && (
                          <p className="text-sm text-muted-foreground">{request.reason}</p>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Submitted: {request.createdAt ? formatDate(request.createdAt) : "N/A"}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
              })}
            </div>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <Calendar className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="font-medium text-lg mb-2">No Leave Requests</h3>
                <p className="text-muted-foreground mb-4">
                  You haven't submitted any leave requests yet.
                </p>
                <Button onClick={() => setIsLeaveDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Request Leave
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="cash-advance" className="space-y-4">
          <div className="flex justify-end">
            <Button onClick={() => setIsCashAdvanceDialogOpen(true)} data-testid="button-new-cash-advance">
              <Plus className="h-4 w-4 mr-2" />
              Request Cash Advance
            </Button>
          </div>

          {cashAdvances && cashAdvances.length > 0 ? (
            <div className="space-y-4">
              {cashAdvances.map((advance) => {
                const isSubmittedByHR = (advance as any).submittedById && (advance as any).submittedById !== advance.employeeId;
                return (
                <Card key={advance.id} data-testid={`card-cash-advance-${advance.id}`}>
                  <CardContent className="pt-6">
                    <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-lg">
                            {formatCurrency(advance.amount)}
                          </h3>
                          {getStatusBadge(advance.status)}
                          {isSubmittedByHR && (
                            <Badge variant="outline" className="text-blue-600 border-blue-300 flex items-center gap-1">
                              <UserPlus className="h-3 w-3" />
                              Filed by HR
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{advance.reason}</p>
                        {advance.remainingBalance && parseFloat(advance.remainingBalance) > 0 && (
                          <p className="text-sm">
                            Remaining: <span className="font-medium">{formatCurrency(advance.remainingBalance)}</span>
                          </p>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Submitted: {advance.createdAt ? formatDate(advance.createdAt) : "N/A"}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
              })}
            </div>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <Wallet className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="font-medium text-lg mb-2">No Cash Advances</h3>
                <p className="text-muted-foreground mb-4">
                  You haven't requested any cash advances yet.
                </p>
                <Button onClick={() => setIsCashAdvanceDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Request Cash Advance
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="loans" className="space-y-4">
          <div className="flex justify-end">
            <Button onClick={() => setIsLoanDialogOpen(true)} data-testid="button-new-loan">
              <Plus className="h-4 w-4 mr-2" />
              Request Loan
            </Button>
          </div>

          {loans && loans.length > 0 ? (
            <div className="space-y-4">
              {loans.map((loan) => {
                const LoanIcon = loanTypeIcons[loan.loanType] || FileText;
                const isSubmittedByHR = (loan as any).submittedById && (loan as any).submittedById !== loan.employeeId;
                return (
                  <Card key={loan.id} data-testid={`card-loan-${loan.id}`}>
                    <CardContent className="pt-6">
                      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <LoanIcon className="h-5 w-5 text-muted-foreground" />
                            <h3 className="font-semibold">
                              {loanTypeLabels[loan.loanType] || loan.loanType}
                            </h3>
                            {getStatusBadge(loan.status)}
                            {isSubmittedByHR && (
                              <Badge variant="outline" className="text-blue-600 border-blue-300 flex items-center gap-1">
                                <UserPlus className="h-3 w-3" />
                                Filed by HR
                              </Badge>
                            )}
                          </div>
                          <p className="text-lg font-semibold">
                            {formatCurrency(loan.totalAmount || loan.amount)}
                            {loan.interest && parseFloat(loan.interest) > 0 && (
                              <span className="text-sm font-normal text-muted-foreground ml-2">
                                (includes {formatCurrency(loan.interest)} interest)
                              </span>
                            )}
                          </p>
                          {loan.reason && (
                            <p className="text-sm text-muted-foreground">{loan.reason}</p>
                          )}
                          {loan.remainingBalance && parseFloat(loan.remainingBalance) > 0 && loan.status === "Disbursed" && (
                            <p className="text-sm">
                              Remaining: <span className="font-medium">{formatCurrency(loan.remainingBalance)}</span>
                              {loan.deductionPerCutoff && (
                                <span className="text-muted-foreground ml-2">
                                  ({formatCurrency(loan.deductionPerCutoff)}/cutoff)
                                </span>
                              )}
                            </p>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Submitted: {loan.createdAt ? formatDate(loan.createdAt) : "N/A"}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <Landmark className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="font-medium text-lg mb-2">No Loans</h3>
                <p className="text-muted-foreground mb-4">
                  You haven't requested any loans yet.
                </p>
                <Button onClick={() => setIsLoanDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Request Loan
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={isLeaveDialogOpen} onOpenChange={setIsLeaveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Request Leave
            </DialogTitle>
          </DialogHeader>
          <Form {...leaveForm}>
            <form onSubmit={leaveForm.handleSubmit((data) => createLeaveRequestMutation.mutate(data))} className="space-y-4">
              <FormField
                control={leaveForm.control}
                name="leaveTypeId"
                render={({ field }) => {
                  const selectedBalance = leaveBalanceData?.balances.find(b => b.leaveTypeId === field.value);
                  const requestedDays = parseFloat(leaveForm.watch("totalDays") || "0");
                  const isInsufficientBalance = selectedBalance && requestedDays > selectedBalance.effectiveAvailable;
                  const unpaidDays = isInsufficientBalance ? requestedDays - selectedBalance.effectiveAvailable : 0;
                  const paidDays = isInsufficientBalance ? selectedBalance.effectiveAvailable : requestedDays;

                  return (
                    <FormItem>
                      <FormLabel>Leave Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-leave-type">
                            <SelectValue placeholder="Select leave type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {leaveTypes?.map((type) => {
                            const balance = leaveBalanceData?.balances.find(b => b.leaveTypeId === type.id);
                            return (
                              <SelectItem key={type.id} value={type.id}>
                                {type.name} {balance ? `(${balance.effectiveAvailable} days available)` : ""}
                              </SelectItem>
                            );
                          })}
                        </SelectContent>
                      </Select>

                      {/* Leave Balance Display */}
                      {field.value && selectedBalance && (
                        <div className="mt-2 p-3 bg-muted rounded-lg text-sm">
                          <div className="font-medium mb-1">Your {selectedBalance.leaveTypeName} Balance:</div>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <span>Total Allocated:</span>
                            <span className="font-medium">{selectedBalance.totalAllocated} days</span>
                            <span>Used:</span>
                            <span className="font-medium">{selectedBalance.used} days</span>
                            {selectedBalance.pending > 0 && (
                              <>
                                <span>Pending Requests:</span>
                                <span className="font-medium text-yellow-600">{selectedBalance.pending} days</span>
                              </>
                            )}
                            <span>Available:</span>
                            <span className="font-medium text-green-600">{selectedBalance.effectiveAvailable} days</span>
                          </div>

                          {/* Warning when requesting more than available */}
                          {isInsufficientBalance && requestedDays > 0 && (
                            <div className="mt-2 p-2 bg-orange-50 dark:bg-orange-950 border border-orange-200 dark:border-orange-800 rounded text-orange-700 dark:text-orange-300">
                              <p className="font-medium text-xs">Insufficient Leave Balance</p>
                              <p className="text-xs mt-1">
                                You're requesting {requestedDays} days but only have {selectedBalance.effectiveAvailable} days available.
                              </p>
                              <p className="text-xs mt-1">
                                <span className="text-green-600 font-medium">{Math.max(0, paidDays).toFixed(1)} days paid</span>
                                {" + "}
                                <span className="text-orange-600 font-medium">{unpaidDays.toFixed(1)} days unpaid</span>
                              </p>
                            </div>
                          )}

                          {!selectedBalance.hasAllocation && (
                            <div className="mt-2 p-2 bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded text-yellow-700 dark:text-yellow-300 text-xs">
                              No allocation found for this leave type. All days will be unpaid.
                            </div>
                          )}
                        </div>
                      )}

                      <FormMessage />
                    </FormItem>
                  );
                }}
              />
              <div className="grid gap-4 grid-cols-2">
                <FormField
                  control={leaveForm.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Date</FormLabel>
                      <FormControl>
                        <Input 
                          type="date" 
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            calculateDays(e.target.value, leaveForm.getValues("endDate"));
                          }}
                          data-testid="input-start-date"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={leaveForm.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Date</FormLabel>
                      <FormControl>
                        <Input 
                          type="date" 
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            calculateDays(leaveForm.getValues("startDate"), e.target.value);
                          }}
                          data-testid="input-end-date"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={leaveForm.control}
                name="totalDays"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Total Days</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.5" {...field} data-testid="input-total-days" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={leaveForm.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason (Optional)</FormLabel>
                    <FormControl>
                      <Textarea {...field} placeholder="Reason for leave" data-testid="input-leave-reason" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsLeaveDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createLeaveRequestMutation.isPending} data-testid="button-submit-leave">
                  {createLeaveRequestMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4 mr-2" />
                  )}
                  Submit Request
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={isCashAdvanceDialogOpen} onOpenChange={setIsCashAdvanceDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Wallet className="h-5 w-5" />
              Request Cash Advance
            </DialogTitle>
          </DialogHeader>
          <Form {...cashAdvanceForm}>
            <form onSubmit={cashAdvanceForm.handleSubmit((data) => createCashAdvanceMutation.mutate(data))} className="space-y-4">
              <FormField
                control={cashAdvanceForm.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (PHP)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.01" 
                        placeholder="5000.00" 
                        {...field} 
                        data-testid="input-cash-amount"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={cashAdvanceForm.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder="Please provide a reason for your cash advance request"
                        data-testid="input-cash-reason"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsCashAdvanceDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createCashAdvanceMutation.isPending} data-testid="button-submit-cash-advance">
                  {createCashAdvanceMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4 mr-2" />
                  )}
                  Submit Request
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={isLoanDialogOpen} onOpenChange={setIsLoanDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Landmark className="h-5 w-5" />
              Request Loan
            </DialogTitle>
          </DialogHeader>
          <Form {...loanForm}>
            <form onSubmit={loanForm.handleSubmit((data) => createLoanMutation.mutate(data))} className="space-y-4">
              <FormField
                control={loanForm.control}
                name="loanType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Loan Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-loan-type">
                          <SelectValue placeholder="Select loan type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {loanTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={loanForm.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (PHP)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="10000.00"
                        {...field}
                        data-testid="input-loan-amount"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={loanForm.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Purpose/Reason (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Please provide the purpose for your loan request"
                        data-testid="input-loan-reason"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsLoanDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createLoanMutation.isPending} data-testid="button-submit-loan">
                  {createLoanMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4 mr-2" />
                  )}
                  Submit Request
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
