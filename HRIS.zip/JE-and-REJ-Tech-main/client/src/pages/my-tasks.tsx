import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { getPhotoDisplayUrl } from "@/lib/photo-url";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  CheckSquare,
  Clock,
  AlertTriangle,
  Circle,
  CheckCircle2,
  XCircle,
  Loader2,
  MessageSquare,
  Send,
  Eye,
  Paperclip,
  Image as ImageIcon,
} from "lucide-react";
import { formatDate } from "@/lib/utils";
import type { Task, Project, TaskComment, Employee } from "@shared/schema";

/**
 * Parse stored photo URLs - handles single URL, JSON array, or already parsed array
 */
function parsePhotoUrls(value: string | null | undefined): string[] {
  if (!value) return [];
  // If it's already a JSON array
  if (value.startsWith("[")) {
    try {
      return JSON.parse(value);
    } catch {
      return [value];
    }
  }
  // Single URL
  return [value];
}

interface TaskWithComments extends Task {
  comments?: TaskComment[];
}

const statusIcons = {
  Todo: Circle,
  In_Progress: Clock,
  Blocked: XCircle,
  Done: CheckCircle2,
};

const statusColors = {
  Todo: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200",
  In_Progress: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  Blocked: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  Done: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
};

const priorityColors = {
  Low: "secondary",
  Medium: "outline",
  High: "default",
  Critical: "destructive",
} as const;

export default function MyTasksPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [filter, setFilter] = useState<string>("all");
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isTaskDialogOpen, setIsTaskDialogOpen] = useState(false);
  const [newComment, setNewComment] = useState("");
  const [commentAttachment, setCommentAttachment] = useState<string | null>(null);
  const [viewingPhoto, setViewingPhoto] = useState<string | null>(null);

  const { data: myTasks, isLoading } = useQuery<Task[]>({
    queryKey: ["/api/my/tasks"],
    enabled: !!user?.employeeId,
  });

  const { data: projects } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: employees } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  // Fetch task details with comments when a task is selected
  const { data: taskDetails, isLoading: taskDetailsLoading } = useQuery<TaskWithComments>({
    queryKey: ["/api/tasks", selectedTask?.id],
    enabled: !!selectedTask?.id && isTaskDialogOpen,
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const response = await apiRequest("PATCH", `/api/tasks/${id}`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/my/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", selectedTask?.id] });
      toast({
        title: "Task Updated",
        description: "Task status has been updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update task.",
        variant: "destructive",
      });
    },
  });

  const addCommentMutation = useMutation({
    mutationFn: async ({ taskId, content, attachmentUrl }: { taskId: string; content: string; attachmentUrl?: string }) => {
      const response = await apiRequest("POST", `/api/tasks/${taskId}/comments`, {
        content,
        authorId: user?.employeeId,
        attachmentUrl,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", selectedTask?.id] });
      setNewComment("");
      setCommentAttachment(null);
      toast({
        title: "Comment Added",
        description: "Your comment has been posted.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add comment.",
        variant: "destructive",
      });
    },
  });

  const handleViewTask = (task: Task) => {
    setSelectedTask(task);
    setIsTaskDialogOpen(true);
  };

  const handleAddComment = () => {
    if (!selectedTask || (!newComment.trim() && !commentAttachment)) return;
    addCommentMutation.mutate({
      taskId: selectedTask.id,
      content: newComment.trim() || "Photo attachment",
      attachmentUrl: commentAttachment || undefined,
    });
  };

  const getEmployeeName = (employeeId: string | null) => {
    if (!employeeId) return "Unknown";
    const employee = employees?.find(e => e.id === employeeId);
    return employee ? `${employee.firstName} ${employee.lastName}` : "Unknown";
  };

  const getEmployeeInitials = (employeeId: string | null) => {
    if (!employeeId) return "?";
    const employee = employees?.find(e => e.id === employeeId);
    if (!employee) return "?";
    return `${employee.firstName?.[0] || ""}${employee.lastName?.[0] || ""}`;
  };

  const getProjectName = (projectId: string | null) => {
    if (!projectId) return "No Project";
    return projects?.find(p => p.id === projectId)?.name || "Unknown Project";
  };

  const filteredTasks = myTasks?.filter(task => {
    if (filter === "all") return true;
    return task.status === filter;
  }) || [];

  const todoCount = myTasks?.filter(t => t.status === "Todo").length || 0;
  const inProgressCount = myTasks?.filter(t => t.status === "In_Progress").length || 0;
  const blockedCount = myTasks?.filter(t => t.status === "Blocked").length || 0;
  const doneCount = myTasks?.filter(t => t.status === "Done").length || 0;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">My Tasks</h1>
        <p className="text-muted-foreground">Tasks assigned to you</p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card 
          className={`cursor-pointer transition-all ${filter === "Todo" ? "ring-2 ring-primary" : "hover-elevate"}`}
          onClick={() => setFilter(filter === "Todo" ? "all" : "Todo")}
        >
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{todoCount}</p>
                <p className="text-sm text-muted-foreground">To Do</p>
              </div>
              <Circle className="h-8 w-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>
        <Card 
          className={`cursor-pointer transition-all ${filter === "In_Progress" ? "ring-2 ring-primary" : "hover-elevate"}`}
          onClick={() => setFilter(filter === "In_Progress" ? "all" : "In_Progress")}
        >
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{inProgressCount}</p>
                <p className="text-sm text-muted-foreground">In Progress</p>
              </div>
              <Clock className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card 
          className={`cursor-pointer transition-all ${filter === "Blocked" ? "ring-2 ring-primary" : "hover-elevate"}`}
          onClick={() => setFilter(filter === "Blocked" ? "all" : "Blocked")}
        >
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{blockedCount}</p>
                <p className="text-sm text-muted-foreground">Blocked</p>
              </div>
              <XCircle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        <Card 
          className={`cursor-pointer transition-all ${filter === "Done" ? "ring-2 ring-primary" : "hover-elevate"}`}
          onClick={() => setFilter(filter === "Done" ? "all" : "Done")}
        >
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{doneCount}</p>
                <p className="text-sm text-muted-foreground">Done</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">
          {filter === "all" ? "All Tasks" : filter.replace("_", " ")} ({filteredTasks.length})
        </h2>
        {filter !== "all" && (
          <Button variant="ghost" size="sm" onClick={() => setFilter("all")}>
            Show All
          </Button>
        )}
      </div>

      {filteredTasks.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <CheckSquare className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="font-medium text-lg mb-2">No Tasks</h3>
            <p className="text-muted-foreground">
              {filter === "all" 
                ? "You don't have any tasks assigned yet."
                : `No ${filter.replace("_", " ").toLowerCase()} tasks.`}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredTasks.map((task) => {
            const StatusIcon = statusIcons[task.status as keyof typeof statusIcons] || Circle;
            return (
              <Card key={task.id} data-testid={`card-task-${task.id}`}>
                <CardContent className="pt-6">
                  <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-3">
                        <StatusIcon className={`h-5 w-5 ${
                          task.status === "Done" ? "text-green-500" :
                          task.status === "In_Progress" ? "text-blue-500" :
                          task.status === "Blocked" ? "text-red-500" : "text-gray-400"
                        }`} />
                        <h3 className="font-semibold text-lg">{task.title}</h3>
                        <Badge variant={priorityColors[task.priority as keyof typeof priorityColors] || "secondary"}>
                          {task.priority}
                        </Badge>
                      </div>
                      {task.description && (
                        <p className="text-muted-foreground">{task.description}</p>
                      )}
                      <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <CheckSquare className="h-4 w-4" />
                          {getProjectName(task.projectId)}
                        </span>
                        {task.dueDate && (
                          <span className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            Due: {formatDate(task.dueDate)}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewTask(task)}
                        data-testid={`button-view-task-${task.id}`}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        Details
                      </Button>
                      <Select
                        value={task.status}
                        onValueChange={(value) => {
                          updateTaskMutation.mutate({ id: task.id, status: value });
                        }}
                        disabled={updateTaskMutation.isPending}
                      >
                        <SelectTrigger className="w-[140px]" data-testid={`select-status-${task.id}`}>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Todo">To Do</SelectItem>
                          <SelectItem value="In_Progress">In Progress</SelectItem>
                          <SelectItem value="Blocked">Blocked</SelectItem>
                          <SelectItem value="Done">Done</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Task Details Dialog */}
      <Dialog open={isTaskDialogOpen} onOpenChange={setIsTaskDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <CheckSquare className="h-5 w-5" />
              Task Details
            </DialogTitle>
            <DialogDescription>
              View task information and comments
            </DialogDescription>
          </DialogHeader>
          {selectedTask && (
            <>
              {/* Scrollable content area */}
              <div className="flex-1 overflow-y-auto space-y-4 py-2 pr-2">
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-lg">{selectedTask.title}</h3>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant={priorityColors[selectedTask.priority as keyof typeof priorityColors] || "secondary"}>
                        {selectedTask.priority}
                      </Badge>
                      <Badge variant="outline">{selectedTask.status.replace("_", " ")}</Badge>
                    </div>
                  </div>

                  {selectedTask.description && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground mb-1">Description</p>
                      <p className="text-sm">{selectedTask.description}</p>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="font-medium text-muted-foreground">Project</p>
                      <p>{getProjectName(selectedTask.projectId)}</p>
                    </div>
                    {selectedTask.dueDate && (
                      <div>
                        <p className="font-medium text-muted-foreground">Due Date</p>
                        <p>{formatDate(selectedTask.dueDate)}</p>
                      </div>
                    )}
                  </div>

                  {/* Task Photos */}
                  {taskDetails?.completionPhotoUrl && parsePhotoUrls(taskDetails.completionPhotoUrl).length > 0 && (
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <ImageIcon className="h-4 w-4" />
                        <span className="text-sm font-medium">Task Photos</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {parsePhotoUrls(taskDetails.completionPhotoUrl).map((url, idx) => (
                          <button
                            key={idx}
                            onClick={() => setViewingPhoto(getPhotoDisplayUrl(url))}
                            className="w-16 h-16 rounded-lg overflow-hidden border hover:border-primary transition-colors"
                          >
                            <img
                              src={getPhotoDisplayUrl(url) || ""}
                              alt={`Task photo ${idx + 1}`}
                              className="w-full h-full object-cover"
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <Separator />

                {/* Comments Section */}
                <div>
                  <h4 className="font-semibold flex items-center gap-2 mb-3">
                    <MessageSquare className="h-4 w-4" />
                    Comments ({taskDetails?.comments?.length || 0})
                  </h4>

                  {taskDetailsLoading ? (
                    <div className="space-y-3">
                      {[...Array(2)].map((_, i) => (
                        <Skeleton key={i} className="h-16" />
                      ))}
                    </div>
                  ) : taskDetails?.comments && taskDetails.comments.length > 0 ? (
                    <div className="space-y-3">
                      {taskDetails.comments.map((comment) => (
                        <div
                          key={comment.id}
                          className="flex gap-3 p-3 rounded-lg bg-muted/50"
                          data-testid={`comment-${comment.id}`}
                        >
                          <Avatar className="h-8 w-8 flex-shrink-0">
                            <AvatarFallback className="text-xs">
                              {getEmployeeInitials(comment.authorId)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                              <span className="text-sm font-medium">
                                {getEmployeeName(comment.authorId)}
                              </span>
                              <span className="text-xs text-muted-foreground">
                                {comment.createdAt ? formatDate(comment.createdAt) : ""}
                              </span>
                            </div>
                            <p className="text-sm break-words">{comment.content}</p>
                            {/* Comment Photo Attachments */}
                            {comment.attachmentUrl && parsePhotoUrls(comment.attachmentUrl).length > 0 && (
                              <div className="flex flex-wrap gap-2 mt-2">
                                {parsePhotoUrls(comment.attachmentUrl).map((url, idx) => (
                                  <button
                                    key={idx}
                                    onClick={() => setViewingPhoto(getPhotoDisplayUrl(url))}
                                    className="w-16 h-16 rounded-lg overflow-hidden border hover:border-primary transition-colors"
                                  >
                                    <img
                                      src={getPhotoDisplayUrl(url) || ""}
                                      alt={`Attachment ${idx + 1}`}
                                      className="w-full h-full object-cover"
                                    />
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-muted-foreground">
                      <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">No comments yet</p>
                      <p className="text-xs">Be the first to comment!</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Fixed Add Comment Form */}
              <div className="flex-shrink-0 pt-4 border-t space-y-3">
                {/* Comment Attachment Preview */}
                {commentAttachment && (
                  <div className="relative inline-block">
                    <img
                      src={commentAttachment}
                      alt="Attachment preview"
                      className="w-16 h-16 rounded object-cover border"
                    />
                    <button
                      onClick={() => setCommentAttachment(null)}
                      className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 text-xs"
                    >
                      ×
                    </button>
                  </div>
                )}
                <div className="flex gap-2">
                  <div className="flex-1 relative">
                    <Textarea
                      placeholder="Add a comment..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      className="min-h-[60px] resize-none pr-10"
                      data-testid="input-new-comment"
                    />
                    {/* Attachment button */}
                    <label className="absolute right-2 bottom-2 cursor-pointer text-muted-foreground hover:text-foreground transition-colors">
                      <Paperclip className="h-5 w-5" />
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        className="hidden"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = (ev) => {
                              setCommentAttachment(ev.target?.result as string);
                            };
                            reader.readAsDataURL(file);
                          }
                          e.target.value = "";
                        }}
                      />
                    </label>
                  </div>
                  <Button
                    size="icon"
                    onClick={handleAddComment}
                    disabled={(!newComment.trim() && !commentAttachment) || addCommentMutation.isPending}
                    data-testid="button-submit-comment"
                  >
                    {addCommentMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            </>
          )}
          <DialogFooter className="flex-shrink-0 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsTaskDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Photo Viewer Dialog */}
      <Dialog open={!!viewingPhoto} onOpenChange={() => setViewingPhoto(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] p-0 overflow-hidden">
          <DialogHeader className="p-4 pb-0">
            <DialogTitle>Photo</DialogTitle>
          </DialogHeader>
          <div className="p-4 flex items-center justify-center overflow-auto">
            {viewingPhoto && (
              <img
                src={viewingPhoto}
                alt="Full size"
                className="max-w-full max-h-[70vh] object-contain rounded-lg"
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
