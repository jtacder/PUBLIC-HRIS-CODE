import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation, useSearch } from "wouter";
import { Eye, EyeOff, Lock, CheckCircle, XCircle, Loader2, Zap, ArrowLeft } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { AnimatedBackground } from "@/components/background/AnimatedBackground";

const resetPasswordSchema = z.object({
  newPassword: z.string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[a-z]/, "Password must contain at least one lowercase letter")
    .regex(/[0-9]/, "Password must contain at least one number"),
  confirmPassword: z.string(),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type ResetPasswordForm = z.infer<typeof resetPasswordSchema>;

export default function ResetPasswordPage() {
  const [, navigate] = useLocation();
  const searchString = useSearch();
  const { toast } = useToast();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  // Extract token from URL query params
  const params = new URLSearchParams(searchString);
  const token = params.get("token");

  // Verify token on mount
  const { data: tokenData, isLoading: isVerifying, error: verifyError } = useQuery({
    queryKey: ["verify-reset-token", token],
    queryFn: async () => {
      if (!token) throw new Error("No reset token provided");
      const response = await fetch(`/api/auth/verify-reset-token/${token}`);
      const data = await response.json();
      if (!response.ok || !data.valid) {
        throw new Error(data.message || "Invalid or expired reset token");
      }
      return data;
    },
    enabled: !!token,
    retry: false,
  });

  const form = useForm<ResetPasswordForm>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      newPassword: "",
      confirmPassword: "",
    },
  });

  const resetMutation = useMutation({
    mutationFn: async (data: ResetPasswordForm) => {
      const response = await apiRequest("POST", "/api/auth/reset-password", {
        token,
        newPassword: data.newPassword,
      });
      return response.json();
    },
    onSuccess: () => {
      setResetSuccess(true);
      toast({
        title: "Password Reset Successful",
        description: "Your password has been reset. You can now log in with your new password.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Reset Failed",
        description: error.message || "Failed to reset password. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ResetPasswordForm) => {
    resetMutation.mutate(data);
  };

  const isTokenValid = tokenData?.valid && !verifyError;
  const isTokenInvalid = (!token || verifyError) && !isVerifying;

  return (
    <div className="relative min-h-screen flex flex-col overflow-hidden">
      {/* Background */}
      <AnimatedBackground variant="electrical" />

      {/* Main Container */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4">
        {/* Card */}
        <div
          className="w-full max-w-md relative overflow-hidden rounded-2xl p-6 md:p-8 shadow-2xl"
          style={{
            background: "rgba(13, 13, 20, 0.92)",
            backdropFilter: "blur(24px) saturate(1.2)",
            WebkitBackdropFilter: "blur(24px) saturate(1.2)",
            border: "1px solid rgba(0, 168, 255, 0.15)",
            boxShadow: `
              0 0 0 1px rgba(0, 168, 255, 0.08),
              0 8px 32px rgba(0, 0, 0, 0.4),
              0 0 80px rgba(0, 168, 255, 0.08),
              inset 0 1px 0 rgba(255, 255, 255, 0.05)
            `,
          }}
        >
          {/* Top gradient border */}
          <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#00a8ff] to-transparent opacity-60" />
          <div className="absolute top-[2px] left-1/4 right-1/4 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

          {/* Loading State */}
          {isVerifying && (
            <div className="text-center py-8">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[#00a8ff]/10 border border-[#00a8ff]/30 flex items-center justify-center">
                <Loader2 className="w-8 h-8 text-[#00a8ff] animate-spin" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                Verifying Link
              </h3>
              <p className="text-white/60 text-sm">Please wait while we verify your reset link...</p>
            </div>
          )}

          {/* Invalid Token State */}
          {isTokenInvalid && (
            <div className="text-center py-8">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[#ff3355]/10 border border-[#ff3355]/30 flex items-center justify-center">
                <XCircle className="w-8 h-8 text-[#ff3355]" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                Invalid or Expired Link
              </h3>
              <p className="text-white/60 text-sm mb-6">
                {!token
                  ? "No reset token was provided. Please request a new password reset link."
                  : "This password reset link is invalid or has expired. Please request a new one."}
              </p>
              <Button
                onClick={() => navigate("/login")}
                className="w-full py-4 bg-gradient-to-r from-[#00a8ff] to-[#0052cc] hover:from-[#0080ff] hover:to-[#0052cc] text-white font-semibold tracking-widest uppercase rounded-xl"
                style={{ fontFamily: "'Orbitron', sans-serif" }}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Login
              </Button>
            </div>
          )}

          {/* Success State */}
          {resetSuccess && (
            <div className="text-center py-8">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                Password Reset Complete
              </h3>
              <p className="text-white/60 text-sm mb-6">
                Your password has been successfully reset. You can now log in with your new password.
              </p>
              <Button
                onClick={() => navigate("/login")}
                className="w-full py-4 bg-gradient-to-r from-[#00a8ff] to-[#0052cc] hover:from-[#0080ff] hover:to-[#0052cc] text-white font-semibold tracking-widest uppercase rounded-xl"
                style={{ fontFamily: "'Orbitron', sans-serif" }}
              >
                Go to Login
              </Button>
            </div>
          )}

          {/* Reset Form */}
          {isTokenValid && !resetSuccess && (
            <>
              <div className="text-center mb-8">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-[#00a8ff]/15 to-[#00a8ff]/5 border border-[#00a8ff]/20 flex items-center justify-center">
                  <Lock className="w-8 h-8 text-[#00a8ff]" />
                </div>
                <h3 className="text-xl font-bold bg-gradient-to-r from-white to-[#00a8ff] bg-clip-text text-transparent" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                  Create New Password
                </h3>
                <p className="text-sm text-white/50 mt-1">Enter your new password below</p>
              </div>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                  <FormField
                    control={form.control}
                    name="newPassword"
                    render={({ field }) => (
                      <FormItem>
                        <label className="block text-xs text-white/70 uppercase tracking-wider font-semibold mb-2">
                          New Password
                        </label>
                        <FormControl>
                          <div className="relative group">
                            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#4a4a5a] group-focus-within:text-[#00a8ff] transition-colors" />
                            <Input
                              type={showPassword ? "text" : "password"}
                              placeholder="Enter new password"
                              className="w-full pl-12 pr-12 py-4 bg-white/5 border border-[#2d2d3a] rounded-xl text-white placeholder:text-white/40 focus:border-[#00a8ff] focus:bg-[#00a8ff]/5 focus:ring-2 focus:ring-[#00a8ff]/20 transition-all"
                              {...field}
                            />
                            <button
                              type="button"
                              onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-4 top-1/2 -translate-y-1/2 text-[#4a4a5a] hover:text-[#00a8ff] transition-colors"
                            >
                              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                            </button>
                          </div>
                        </FormControl>
                        <FormMessage className="text-[#ff3355]" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <label className="block text-xs text-white/70 uppercase tracking-wider font-semibold mb-2">
                          Confirm Password
                        </label>
                        <FormControl>
                          <div className="relative group">
                            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#4a4a5a] group-focus-within:text-[#00a8ff] transition-colors" />
                            <Input
                              type={showConfirmPassword ? "text" : "password"}
                              placeholder="Confirm new password"
                              className="w-full pl-12 pr-12 py-4 bg-white/5 border border-[#2d2d3a] rounded-xl text-white placeholder:text-white/40 focus:border-[#00a8ff] focus:bg-[#00a8ff]/5 focus:ring-2 focus:ring-[#00a8ff]/20 transition-all"
                              {...field}
                            />
                            <button
                              type="button"
                              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                              className="absolute right-4 top-1/2 -translate-y-1/2 text-[#4a4a5a] hover:text-[#00a8ff] transition-colors"
                            >
                              {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                            </button>
                          </div>
                        </FormControl>
                        <FormMessage className="text-[#ff3355]" />
                      </FormItem>
                    )}
                  />

                  {/* Password Requirements */}
                  <div className="text-xs text-white/50 space-y-1">
                    <p className="font-semibold text-white/70">Password requirements:</p>
                    <ul className="list-disc list-inside space-y-0.5 ml-1">
                      <li>At least 8 characters</li>
                      <li>One uppercase letter</li>
                      <li>One lowercase letter</li>
                      <li>One number</li>
                    </ul>
                  </div>

                  <Button
                    type="submit"
                    disabled={resetMutation.isPending}
                    className="w-full py-5 bg-gradient-to-r from-[#00a8ff] to-[#0052cc] hover:from-[#0080ff] hover:to-[#0052cc] text-white font-semibold tracking-widest uppercase rounded-xl shadow-lg shadow-[#00a8ff]/30 hover:shadow-[#00a8ff]/50 hover:-translate-y-0.5 transition-all duration-300 relative overflow-hidden group"
                    style={{ fontFamily: "'Orbitron', sans-serif" }}
                  >
                    <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-500" />
                    {resetMutation.isPending ? (
                      <span className="flex items-center justify-center gap-2">
                        <Loader2 className="h-5 w-5 animate-spin" />
                        Resetting...
                      </span>
                    ) : (
                      "Reset Password"
                    )}
                  </Button>

                  <div className="text-center">
                    <button
                      type="button"
                      onClick={() => navigate("/login")}
                      className="text-sm text-white/50 hover:text-[#00a8ff] transition-colors"
                    >
                      <ArrowLeft className="w-4 h-4 inline mr-1" />
                      Back to Login
                    </button>
                  </div>
                </form>
              </Form>
            </>
          )}
        </div>

        {/* Logo */}
        <div className="mt-8 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#00a8ff] to-[#0052cc] flex items-center justify-center shadow-lg shadow-[#00a8ff]/20">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg tracking-wider bg-gradient-to-r from-white to-[#00a8ff] bg-clip-text text-transparent" style={{ fontFamily: "'Orbitron', sans-serif" }}>
              JE & REJ TECH
            </h1>
            <span className="text-xs text-[#ff3355] tracking-[2px] uppercase font-semibold">Corporation</span>
          </div>
        </div>
      </div>

      {/* Google Fonts */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Rajdhani:wght@300;400;500;600;700&display=swap');
      `}</style>
    </div>
  );
}
