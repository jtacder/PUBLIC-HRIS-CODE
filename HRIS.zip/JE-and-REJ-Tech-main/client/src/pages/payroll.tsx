import { useState, useEffect, useMemo, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { usePagination } from "@/hooks/use-pagination";
import { getPhotoDisplayUrl } from "@/lib/photo-url";
import * as XLSX from "xlsx";
import { TablePagination } from "@/components/ui/table-pagination";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Banknote,
  Calculator,
  FileText,
  Loader2,
  Pencil,
  Check,
  Send,
  MoreHorizontal,
  Trash2,
  RotateCcw,
  CheckCircle2,
  X,
  Download,
} from "lucide-react";
import { SearchableEmployeeSelect } from "@/components/searchable-employee-select";
import { 
  formatCurrency, 
  formatDate,
  getInitials, 
  getStatusColorClass,
  getRoleDisplayName,
} from "@/lib/utils";
import type { Employee, PayrollRecord, PayrollCutoff } from "@shared/schema";

interface PayrollSummary {
  cutoffStart: string;
  cutoffEnd: string;
  totalGross: string;
  totalDeductions: string;
  totalNet: string;
  totalSSS: string;
  totalPhilHealth: string;
  totalPagibig: string;
  totalTax: string;
  recordCount: number;
}

// Generate fallback cutoff options if no settings are defined
function generateFallbackCutoffOptions() {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  
  // Format dates in local time to avoid UTC shift
  const formatLocalDate = (d: Date) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  };
  
  const options = [];
  
  // Current month cutoffs
  const firstHalfStart = new Date(year, month, 1);
  const firstHalfEnd = new Date(year, month, 15);
  const secondHalfStart = new Date(year, month, 16);
  const secondHalfEnd = new Date(year, month + 1, 0); // Last day of month
  
  options.push({
    label: `${formatDate(secondHalfStart)} - ${formatDate(secondHalfEnd)}`,
    start: formatLocalDate(secondHalfStart),
    end: formatLocalDate(secondHalfEnd),
  });
  
  options.push({
    label: `${formatDate(firstHalfStart)} - ${formatDate(firstHalfEnd)}`,
    start: formatLocalDate(firstHalfStart),
    end: formatLocalDate(firstHalfEnd),
  });
  
  return options;
}

interface PayslipEditForm {
  basicPay: string;
  regularOTPay: string;
  restDayOTPay: string;
  holidayOTPay: string;
  bonusAmount: string;
  bonusNotes: string;
  allowances: string;
  colaAllowance: string;
  sssDeduction: string;
  philhealthDeduction: string;
  pagibigDeduction: string;
  taxDeduction: string;
  lateDeduction: string;
  undertimeDeduction: string;
  otherDeductionAmount: string;
  otherDeductionNotes: string;
  cashAdvanceDeduction: string;
  sssLoanDeduction: string;
  pagibigLoanDeduction: string;
  bankLoanDeduction: string;
  overrideNetPay: string;
  editNotes: string;
}

export default function PayrollPage() {
  const { toast } = useToast();
  const [selectedRecord, setSelectedRecord] = useState<PayrollRecord | null>(null);
  const [showPayslip, setShowPayslip] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showApproveAllConfirm, setShowApproveAllConfirm] = useState(false);
  const [showReleaseAllConfirm, setShowReleaseAllConfirm] = useState(false);
  const [showRevertAllConfirm, setShowRevertAllConfirm] = useState(false);
  const [showApproveSelectedConfirm, setShowApproveSelectedConfirm] = useState(false);
  const [showReleaseSelectedConfirm, setShowReleaseSelectedConfirm] = useState(false);
  const [showRevertSelectedConfirm, setShowRevertSelectedConfirm] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [employeeFilter, setEmployeeFilter] = useState<string>("all");
  const [editForm, setEditForm] = useState<PayslipEditForm>({
    basicPay: "",
    regularOTPay: "",
    restDayOTPay: "",
    holidayOTPay: "",
    bonusAmount: "",
    bonusNotes: "",
    allowances: "",
    colaAllowance: "",
    sssDeduction: "",
    philhealthDeduction: "",
    pagibigDeduction: "",
    taxDeduction: "",
    lateDeduction: "",
    undertimeDeduction: "",
    otherDeductionAmount: "",
    otherDeductionNotes: "",
    cashAdvanceDeduction: "",
    sssLoanDeduction: "",
    pagibigLoanDeduction: "",
    bankLoanDeduction: "",
    overrideNetPay: "",
    editNotes: "",
  });

  const { data: employees, isLoading: employeesLoading } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const { data: cutoffSettings = [] } = useQuery<PayrollCutoff[]>({
    queryKey: ["/api/settings/payroll-cutoffs"],
  });

  // Calculate cutoff options based on settings and current date
  const cutoffOptions = (() => {
    const options: { label: string; start: string; end: string; name?: string }[] = [];
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();

    // Show cutoffs for current and previous 2 months to cover cross-year periods
    [0, -1, -2].forEach(monthOffset => {
      const d = new Date(currentYear, currentMonth + monthOffset, 1);
      const year = d.getFullYear();
      const month = d.getMonth();

      cutoffSettings.forEach(setting => {
        const start = new Date(year, month, setting.startDay);
        let end: Date;
        
        if (setting.endDay < setting.startDay) {
          // Crosses into next month (e.g., Dec 25 -> Jan 10)
          end = new Date(year, month + 1, setting.endDay);
        } else {
          end = new Date(year, month, setting.endDay);
        }

        // Only add if the end date is not too far in the future
        const maxFutureDate = new Date(currentYear, currentMonth + 2, 0);
        if (end <= maxFutureDate) {
          // Format dates in local time to avoid UTC shift
          const formatLocalDate = (d: Date) => {
            const year = d.getFullYear();
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
          };
          options.push({
            label: `${formatDate(start)} - ${formatDate(end)}`,
            start: formatLocalDate(start),
            end: formatLocalDate(end),
            name: setting.name
          });
        }
      });
    });

    // Fallback if no settings defined
    if (options.length === 0) {
      return generateFallbackCutoffOptions();
    }

    // Remove duplicates based on start-end combo
    const uniqueOptions = options.filter((opt, idx, arr) => 
      arr.findIndex(o => o.start === opt.start && o.end === opt.end) === idx
    );

    // Sort by date descending
    return uniqueOptions.sort((a, b) => b.start.localeCompare(a.start));
  })();

  const [selectedCutoff, setSelectedCutoff] = useState(cutoffOptions[0]);

  // Update selected cutoff if options change and current selection is no longer valid
  if (selectedCutoff && !cutoffOptions.some(o => o.start === selectedCutoff.start && o.end === selectedCutoff.end)) {
    setSelectedCutoff(cutoffOptions[0]);
  }

  const { data: payrollRecords, isLoading: payrollLoading } = useQuery<PayrollRecord[]>({
    queryKey: ["/api/payroll", selectedCutoff?.start, selectedCutoff?.end],
    enabled: !!selectedCutoff,
  });

  const { data: summary, isLoading: summaryLoading } = useQuery<PayrollSummary>({
    queryKey: ["/api/payroll/summary", selectedCutoff?.start, selectedCutoff?.end],
    enabled: !!selectedCutoff,
  });

  // Create employee map
  const employeeMap = new Map(employees?.map(e => [e.id, e]) || []);

  // Filter payroll records by employee
  const filteredPayrollRecords = useMemo(() => {
    if (!payrollRecords) return [];
    if (employeeFilter === "all") return payrollRecords;
    return payrollRecords.filter(r => r.employeeId === employeeFilter);
  }, [payrollRecords, employeeFilter]);

  // Pagination
  const pagination = usePagination(filteredPayrollRecords);

  const computeMutation = useMutation({
    mutationFn: async () => {
      if (!selectedCutoff) return;
      return apiRequest("POST", "/api/payroll/compute", {
        cutoffStart: selectedCutoff.start,
        cutoffEnd: selectedCutoff.end,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/summary", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Payroll Computed",
        description: "Payroll records have been generated for all employees.",
      });
    },
    onError: () => {
      toast({
        title: "Computation Failed",
        description: "Failed to compute payroll. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deletePayrollMutation = useMutation({
    mutationFn: async () => {
      if (!selectedCutoff) return;
      return apiRequest("DELETE", `/api/payroll/cutoff?cutoffStart=${selectedCutoff.start}&cutoffEnd=${selectedCutoff.end}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/summary", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setShowDeleteConfirm(false);
      toast({
        title: "Payroll Deleted",
        description: "Draft payslips have been deleted. You can now make attendance corrections and regenerate.",
      });
    },
    onError: () => {
      toast({
        title: "Deletion Failed",
        description: "Failed to delete payroll records. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updatePayrollMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Record<string, unknown> }) => {
      const response = await apiRequest("PATCH", `/api/payroll/${id}`, data);
      return response.json();
    },
    onSuccess: (updatedRecord) => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/summary", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      // Update the selected record with the fresh data from the server
      if (updatedRecord) {
        setSelectedRecord(updatedRecord);
      }
      setIsEditing(false);
      toast({
        title: "Payslip Updated",
        description: "Payslip has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update payslip. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const endpoint = status === "Approved" ? `/api/payroll/${id}/approve` :
                       status === "Released" ? `/api/payroll/${id}/release` :
                       `/api/payroll/${id}`;
      const body = status === "Draft" ? { status: "Draft" } : undefined;
      const response = await apiRequest("PATCH", endpoint, body);
      return response.json();
    },
    onSuccess: (updatedRecord) => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/summary", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      // Update the selected record with the fresh data from the server
      if (updatedRecord) {
        setSelectedRecord(updatedRecord);
      }
      toast({
        title: "Status Updated",
        description: "Payslip status has been updated.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update status. Please try again.",
        variant: "destructive",
      });
    },
  });

  const releaseAllMutation = useMutation({
    mutationFn: async () => {
      if (!selectedCutoff) return;
      const response = await apiRequest("POST", "/api/payroll/release-all", {
        cutoffStart: selectedCutoff.start,
        cutoffEnd: selectedCutoff.end,
      });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/summary", selectedCutoff?.start, selectedCutoff?.end] });
      setShowReleaseAllConfirm(false);
      toast({
        title: "Payroll Released",
        description: `${data?.releasedCount || 0} payslips have been released.`,
      });
    },
    onError: () => {
      toast({
        title: "Release Failed",
        description: "Failed to release payroll records. Please try again.",
        variant: "destructive",
      });
    },
  });

  const revertAllMutation = useMutation({
    mutationFn: async () => {
      if (!selectedCutoff) return;
      const response = await apiRequest("POST", "/api/payroll/revert-all", {
        cutoffStart: selectedCutoff.start,
        cutoffEnd: selectedCutoff.end,
      });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/summary", selectedCutoff?.start, selectedCutoff?.end] });
      setShowRevertAllConfirm(false);
      toast({
        title: "Payroll Reverted",
        description: `${data?.revertedCount || 0} payslips have been reverted to draft.`,
      });
    },
    onError: () => {
      toast({
        title: "Revert Failed",
        description: "Failed to revert payroll records. Please try again.",
        variant: "destructive",
      });
    },
  });

  const approveAllMutation = useMutation({
    mutationFn: async () => {
      if (!selectedCutoff) return;
      const response = await apiRequest("POST", "/api/payroll/approve-all", {
        cutoffStart: selectedCutoff.start,
        cutoffEnd: selectedCutoff.end,
      });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/summary", selectedCutoff?.start, selectedCutoff?.end] });
      setShowApproveAllConfirm(false);
      toast({
        title: "Payroll Approved",
        description: `${data?.approvedCount || 0} payslips have been approved.`,
      });
    },
    onError: () => {
      toast({
        title: "Approval Failed",
        description: "Failed to approve payroll records. Please try again.",
        variant: "destructive",
      });
    },
  });

  const approveSelectedMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      const response = await apiRequest("POST", "/api/payroll/approve-selected", { ids });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/summary", selectedCutoff?.start, selectedCutoff?.end] });
      setShowApproveSelectedConfirm(false);
      setSelectedIds(new Set());
      toast({
        title: "Selected Payslips Approved",
        description: `${data?.approvedCount || 0} payslips have been approved.`,
      });
    },
    onError: () => {
      toast({
        title: "Approval Failed",
        description: "Failed to approve selected payslips. Please try again.",
        variant: "destructive",
      });
    },
  });

  const releaseSelectedMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      const response = await apiRequest("POST", "/api/payroll/release-selected", { ids });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/summary", selectedCutoff?.start, selectedCutoff?.end] });
      setShowReleaseSelectedConfirm(false);
      setSelectedIds(new Set());
      toast({
        title: "Selected Payslips Released",
        description: `${data?.releasedCount || 0} payslips have been released.`,
      });
    },
    onError: () => {
      toast({
        title: "Release Failed",
        description: "Failed to release selected payslips. Please try again.",
        variant: "destructive",
      });
    },
  });

  const revertSelectedMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      const response = await apiRequest("POST", "/api/payroll/revert-selected", { ids });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll", selectedCutoff?.start, selectedCutoff?.end] });
      queryClient.invalidateQueries({ queryKey: ["/api/payroll/summary", selectedCutoff?.start, selectedCutoff?.end] });
      setShowRevertSelectedConfirm(false);
      setSelectedIds(new Set());
      toast({
        title: "Selected Payslips Reverted",
        description: `${data?.revertedCount || 0} payslips have been reverted to draft.`,
      });
    },
    onError: () => {
      toast({
        title: "Revert Failed",
        description: "Failed to revert selected payslips. Please try again.",
        variant: "destructive",
      });
    },
  });

  const isLoading = employeesLoading || payrollLoading || summaryLoading;

  // Selection helpers
  const toggleSelection = (id: string) => {
    setSelectedIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const toggleSelectAll = () => {
    if (!filteredPayrollRecords || filteredPayrollRecords.length === 0) return;
    if (selectedIds.size === filteredPayrollRecords.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredPayrollRecords.map(r => r.id)));
    }
  };

  const clearSelection = () => {
    setSelectedIds(new Set());
  };

  // Status counts
  const statusCounts = {
    draft: payrollRecords?.filter(r => r.status === "Draft").length || 0,
    approved: payrollRecords?.filter(r => r.status === "Approved").length || 0,
    released: payrollRecords?.filter(r => r.status === "Released").length || 0,
  };

  // Selected items by status
  const selectedRecords = payrollRecords?.filter(r => selectedIds.has(r.id)) || [];
  const selectedDrafts = selectedRecords.filter(r => r.status === "Draft");
  const selectedApproved = selectedRecords.filter(r => r.status === "Approved");
  const selectedNonDraft = selectedRecords.filter(r => r.status !== "Draft");

  const handleCutoffChange = (value: string) => {
    const option = cutoffOptions.find(o => `${o.start}_${o.end}` === value);
    if (option) {
      setSelectedCutoff(option);
    }
  };

  const openPayslip = (record: PayrollRecord, edit: boolean = false) => {
    setSelectedRecord(record);
    setEditForm({
      basicPay: String(record.basicPay || "0"),
      regularOTPay: String(record.regularOTPay || "0"),
      restDayOTPay: String(record.restDayOTPay || "0"),
      holidayOTPay: String(record.holidayOTPay || "0"),
      bonusAmount: String(record.bonusAmount || "0"),
      bonusNotes: record.bonusNotes || "",
      allowances: String(record.allowances || "0"),
      colaAllowance: String((record as any).colaAllowance || "0"),
      sssDeduction: String(record.sssDeduction || "0"),
      philhealthDeduction: String(record.philhealthDeduction || "0"),
      pagibigDeduction: String(record.pagibigDeduction || "0"),
      taxDeduction: String(record.taxDeduction || "0"),
      lateDeduction: String(record.lateDeduction || "0"),
      undertimeDeduction: String(record.undertimeDeduction || "0"),
      otherDeductionAmount: String(record.otherDeductionAmount || "0"),
      otherDeductionNotes: record.otherDeductionNotes || "",
      cashAdvanceDeduction: String(record.cashAdvanceDeduction || "0"),
      sssLoanDeduction: String(record.sssLoanDeduction || "0"),
      pagibigLoanDeduction: String(record.pagibigLoanDeduction || "0"),
      bankLoanDeduction: String(record.bankLoanDeduction || "0"),
      overrideNetPay: record.overrideNetPay ? String(record.overrideNetPay) : "",
      editNotes: record.editNotes || "",
    });
    setIsEditing(edit);
    setShowPayslip(true);
  };

  const handleSavePayslip = () => {
    if (!selectedRecord) return;

    // Convert string values to numbers before sending to backend
    const numericData = {
      basicPay: parseFloat(editForm.basicPay) || 0,
      regularOTPay: parseFloat(editForm.regularOTPay) || 0,
      restDayOTPay: parseFloat(editForm.restDayOTPay) || 0,
      holidayOTPay: parseFloat(editForm.holidayOTPay) || 0,
      bonusAmount: parseFloat(editForm.bonusAmount) || 0,
      bonusNotes: editForm.bonusNotes || null,
      allowances: parseFloat(editForm.allowances) || 0,
      colaAllowance: parseFloat(editForm.colaAllowance) || 0,
      sssDeduction: parseFloat(editForm.sssDeduction) || 0,
      philhealthDeduction: parseFloat(editForm.philhealthDeduction) || 0,
      pagibigDeduction: parseFloat(editForm.pagibigDeduction) || 0,
      taxDeduction: parseFloat(editForm.taxDeduction) || 0,
      lateDeduction: parseFloat(editForm.lateDeduction) || 0,
      undertimeDeduction: parseFloat(editForm.undertimeDeduction) || 0,
      otherDeductionAmount: parseFloat(editForm.otherDeductionAmount) || 0,
      otherDeductionNotes: editForm.otherDeductionNotes || null,
      cashAdvanceDeduction: parseFloat(editForm.cashAdvanceDeduction) || 0,
      sssLoanDeduction: parseFloat(editForm.sssLoanDeduction) || 0,
      pagibigLoanDeduction: parseFloat(editForm.pagibigLoanDeduction) || 0,
      bankLoanDeduction: parseFloat(editForm.bankLoanDeduction) || 0,
      overrideNetPay: editForm.overrideNetPay ? parseFloat(editForm.overrideNetPay) : null,
      editNotes: editForm.editNotes || null,
    };
    
    updatePayrollMutation.mutate({
      id: selectedRecord.id,
      data: numericData,
    });
  };

  const handleStatusChange = (recordId: string, newStatus: string) => {
    updateStatusMutation.mutate({ id: recordId, status: newStatus });
  };

  // Export payroll to Excel
  const handleExportToExcel = useCallback(() => {
    if (!payrollRecords || payrollRecords.length === 0 || !selectedCutoff) return;

    const data = filteredPayrollRecords.map((record) => {
      const employee = employeeMap.get(record.employeeId);
      return {
        "Employee No.": employee?.employeeNo || "",
        "Employee Name": employee ? `${employee.lastName}, ${employee.firstName}` : "",
        "Position": employee?.position || "",
        "Department": employee?.department || "",
        "Days Worked": Number(record.daysWorked) || 0,
        "Hours Worked": Number(record.hoursWorked) || 0,
        "Basic Pay": Number(record.basicPay) || 0,
        "Regular OT Pay": Number(record.regularOTPay) || 0,
        "Rest Day OT Pay": Number(record.restDayOTPay) || 0,
        "Holiday OT Pay": Number(record.holidayOTPay) || 0,
        "Allowances": Number(record.allowances) || 0,
        "Bonus": Number(record.bonusAmount) || 0,
        "COLA": Number((record as any).colaAllowance) || 0,
        "Gross Pay": Number(record.grossPay) || 0,
        "SSS": Number(record.sssDeduction) || 0,
        "PhilHealth": Number(record.philhealthDeduction) || 0,
        "Pag-IBIG": Number(record.pagibigDeduction) || 0,
        "Tax": Number(record.taxDeduction) || 0,
        "Late Deduction": Number(record.lateDeduction) || 0,
        "Undertime Deduction": Number(record.undertimeDeduction) || 0,
        "Cash Advance": Number(record.cashAdvanceDeduction) || 0,
        "SSS Loan": Number(record.sssLoanDeduction) || 0,
        "Pag-IBIG Loan": Number(record.pagibigLoanDeduction) || 0,
        "Bank Loan": Number(record.bankLoanDeduction) || 0,
        "Other Deductions": Number(record.otherDeductionAmount) || 0,
        "Total Deductions": Number(record.totalDeductions) || 0,
        "Net Pay": Number(record.overrideNetPay || record.netPay) || 0,
        "Meal Allowance (FYI)": Number(record.mealAllowanceTotal) || 0,
        "Status": record.status,
      };
    });

    const ws = XLSX.utils.json_to_sheet(data);

    // Auto-size columns based on header length
    const colWidths = Object.keys(data[0] || {}).map((key) => ({
      wch: Math.max(key.length + 2, 14),
    }));
    ws["!cols"] = colWidths;

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Payroll");

    const fileName = `Payroll_${selectedCutoff.start}_to_${selectedCutoff.end}.xlsx`;
    XLSX.writeFile(wb, fileName);

    toast({
      title: "Export Complete",
      description: `Payroll exported as ${fileName}`,
    });
  }, [payrollRecords, filteredPayrollRecords, employeeMap, selectedCutoff, toast]);

  if (!selectedCutoff && cutoffOptions.length > 0) {
    setSelectedCutoff(cutoffOptions[0]);
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Payroll</h1>
          <p className="text-muted-foreground">
            Compute and manage employee compensation
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {statusCounts.draft > 0 && (
            <Button
              variant="outline"
              onClick={() => setShowDeleteConfirm(true)}
              disabled={deletePayrollMutation.isPending || !selectedCutoff}
              data-testid="button-delete-payroll"
            >
              {deletePayrollMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Trash2 className="h-4 w-4 mr-2" />
              )}
              Delete Draft ({statusCounts.draft})
            </Button>
          )}
          {statusCounts.draft > 0 && (
            <Button
              variant="default"
              onClick={() => setShowApproveAllConfirm(true)}
              disabled={approveAllMutation.isPending || !selectedCutoff}
              data-testid="button-approve-all"
            >
              {approveAllMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Check className="h-4 w-4 mr-2" />
              )}
              Approve All ({statusCounts.draft})
            </Button>
          )}
          {statusCounts.approved > 0 && (
            <Button
              variant="default"
              onClick={() => setShowReleaseAllConfirm(true)}
              disabled={releaseAllMutation.isPending || !selectedCutoff}
              data-testid="button-release-all"
            >
              {releaseAllMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Send className="h-4 w-4 mr-2" />
              )}
              Release All ({statusCounts.approved})
            </Button>
          )}
          {(statusCounts.approved > 0 || statusCounts.released > 0) && (
            <Button
              variant="outline"
              onClick={() => setShowRevertAllConfirm(true)}
              disabled={revertAllMutation.isPending || !selectedCutoff}
              data-testid="button-revert-all"
            >
              {revertAllMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <RotateCcw className="h-4 w-4 mr-2" />
              )}
              Revert All ({statusCounts.approved + statusCounts.released})
            </Button>
          )}
          <Button
            onClick={() => computeMutation.mutate()}
            disabled={computeMutation.isPending || !selectedCutoff}
            data-testid="button-compute-payroll"
          >
            {computeMutation.isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Calculator className="h-4 w-4 mr-2" />
            )}
            Compute Payroll
          </Button>
          {payrollRecords && payrollRecords.length > 0 && (
            <Button
              variant="outline"
              onClick={handleExportToExcel}
              data-testid="button-export-payroll"
            >
              <Download className="h-4 w-4 mr-2" />
              Export Excel
            </Button>
          )}
        </div>
      </div>

      {/* Cutoff Selection & Summary */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Cutoff Period
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedCutoff && (
              <Select
                value={`${selectedCutoff.start}_${selectedCutoff.end}`}
                onValueChange={handleCutoffChange}
              >
                <SelectTrigger data-testid="select-cutoff">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {cutoffOptions.map((option) => (
                    <SelectItem key={`${option.start}_${option.end}`} value={`${option.start}_${option.end}`}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Gross
            </CardTitle>
          </CardHeader>
          <CardContent>
            {summaryLoading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <p className="text-2xl font-bold text-foreground" data-testid="summary-gross">
                {formatCurrency(summary?.totalGross || 0)}
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Deductions
            </CardTitle>
          </CardHeader>
          <CardContent>
            {summaryLoading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <p className="text-2xl font-bold text-red-500" data-testid="summary-deductions">
                {formatCurrency(summary?.totalDeductions || 0)}
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Net Pay
            </CardTitle>
          </CardHeader>
          <CardContent>
            {summaryLoading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <p className="text-2xl font-bold text-green-600" data-testid="summary-net">
                {formatCurrency(summary?.totalNet || 0)}
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Government Contributions Summary */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-xs font-medium text-muted-foreground uppercase mb-1">SSS Total</p>
            {summaryLoading ? (
              <Skeleton className="h-6 w-24" />
            ) : (
              <p className="text-lg font-bold font-mono">{formatCurrency(summary?.totalSSS || 0)}</p>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs font-medium text-muted-foreground uppercase mb-1">PhilHealth Total</p>
            {summaryLoading ? (
              <Skeleton className="h-6 w-24" />
            ) : (
              <p className="text-lg font-bold font-mono">{formatCurrency(summary?.totalPhilHealth || 0)}</p>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs font-medium text-muted-foreground uppercase mb-1">Pag-IBIG Total</p>
            {summaryLoading ? (
              <Skeleton className="h-6 w-24" />
            ) : (
              <p className="text-lg font-bold font-mono">{formatCurrency(summary?.totalPagibig || 0)}</p>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs font-medium text-muted-foreground uppercase mb-1">Withholding Tax</p>
            {summaryLoading ? (
              <Skeleton className="h-6 w-24" />
            ) : (
              <p className="text-lg font-bold font-mono">{formatCurrency(summary?.totalTax || 0)}</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Payroll Table */}
      <Card>
        <CardHeader className="flex flex-col gap-4 space-y-0 sm:flex-row sm:items-center sm:justify-between">
          <CardTitle className="flex items-center gap-2">
            <Banknote className="h-5 w-5" />
            Payroll Records
          </CardTitle>
          <SearchableEmployeeSelect
            employees={employees || []}
            value={employeeFilter}
            onValueChange={setEmployeeFilter}
            placeholder="Filter by employee..."
            allowAll
            allLabel="All Employees"
            className="w-full sm:w-[200px]"
            data-testid="filter-payroll-employee"
          />
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex items-center gap-4">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                  <Skeleton className="h-6 w-24" />
                </div>
              ))}
            </div>
          ) : filteredPayrollRecords && filteredPayrollRecords.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox
                        checked={filteredPayrollRecords && filteredPayrollRecords.length > 0 && selectedIds.size === filteredPayrollRecords.length}
                        onCheckedChange={toggleSelectAll}
                        aria-label="Select all"
                      />
                    </TableHead>
                    <TableHead>Employee</TableHead>
                    <TableHead className="text-center">Days</TableHead>
                    <TableHead className="text-right">Gross Pay</TableHead>
                    <TableHead className="text-right">Deductions</TableHead>
                    <TableHead className="text-right">Net Pay</TableHead>
                    <TableHead className="text-center">Status</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pagination.paginatedData.map((record) => {
                    const employee = employeeMap.get(record.employeeId);
                    return (
                      <TableRow key={record.id} data-testid={`payroll-row-${record.id}`}>
                        <TableCell>
                          <Checkbox
                            checked={selectedIds.has(record.id)}
                            onCheckedChange={() => toggleSelection(record.id)}
                            aria-label={`Select ${employee?.firstName} ${employee?.lastName}`}
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={getPhotoDisplayUrl(employee?.profilePhotoUrl) || undefined} />
                              <AvatarFallback>
                                {getInitials(employee?.firstName, employee?.lastName)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">
                                {employee?.firstName} {employee?.lastName}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {employee?.position || getRoleDisplayName(employee?.role || "")}
                              </p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-center font-mono">
                          {record.daysWorked || 0}
                        </TableCell>
                        <TableCell className="text-right font-mono">
                          {formatCurrency(record.grossPay || 0)}
                        </TableCell>
                        <TableCell className="text-right font-mono text-red-500">
                          -{formatCurrency(record.totalDeductions || 0)}
                        </TableCell>
                        <TableCell className="text-right font-mono font-bold text-green-600">
                          {formatCurrency(record.netPay || 0)}
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge variant="secondary" className={getStatusColorClass(record.status)}>
                            {record.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openPayslip(record)}
                              data-testid={`button-view-payslip-${record.id}`}
                            >
                              <FileText className="h-4 w-4 mr-1" />
                              View
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" aria-label="Payroll actions" data-testid={`button-payroll-actions-${record.id}`}>
                                  <MoreHorizontal className="h-4 w-4" aria-hidden="true" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => openPayslip(record, true)} data-testid={`button-edit-payslip-${record.id}`}>
                                  <Pencil className="mr-2 h-4 w-4" />
                                  Edit Payslip
                                </DropdownMenuItem>
                                {record.status === "Draft" && (
                                  <DropdownMenuItem onClick={() => handleStatusChange(record.id, "Approved")} data-testid={`button-approve-payslip-${record.id}`}>
                                    <Check className="mr-2 h-4 w-4" />
                                    Mark as Complete
                                  </DropdownMenuItem>
                                )}
                                {record.status === "Approved" && (
                                  <DropdownMenuItem onClick={() => handleStatusChange(record.id, "Released")} data-testid={`button-release-payslip-${record.id}`}>
                                    <Send className="mr-2 h-4 w-4" />
                                    Release Payslip
                                  </DropdownMenuItem>
                                )}
                                {record.status !== "Draft" && (
                                  <DropdownMenuItem onClick={() => handleStatusChange(record.id, "Draft")} data-testid={`button-revert-payslip-${record.id}`}>
                                    <Pencil className="mr-2 h-4 w-4" />
                                    Revert to Draft
                                  </DropdownMenuItem>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              <TablePagination
                currentPage={pagination.currentPage}
                pageSize={pagination.pageSize}
                totalPages={pagination.totalPages}
                totalItems={pagination.totalItems}
                startIndex={pagination.startIndex}
                endIndex={pagination.endIndex}
                canGoNext={pagination.canGoNext}
                canGoPrevious={pagination.canGoPrevious}
                onPageChange={pagination.goToPage}
                onPageSizeChange={pagination.setPageSize}
                onNextPage={pagination.goToNextPage}
                onPreviousPage={pagination.goToPreviousPage}
                onFirstPage={pagination.goToFirstPage}
                onLastPage={pagination.goToLastPage}
              />

              {/* Floating Action Bar for Selected Items */}
              {selectedIds.size > 0 && (
                <div className="sticky bottom-0 left-0 right-0 p-4 bg-muted/95 backdrop-blur border-t flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium">
                      {selectedIds.size} item{selectedIds.size !== 1 ? 's' : ''} selected
                    </span>
                    <Button variant="ghost" size="sm" onClick={clearSelection} className="h-7 px-2">
                      <X className="h-3 w-3 mr-1" />
                      Clear
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    {selectedDrafts.length > 0 && (
                      <Button
                        size="sm"
                        onClick={() => setShowApproveSelectedConfirm(true)}
                        disabled={approveSelectedMutation.isPending}
                        data-testid="button-approve-selected"
                      >
                        {approveSelectedMutation.isPending ? (
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        ) : (
                          <Check className="h-4 w-4 mr-2" />
                        )}
                        Approve Selected ({selectedDrafts.length})
                      </Button>
                    )}
                    {selectedApproved.length > 0 && (
                      <Button
                        size="sm"
                        onClick={() => setShowReleaseSelectedConfirm(true)}
                        disabled={releaseSelectedMutation.isPending}
                        data-testid="button-release-selected"
                      >
                        {releaseSelectedMutation.isPending ? (
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        ) : (
                          <Send className="h-4 w-4 mr-2" />
                        )}
                        Release Selected ({selectedApproved.length})
                      </Button>
                    )}
                    {selectedNonDraft.length > 0 && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowRevertSelectedConfirm(true)}
                        disabled={revertSelectedMutation.isPending}
                        data-testid="button-revert-selected"
                      >
                        {revertSelectedMutation.isPending ? (
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        ) : (
                          <RotateCcw className="h-4 w-4 mr-2" />
                        )}
                        Revert Selected ({selectedNonDraft.length})
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <Banknote className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-1">No payroll records</h3>
              <p className="text-muted-foreground mb-4">
                Click "Compute Payroll" to generate records for this period
              </p>
              <Button onClick={() => computeMutation.mutate()} disabled={computeMutation.isPending || !selectedCutoff}>
                <Calculator className="h-4 w-4 mr-2" />
                Compute Payroll
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payslip Modal */}
      <Dialog open={showPayslip} onOpenChange={(open) => { setShowPayslip(open); if (!open) setIsEditing(false); }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              {isEditing ? "Edit Payslip" : "Payslip"}
            </DialogTitle>
          </DialogHeader>
          {selectedRecord && (
            <div className="space-y-6">
              {/* Employee Info */}
              <div className="flex items-center justify-between pb-4 border-b">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={getPhotoDisplayUrl(employeeMap.get(selectedRecord.employeeId)?.profilePhotoUrl) || undefined} />
                    <AvatarFallback>
                      {getInitials(
                        employeeMap.get(selectedRecord.employeeId)?.firstName,
                        employeeMap.get(selectedRecord.employeeId)?.lastName
                      )}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-bold">
                      {employeeMap.get(selectedRecord.employeeId)?.firstName}{" "}
                      {employeeMap.get(selectedRecord.employeeId)?.lastName}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {formatDate(selectedRecord.cutoffStart)} - {formatDate(selectedRecord.cutoffEnd)}
                    </p>
                  </div>
                </div>
                <Badge variant="secondary" className={getStatusColorClass(selectedRecord.status)}>
                  {selectedRecord.status}
                </Badge>
              </div>

              {isEditing ? (
                <>
                  {/* Editable Earnings */}
                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase">Earnings</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="basicPay">Basic Pay</Label>
                        <Input 
                          id="basicPay" 
                          type="number" 
                          step="0.01"
                          value={editForm.basicPay}
                          onChange={(e) => setEditForm(prev => ({ ...prev, basicPay: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="allowances">Allowances</Label>
                        <Input 
                          id="allowances" 
                          type="number" 
                          step="0.01"
                          value={editForm.allowances}
                          onChange={(e) => setEditForm(prev => ({ ...prev, allowances: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="regularOTPay">Regular OT Pay</Label>
                        <Input 
                          id="regularOTPay" 
                          type="number" 
                          step="0.01"
                          value={editForm.regularOTPay}
                          onChange={(e) => setEditForm(prev => ({ ...prev, regularOTPay: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="restDayOTPay">Rest Day OT Pay</Label>
                        <Input 
                          id="restDayOTPay" 
                          type="number" 
                          step="0.01"
                          value={editForm.restDayOTPay}
                          onChange={(e) => setEditForm(prev => ({ ...prev, restDayOTPay: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="holidayOTPay">Holiday OT Pay</Label>
                        <Input 
                          id="holidayOTPay" 
                          type="number" 
                          step="0.01"
                          value={editForm.holidayOTPay}
                          onChange={(e) => setEditForm(prev => ({ ...prev, holidayOTPay: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="bonusAmount">Bonus Amount</Label>
                        <Input
                          id="bonusAmount"
                          type="number"
                          step="0.01"
                          value={editForm.bonusAmount}
                          onChange={(e) => setEditForm(prev => ({ ...prev, bonusAmount: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="colaAllowance">COLA (Tax-Exempt)</Label>
                        <Input
                          id="colaAllowance"
                          type="number"
                          step="0.01"
                          value={editForm.colaAllowance}
                          onChange={(e) => setEditForm(prev => ({ ...prev, colaAllowance: e.target.value }))}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="bonusNotes">Bonus Notes</Label>
                      <Input 
                        id="bonusNotes" 
                        value={editForm.bonusNotes}
                        onChange={(e) => setEditForm(prev => ({ ...prev, bonusNotes: e.target.value }))}
                        placeholder="e.g., 13th month, performance bonus"
                      />
                    </div>
                  </div>

                  {/* Editable Deductions */}
                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase">Deductions</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="sssDeduction">SSS</Label>
                        <Input 
                          id="sssDeduction" 
                          type="number" 
                          step="0.01"
                          value={editForm.sssDeduction}
                          onChange={(e) => setEditForm(prev => ({ ...prev, sssDeduction: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="philhealthDeduction">PhilHealth</Label>
                        <Input 
                          id="philhealthDeduction" 
                          type="number" 
                          step="0.01"
                          value={editForm.philhealthDeduction}
                          onChange={(e) => setEditForm(prev => ({ ...prev, philhealthDeduction: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="pagibigDeduction">Pag-IBIG</Label>
                        <Input 
                          id="pagibigDeduction" 
                          type="number" 
                          step="0.01"
                          value={editForm.pagibigDeduction}
                          onChange={(e) => setEditForm(prev => ({ ...prev, pagibigDeduction: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="taxDeduction">Withholding Tax</Label>
                        <Input 
                          id="taxDeduction" 
                          type="number" 
                          step="0.01"
                          value={editForm.taxDeduction}
                          onChange={(e) => setEditForm(prev => ({ ...prev, taxDeduction: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lateDeduction">Late Deduction</Label>
                        <Input 
                          id="lateDeduction" 
                          type="number" 
                          step="0.01"
                          value={editForm.lateDeduction}
                          onChange={(e) => setEditForm(prev => ({ ...prev, lateDeduction: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="undertimeDeduction">Undertime Deduction</Label>
                        <Input 
                          id="undertimeDeduction" 
                          type="number" 
                          step="0.01"
                          value={editForm.undertimeDeduction}
                          onChange={(e) => setEditForm(prev => ({ ...prev, undertimeDeduction: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cashAdvanceDeduction">Cash Advance</Label>
                        <Input 
                          id="cashAdvanceDeduction" 
                          type="number" 
                          step="0.01"
                          value={editForm.cashAdvanceDeduction}
                          onChange={(e) => setEditForm(prev => ({ ...prev, cashAdvanceDeduction: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="sssLoanDeduction">SSS Loan</Label>
                        <Input
                          id="sssLoanDeduction"
                          type="number"
                          step="0.01"
                          value={editForm.sssLoanDeduction}
                          onChange={(e) => setEditForm(prev => ({ ...prev, sssLoanDeduction: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="pagibigLoanDeduction">Pag-IBIG Loan</Label>
                        <Input
                          id="pagibigLoanDeduction"
                          type="number"
                          step="0.01"
                          value={editForm.pagibigLoanDeduction}
                          onChange={(e) => setEditForm(prev => ({ ...prev, pagibigLoanDeduction: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="bankLoanDeduction">Bank Loan</Label>
                        <Input
                          id="bankLoanDeduction"
                          type="number"
                          step="0.01"
                          value={editForm.bankLoanDeduction}
                          onChange={(e) => setEditForm(prev => ({ ...prev, bankLoanDeduction: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="otherDeductionAmount">Other Deduction</Label>
                        <Input
                          id="otherDeductionAmount"
                          type="number"
                          step="0.01"
                          value={editForm.otherDeductionAmount}
                          onChange={(e) => setEditForm(prev => ({ ...prev, otherDeductionAmount: e.target.value }))}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="otherDeductionNotes">Other Deduction Notes</Label>
                      <Input 
                        id="otherDeductionNotes" 
                        value={editForm.otherDeductionNotes}
                        onChange={(e) => setEditForm(prev => ({ ...prev, otherDeductionNotes: e.target.value }))}
                        placeholder="e.g., uniform, loan payment"
                      />
                    </div>
                  </div>

                  {/* Override Net Pay */}
                  <div className="space-y-3 p-4 rounded-lg bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800">
                    <h4 className="text-sm font-semibold text-yellow-700 dark:text-yellow-400">Override Net Pay (Optional)</h4>
                    <p className="text-xs text-muted-foreground">Leave empty to auto-calculate based on earnings and deductions</p>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="overrideNetPay">Final Net Pay Override</Label>
                        <Input 
                          id="overrideNetPay" 
                          type="number" 
                          step="0.01"
                          value={editForm.overrideNetPay}
                          onChange={(e) => setEditForm(prev => ({ ...prev, overrideNetPay: e.target.value }))}
                          placeholder="Leave empty for auto-calculate"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="editNotes">Edit Notes</Label>
                      <Textarea 
                        id="editNotes" 
                        value={editForm.editNotes}
                        onChange={(e) => setEditForm(prev => ({ ...prev, editNotes: e.target.value }))}
                        placeholder="Reason for manual adjustment..."
                      />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  {/* View-only Earnings */}
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase">Earnings</h4>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>Basic Pay ({selectedRecord.daysWorked || 0} days)</span>
                        <span className="font-mono">{formatCurrency(selectedRecord.basicPay || 0)}</span>
                      </div>
                      {parseFloat(String(selectedRecord.allowances || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>Allowances</span>
                          <span className="font-mono">{formatCurrency(selectedRecord.allowances || 0)}</span>
                        </div>
                      )}
                      {parseFloat(String(selectedRecord.regularOTPay || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>Regular OT Pay ({selectedRecord.regularOTMinutes || 0}m)</span>
                          <span className="font-mono">{formatCurrency(selectedRecord.regularOTPay || 0)}</span>
                        </div>
                      )}
                      {parseFloat(String(selectedRecord.restDayOTPay || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>Rest Day OT Pay ({selectedRecord.restDayOTMinutes || 0}m)</span>
                          <span className="font-mono">{formatCurrency(selectedRecord.restDayOTPay || 0)}</span>
                        </div>
                      )}
                      {parseFloat(String(selectedRecord.holidayOTPay || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>Holiday OT Pay ({selectedRecord.holidayOTMinutes || 0}m)</span>
                          <span className="font-mono">{formatCurrency(selectedRecord.holidayOTPay || 0)}</span>
                        </div>
                      )}
                      {parseFloat(String(selectedRecord.bonusAmount || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>Bonus {selectedRecord.bonusNotes ? `(${selectedRecord.bonusNotes})` : ""}</span>
                          <span className="font-mono">{formatCurrency(selectedRecord.bonusAmount || 0)}</span>
                        </div>
                      )}
                      {parseFloat(String((selectedRecord as any).colaAllowance || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>COLA (Tax-Exempt)</span>
                          <span className="font-mono">{formatCurrency((selectedRecord as any).colaAllowance || 0)}</span>
                        </div>
                      )}
                      <div className="flex justify-between font-semibold pt-2 border-t">
                        <span>Gross Pay</span>
                        <span className="font-mono">{formatCurrency(selectedRecord.grossPay || 0)}</span>
                      </div>
                    </div>
                  </div>

                  {/* View-only Deductions */}
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase">Deductions</h4>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>SSS</span>
                        <span className="font-mono text-red-500">-{formatCurrency(selectedRecord.sssDeduction || 0)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>PhilHealth</span>
                        <span className="font-mono text-red-500">-{formatCurrency(selectedRecord.philhealthDeduction || 0)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Pag-IBIG</span>
                        <span className="font-mono text-red-500">-{formatCurrency(selectedRecord.pagibigDeduction || 0)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Withholding Tax</span>
                        <span className="font-mono text-red-500">-{formatCurrency(selectedRecord.taxDeduction || 0)}</span>
                      </div>
                      {parseFloat(String(selectedRecord.lateDeduction || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>Late Deduction ({selectedRecord.totalLateMinutes || 0}m)</span>
                          <span className="font-mono text-red-500">-{formatCurrency(selectedRecord.lateDeduction || 0)}</span>
                        </div>
                      )}
                      {parseFloat(String(selectedRecord.undertimeDeduction || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>Undertime ({selectedRecord.totalUndertimeMinutes || 0}m)</span>
                          <span className="font-mono text-red-500">-{formatCurrency(selectedRecord.undertimeDeduction || 0)}</span>
                        </div>
                      )}
                      {parseFloat(String(selectedRecord.otherDeductionAmount || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>Other {selectedRecord.otherDeductionNotes ? `(${selectedRecord.otherDeductionNotes})` : ""}</span>
                          <span className="font-mono text-red-500">-{formatCurrency(selectedRecord.otherDeductionAmount || 0)}</span>
                        </div>
                      )}
                      {parseFloat(String(selectedRecord.cashAdvanceDeduction || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>Cash Advance</span>
                          <span className="font-mono text-red-500">-{formatCurrency(selectedRecord.cashAdvanceDeduction || 0)}</span>
                        </div>
                      )}
                      {parseFloat(String(selectedRecord.sssLoanDeduction || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>SSS Loan</span>
                          <span className="font-mono text-red-500">-{formatCurrency(selectedRecord.sssLoanDeduction || 0)}</span>
                        </div>
                      )}
                      {parseFloat(String(selectedRecord.pagibigLoanDeduction || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>Pag-IBIG Loan</span>
                          <span className="font-mono text-red-500">-{formatCurrency(selectedRecord.pagibigLoanDeduction || 0)}</span>
                        </div>
                      )}
                      {parseFloat(String(selectedRecord.bankLoanDeduction || 0)) > 0 && (
                        <div className="flex justify-between text-sm">
                          <span>Bank Loan</span>
                          <span className="font-mono text-red-500">-{formatCurrency(selectedRecord.bankLoanDeduction || 0)}</span>
                        </div>
                      )}
                      <div className="flex justify-between font-semibold pt-2 border-t text-red-500">
                        <span>Total Deductions</span>
                        <span className="font-mono">-{formatCurrency(selectedRecord.totalDeductions || 0)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Net Pay */}
                  <div className="p-4 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-green-700 dark:text-green-400">Net Pay</span>
                      <span className="text-2xl font-bold font-mono text-green-700 dark:text-green-400">
                        {formatCurrency(selectedRecord.overrideNetPay || selectedRecord.netPay || 0)}
                      </span>
                    </div>
                    {selectedRecord.isEdited && (
                      <p className="text-xs text-muted-foreground mt-2">
                        * Manually adjusted by HR {selectedRecord.editNotes ? `- ${selectedRecord.editNotes}` : ""}
                      </p>
                    )}
                  </div>

                  {/* Meal Allowance (FYI - not included in pay) */}
                  {parseFloat(String(selectedRecord.mealAllowanceTotal || 0)) > 0 && (
                    <div className="p-4 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800">
                      <div className="flex justify-between items-center">
                        <span className="font-semibold text-amber-700 dark:text-amber-400">Meal Allowance</span>
                        <span className="text-lg font-bold font-mono text-amber-700 dark:text-amber-400">
                          {formatCurrency(selectedRecord.mealAllowanceTotal || 0)}
                        </span>
                      </div>
                      <p className="text-xs text-amber-600/70 dark:text-amber-400/70 mt-1">
                        Daily provision — not included in Net Pay
                      </p>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
          <DialogFooter>
            {isEditing ? (
              <>
                <Button variant="outline" onClick={() => setIsEditing(false)} data-testid="button-cancel-payslip-edit">Cancel</Button>
                <Button onClick={handleSavePayslip} disabled={updatePayrollMutation.isPending} data-testid="button-save-payslip">
                  {updatePayrollMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Save Changes
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={() => setShowPayslip(false)} data-testid="button-close-payslip">Close</Button>
                <Button onClick={() => setIsEditing(true)} data-testid="button-edit-payslip">
                  <Pencil className="mr-2 h-4 w-4" />
                  Edit
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Draft Payslips?</AlertDialogTitle>
            <AlertDialogDescription>
              This will delete all draft payslips for the current cutoff period ({selectedCutoff?.start} to {selectedCutoff?.end}).
              This allows you to make corrections to attendance records and then regenerate the payroll.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletePayrollMutation.mutate()}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete-payroll"
            >
              {deletePayrollMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Delete Draft Payslips
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Approve All Confirmation */}
      <AlertDialog open={showApproveAllConfirm} onOpenChange={setShowApproveAllConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Approve All Payslips?</AlertDialogTitle>
            <AlertDialogDescription>
              This will approve all {statusCounts.draft} draft payslips for the current cutoff period
              ({selectedCutoff?.start} to {selectedCutoff?.end}).
              Approved payslips will have cash advance and loan deductions applied.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => approveAllMutation.mutate()}
              data-testid="button-confirm-approve-all"
            >
              {approveAllMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Approve All ({statusCounts.draft})
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Release All Confirmation */}
      <AlertDialog open={showReleaseAllConfirm} onOpenChange={setShowReleaseAllConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Release All Payslips?</AlertDialogTitle>
            <AlertDialogDescription>
              This will release all {statusCounts.approved} approved payslips for the current cutoff period
              ({selectedCutoff?.start} to {selectedCutoff?.end}).
              Released payslips will be visible to employees.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => releaseAllMutation.mutate()}
              data-testid="button-confirm-release-all"
            >
              {releaseAllMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Release All ({statusCounts.approved})
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Revert All Confirmation */}
      <AlertDialog open={showRevertAllConfirm} onOpenChange={setShowRevertAllConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Revert All Payslips to Draft?</AlertDialogTitle>
            <AlertDialogDescription>
              This will revert all {statusCounts.approved + statusCounts.released} approved and released payslips
              back to draft status for the current cutoff period ({selectedCutoff?.start} to {selectedCutoff?.end}).
              Employees will no longer see these payslips until they are released again.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => revertAllMutation.mutate()}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-revert-all"
            >
              {revertAllMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Revert All to Draft
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Approve Selected Confirmation */}
      <AlertDialog open={showApproveSelectedConfirm} onOpenChange={setShowApproveSelectedConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Approve Selected Payslips?</AlertDialogTitle>
            <AlertDialogDescription>
              This will approve {selectedDrafts.length} selected draft payslip{selectedDrafts.length !== 1 ? 's' : ''}.
              Cash advance and loan deductions will be applied.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => approveSelectedMutation.mutate(selectedDrafts.map(r => r.id))}
              data-testid="button-confirm-approve-selected"
            >
              {approveSelectedMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Approve Selected ({selectedDrafts.length})
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Release Selected Confirmation */}
      <AlertDialog open={showReleaseSelectedConfirm} onOpenChange={setShowReleaseSelectedConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Release Selected Payslips?</AlertDialogTitle>
            <AlertDialogDescription>
              This will release {selectedApproved.length} selected approved payslip{selectedApproved.length !== 1 ? 's' : ''}.
              Released payslips will be visible to employees.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => releaseSelectedMutation.mutate(selectedApproved.map(r => r.id))}
              data-testid="button-confirm-release-selected"
            >
              {releaseSelectedMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Release Selected ({selectedApproved.length})
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Revert Selected Confirmation */}
      <AlertDialog open={showRevertSelectedConfirm} onOpenChange={setShowRevertSelectedConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Revert Selected Payslips to Draft?</AlertDialogTitle>
            <AlertDialogDescription>
              This will revert {selectedNonDraft.length} selected payslip{selectedNonDraft.length !== 1 ? 's' : ''} back to draft status.
              Employees will no longer see these payslips until they are released again.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => revertSelectedMutation.mutate(selectedNonDraft.map(r => r.id))}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-revert-selected"
            >
              {revertSelectedMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Revert to Draft ({selectedNonDraft.length})
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
