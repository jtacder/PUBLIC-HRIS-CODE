import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { usePagination } from "@/hooks/use-pagination";
import { TablePagination } from "@/components/ui/table-pagination";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { getPhotoDisplayUrl } from "@/lib/photo-url";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  User,
  FileText,
  Briefcase,
  DollarSign,
  AlertTriangle,
  Search,
  Calendar,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  Shield,
  Wallet,
  TrendingDown,
  CheckCircle2,
  Clock,
  XCircle,
  Camera,
  Loader2,
} from "lucide-react";
import type { Employee, DisciplinaryAction, PayrollRecord, EmployeeDocument, CashAdvance, Loan } from "@shared/schema";
import { getInitials } from "@/lib/utils";

// Loan type display helpers
const loanTypeLabels: Record<string, string> = {
  SSS_Loan: "SSS Loan",
  Pagibig_Loan: "Pag-IBIG Loan",
  Bank_Loan: "Bank Loan",
};

interface Employee201File {
  employee: Employee;
  documents: EmployeeDocument[];
  disciplinaryHistory: DisciplinaryAction[];
  payrollHistory: PayrollRecord[];
  cashAdvances: CashAdvance[];
  loans: Loan[];
}

const formatCurrency = (amount: string | number | null | undefined) => {
  const value = typeof amount === "string" ? parseFloat(amount) : amount || 0;
  return new Intl.NumberFormat('en-PH', {
    style: 'currency',
    currency: 'PHP',
    minimumFractionDigits: 2
  }).format(value);
};

const getCashAdvanceStatusBadge = (status: string) => {
  switch (status) {
    case "Pending":
      return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
    case "Approved":
      return <Badge variant="secondary" className="bg-blue-100 text-blue-800"><CheckCircle2 className="h-3 w-3 mr-1" />Approved</Badge>;
    case "Disbursed":
      return <Badge variant="secondary" className="bg-green-100 text-green-800"><TrendingDown className="h-3 w-3 mr-1" />Disbursed</Badge>;
    case "Fully_Paid":
      return <Badge variant="default"><CheckCircle2 className="h-3 w-3 mr-1" />Fully Paid</Badge>;
    case "Rejected":
      return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

const getLoanStatusBadge = (status: string) => {
  switch (status) {
    case "Pending":
      return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
    case "Approved":
      return <Badge variant="secondary" className="bg-blue-100 text-blue-800"><CheckCircle2 className="h-3 w-3 mr-1" />Approved</Badge>;
    case "Disbursed":
      return <Badge variant="secondary" className="bg-purple-100 text-purple-800"><TrendingDown className="h-3 w-3 mr-1" />Disbursed</Badge>;
    case "Fully_Paid":
      return <Badge variant="default"><CheckCircle2 className="h-3 w-3 mr-1" />Fully Paid</Badge>;
    case "Rejected":
      return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

const statusColors: Record<string, string> = {
  Active: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  Probationary: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  Suspended: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  Terminated: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
};

export default function TwoOhOneFilesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedEmployee, setSelectedEmployee] = useState<string | null>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: employees = [], isLoading } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  // Photo upload mutation for 201 file
  const uploadPhotoMutation = useMutation({
    mutationFn: async ({ employeeId, photoData }: { employeeId: string; photoData: string }) => {
      const response = await apiRequest("PATCH", `/api/employees/${employeeId}`, {
        profilePhotoUrl: photoData,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      if (selectedEmployee) {
        queryClient.invalidateQueries({ queryKey: [`/api/employees/${selectedEmployee}/complete-file`] });
      }
      toast({
        title: "Photo Updated",
        description: "Employee profile photo has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Upload Failed",
        description: "Failed to update profile photo. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedEmployee) return;

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid file",
        description: "Please select an image file (JPEG, PNG, or WebP).",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image under 5MB.",
        variant: "destructive",
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      if (dataUrl) {
        uploadPhotoMutation.mutate({ employeeId: selectedEmployee, photoData: dataUrl });
      }
    };
    reader.readAsDataURL(file);
    // Reset input so the same file can be selected again
    e.target.value = "";
  };

  const isHrOrAdmin = user?.role === "ADMIN" || user?.role === "HR";

  const { data: employeeFile, isLoading: fileLoading, error: fileError } = useQuery<Employee201File>({
    queryKey: [`/api/employees/${selectedEmployee}/complete-file`],
    enabled: !!selectedEmployee,
  });

  // Debug logging
  if (fileError) {
    console.error("201 File Query Error:", fileError);
  }
  if (selectedEmployee && !fileLoading && !employeeFile) {
    console.warn("No data returned for employee:", selectedEmployee);
  }

  const filteredEmployees = employees.filter((employee) => {
    const searchLower = searchQuery.toLowerCase();
    const matchesSearch =
      employee.firstName.toLowerCase().includes(searchLower) ||
      employee.lastName.toLowerCase().includes(searchLower) ||
      employee.employeeNo?.toLowerCase().includes(searchLower);
    const matchesStatus =
      statusFilter === "all" || employee.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Pagination
  const pagination = usePagination(filteredEmployees);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="h-48" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight" data-testid="text-page-title">
          Employee 201 Files
        </h1>
        <p className="text-muted-foreground">
          Complete employee records, documents, and history
        </p>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="flex flex-col gap-4 p-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by name or employee number..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              aria-label="Search by name or employee number"
              data-testid="input-search-employees"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-40" data-testid="select-status-filter">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="Active">Active</SelectItem>
              <SelectItem value="Probationary">Probationary</SelectItem>
              <SelectItem value="Suspended">Suspended</SelectItem>
              <SelectItem value="Terminated">Terminated</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Employee Cards */}
      {filteredEmployees.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <User className="h-12 w-12 text-muted-foreground/50" />
            <h3 className="mt-4 text-lg font-semibold">No employees found</h3>
            <p className="text-sm text-muted-foreground">
              Try adjusting your search filters
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {pagination.paginatedData.map((employee) => (
            <Card
              key={employee.id}
              className="cursor-pointer hover-elevate"
              onClick={() => setSelectedEmployee(employee.id)}
              data-testid={`card-employee-${employee.id}`}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <Avatar className="h-14 w-14 border">
                    {employee.profilePhotoUrl && (
                      <AvatarImage
                        src={getPhotoDisplayUrl(employee.profilePhotoUrl) || ""}
                        alt={`${employee.firstName} ${employee.lastName}`}
                      />
                    )}
                    <AvatarFallback className="text-lg">
                      {getInitials(employee.firstName, employee.lastName)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold">
                        {employee.firstName} {employee.lastName}
                      </h3>
                      <Badge
                        variant="secondary"
                        className={statusColors[employee.status] || ""}
                      >
                        {employee.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {employee.employeeNo || "No ID"}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {employee.position || employee.role}
                    </p>
                    {employee.department && (
                      <p className="text-xs text-muted-foreground">
                        {employee.department}
                      </p>
                    )}
                  </div>
                </div>
                <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
                  <span>
                    Hired:{" "}
                    {employee.startDate
                      ? format(new Date(employee.startDate), "MMM d, yyyy")
                      : "N/A"}
                  </span>
                  <Button variant="ghost" size="sm">
                    View File
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <TablePagination
          currentPage={pagination.currentPage}
          pageSize={pagination.pageSize}
          totalPages={pagination.totalPages}
          totalItems={pagination.totalItems}
          startIndex={pagination.startIndex}
          endIndex={pagination.endIndex}
          canGoNext={pagination.canGoNext}
          canGoPrevious={pagination.canGoPrevious}
          onPageChange={pagination.goToPage}
          onPageSizeChange={pagination.setPageSize}
          onNextPage={pagination.goToNextPage}
          onPreviousPage={pagination.goToPreviousPage}
          onFirstPage={pagination.goToFirstPage}
          onLastPage={pagination.goToLastPage}
        />
        </>
      )}

      {/* 201 File Dialog */}
      <Dialog
        open={!!selectedEmployee}
        onOpenChange={(open) => !open && setSelectedEmployee(null)}
      >
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          {fileLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-8 w-48" />
              <Skeleton className="h-64" />
            </div>
          ) : employeeFile ? (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  <div className="relative group">
                    <Avatar className="h-12 w-12">
                      {employeeFile.employee.profilePhotoUrl && (
                        <AvatarImage
                          src={getPhotoDisplayUrl(employeeFile.employee.profilePhotoUrl) || ""}
                          alt={`${employeeFile.employee.firstName} ${employeeFile.employee.lastName}`}
                        />
                      )}
                      <AvatarFallback className="text-sm">
                        {getInitials(
                          employeeFile.employee.firstName,
                          employeeFile.employee.lastName
                        )}
                      </AvatarFallback>
                    </Avatar>
                    {isHrOrAdmin && (
                      <button
                        type="button"
                        onClick={() => photoInputRef.current?.click()}
                        disabled={uploadPhotoMutation.isPending}
                        className="absolute inset-0 flex items-center justify-center rounded-full bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                        title="Update profile photo"
                      >
                        {uploadPhotoMutation.isPending ? (
                          <Loader2 className="h-5 w-5 text-white animate-spin" />
                        ) : (
                          <Camera className="h-5 w-5 text-white" />
                        )}
                      </button>
                    )}
                    <input
                      ref={photoInputRef}
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="hidden"
                      onChange={handlePhotoSelect}
                    />
                  </div>
                  <div>
                    <span>
                      {employeeFile.employee.firstName}{" "}
                      {employeeFile.employee.lastName}
                    </span>
                    <p className="text-sm font-normal text-muted-foreground">
                      {employeeFile.employee.employeeNo} -{" "}
                      {employeeFile.employee.position || employeeFile.employee.role}
                    </p>
                  </div>
                </DialogTitle>
                <DialogDescription>
                  Complete 201 employee file and records
                </DialogDescription>
              </DialogHeader>

              <Tabs defaultValue="personal" className="mt-4">
                <TabsList className="grid w-full grid-cols-5">
                  <TabsTrigger value="personal">
                    <User className="mr-2 h-4 w-4" />
                    Personal
                  </TabsTrigger>
                  <TabsTrigger value="employment">
                    <Briefcase className="mr-2 h-4 w-4" />
                    Employment
                  </TabsTrigger>
                  <TabsTrigger value="payroll">
                    <DollarSign className="mr-2 h-4 w-4" />
                    Payroll
                  </TabsTrigger>
                  <TabsTrigger value="cash-advances">
                    <Wallet className="mr-2 h-4 w-4" />
                    Cash Adv
                  </TabsTrigger>
                  <TabsTrigger value="loans">
                    <CreditCard className="mr-2 h-4 w-4" />
                    Loans
                  </TabsTrigger>
                  <TabsTrigger value="disciplinary">
                    <AlertTriangle className="mr-2 h-4 w-4" />
                    Records
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="personal" className="space-y-4 pt-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Contact Information</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3 text-sm">
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          <span>{employeeFile.employee.email || "Not provided"}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <span>{employeeFile.employee.phone || "Not provided"}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span>{employeeFile.employee.address || "Not provided"}</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Emergency Contact</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3 text-sm">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span>{employeeFile.employee.emergencyContactName || "Not provided"}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <span>{employeeFile.employee.emergencyContactPhone || "Not provided"}</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Government IDs</CardTitle>
                    </CardHeader>
                    <CardContent className="grid gap-4 text-sm md:grid-cols-2">
                      <div className="flex items-center gap-2">
                        <CreditCard className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-xs text-muted-foreground">SSS Number</p>
                          <p>{employeeFile.employee.sssNo || "Not provided"}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Shield className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-xs text-muted-foreground">PhilHealth</p>
                          <p>{employeeFile.employee.philhealthNo || "Not provided"}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <CreditCard className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-xs text-muted-foreground">Pag-IBIG</p>
                          <p>{employeeFile.employee.pagibigNo || "Not provided"}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-xs text-muted-foreground">TIN</p>
                          <p>{employeeFile.employee.tinNo || "Not provided"}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="employment" className="space-y-4 pt-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Employment Details</CardTitle>
                    </CardHeader>
                    <CardContent className="grid gap-4 text-sm md:grid-cols-2">
                      <div>
                        <p className="text-xs text-muted-foreground">Position</p>
                        <p className="font-medium">{employeeFile.employee.position || "N/A"}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Department</p>
                        <p className="font-medium">{employeeFile.employee.department || "N/A"}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Role</p>
                        <p className="font-medium">{employeeFile.employee.role}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Status</p>
                        <Badge
                          variant="secondary"
                          className={statusColors[employeeFile.employee.status] || ""}
                        >
                          {employeeFile.employee.status}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Start Date</p>
                        <p className="font-medium">
                          {employeeFile.employee.startDate
                            ? format(new Date(employeeFile.employee.startDate), "MMMM d, yyyy")
                            : "N/A"}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Base Rate</p>
                        <p className="font-medium">
                          PHP {parseFloat(employeeFile.employee.baseRate || "0").toLocaleString()} /{" "}
                          {employeeFile.employee.rateType}
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Documents</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {employeeFile.documents.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No documents uploaded</p>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Document</TableHead>
                              <TableHead>Type</TableHead>
                              <TableHead>Uploaded</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {employeeFile.documents.map((doc) => (
                              <TableRow key={doc.id}>
                                <TableCell>{doc.documentName}</TableCell>
                                <TableCell>{doc.documentType}</TableCell>
                                <TableCell>
                                  {doc.createdAt ? format(new Date(doc.createdAt), "MMM d, yyyy") : "-"}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="payroll" className="pt-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Recent Payroll History</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {employeeFile.payrollHistory.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No payroll records found</p>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Cutoff</TableHead>
                              <TableHead className="text-right">Gross</TableHead>
                              <TableHead className="text-right">Deductions</TableHead>
                              <TableHead className="text-right">Net Pay</TableHead>
                              <TableHead>Status</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {employeeFile.payrollHistory.map((record) => (
                              <TableRow key={record.id}>
                                <TableCell>
                                  {format(new Date(record.cutoffStart), "MMM d")} -{" "}
                                  {format(new Date(record.cutoffEnd), "MMM d, yyyy")}
                                </TableCell>
                                <TableCell className="text-right">
                                  PHP {parseFloat(record.grossPay || "0").toLocaleString()}
                                </TableCell>
                                <TableCell className="text-right">
                                  PHP {parseFloat(record.totalDeductions || "0").toLocaleString()}
                                </TableCell>
                                <TableCell className="text-right font-medium">
                                  PHP {parseFloat(record.netPay || "0").toLocaleString()}
                                </TableCell>
                                <TableCell>
                                  <Badge variant="outline">{record.status}</Badge>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="cash-advances" className="space-y-4 pt-4">
                  {/* Cash Advance Summary */}
                  {employeeFile.cashAdvances && employeeFile.cashAdvances.length > 0 && (
                    <div className="grid gap-4 md:grid-cols-3">
                      <Card>
                        <CardContent className="pt-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-2xl font-bold">
                                {formatCurrency(
                                  employeeFile.cashAdvances
                                    .filter(ca => ca.status === "Disbursed")
                                    .reduce((sum, ca) => sum + parseFloat(String(ca.remainingBalance) || "0"), 0)
                                )}
                              </p>
                              <p className="text-sm text-muted-foreground">Total Outstanding</p>
                            </div>
                            <Wallet className="h-8 w-8 text-orange-500" />
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-2xl font-bold">
                                {employeeFile.cashAdvances.filter(ca => ca.status === "Disbursed").length}
                              </p>
                              <p className="text-sm text-muted-foreground">Active Advances</p>
                            </div>
                            <TrendingDown className="h-8 w-8 text-blue-500" />
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-2xl font-bold">
                                {formatCurrency(
                                  employeeFile.cashAdvances
                                    .filter(ca => ca.status === "Disbursed" && ca.deductionPerCutoff)
                                    .reduce((sum, ca) => sum + parseFloat(String(ca.deductionPerCutoff) || "0"), 0)
                                )}
                              </p>
                              <p className="text-sm text-muted-foreground">Deduction/Cutoff</p>
                            </div>
                            <DollarSign className="h-8 w-8 text-green-500" />
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  )}

                  {/* Cash Advance List */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Cash Advance History</CardTitle>
                      <CardDescription>All cash advance requests and their status</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {!employeeFile.cashAdvances || employeeFile.cashAdvances.length === 0 ? (
                        <div className="flex flex-col items-center py-8 text-center">
                          <Wallet className="h-8 w-8 text-muted-foreground/50" />
                          <p className="mt-2 font-medium">No Cash Advances</p>
                          <p className="text-sm text-muted-foreground">
                            This employee has no cash advance records
                          </p>
                        </div>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Date Requested</TableHead>
                              <TableHead className="text-right">Amount</TableHead>
                              <TableHead className="text-right">Remaining</TableHead>
                              <TableHead className="text-right">Per Cutoff</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead>Reason</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {employeeFile.cashAdvances.map((advance) => (
                              <TableRow key={advance.id}>
                                <TableCell>
                                  {advance.createdAt
                                    ? format(new Date(advance.createdAt), "MMM d, yyyy")
                                    : "-"}
                                </TableCell>
                                <TableCell className="text-right font-semibold">
                                  {formatCurrency(advance.amount)}
                                </TableCell>
                                <TableCell className="text-right">
                                  {advance.remainingBalance
                                    ? formatCurrency(advance.remainingBalance)
                                    : "-"}
                                </TableCell>
                                <TableCell className="text-right">
                                  {advance.deductionPerCutoff
                                    ? formatCurrency(advance.deductionPerCutoff)
                                    : "-"}
                                </TableCell>
                                <TableCell>{getCashAdvanceStatusBadge(advance.status)}</TableCell>
                                <TableCell className="max-w-xs truncate text-sm text-muted-foreground">
                                  {advance.reason || "-"}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="loans" className="space-y-4 pt-4">
                  {/* Loans Summary */}
                  {employeeFile.loans && employeeFile.loans.length > 0 && (
                    <div className="grid gap-4 md:grid-cols-3">
                      <Card>
                        <CardContent className="pt-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-2xl font-bold">
                                {formatCurrency(
                                  employeeFile.loans
                                    .filter(l => l.status === "Disbursed")
                                    .reduce((sum, l) => sum + parseFloat(String(l.remainingBalance) || "0"), 0)
                                )}
                              </p>
                              <p className="text-sm text-muted-foreground">Total Outstanding</p>
                            </div>
                            <CreditCard className="h-8 w-8 text-purple-500" />
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-2xl font-bold">
                                {employeeFile.loans.filter(l => l.status === "Disbursed").length}
                              </p>
                              <p className="text-sm text-muted-foreground">Active Loans</p>
                            </div>
                            <TrendingDown className="h-8 w-8 text-blue-500" />
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-2xl font-bold">
                                {formatCurrency(
                                  employeeFile.loans
                                    .filter(l => l.status === "Disbursed" && l.deductionPerCutoff)
                                    .reduce((sum, l) => sum + parseFloat(String(l.deductionPerCutoff) || "0"), 0)
                                )}
                              </p>
                              <p className="text-sm text-muted-foreground">Deduction/Cutoff</p>
                            </div>
                            <DollarSign className="h-8 w-8 text-green-500" />
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  )}

                  {/* Loans List */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Loan History</CardTitle>
                      <CardDescription>All loan requests and their status</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {!employeeFile.loans || employeeFile.loans.length === 0 ? (
                        <div className="flex flex-col items-center py-8 text-center">
                          <CreditCard className="h-8 w-8 text-muted-foreground/50" />
                          <p className="mt-2 font-medium">No Loans</p>
                          <p className="text-sm text-muted-foreground">
                            This employee has no loan records
                          </p>
                        </div>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Date Requested</TableHead>
                              <TableHead>Type</TableHead>
                              <TableHead className="text-right">Amount</TableHead>
                              <TableHead className="text-right">Interest</TableHead>
                              <TableHead className="text-right">Total</TableHead>
                              <TableHead className="text-right">Remaining</TableHead>
                              <TableHead>Status</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {employeeFile.loans.map((loan) => (
                              <TableRow key={loan.id}>
                                <TableCell>
                                  {loan.createdAt
                                    ? format(new Date(loan.createdAt), "MMM d, yyyy")
                                    : "-"}
                                </TableCell>
                                <TableCell className="font-medium">
                                  {loanTypeLabels[loan.loanType] || loan.loanType}
                                </TableCell>
                                <TableCell className="text-right">
                                  {formatCurrency(loan.amount)}
                                </TableCell>
                                <TableCell className="text-right">
                                  {loan.interest && parseFloat(loan.interest) > 0
                                    ? formatCurrency(loan.interest)
                                    : "-"}
                                </TableCell>
                                <TableCell className="text-right font-semibold">
                                  {formatCurrency(loan.totalAmount)}
                                </TableCell>
                                <TableCell className="text-right">
                                  {loan.remainingBalance
                                    ? formatCurrency(loan.remainingBalance)
                                    : "-"}
                                </TableCell>
                                <TableCell>{getLoanStatusBadge(loan.status)}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="disciplinary" className="pt-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Disciplinary History</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {employeeFile.disciplinaryHistory.length === 0 ? (
                        <div className="flex flex-col items-center py-8 text-center">
                          <Shield className="h-8 w-8 text-green-500" />
                          <p className="mt-2 font-medium">Clean Record</p>
                          <p className="text-sm text-muted-foreground">
                            No disciplinary actions on file
                          </p>
                        </div>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Date</TableHead>
                              <TableHead>Violation</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead>Sanction</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {employeeFile.disciplinaryHistory.map((action) => (
                              <TableRow key={action.id}>
                                <TableCell>
                                  {format(new Date(action.incidentDate), "MMM d, yyyy")}
                                </TableCell>
                                <TableCell>{action.violationType.replace(/_/g, " ")}</TableCell>
                                <TableCell>
                                  <Badge variant="outline">{action.status.replace(/_/g, " ")}</Badge>
                                </TableCell>
                                <TableCell>{action.sanction || "-"}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          ) : (
            <div className="py-8 text-center">
              <p className="text-muted-foreground">Failed to load employee file</p>
              {fileError && (
                <p className="text-sm text-red-500 mt-2">
                  Error: {fileError instanceof Error ? fileError.message : String(fileError)}
                </p>
              )}
              <p className="text-xs text-muted-foreground mt-2">
                Employee ID: {selectedEmployee}
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
