import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { usePagination } from "@/hooks/use-pagination";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { getPhotoDisplayUrl } from "@/lib/photo-url";
import { TablePagination } from "@/components/ui/table-pagination";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Calendar,
  Wallet,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  DollarSign,
  FileText,
  Ban,
  Send,
  TrendingDown,
  Landmark,
  Building2,
  Banknote,
  Edit3,
  History,
  UserPlus,
  Plus,
} from "lucide-react";
import { formatDate, formatCurrency, getInitials } from "@/lib/utils";
import { SearchableEmployeeSelect } from "@/components/searchable-employee-select";
import type { LeaveRequest, CashAdvance, Employee, LeaveTypeRecord, Loan } from "@shared/schema";

// Loan type display helpers
const loanTypeLabels: Record<string, string> = {
  SSS_Loan: "SSS Loan",
  Pagibig_Loan: "Pag-IBIG Loan",
  Bank_Loan: "Bank Loan",
};

const loanTypeIcons: Record<string, any> = {
  SSS_Loan: Landmark,
  Pagibig_Loan: Building2,
  Bank_Loan: Banknote,
};

type LeaveStatusFilter = "All" | "Pending" | "Approved" | "Rejected";
type CashAdvanceStatusFilter = "All" | "Pending" | "Approved" | "Disbursed" | "Rejected";
type LoanStatusFilter = "All" | "Pending" | "Approved" | "Disbursed" | "Rejected" | "Fully_Paid";

const approveLeaveSchema = z.object({
  remarks: z.string().optional(),
});

const rejectLeaveSchema = z.object({
  remarks: z.string().min(1, "Remarks are required when rejecting"),
});

const approveCashAdvanceSchema = z.object({
  deductionPerCutoff: z.string().min(1, "Deduction amount is required"),
});

const approveLoanSchema = z.object({
  deductionPerCutoff: z.string().min(1, "Deduction amount is required"),
  interest: z.string().optional(),
  remarks: z.string().optional(),
  startDeductionDate: z.string().optional(),
});

const balanceAdjustmentSchema = z.object({
  newBalance: z.string().min(1, "New balance is required"),
  adjustmentType: z.string().min(1, "Adjustment type is required"),
  reason: z.string().min(20, "Reason must be at least 20 characters for accountability"),
});

// On-behalf submission schemas
const submitLeaveOnBehalfSchema = z.object({
  employeeId: z.string().min(1, "Please select an employee"),
  leaveTypeId: z.string().min(1, "Please select a leave type"),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().min(1, "End date is required"),
  totalDays: z.string().min(1, "Total days is required"),
  reason: z.string().optional(),
});

const submitCashAdvanceOnBehalfSchema = z.object({
  employeeId: z.string().min(1, "Please select an employee"),
  amount: z.string().min(1, "Amount is required"),
  reason: z.string().optional(),
});

const submitLoanOnBehalfSchema = z.object({
  employeeId: z.string().min(1, "Please select an employee"),
  loanType: z.string().min(1, "Please select a loan type"),
  amount: z.string().min(1, "Amount is required"),
  interest: z.string().optional(),
  reason: z.string().optional(),
});

type ApproveLeaveValues = z.infer<typeof approveLeaveSchema>;
type RejectLeaveValues = z.infer<typeof rejectLeaveSchema>;
type ApproveCashAdvanceValues = z.infer<typeof approveCashAdvanceSchema>;
type ApproveLoanValues = z.infer<typeof approveLoanSchema>;
type BalanceAdjustmentValues = z.infer<typeof balanceAdjustmentSchema>;
type SubmitLeaveOnBehalfValues = z.infer<typeof submitLeaveOnBehalfSchema>;
type SubmitCashAdvanceOnBehalfValues = z.infer<typeof submitCashAdvanceOnBehalfSchema>;
type SubmitLoanOnBehalfValues = z.infer<typeof submitLoanOnBehalfSchema>;

export default function HRRequestsPage() {
  const { toast } = useToast();
  const [leaveStatusFilter, setLeaveStatusFilter] = useState<LeaveStatusFilter>("All");
  const [cashAdvanceStatusFilter, setCashAdvanceStatusFilter] = useState<CashAdvanceStatusFilter>("All");
  const [loanStatusFilter, setLoanStatusFilter] = useState<LoanStatusFilter>("All");
  const [leaveEmployeeFilter, setLeaveEmployeeFilter] = useState<string>("all");
  const [cashAdvanceEmployeeFilter, setCashAdvanceEmployeeFilter] = useState<string>("all");
  const [loanEmployeeFilter, setLoanEmployeeFilter] = useState<string>("all");
  const [loanTypeFilter, setLoanTypeFilter] = useState<string>("all");

  // Dialog states
  const [selectedLeaveRequest, setSelectedLeaveRequest] = useState<LeaveRequest | null>(null);
  const [selectedCashAdvance, setSelectedCashAdvance] = useState<CashAdvance | null>(null);
  const [selectedLoan, setSelectedLoan] = useState<Loan | null>(null);
  const [isApproveLeaveDialogOpen, setIsApproveLeaveDialogOpen] = useState(false);
  const [isRejectLeaveDialogOpen, setIsRejectLeaveDialogOpen] = useState(false);
  const [isApproveCashDialogOpen, setIsApproveCashDialogOpen] = useState(false);
  const [isRejectCashDialogOpen, setIsRejectCashDialogOpen] = useState(false);
  const [isDisburseCashDialogOpen, setIsDisburseCashDialogOpen] = useState(false);
  const [isApproveLoanDialogOpen, setIsApproveLoanDialogOpen] = useState(false);
  const [isRejectLoanDialogOpen, setIsRejectLoanDialogOpen] = useState(false);
  const [isDisburseLoanDialogOpen, setIsDisburseLoanDialogOpen] = useState(false);
  const [isAdjustBalanceDialogOpen, setIsAdjustBalanceDialogOpen] = useState(false);
  const [adjustBalanceEntity, setAdjustBalanceEntity] = useState<{ type: "CashAdvance" | "Loan"; id: string; currentBalance: string } | null>(null);

  // On-behalf submission dialog states
  const [isSubmitLeaveOnBehalfDialogOpen, setIsSubmitLeaveOnBehalfDialogOpen] = useState(false);
  const [isSubmitCashAdvanceOnBehalfDialogOpen, setIsSubmitCashAdvanceOnBehalfDialogOpen] = useState(false);
  const [isSubmitLoanOnBehalfDialogOpen, setIsSubmitLoanOnBehalfDialogOpen] = useState(false);

  // Leave balance state for on-behalf submission
  const [selectedEmployeeForLeave, setSelectedEmployeeForLeave] = useState<string>("");
  const [selectedLeaveTypeForBalance, setSelectedLeaveTypeForBalance] = useState<string>("");

  // Fetch leave balance for selected employee
  const { data: leaveBalanceData } = useQuery<{
    employeeId: string;
    year: number;
    balances: Array<{
      leaveTypeId: string;
      leaveTypeName: string;
      leaveTypeCode: string;
      isPaid: boolean;
      available: number;
      effectiveAvailable: number;
      used: number;
      pending: number;
      totalAllocated: number;
      hasAllocation: boolean;
    }>;
  }>({
    queryKey: ["/api/leave-requests/balance", selectedEmployeeForLeave],
    queryFn: async () => {
      if (!selectedEmployeeForLeave) return null;
      const res = await apiRequest("GET", `/api/leave-requests/balance/${selectedEmployeeForLeave}`);
      return res.json();
    },
    enabled: !!selectedEmployeeForLeave,
  });

  // Fetch data
  const { data: leaveRequests, isLoading: leaveLoading } = useQuery<LeaveRequest[]>({
    queryKey: ["/api/leave-requests"],
  });

  const { data: cashAdvances, isLoading: cashLoading } = useQuery<CashAdvance[]>({
    queryKey: ["/api/cash-advances"],
  });

  const { data: loans, isLoading: loansLoading } = useQuery<Loan[]>({
    queryKey: ["/api/loans"],
  });

  const { data: employees } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const { data: leaveTypes } = useQuery<LeaveTypeRecord[]>({
    queryKey: ["/api/leave-types"],
  });

  // Create employee map for easy lookup
  const employeeMap = useMemo(() => {
    return new Map(employees?.map(e => [e.id, e]) || []);
  }, [employees]);

  // Forms
  const approveLeaveForm = useForm<ApproveLeaveValues>({
    resolver: zodResolver(approveLeaveSchema),
    defaultValues: { remarks: "" },
  });

  const rejectLeaveForm = useForm<RejectLeaveValues>({
    resolver: zodResolver(rejectLeaveSchema),
    defaultValues: { remarks: "" },
  });

  const approveCashAdvanceForm = useForm<ApproveCashAdvanceValues>({
    resolver: zodResolver(approveCashAdvanceSchema),
    defaultValues: { deductionPerCutoff: "" },
  });

  const approveLoanForm = useForm<ApproveLoanValues>({
    resolver: zodResolver(approveLoanSchema),
    defaultValues: { deductionPerCutoff: "", interest: "", remarks: "", startDeductionDate: "" },
  });

  const balanceAdjustmentForm = useForm<BalanceAdjustmentValues>({
    resolver: zodResolver(balanceAdjustmentSchema),
    defaultValues: { newBalance: "", adjustmentType: "", reason: "" },
  });

  // On-behalf submission forms
  const submitLeaveOnBehalfForm = useForm<SubmitLeaveOnBehalfValues>({
    resolver: zodResolver(submitLeaveOnBehalfSchema),
    defaultValues: { employeeId: "", leaveTypeId: "", startDate: "", endDate: "", totalDays: "1", reason: "" },
  });

  const submitCashAdvanceOnBehalfForm = useForm<SubmitCashAdvanceOnBehalfValues>({
    resolver: zodResolver(submitCashAdvanceOnBehalfSchema),
    defaultValues: { employeeId: "", amount: "", reason: "" },
  });

  const submitLoanOnBehalfForm = useForm<SubmitLoanOnBehalfValues>({
    resolver: zodResolver(submitLoanOnBehalfSchema),
    defaultValues: { employeeId: "", loanType: "", amount: "", interest: "0", reason: "" },
  });

  // Mutations for Leave Requests
  const approveLeaveRequestMutation = useMutation({
    mutationFn: async ({ id, remarks }: { id: string; remarks?: string }) => {
      const response = await apiRequest("POST", `/api/leave-requests/${id}/approve`, { remarks });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leave-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      setIsApproveLeaveDialogOpen(false);
      setSelectedLeaveRequest(null);
      approveLeaveForm.reset();
      toast({
        title: "Leave Request Approved",
        description: "The leave request has been approved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to approve leave request.",
        variant: "destructive",
      });
    },
  });

  const rejectLeaveRequestMutation = useMutation({
    mutationFn: async ({ id, remarks }: { id: string; remarks: string }) => {
      const response = await apiRequest("POST", `/api/leave-requests/${id}/reject`, { remarks });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leave-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsRejectLeaveDialogOpen(false);
      setSelectedLeaveRequest(null);
      rejectLeaveForm.reset();
      toast({
        title: "Leave Request Rejected",
        description: "The leave request has been rejected.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to reject leave request.",
        variant: "destructive",
      });
    },
  });

  // Mutations for Cash Advances
  const approveCashAdvanceMutation = useMutation({
    mutationFn: async ({ id, deductionPerCutoff }: { id: string; deductionPerCutoff: string }) => {
      const response = await apiRequest("POST", `/api/cash-advances/${id}/approve`, { deductionPerCutoff });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cash-advances"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsApproveCashDialogOpen(false);
      setSelectedCashAdvance(null);
      approveCashAdvanceForm.reset();
      toast({
        title: "Cash Advance Approved",
        description: "The cash advance has been approved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to approve cash advance.",
        variant: "destructive",
      });
    },
  });

  const rejectCashAdvanceMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("POST", `/api/cash-advances/${id}/reject`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cash-advances"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsRejectCashDialogOpen(false);
      setSelectedCashAdvance(null);
      toast({
        title: "Cash Advance Rejected",
        description: "The cash advance has been rejected.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to reject cash advance.",
        variant: "destructive",
      });
    },
  });

  const disburseCashAdvanceMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("POST", `/api/cash-advances/${id}/disburse`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cash-advances"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsDisburseCashDialogOpen(false);
      setSelectedCashAdvance(null);
      toast({
        title: "Cash Advance Disbursed",
        description: "The cash advance has been marked as disbursed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to disburse cash advance.",
        variant: "destructive",
      });
    },
  });

  // Mutations for Loans
  const approveLoanMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: string; deductionPerCutoff: string; interest?: string; remarks?: string; startDeductionDate?: string }) => {
      const response = await apiRequest("POST", `/api/loans/${id}/approve`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/loans"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsApproveLoanDialogOpen(false);
      setSelectedLoan(null);
      approveLoanForm.reset();
      toast({
        title: "Loan Approved",
        description: "The loan has been approved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to approve loan.",
        variant: "destructive",
      });
    },
  });

  const rejectLoanMutation = useMutation({
    mutationFn: async ({ id, remarks }: { id: string; remarks?: string }) => {
      const response = await apiRequest("POST", `/api/loans/${id}/reject`, { remarks });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/loans"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsRejectLoanDialogOpen(false);
      setSelectedLoan(null);
      toast({
        title: "Loan Rejected",
        description: "The loan has been rejected.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to reject loan.",
        variant: "destructive",
      });
    },
  });

  const disburseLoanMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("POST", `/api/loans/${id}/disburse`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/loans"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsDisburseLoanDialogOpen(false);
      setSelectedLoan(null);
      toast({
        title: "Loan Disbursed",
        description: "The loan has been marked as disbursed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to disburse loan.",
        variant: "destructive",
      });
    },
  });

  // Balance Adjustment Mutation
  const adjustBalanceMutation = useMutation({
    mutationFn: async ({ entityType, entityId, ...data }: { entityType: "CashAdvance" | "Loan"; entityId: string; newBalance: string; adjustmentType: string; reason: string }) => {
      const endpoint = entityType === "CashAdvance"
        ? `/api/balance-adjustments/cash-advances/${entityId}/adjust`
        : `/api/balance-adjustments/loans/${entityId}/adjust`;
      const response = await apiRequest("POST", endpoint, data);
      return response.json();
    },
    onSuccess: (_, variables) => {
      if (variables.entityType === "CashAdvance") {
        queryClient.invalidateQueries({ queryKey: ["/api/cash-advances"] });
      } else {
        queryClient.invalidateQueries({ queryKey: ["/api/loans"] });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsAdjustBalanceDialogOpen(false);
      setAdjustBalanceEntity(null);
      balanceAdjustmentForm.reset();
      toast({
        title: "Balance Adjusted",
        description: "The balance has been adjusted and recorded in the audit trail.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to adjust balance.",
        variant: "destructive",
      });
    },
  });

  // On-behalf submission mutations
  const submitLeaveOnBehalfMutation = useMutation({
    mutationFn: async (data: SubmitLeaveOnBehalfValues) => {
      const response = await apiRequest("POST", "/api/leave-requests", data);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to submit leave request");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leave-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/leave-requests/balance", selectedEmployeeForLeave] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsSubmitLeaveOnBehalfDialogOpen(false);
      setSelectedEmployeeForLeave("");
      submitLeaveOnBehalfForm.reset();
      toast({
        title: "Leave Request Submitted",
        description: "Leave request has been submitted on behalf of the employee.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit leave request.",
        variant: "destructive",
      });
    },
  });

  const submitCashAdvanceOnBehalfMutation = useMutation({
    mutationFn: async (data: SubmitCashAdvanceOnBehalfValues) => {
      const response = await apiRequest("POST", "/api/cash-advances", data);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to submit cash advance request");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cash-advances"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsSubmitCashAdvanceOnBehalfDialogOpen(false);
      submitCashAdvanceOnBehalfForm.reset();
      toast({
        title: "Cash Advance Submitted",
        description: "Cash advance request has been submitted on behalf of the employee.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit cash advance request.",
        variant: "destructive",
      });
    },
  });

  const submitLoanOnBehalfMutation = useMutation({
    mutationFn: async (data: SubmitLoanOnBehalfValues) => {
      const response = await apiRequest("POST", "/api/loans", data);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to submit loan application");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/loans"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsSubmitLoanOnBehalfDialogOpen(false);
      submitLoanOnBehalfForm.reset();
      toast({
        title: "Loan Submitted",
        description: "Loan application has been submitted on behalf of the employee.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit loan application.",
        variant: "destructive",
      });
    },
  });

  // Filter leave requests
  const filteredLeaveRequests = useMemo(() => {
    if (!leaveRequests) return [];
    return leaveRequests.filter(r => {
      const matchesStatus = leaveStatusFilter === "All" || r.status === leaveStatusFilter;
      const matchesEmployee = leaveEmployeeFilter === "all" || r.employeeId === leaveEmployeeFilter;
      return matchesStatus && matchesEmployee;
    });
  }, [leaveRequests, leaveStatusFilter, leaveEmployeeFilter]);

  // Filter cash advances
  const filteredCashAdvances = useMemo(() => {
    if (!cashAdvances) return [];
    return cashAdvances.filter(c => {
      const matchesStatus = cashAdvanceStatusFilter === "All" || c.status === cashAdvanceStatusFilter;
      const matchesEmployee = cashAdvanceEmployeeFilter === "all" || c.employeeId === cashAdvanceEmployeeFilter;
      return matchesStatus && matchesEmployee;
    });
  }, [cashAdvances, cashAdvanceStatusFilter, cashAdvanceEmployeeFilter]);

  // Filter loans
  const filteredLoans = useMemo(() => {
    if (!loans) return [];
    return loans.filter(l => {
      const matchesStatus = loanStatusFilter === "All" || l.status === loanStatusFilter;
      const matchesEmployee = loanEmployeeFilter === "all" || l.employeeId === loanEmployeeFilter;
      const matchesType = loanTypeFilter === "all" || l.loanType === loanTypeFilter;
      return matchesStatus && matchesEmployee && matchesType;
    });
  }, [loans, loanStatusFilter, loanEmployeeFilter, loanTypeFilter]);

  // Pagination for each request type
  const leavePagination = usePagination(filteredLeaveRequests);
  const cashAdvancePagination = usePagination(filteredCashAdvances);
  const loanPagination = usePagination(filteredLoans);

  // Summary statistics
  const pendingLeaveCount = leaveRequests?.filter(r => r.status === "Pending").length ?? 0;
  const pendingCashCount = cashAdvances?.filter(c => c.status === "Pending").length ?? 0;
  const pendingLoanCount = loans?.filter(l => l.status === "Pending").length ?? 0;

  const totalDisbursedThisMonth = useMemo(() => {
    if (!cashAdvances) return 0;
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    return cashAdvances
      .filter(c => {
        if (!c.disbursedAt) return false;
        const disbursedDate = new Date(c.disbursedAt);
        return disbursedDate.getMonth() === currentMonth &&
               disbursedDate.getFullYear() === currentYear;
      })
      .reduce((sum, c) => sum + parseFloat(c.amount || "0"), 0);
  }, [cashAdvances]);

  // Total outstanding balance from all disbursed cash advances
  const totalOutstandingBalance = useMemo(() => {
    if (!cashAdvances) return 0;
    return cashAdvances
      .filter(c => c.status === "Disbursed")
      .reduce((sum, c) => sum + parseFloat(String(c.remainingBalance) || "0"), 0);
  }, [cashAdvances]);

  // Total outstanding loan balance
  const totalOutstandingLoanBalance = useMemo(() => {
    if (!loans) return 0;
    return loans
      .filter(l => l.status === "Disbursed")
      .reduce((sum, l) => sum + parseFloat(String(l.remainingBalance) || "0"), 0);
  }, [loans]);

  // Helper functions
  const getLeaveTypeName = (typeId: string) => {
    return leaveTypes?.find(t => t.id === typeId)?.name || "Unknown";
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Approved":
        return <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">Approved</Badge>;
      case "Rejected":
        return <Badge variant="destructive">Rejected</Badge>;
      case "Pending":
        return <Badge className="bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400">Pending</Badge>;
      case "Disbursed":
        return <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400">Disbursed</Badge>;
      case "Fully_Paid":
        return <Badge variant="outline">Fully Paid</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getEmployeeName = (employeeId: string) => {
    const employee = employeeMap.get(employeeId);
    if (!employee) return "Unknown Employee";
    return `${employee.firstName} ${employee.lastName}`;
  };

  const getEmployeeDetails = (employeeId: string) => {
    return employeeMap.get(employeeId);
  };

  // Dialog handlers for Leave Requests
  const handleApproveLeave = (request: LeaveRequest) => {
    setSelectedLeaveRequest(request);
    approveLeaveForm.reset({ remarks: "" });
    setIsApproveLeaveDialogOpen(true);
  };

  const handleRejectLeave = (request: LeaveRequest) => {
    setSelectedLeaveRequest(request);
    rejectLeaveForm.reset({ remarks: "" });
    setIsRejectLeaveDialogOpen(true);
  };

  // Dialog handlers for Cash Advances
  const handleApproveCash = (advance: CashAdvance) => {
    setSelectedCashAdvance(advance);
    approveCashAdvanceForm.reset({ deductionPerCutoff: "" });
    setIsApproveCashDialogOpen(true);
  };

  const handleRejectCash = (advance: CashAdvance) => {
    setSelectedCashAdvance(advance);
    setIsRejectCashDialogOpen(true);
  };

  const handleDisburseCash = (advance: CashAdvance) => {
    setSelectedCashAdvance(advance);
    setIsDisburseCashDialogOpen(true);
  };

  // Dialog handlers for Loans
  const handleApproveLoan = (loan: Loan) => {
    setSelectedLoan(loan);
    approveLoanForm.reset({ deductionPerCutoff: "", interest: "", remarks: "", startDeductionDate: "" });
    setIsApproveLoanDialogOpen(true);
  };

  const handleRejectLoan = (loan: Loan) => {
    setSelectedLoan(loan);
    setIsRejectLoanDialogOpen(true);
  };

  const handleDisburseLoan = (loan: Loan) => {
    setSelectedLoan(loan);
    setIsDisburseLoanDialogOpen(true);
  };

  // Balance adjustment handler
  const handleAdjustBalance = (type: "CashAdvance" | "Loan", id: string, currentBalance: string) => {
    setAdjustBalanceEntity({ type, id, currentBalance });
    balanceAdjustmentForm.reset({ newBalance: currentBalance, adjustmentType: "", reason: "" });
    setIsAdjustBalanceDialogOpen(true);
  };

  if (leaveLoading || cashLoading || loansLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid gap-4 md:grid-cols-3">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Leave & Loans</h1>
        <p className="text-muted-foreground">Manage leave requests, cash advances, and loans</p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{pendingLeaveCount}</p>
                <p className="text-sm text-muted-foreground">Pending Leave</p>
              </div>
              <Calendar className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{pendingCashCount}</p>
                <p className="text-sm text-muted-foreground">Pending Cash Adv</p>
              </div>
              <Wallet className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{pendingLoanCount}</p>
                <p className="text-sm text-muted-foreground">Pending Loans</p>
              </div>
              <Landmark className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{formatCurrency(totalOutstandingBalance)}</p>
                <p className="text-sm text-muted-foreground">CA Outstanding</p>
              </div>
              <TrendingDown className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{formatCurrency(totalOutstandingLoanBalance)}</p>
                <p className="text-sm text-muted-foreground">Loan Outstanding</p>
              </div>
              <TrendingDown className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{formatCurrency(totalDisbursedThisMonth)}</p>
                <p className="text-sm text-muted-foreground">Disbursed This Month</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="leave" className="space-y-4">
        <TabsList>
          <TabsTrigger value="leave" data-testid="tab-leave">
            <Calendar className="h-4 w-4 mr-2" />
            Leave Requests
          </TabsTrigger>
          <TabsTrigger value="cash-advance" data-testid="tab-cash-advance">
            <Wallet className="h-4 w-4 mr-2" />
            Cash Advances
          </TabsTrigger>
          <TabsTrigger value="loans" data-testid="tab-loans">
            <Landmark className="h-4 w-4 mr-2" />
            Loans
          </TabsTrigger>
        </TabsList>

        {/* Leave Requests Tab */}
        <TabsContent value="leave" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-col gap-4 space-y-0 pb-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4">
                <CardTitle className="text-lg font-medium">Leave Requests</CardTitle>
                <Button
                  size="sm"
                  onClick={() => {
                    submitLeaveOnBehalfForm.reset();
                    setIsSubmitLeaveOnBehalfDialogOpen(true);
                  }}
                  data-testid="submit-leave-on-behalf"
                >
                  <UserPlus className="h-4 w-4 mr-2" />
                  Submit on Behalf
                </Button>
              </div>
              <div className="flex flex-col gap-2 sm:flex-row">
                <SearchableEmployeeSelect
                  employees={employees || []}
                  value={leaveEmployeeFilter}
                  onValueChange={setLeaveEmployeeFilter}
                  placeholder="Filter by employee..."
                  allowAll
                  allLabel="All Employees"
                  className="w-full sm:w-[200px]"
                  data-testid="filter-leave-employee"
                />
                <Select value={leaveStatusFilter} onValueChange={(val) => setLeaveStatusFilter(val as LeaveStatusFilter)}>
                  <SelectTrigger className="w-full sm:w-[150px]" data-testid="filter-leave-status">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Status</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Approved">Approved</SelectItem>
                    <SelectItem value="Rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {filteredLeaveRequests.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No leave requests found.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Employee</TableHead>
                        <TableHead>Leave Type</TableHead>
                        <TableHead>Date Range</TableHead>
                        <TableHead>Days</TableHead>
                        <TableHead>Reason</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {leavePagination.paginatedData.map((request) => {
                        // Use embedded employee data from enhanced response, fallback to map lookup
                        const embeddedEmployee = (request as any).employee;
                        const employee = embeddedEmployee || getEmployeeDetails(request.employeeId);
                        const embeddedSubmitter = (request as any).submittedBy;
                        const submitter = embeddedSubmitter || ((request as any).submittedById ? getEmployeeDetails((request as any).submittedById) : null);
                        const isOnBehalf = (request as any).submittedById && (request as any).submittedById !== request.employeeId;
                        const paidDays = parseFloat((request as any).paidDays || request.totalDays);
                        const unpaidDays = parseFloat((request as any).unpaidDays || "0");
                        const hasUnpaidDays = unpaidDays > 0;
                        return (
                          <TableRow key={request.id} data-testid={`leave-row-${request.id}`}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Avatar className="h-8 w-8">
                                  <AvatarImage src={getPhotoDisplayUrl(employee?.profilePhotoUrl) || undefined} />
                                  <AvatarFallback>{getInitials(employee?.firstName, employee?.lastName)}</AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="text-sm font-medium">
                                    {employee ? `${employee.firstName} ${employee.lastName}` : "Unknown Employee"}
                                  </p>
                                  <p className="text-xs text-muted-foreground">{employee?.employeeNo}</p>
                                  {isOnBehalf && submitter && (
                                    <p className="text-xs text-blue-600 dark:text-blue-400 flex items-center gap-1">
                                      <UserPlus className="h-3 w-3" />
                                      Filed by {submitter.firstName} {submitter.lastName}
                                    </p>
                                  )}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell className="text-sm">{getLeaveTypeName(request.leaveTypeId)}</TableCell>
                            <TableCell className="text-sm">
                              <div className="space-y-1">
                                <p>{formatDate(request.startDate)}</p>
                                <p className="text-muted-foreground">to {formatDate(request.endDate)}</p>
                              </div>
                            </TableCell>
                            <TableCell className="text-sm font-medium">
                              <div>
                                <span>{request.totalDays}</span>
                                {hasUnpaidDays && (
                                  <div className="text-xs">
                                    <span className="text-green-600">{paidDays} paid</span>
                                    <span className="text-orange-600 ml-1">/ {unpaidDays} unpaid</span>
                                  </div>
                                )}
                              </div>
                            </TableCell>
                            <TableCell className="text-sm max-w-xs truncate">
                              {request.reason || <span className="text-muted-foreground italic">No reason provided</span>}
                            </TableCell>
                            <TableCell>{getStatusBadge(request.status)}</TableCell>
                            <TableCell>
                              {request.status === "Pending" && (
                                <div className="flex gap-2">
                                  <Button
                                    size="sm"
                                    onClick={() => handleApproveLeave(request)}
                                    data-testid={`approve-leave-${request.id}`}
                                  >
                                    <CheckCircle2 className="h-4 w-4 mr-1" />
                                    Approve
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => handleRejectLeave(request)}
                                    data-testid={`reject-leave-${request.id}`}
                                  >
                                    <XCircle className="h-4 w-4 mr-1" />
                                    Reject
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                  <TablePagination
                    currentPage={leavePagination.currentPage}
                    pageSize={leavePagination.pageSize}
                    totalPages={leavePagination.totalPages}
                    totalItems={leavePagination.totalItems}
                    startIndex={leavePagination.startIndex}
                    endIndex={leavePagination.endIndex}
                    canGoNext={leavePagination.canGoNext}
                    canGoPrevious={leavePagination.canGoPrevious}
                    onPageChange={leavePagination.goToPage}
                    onPageSizeChange={leavePagination.setPageSize}
                    onNextPage={leavePagination.goToNextPage}
                    onPreviousPage={leavePagination.goToPreviousPage}
                    onFirstPage={leavePagination.goToFirstPage}
                    onLastPage={leavePagination.goToLastPage}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Cash Advances Tab */}
        <TabsContent value="cash-advance" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-col gap-4 space-y-0 pb-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4">
                <CardTitle className="text-lg font-medium">Cash Advances</CardTitle>
                <Button
                  size="sm"
                  onClick={() => {
                    submitCashAdvanceOnBehalfForm.reset();
                    setIsSubmitCashAdvanceOnBehalfDialogOpen(true);
                  }}
                  data-testid="submit-cash-advance-on-behalf"
                >
                  <UserPlus className="h-4 w-4 mr-2" />
                  Submit on Behalf
                </Button>
              </div>
              <div className="flex flex-col gap-2 sm:flex-row">
                <SearchableEmployeeSelect
                  employees={employees || []}
                  value={cashAdvanceEmployeeFilter}
                  onValueChange={setCashAdvanceEmployeeFilter}
                  placeholder="Filter by employee..."
                  allowAll
                  allLabel="All Employees"
                  className="w-full sm:w-[200px]"
                  data-testid="filter-cash-employee"
                />
                <Select value={cashAdvanceStatusFilter} onValueChange={(val) => setCashAdvanceStatusFilter(val as CashAdvanceStatusFilter)}>
                  <SelectTrigger className="w-full sm:w-[150px]" data-testid="filter-cash-status">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Status</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Approved">Approved</SelectItem>
                    <SelectItem value="Disbursed">Disbursed</SelectItem>
                    <SelectItem value="Rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {filteredCashAdvances.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground">
                  <Wallet className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No cash advances found.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Employee</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Reason</TableHead>
                        <TableHead>Remaining Balance</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {cashAdvancePagination.paginatedData.map((advance) => {
                        const employee = getEmployeeDetails(advance.employeeId);
                        const submitter = (advance as any).submittedById ? getEmployeeDetails((advance as any).submittedById) : null;
                        const isOnBehalf = (advance as any).submittedById && (advance as any).submittedById !== advance.employeeId;
                        return (
                          <TableRow key={advance.id} data-testid={`cash-advance-row-${advance.id}`}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Avatar className="h-8 w-8">
                                  <AvatarImage src={getPhotoDisplayUrl(employee?.profilePhotoUrl) || undefined} />
                                  <AvatarFallback>{getInitials(employee?.firstName, employee?.lastName)}</AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="text-sm font-medium">{getEmployeeName(advance.employeeId)}</p>
                                  <p className="text-xs text-muted-foreground">{employee?.employeeNo}</p>
                                  {isOnBehalf && submitter && (
                                    <p className="text-xs text-blue-600 dark:text-blue-400 flex items-center gap-1">
                                      <UserPlus className="h-3 w-3" />
                                      Filed by {submitter.firstName} {submitter.lastName}
                                    </p>
                                  )}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell className="text-sm font-semibold">{formatCurrency(advance.amount)}</TableCell>
                            <TableCell className="text-sm max-w-xs truncate">
                              {advance.reason || <span className="text-muted-foreground italic">No reason provided</span>}
                            </TableCell>
                            <TableCell className="text-sm">
                              {advance.remainingBalance ? formatCurrency(advance.remainingBalance) : "-"}
                            </TableCell>
                            <TableCell>{getStatusBadge(advance.status)}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                {advance.status === "Pending" && (
                                  <>
                                    <Button
                                      size="sm"
                                      onClick={() => handleApproveCash(advance)}
                                      data-testid={`approve-cash-${advance.id}`}
                                    >
                                      <CheckCircle2 className="h-4 w-4 mr-1" />
                                      Approve
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="destructive"
                                      onClick={() => handleRejectCash(advance)}
                                      data-testid={`reject-cash-${advance.id}`}
                                    >
                                      <XCircle className="h-4 w-4 mr-1" />
                                      Reject
                                    </Button>
                                  </>
                                )}
                                {advance.status === "Approved" && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleDisburseCash(advance)}
                                    data-testid={`disburse-cash-${advance.id}`}
                                  >
                                    <Send className="h-4 w-4 mr-1" />
                                    Disburse
                                  </Button>
                                )}
                                {(advance.status === "Disbursed" || advance.status === "Fully_Paid") && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleAdjustBalance("CashAdvance", advance.id, String(advance.remainingBalance || "0"))}
                                    data-testid={`adjust-cash-${advance.id}`}
                                  >
                                    <Edit3 className="h-4 w-4 mr-1" />
                                    Adjust
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                  <TablePagination
                    currentPage={cashAdvancePagination.currentPage}
                    pageSize={cashAdvancePagination.pageSize}
                    totalPages={cashAdvancePagination.totalPages}
                    totalItems={cashAdvancePagination.totalItems}
                    startIndex={cashAdvancePagination.startIndex}
                    endIndex={cashAdvancePagination.endIndex}
                    canGoNext={cashAdvancePagination.canGoNext}
                    canGoPrevious={cashAdvancePagination.canGoPrevious}
                    onPageChange={cashAdvancePagination.goToPage}
                    onPageSizeChange={cashAdvancePagination.setPageSize}
                    onNextPage={cashAdvancePagination.goToNextPage}
                    onPreviousPage={cashAdvancePagination.goToPreviousPage}
                    onFirstPage={cashAdvancePagination.goToFirstPage}
                    onLastPage={cashAdvancePagination.goToLastPage}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Loans Tab */}
        <TabsContent value="loans" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-col gap-4 space-y-0 pb-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4">
                <CardTitle className="text-lg font-medium">Loan Requests</CardTitle>
                <Button
                  size="sm"
                  onClick={() => {
                    submitLoanOnBehalfForm.reset();
                    setIsSubmitLoanOnBehalfDialogOpen(true);
                  }}
                  data-testid="submit-loan-on-behalf"
                >
                  <UserPlus className="h-4 w-4 mr-2" />
                  Submit on Behalf
                </Button>
              </div>
              <div className="flex flex-col gap-2 sm:flex-row">
                <SearchableEmployeeSelect
                  employees={employees || []}
                  value={loanEmployeeFilter}
                  onValueChange={setLoanEmployeeFilter}
                  placeholder="Filter by employee..."
                  allowAll
                  allLabel="All Employees"
                  className="w-full sm:w-[200px]"
                  data-testid="filter-loan-employee"
                />
                <Select value={loanTypeFilter} onValueChange={setLoanTypeFilter}>
                  <SelectTrigger className="w-full sm:w-[150px]" data-testid="filter-loan-type">
                    <SelectValue placeholder="Loan Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="SSS_Loan">SSS Loan</SelectItem>
                    <SelectItem value="Pagibig_Loan">Pag-IBIG Loan</SelectItem>
                    <SelectItem value="Bank_Loan">Bank Loan</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={loanStatusFilter} onValueChange={(val) => setLoanStatusFilter(val as LoanStatusFilter)}>
                  <SelectTrigger className="w-full sm:w-[150px]" data-testid="filter-loan-status">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Status</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Approved">Approved</SelectItem>
                    <SelectItem value="Disbursed">Disbursed</SelectItem>
                    <SelectItem value="Fully_Paid">Fully Paid</SelectItem>
                    <SelectItem value="Rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {filteredLoans.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground">
                  <Landmark className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No loan requests found.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Employee</TableHead>
                        <TableHead>Loan Type</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Interest</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead>Remaining</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loanPagination.paginatedData.map((loan) => {
                        const employee = getEmployeeDetails(loan.employeeId);
                        const submitter = (loan as any).submittedById ? getEmployeeDetails((loan as any).submittedById) : null;
                        const isOnBehalf = (loan as any).submittedById && (loan as any).submittedById !== loan.employeeId;
                        const LoanIcon = loanTypeIcons[loan.loanType] || FileText;
                        return (
                          <TableRow key={loan.id} data-testid={`loan-row-${loan.id}`}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Avatar className="h-8 w-8">
                                  <AvatarImage src={getPhotoDisplayUrl(employee?.profilePhotoUrl) || undefined} />
                                  <AvatarFallback>{getInitials(employee?.firstName, employee?.lastName)}</AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="text-sm font-medium">{getEmployeeName(loan.employeeId)}</p>
                                  <p className="text-xs text-muted-foreground">{employee?.employeeNo}</p>
                                  {isOnBehalf && submitter && (
                                    <p className="text-xs text-blue-600 dark:text-blue-400 flex items-center gap-1">
                                      <UserPlus className="h-3 w-3" />
                                      Filed by {submitter.firstName} {submitter.lastName}
                                    </p>
                                  )}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <LoanIcon className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm">{loanTypeLabels[loan.loanType] || loan.loanType}</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-sm font-medium">{formatCurrency(loan.amount)}</TableCell>
                            <TableCell className="text-sm">
                              {loan.interest && parseFloat(loan.interest) > 0
                                ? formatCurrency(loan.interest)
                                : <span className="text-muted-foreground">-</span>}
                            </TableCell>
                            <TableCell className="text-sm font-medium">{formatCurrency(loan.totalAmount)}</TableCell>
                            <TableCell className="text-sm">
                              {loan.status === "Disbursed" ? (
                                <span className="font-medium">{formatCurrency(loan.remainingBalance || "0")}</span>
                              ) : loan.status === "Fully_Paid" ? (
                                <span className="text-green-600">Paid</span>
                              ) : (
                                <span className="text-muted-foreground">-</span>
                              )}
                            </TableCell>
                            <TableCell>{getStatusBadge(loan.status)}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                {loan.status === "Pending" && (
                                  <>
                                    <Button
                                      size="sm"
                                      onClick={() => handleApproveLoan(loan)}
                                      data-testid={`approve-loan-${loan.id}`}
                                    >
                                      <CheckCircle2 className="h-4 w-4 mr-1" />
                                      Approve
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="destructive"
                                      onClick={() => handleRejectLoan(loan)}
                                      data-testid={`reject-loan-${loan.id}`}
                                    >
                                      <XCircle className="h-4 w-4 mr-1" />
                                      Reject
                                    </Button>
                                  </>
                                )}
                                {loan.status === "Approved" && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleDisburseLoan(loan)}
                                    data-testid={`disburse-loan-${loan.id}`}
                                  >
                                    <Send className="h-4 w-4 mr-1" />
                                    Disburse
                                  </Button>
                                )}
                                {(loan.status === "Disbursed" || loan.status === "Fully_Paid") && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleAdjustBalance("Loan", loan.id, String(loan.remainingBalance || "0"))}
                                    data-testid={`adjust-loan-${loan.id}`}
                                  >
                                    <Edit3 className="h-4 w-4 mr-1" />
                                    Adjust
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                  <TablePagination
                    currentPage={loanPagination.currentPage}
                    pageSize={loanPagination.pageSize}
                    totalPages={loanPagination.totalPages}
                    totalItems={loanPagination.totalItems}
                    startIndex={loanPagination.startIndex}
                    endIndex={loanPagination.endIndex}
                    canGoNext={loanPagination.canGoNext}
                    canGoPrevious={loanPagination.canGoPrevious}
                    onPageChange={loanPagination.goToPage}
                    onPageSizeChange={loanPagination.setPageSize}
                    onNextPage={loanPagination.goToNextPage}
                    onPreviousPage={loanPagination.goToPreviousPage}
                    onFirstPage={loanPagination.goToFirstPage}
                    onLastPage={loanPagination.goToLastPage}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Approve Leave Request Dialog */}
      <Dialog open={isApproveLeaveDialogOpen} onOpenChange={setIsApproveLeaveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              Approve Leave Request
            </DialogTitle>
            <DialogDescription>
              Approve this leave request for {selectedLeaveRequest && getEmployeeName(selectedLeaveRequest.employeeId)}
            </DialogDescription>
          </DialogHeader>
          <Form {...approveLeaveForm}>
            <form onSubmit={approveLeaveForm.handleSubmit((data) => {
              if (selectedLeaveRequest) {
                approveLeaveRequestMutation.mutate({
                  id: selectedLeaveRequest.id,
                  remarks: data.remarks,
                });
              }
            })} className="space-y-4">
              <FormField
                control={approveLeaveForm.control}
                name="remarks"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Remarks (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Add any remarks or notes..."
                        data-testid="input-approve-leave-remarks"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsApproveLeaveDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={approveLeaveRequestMutation.isPending} data-testid="button-confirm-approve-leave">
                  {approveLeaveRequestMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Approve Request
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Reject Leave Request Dialog */}
      <Dialog open={isRejectLeaveDialogOpen} onOpenChange={setIsRejectLeaveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <XCircle className="h-5 w-5 text-red-500" />
              Reject Leave Request
            </DialogTitle>
            <DialogDescription>
              Reject this leave request for {selectedLeaveRequest && getEmployeeName(selectedLeaveRequest.employeeId)}
            </DialogDescription>
          </DialogHeader>
          <Form {...rejectLeaveForm}>
            <form onSubmit={rejectLeaveForm.handleSubmit((data) => {
              if (selectedLeaveRequest) {
                rejectLeaveRequestMutation.mutate({
                  id: selectedLeaveRequest.id,
                  remarks: data.remarks,
                });
              }
            })} className="space-y-4">
              <FormField
                control={rejectLeaveForm.control}
                name="remarks"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Remarks (Required)</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Please provide a reason for rejection..."
                        data-testid="input-reject-leave-remarks"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsRejectLeaveDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" variant="destructive" disabled={rejectLeaveRequestMutation.isPending} data-testid="button-confirm-reject-leave">
                  {rejectLeaveRequestMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Reject Request
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Approve Cash Advance Dialog */}
      <Dialog open={isApproveCashDialogOpen} onOpenChange={setIsApproveCashDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              Approve Cash Advance
            </DialogTitle>
            <DialogDescription>
              Approve this cash advance of {selectedCashAdvance && formatCurrency(selectedCashAdvance.amount)} for {selectedCashAdvance && getEmployeeName(selectedCashAdvance.employeeId)}
            </DialogDescription>
          </DialogHeader>
          <Form {...approveCashAdvanceForm}>
            <form onSubmit={approveCashAdvanceForm.handleSubmit((data) => {
              if (selectedCashAdvance) {
                approveCashAdvanceMutation.mutate({
                  id: selectedCashAdvance.id,
                  deductionPerCutoff: data.deductionPerCutoff,
                });
              }
            })} className="space-y-4">
              <FormField
                control={approveCashAdvanceForm.control}
                name="deductionPerCutoff"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deduction Per Cutoff (PHP)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="500.00"
                        {...field}
                        data-testid="input-deduction-per-cutoff"
                      />
                    </FormControl>
                    <p className="text-xs text-muted-foreground">
                      How much should be deducted from each payroll period?
                    </p>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsApproveCashDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={approveCashAdvanceMutation.isPending} data-testid="button-confirm-approve-cash">
                  {approveCashAdvanceMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Approve
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Reject Cash Advance Dialog */}
      <AlertDialog open={isRejectCashDialogOpen} onOpenChange={setIsRejectCashDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Ban className="h-5 w-5 text-red-500" />
              Reject Cash Advance?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to reject this cash advance request of {selectedCashAdvance && formatCurrency(selectedCashAdvance.amount)} for {selectedCashAdvance && getEmployeeName(selectedCashAdvance.employeeId)}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (selectedCashAdvance) {
                  rejectCashAdvanceMutation.mutate(selectedCashAdvance.id);
                }
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-reject-cash"
            >
              {rejectCashAdvanceMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Reject Request
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Disburse Cash Advance Dialog */}
      <AlertDialog open={isDisburseCashDialogOpen} onOpenChange={setIsDisburseCashDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Send className="h-5 w-5 text-blue-500" />
              Disburse Cash Advance?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Confirm that you have disbursed {selectedCashAdvance && formatCurrency(selectedCashAdvance.amount)} to {selectedCashAdvance && getEmployeeName(selectedCashAdvance.employeeId)}. This will mark the cash advance as disbursed and begin payroll deductions.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (selectedCashAdvance) {
                  disburseCashAdvanceMutation.mutate(selectedCashAdvance.id);
                }
              }}
              data-testid="button-confirm-disburse-cash"
            >
              {disburseCashAdvanceMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Confirm Disbursement
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Approve Loan Dialog */}
      <Dialog open={isApproveLoanDialogOpen} onOpenChange={setIsApproveLoanDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              Approve Loan
            </DialogTitle>
            <DialogDescription>
              Approve this {selectedLoan && loanTypeLabels[selectedLoan.loanType]} of {selectedLoan && formatCurrency(selectedLoan.amount)} for {selectedLoan && getEmployeeName(selectedLoan.employeeId)}
            </DialogDescription>
          </DialogHeader>
          <Form {...approveLoanForm}>
            <form onSubmit={approveLoanForm.handleSubmit((data) => {
              if (selectedLoan) {
                approveLoanMutation.mutate({
                  id: selectedLoan.id,
                  deductionPerCutoff: data.deductionPerCutoff,
                  interest: data.interest || undefined,
                  remarks: data.remarks || undefined,
                  startDeductionDate: data.startDeductionDate || undefined,
                });
              }
            })} className="space-y-4">
              <FormField
                control={approveLoanForm.control}
                name="interest"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Interest Amount (PHP) - Optional</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        {...field}
                        data-testid="input-loan-interest"
                      />
                    </FormControl>
                    <p className="text-xs text-muted-foreground">
                      This will be added to the principal to calculate the total amount.
                    </p>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={approveLoanForm.control}
                name="deductionPerCutoff"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deduction Per Cutoff (PHP)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="500.00"
                        {...field}
                        data-testid="input-loan-deduction"
                      />
                    </FormControl>
                    <p className="text-xs text-muted-foreground">
                      How much should be deducted from each payroll period?
                    </p>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={approveLoanForm.control}
                name="startDeductionDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Deduction Date (Optional)</FormLabel>
                    <FormControl>
                      <Input
                        type="date"
                        {...field}
                        data-testid="input-loan-start-date"
                      />
                    </FormControl>
                    <p className="text-xs text-muted-foreground">
                      Leave empty to start deductions immediately upon disbursement.
                    </p>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={approveLoanForm.control}
                name="remarks"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Remarks (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Add any notes..."
                        data-testid="input-loan-remarks"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsApproveLoanDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={approveLoanMutation.isPending} data-testid="button-confirm-approve-loan">
                  {approveLoanMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Approve Loan
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Reject Loan Dialog */}
      <AlertDialog open={isRejectLoanDialogOpen} onOpenChange={setIsRejectLoanDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Ban className="h-5 w-5 text-red-500" />
              Reject Loan?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to reject this loan request of {selectedLoan && formatCurrency(selectedLoan.amount)} for {selectedLoan && getEmployeeName(selectedLoan.employeeId)}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (selectedLoan) {
                  rejectLoanMutation.mutate({ id: selectedLoan.id });
                }
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-reject-loan"
            >
              {rejectLoanMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Reject Loan
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Disburse Loan Dialog */}
      <AlertDialog open={isDisburseLoanDialogOpen} onOpenChange={setIsDisburseLoanDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Send className="h-5 w-5 text-blue-500" />
              Disburse Loan?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Confirm that you have disbursed {selectedLoan && formatCurrency(selectedLoan.totalAmount)} to {selectedLoan && getEmployeeName(selectedLoan.employeeId)}. This will mark the loan as disbursed and begin payroll deductions.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (selectedLoan) {
                  disburseLoanMutation.mutate(selectedLoan.id);
                }
              }}
              data-testid="button-confirm-disburse-loan"
            >
              {disburseLoanMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Confirm Disbursement
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Balance Adjustment Dialog */}
      <Dialog open={isAdjustBalanceDialogOpen} onOpenChange={setIsAdjustBalanceDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit3 className="h-5 w-5 text-orange-500" />
              Adjust Balance
            </DialogTitle>
            <DialogDescription>
              Manually adjust the remaining balance. This action will be recorded in the audit trail.
            </DialogDescription>
          </DialogHeader>
          <Form {...balanceAdjustmentForm}>
            <form onSubmit={balanceAdjustmentForm.handleSubmit((data) => {
              if (adjustBalanceEntity) {
                adjustBalanceMutation.mutate({
                  entityType: adjustBalanceEntity.type,
                  entityId: adjustBalanceEntity.id,
                  newBalance: data.newBalance,
                  adjustmentType: data.adjustmentType,
                  reason: data.reason,
                });
              }
            })} className="space-y-4">
              <div className="p-3 bg-muted rounded-md">
                <p className="text-sm">
                  Current Balance: <span className="font-semibold">{adjustBalanceEntity && formatCurrency(adjustBalanceEntity.currentBalance)}</span>
                </p>
              </div>
              <FormField
                control={balanceAdjustmentForm.control}
                name="newBalance"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>New Balance (PHP)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        {...field}
                        data-testid="input-new-balance"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={balanceAdjustmentForm.control}
                name="adjustmentType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Adjustment Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-adjustment-type">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Manual_Override">Manual Override</SelectItem>
                        <SelectItem value="Correction">Correction</SelectItem>
                        <SelectItem value="Partial_Waiver">Partial Waiver</SelectItem>
                        <SelectItem value="Full_Write_Off">Full Write-Off</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={balanceAdjustmentForm.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason (Required - min 20 characters)</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Please provide a detailed reason for this adjustment..."
                        rows={3}
                        data-testid="input-adjustment-reason"
                      />
                    </FormControl>
                    <p className="text-xs text-muted-foreground">
                      This reason will be recorded in the audit trail for accountability.
                    </p>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAdjustBalanceDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={adjustBalanceMutation.isPending} data-testid="button-confirm-adjust">
                  {adjustBalanceMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Confirm Adjustment
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Submit Leave Request on Behalf Dialog */}
      <Dialog open={isSubmitLeaveOnBehalfDialogOpen} onOpenChange={(open) => {
        setIsSubmitLeaveOnBehalfDialogOpen(open);
        if (!open) {
          setSelectedEmployeeForLeave("");
          setSelectedLeaveTypeForBalance("");
        }
      }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5 text-blue-500" />
              Submit Leave Request on Behalf
            </DialogTitle>
            <DialogDescription>
              Submit a leave request on behalf of an employee who cannot do it themselves.
            </DialogDescription>
          </DialogHeader>
          <Form {...submitLeaveOnBehalfForm}>
            <form onSubmit={submitLeaveOnBehalfForm.handleSubmit((data) => {
              submitLeaveOnBehalfMutation.mutate(data);
            })} className="space-y-4">
              <FormField
                control={submitLeaveOnBehalfForm.control}
                name="employeeId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Employee</FormLabel>
                    <FormControl>
                      <SearchableEmployeeSelect
                        employees={employees || []}
                        value={field.value}
                        onValueChange={(value) => {
                          field.onChange(value);
                          setSelectedEmployeeForLeave(value);
                        }}
                        placeholder="Select employee..."
                        className="w-full"
                        data-testid="select-leave-employee"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={submitLeaveOnBehalfForm.control}
                name="leaveTypeId"
                render={({ field }) => {
                  const selectedBalance = leaveBalanceData?.balances.find(b => b.leaveTypeId === field.value);
                  const requestedDays = parseFloat(submitLeaveOnBehalfForm.watch("totalDays") || "0");
                  const isInsufficientBalance = selectedBalance && requestedDays > selectedBalance.effectiveAvailable;
                  const unpaidDays = isInsufficientBalance ? requestedDays - selectedBalance.effectiveAvailable : 0;
                  const paidDays = isInsufficientBalance ? selectedBalance.effectiveAvailable : requestedDays;

                  return (
                    <FormItem>
                      <FormLabel>Leave Type</FormLabel>
                      <Select onValueChange={(value) => {
                        field.onChange(value);
                        setSelectedLeaveTypeForBalance(value);
                      }} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-leave-type">
                            <SelectValue placeholder="Select leave type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {leaveTypes?.map((type) => {
                            const balance = leaveBalanceData?.balances.find(b => b.leaveTypeId === type.id);
                            return (
                              <SelectItem key={type.id} value={type.id}>
                                {type.name} {balance ? `(${balance.effectiveAvailable} days available)` : ""}
                              </SelectItem>
                            );
                          })}
                        </SelectContent>
                      </Select>

                      {/* Leave Balance Display */}
                      {selectedEmployeeForLeave && field.value && selectedBalance && (
                        <div className="mt-2 p-3 bg-muted rounded-lg text-sm">
                          <div className="font-medium mb-1">Leave Balance for {selectedBalance.leaveTypeName}:</div>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <span>Total Allocated:</span>
                            <span className="font-medium">{selectedBalance.totalAllocated} days</span>
                            <span>Used:</span>
                            <span className="font-medium">{selectedBalance.used} days</span>
                            <span>Pending Requests:</span>
                            <span className="font-medium text-yellow-600">{selectedBalance.pending} days</span>
                            <span>Available:</span>
                            <span className="font-medium text-green-600">{selectedBalance.effectiveAvailable} days</span>
                          </div>

                          {/* Warning when requesting more than available */}
                          {isInsufficientBalance && requestedDays > 0 && (
                            <div className="mt-2 p-2 bg-orange-50 dark:bg-orange-950 border border-orange-200 dark:border-orange-800 rounded text-orange-700 dark:text-orange-300">
                              <p className="font-medium">Insufficient Leave Balance</p>
                              <p className="text-xs mt-1">
                                Requesting {requestedDays} days but only {selectedBalance.effectiveAvailable} days available.
                              </p>
                              <p className="text-xs mt-1">
                                <span className="text-green-600 font-medium">{Math.max(0, paidDays).toFixed(1)} days paid</span>
                                {" + "}
                                <span className="text-orange-600 font-medium">{unpaidDays.toFixed(1)} days unpaid</span>
                              </p>
                            </div>
                          )}

                          {!selectedBalance.hasAllocation && (
                            <div className="mt-2 p-2 bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded text-yellow-700 dark:text-yellow-300 text-xs">
                              No allocation found for this leave type. All days will be unpaid.
                            </div>
                          )}
                        </div>
                      )}

                      <FormMessage />
                    </FormItem>
                  );
                }}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={submitLeaveOnBehalfForm.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} data-testid="input-leave-start-date" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={submitLeaveOnBehalfForm.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} data-testid="input-leave-end-date" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={submitLeaveOnBehalfForm.control}
                name="totalDays"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Total Days</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.5" min="0.5" {...field} data-testid="input-leave-total-days" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={submitLeaveOnBehalfForm.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason (Optional)</FormLabel>
                    <FormControl>
                      <Textarea {...field} placeholder="Enter reason for leave..." data-testid="input-leave-reason" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsSubmitLeaveOnBehalfDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={submitLeaveOnBehalfMutation.isPending} data-testid="button-submit-leave-on-behalf">
                  {submitLeaveOnBehalfMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Submit Request
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Submit Cash Advance on Behalf Dialog */}
      <Dialog open={isSubmitCashAdvanceOnBehalfDialogOpen} onOpenChange={setIsSubmitCashAdvanceOnBehalfDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5 text-blue-500" />
              Submit Cash Advance on Behalf
            </DialogTitle>
            <DialogDescription>
              Submit a cash advance request on behalf of an employee.
            </DialogDescription>
          </DialogHeader>
          <Form {...submitCashAdvanceOnBehalfForm}>
            <form onSubmit={submitCashAdvanceOnBehalfForm.handleSubmit((data) => {
              submitCashAdvanceOnBehalfMutation.mutate(data);
            })} className="space-y-4">
              <FormField
                control={submitCashAdvanceOnBehalfForm.control}
                name="employeeId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Employee</FormLabel>
                    <FormControl>
                      <SearchableEmployeeSelect
                        employees={employees || []}
                        value={field.value}
                        onValueChange={field.onChange}
                        placeholder="Select employee..."
                        className="w-full"
                        data-testid="select-cash-advance-employee"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={submitCashAdvanceOnBehalfForm.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (PHP)</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" min="1" placeholder="0.00" {...field} data-testid="input-cash-advance-amount" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={submitCashAdvanceOnBehalfForm.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason (Optional)</FormLabel>
                    <FormControl>
                      <Textarea {...field} placeholder="Enter reason for cash advance..." data-testid="input-cash-advance-reason" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsSubmitCashAdvanceOnBehalfDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={submitCashAdvanceOnBehalfMutation.isPending} data-testid="button-submit-cash-advance-on-behalf">
                  {submitCashAdvanceOnBehalfMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Submit Request
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Submit Loan on Behalf Dialog */}
      <Dialog open={isSubmitLoanOnBehalfDialogOpen} onOpenChange={setIsSubmitLoanOnBehalfDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5 text-blue-500" />
              Submit Loan Application on Behalf
            </DialogTitle>
            <DialogDescription>
              Submit a loan application on behalf of an employee.
            </DialogDescription>
          </DialogHeader>
          <Form {...submitLoanOnBehalfForm}>
            <form onSubmit={submitLoanOnBehalfForm.handleSubmit((data) => {
              submitLoanOnBehalfMutation.mutate(data);
            })} className="space-y-4">
              <FormField
                control={submitLoanOnBehalfForm.control}
                name="employeeId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Employee</FormLabel>
                    <FormControl>
                      <SearchableEmployeeSelect
                        employees={employees || []}
                        value={field.value}
                        onValueChange={field.onChange}
                        placeholder="Select employee..."
                        className="w-full"
                        data-testid="select-loan-employee"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={submitLoanOnBehalfForm.control}
                name="loanType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Loan Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-loan-type-input">
                          <SelectValue placeholder="Select loan type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="SSS_Loan">SSS Loan</SelectItem>
                        <SelectItem value="Pagibig_Loan">Pag-IBIG Loan</SelectItem>
                        <SelectItem value="Bank_Loan">Bank Loan</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={submitLoanOnBehalfForm.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Loan Amount (PHP)</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" min="1" placeholder="0.00" {...field} data-testid="input-loan-amount" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={submitLoanOnBehalfForm.control}
                name="interest"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Interest Amount (PHP) - Optional</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" min="0" placeholder="0.00" {...field} data-testid="input-loan-interest-input" />
                    </FormControl>
                    <p className="text-xs text-muted-foreground">
                      Interest will be added to the principal for total amount.
                    </p>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={submitLoanOnBehalfForm.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason (Optional)</FormLabel>
                    <FormControl>
                      <Textarea {...field} placeholder="Enter reason for loan..." data-testid="input-loan-reason" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsSubmitLoanOnBehalfDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={submitLoanOnBehalfMutation.isPending} data-testid="button-submit-loan-on-behalf">
                  {submitLoanOnBehalfMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Submit Application
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
