import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { usePagination } from "@/hooks/use-pagination";
import { TablePagination } from "@/components/ui/table-pagination";
import { format } from "date-fns";
import { PhotoUploader } from "@/components/photo-uploader";
import { MapPicker } from "@/components/map-picker";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { getInitials } from "@/lib/utils";
import {
  Plus,
  MapPin,
  Users,
  FolderKanban,
  Search,
  Building2,
  MoreHorizontal,
  Pencil,
  Trash2,
  UserPlus,
  X,
  Eye,
  ClipboardList,
  DollarSign,
  Clock,
  Calendar,
  CheckCircle2,
  MessageSquare,
  Send,
  FileText,
  Archive,
  Paperclip,
  Banknote,
} from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import type { Project, Employee, Task } from "@shared/schema";

const statusColors: Record<string, string> = {
  Planning: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  Active: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  "On Hold": "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  Completed: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200",
  Cancelled: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
};

// Tab type for filtering projects
type ProjectTab = "projects" | "offices" | "completed" | "archived";

interface ProjectFormData {
  poNumber: string;
  name: string;
  code: string;
  description: string;
  client: string;
  locationName: string;
  locationLat: string;
  locationLng: string;
  geoRadius: string;
  startDate: string;
  deadline: string;
  allocatedHours: string;
  mealAllowance: string;
  status: "Planning" | "Active" | "On Hold" | "Completed" | "Cancelled";
  isOffice: boolean;
  projectManagerId: string;
}

const emptyProjectForm: ProjectFormData = {
  poNumber: "",
  name: "",
  code: "",
  description: "",
  client: "",
  locationName: "",
  locationLat: "",
  locationLng: "",
  geoRadius: "100",
  startDate: "",
  deadline: "",
  allocatedHours: "",
  mealAllowance: "",
  status: "Planning",
  isOffice: false,
  projectManagerId: "_none_",
};

// Enriched project with computed fields from API
interface EnrichedProject extends Project {
  taskCount?: number;
  completedTasks?: number;
  progress?: number;
  totalApprovedExpenses?: number;
  hoursUsed?: number;
  totalLaborCost?: number;
  estimatedMealAllowance?: number;
}

// Project comment interface
interface ProjectComment {
  id: string;
  projectId: string;
  authorId: string;
  content: string;
  attachments?: { url: string; name: string; type: string; size?: number }[];
  createdAt: string;
  updatedAt?: string;
}

interface ProjectAssignment {
  id: string;
  employeeId: string;
  projectId: string;
  isActive: boolean;
  employee?: Employee;
}

export default function ProjectsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<ProjectTab>("projects");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<EnrichedProject | null>(null);
  const [projectForm, setProjectForm] = useState<ProjectFormData>(emptyProjectForm);
  const [employeeSearch, setEmployeeSearch] = useState("");
  const [newComment, setNewComment] = useState("");
  const [commentAttachments, setCommentAttachments] = useState<string[]>([]);

  const { data: projects = [], isLoading } = useQuery<EnrichedProject[]>({
    queryKey: ["/api/projects"],
  });

  const { data: employees = [] } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: projectDetails } = useQuery<{ project: Project; assignments: ProjectAssignment[]; tasks: Task[] }>({
    queryKey: ["/api/projects", selectedProject?.id, "details"],
    enabled: !!selectedProject && (isAssignDialogOpen || isDetailsDialogOpen),
  });

  const { data: projectComments = [], isLoading: commentsLoading } = useQuery<ProjectComment[]>({
    queryKey: [`/api/projects/${selectedProject?.id}/comments`],
    enabled: !!selectedProject && isDetailsDialogOpen,
  });

  const createProjectMutation = useMutation({
    mutationFn: async (data: ProjectFormData) => {
      const payload: any = {
        ...data,
        poNumber: data.poNumber || null,
        geoRadius: data.geoRadius ? parseInt(data.geoRadius) : 100,
        locationLat: data.locationLat ? String(data.locationLat) : null,
        locationLng: data.locationLng ? String(data.locationLng) : null,
        allocatedHours: data.allocatedHours ? String(data.allocatedHours) : null,
        projectManagerId: data.projectManagerId === "_none_" ? null : (data.projectManagerId || null),
      };

      // For office locations, explicitly set deadline to null
      if (data.isOffice) {
        payload.deadline = null;
        payload.startDate = null;
        payload.poNumber = null; // Offices don't have P.O numbers
      } else {
        payload.deadline = data.deadline || null;
        payload.startDate = data.startDate || null;
      }

      const response = await apiRequest("POST", "/api/projects", payload);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setIsAddDialogOpen(false);
      setProjectForm(emptyProjectForm);
      toast({ title: "Project Created", description: "New project has been added successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create project.", variant: "destructive" });
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: ProjectFormData }) => {
      const payload: any = {
        ...data,
        poNumber: data.poNumber || null,
        geoRadius: data.geoRadius ? parseInt(data.geoRadius) : 100,
        locationLat: data.locationLat ? String(data.locationLat) : null,
        locationLng: data.locationLng ? String(data.locationLng) : null,
        allocatedHours: data.allocatedHours ? String(data.allocatedHours) : null,
        projectManagerId: data.projectManagerId === "_none_" ? null : (data.projectManagerId || null),
      };

      // For office locations, explicitly set deadline to null
      // For non-office, preserve empty string as null or valid date
      if (data.isOffice) {
        payload.deadline = null;
        payload.startDate = null;
        payload.poNumber = null;
      } else {
        payload.deadline = data.deadline || null;
        payload.startDate = data.startDate || null;
      }

      const response = await apiRequest("PATCH", `/api/projects/${id}`, payload);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      setIsEditDialogOpen(false);
      setSelectedProject(null);
      toast({ title: "Project Updated", description: "Project has been updated successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update project.", variant: "destructive" });
    },
  });

  const addCommentMutation = useMutation({
    mutationFn: async ({ projectId, content, attachments }: { projectId: string; content: string; attachments?: { url: string; name: string; type: string }[] }) => {
      const response = await apiRequest("POST", `/api/projects/${projectId}/comments`, { content, attachments });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${selectedProject?.id}/comments`] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setNewComment("");
      setCommentAttachments([]);
      toast({ title: "Comment Added", description: "Your comment has been posted." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add comment.", variant: "destructive" });
    },
  });

  const deleteProjectMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/projects/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      setIsDeleteDialogOpen(false);
      setSelectedProject(null);
      toast({ title: "Project Deleted", description: "Project has been deleted." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete project.", variant: "destructive" });
    },
  });

  const assignEmployeeMutation = useMutation({
    mutationFn: async ({ projectId, employeeId }: { projectId: string; employeeId: string }) => {
      const response = await apiRequest("POST", `/api/projects/${projectId}/assignments`, { employeeId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", selectedProject?.id, "details"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      toast({ title: "Employee Assigned", description: "Employee has been assigned to the project." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to assign employee.", variant: "destructive" });
    },
  });

  const unassignEmployeeMutation = useMutation({
    mutationFn: async ({ projectId, assignmentId }: { projectId: string; assignmentId: string }) => {
      await apiRequest("DELETE", `/api/projects/${projectId}/assignments/${assignmentId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", selectedProject?.id, "details"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      toast({ title: "Employee Removed", description: "Employee has been removed from the project." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to remove employee.", variant: "destructive" });
    },
  });

  const handleEdit = (project: EnrichedProject) => {
    setSelectedProject(project);
    setProjectForm({
      poNumber: (project as any).poNumber || "",
      name: project.name,
      code: project.code || "",
      description: project.description || "",
      client: project.client || "",
      locationName: project.locationName || "",
      locationLat: project.locationLat?.toString() || "",
      locationLng: project.locationLng?.toString() || "",
      geoRadius: project.geoRadius?.toString() || "100",
      startDate: project.startDate ? format(new Date(project.startDate), "yyyy-MM-dd") : "",
      deadline: project.deadline ? format(new Date(project.deadline), "yyyy-MM-dd") : "",
      allocatedHours: project.allocatedHours?.toString() || "",
      mealAllowance: project.mealAllowance?.toString() || "",
      status: project.status as any,
      isOffice: project.isOffice || false,
      projectManagerId: project.projectManagerId || "_none_",
    });
    setIsEditDialogOpen(true);
  };

  const handleDelete = (project: EnrichedProject) => {
    setSelectedProject(project);
    setIsDeleteDialogOpen(true);
  };

  const handleAssign = (project: EnrichedProject) => {
    setSelectedProject(project);
    setEmployeeSearch("");
    setIsAssignDialogOpen(true);
  };

  const handleViewDetails = (project: EnrichedProject) => {
    setSelectedProject(project);
    setNewComment("");
    setCommentAttachments([]);
    setIsDetailsDialogOpen(true);
  };

  const handleAddComment = () => {
    if (!selectedProject || !newComment.trim()) return;

    // Convert attachments to the expected format
    const attachments = commentAttachments.length > 0
      ? commentAttachments.map((url, index) => ({
          url,
          name: `attachment-${index + 1}${url.startsWith('data:image/') ? '.jpg' : '.file'}`,
          type: url.startsWith('data:image/') ? 'image' : 'file',
        }))
      : undefined;

    addCommentMutation.mutate({
      projectId: selectedProject.id,
      content: newComment.trim(),
      attachments,
    });
  };

  const getEmployeeName = (employeeId: string) => {
    const emp = employees.find(e => e.id === employeeId);
    return emp ? `${emp.firstName} ${emp.lastName}` : "Unknown";
  };


  // Filter projects based on active tab
  const projectsByTab = useMemo(() => {
    return projects.filter((project) => {
      switch (activeTab) {
        case "projects":
          // Active/Planning/On Hold projects, excluding offices
          return !project.isOffice && !["Completed", "Cancelled"].includes(project.status);
        case "offices":
          return project.isOffice === true;
        case "completed":
          return project.status === "Completed";
        case "archived":
          return project.status === "Cancelled";
        default:
          return true;
      }
    });
  }, [projects, activeTab]);

  // Further filter by search and status
  const filteredProjects = projectsByTab.filter((project) => {
    const matchesSearch =
      project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.code?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.client?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (project as any).poNumber?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || project.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Pagination
  const pagination = usePagination(filteredProjects);

  const filteredEmployees = employees.filter((emp) => {
    const searchLower = employeeSearch.toLowerCase();
    const matchesSearch =
      `${emp.firstName} ${emp.lastName}`.toLowerCase().includes(searchLower) ||
      emp.email?.toLowerCase().includes(searchLower) ||
      emp.employeeNo?.toLowerCase().includes(searchLower);
    const isNotAssigned = !projectDetails?.assignments.some(a => a.employeeId === emp.id);
    return matchesSearch && isNotAssigned;
  });

  // Stats for all projects (not filtered by tab)
  const stats = {
    total: projects.filter(p => !p.isOffice).length,
    active: projects.filter((p) => p.status === "Active" && !p.isOffice).length,
    planning: projects.filter((p) => p.status === "Planning" && !p.isOffice).length,
    completed: projects.filter((p) => p.status === "Completed").length,
    offices: projects.filter((p) => p.isOffice).length,
    archived: projects.filter((p) => p.status === "Cancelled").length,
  };

  // Get project tasks for the details modal
  const projectTasks = useMemo(() => {
    if (!selectedProject) return [];
    return tasks.filter(t => t.projectId === selectedProject.id);
  }, [selectedProject, tasks]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  // Project form fields as JSX variable instead of inline component.
  // This prevents focus loss on inputs because React doesn't recreate elements on each render.
  const projectFormFields = (
    <div className="grid gap-4 py-4">
      {/* P.O Number - First field for non-office projects */}
      {!projectForm.isOffice && (
        <div className="space-y-2">
          <Label htmlFor="poNumber">P.O Number</Label>
          <Input
            id="poNumber"
            value={projectForm.poNumber}
            onChange={(e) => setProjectForm({ ...projectForm, poNumber: e.target.value })}
            placeholder="Purchase Order Number"
            data-testid="input-po-number"
          />
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Project Name *</Label>
          <Input
            id="name"
            value={projectForm.name}
            onChange={(e) => setProjectForm({ ...projectForm, name: e.target.value })}
            placeholder="e.g., SM Mall Electrical Upgrade"
            data-testid="input-project-name"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="code">Project Code</Label>
          <Input
            id="code"
            value={projectForm.code}
            onChange={(e) => setProjectForm({ ...projectForm, code: e.target.value })}
            placeholder="e.g., PRJ-2024-001"
            data-testid="input-project-code"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={projectForm.description}
          onChange={(e) => setProjectForm({ ...projectForm, description: e.target.value })}
          placeholder="Project scope and details..."
          data-testid="input-project-description"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="client">Client Name</Label>
        <Input
          id="client"
          value={projectForm.client}
          onChange={(e) => setProjectForm({ ...projectForm, client: e.target.value })}
          placeholder="Client company name"
          data-testid="input-client"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="projectManager">Project Manager</Label>
        <Select
          value={projectForm.projectManagerId}
          onValueChange={(value) => setProjectForm({ ...projectForm, projectManagerId: value })}
        >
          <SelectTrigger data-testid="select-project-manager">
            <SelectValue placeholder="Select project manager" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="_none_">No manager assigned</SelectItem>
            {employees.map((emp) => (
              <SelectItem key={emp.id} value={emp.id}>
                {emp.firstName} {emp.lastName}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center gap-2 p-3 rounded-lg border">
        <Checkbox
          id="isOffice"
          checked={projectForm.isOffice}
          onCheckedChange={(checked) => setProjectForm({ 
            ...projectForm, 
            isOffice: checked === true, 
            deadline: checked ? "" : projectForm.deadline,
            startDate: checked ? "" : projectForm.startDate,
            allocatedHours: checked ? "" : projectForm.allocatedHours,
            status: checked ? "Active" : projectForm.status,
          })}
          data-testid="checkbox-is-office"
        />
        <div className="flex items-center gap-2">
          <Building2 className="h-4 w-4 text-muted-foreground" />
          <Label htmlFor="isOffice" className="text-sm cursor-pointer">
            Permanent Office (no deadline, dates, or hours tracking)
          </Label>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="locationName">Site Location</Label>
        <Input
          id="locationName"
          value={projectForm.locationName}
          onChange={(e) => setProjectForm({ ...projectForm, locationName: e.target.value })}
          placeholder="Project site location"
          data-testid="input-location-name"
        />
      </div>

      <MapPicker
        latitude={projectForm.locationLat ? parseFloat(projectForm.locationLat) : null}
        longitude={projectForm.locationLng ? parseFloat(projectForm.locationLng) : null}
        onChange={(lat, lng) => setProjectForm({
          ...projectForm,
          locationLat: lat.toString(),
          locationLng: lng.toString(),
        })}
        geoRadius={parseInt(projectForm.geoRadius) || 100}
        onRadiusChange={(radius) => setProjectForm({ ...projectForm, geoRadius: radius.toString() })}
      />

      {/* Only show dates, hours, and status for projects (not offices) */}
      {!projectForm.isOffice && (
        <>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate">Start Date</Label>
              <Input
                id="startDate"
                type="date"
                value={projectForm.startDate}
                onChange={(e) => setProjectForm({ ...projectForm, startDate: e.target.value })}
                data-testid="input-start-date"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="deadline">Deadline</Label>
              <Input
                id="deadline"
                type="date"
                value={projectForm.deadline}
                onChange={(e) => setProjectForm({ ...projectForm, deadline: e.target.value })}
                data-testid="input-deadline"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="allocatedHours">Allocated Hours</Label>
              <Input
                id="allocatedHours"
                type="number"
                value={projectForm.allocatedHours}
                onChange={(e) => setProjectForm({ ...projectForm, allocatedHours: e.target.value })}
                placeholder="e.g. 160"
                data-testid="input-allocated-hours"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="mealAllowance">Meal Allowance</Label>
              <Input
                id="mealAllowance"
                type="number"
                step="0.01"
                min="0"
                value={projectForm.mealAllowance}
                onChange={(e) => setProjectForm({ ...projectForm, mealAllowance: e.target.value })}
                placeholder="Per Head Amount"
                data-testid="input-meal-allowance"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={projectForm.status}
                onValueChange={(value) => setProjectForm({ ...projectForm, status: value as any })}
              >
                <SelectTrigger data-testid="select-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Planning">Planning</SelectItem>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="On Hold">On Hold</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                  <SelectItem value="Cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-page-title">
            Project Management
          </h1>
          <p className="text-muted-foreground">
            Manage electrical contracting projects and site locations
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-project" onClick={() => setProjectForm(emptyProjectForm)}>
              <Plus className="mr-2 h-4 w-4" />
              New Project
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
            <DialogHeader className="flex-shrink-0">
              <DialogTitle>Create New Project</DialogTitle>
              <DialogDescription>
                Add a new electrical contracting project with geo-fencing for attendance.
              </DialogDescription>
            </DialogHeader>
            <div className="flex-1 overflow-y-auto py-2 pr-2">
              {projectFormFields}
            </div>
            <DialogFooter className="flex-shrink-0 pt-4 border-t">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={() => createProjectMutation.mutate(projectForm)}
                disabled={!projectForm.name || createProjectMutation.isPending}
                data-testid="button-save-project"
              >
                {createProjectMutation.isPending ? "Creating..." : "Create Project"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Projects</CardTitle>
            <FolderKanban className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active</CardTitle>
            <div className="h-2 w-2 rounded-full bg-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.active}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Planning</CardTitle>
            <div className="h-2 w-2 rounded-full bg-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.planning}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <div className="h-2 w-2 rounded-full bg-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.completed}</div>
          </CardContent>
        </Card>
      </div>

      {/* Tab Toggles */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as ProjectTab)} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="projects" className="gap-2">
            <FolderKanban className="h-4 w-4" />
            <span className="hidden sm:inline">Projects</span>
            <Badge variant="secondary" className="ml-1">{stats.total}</Badge>
          </TabsTrigger>
          <TabsTrigger value="offices" className="gap-2">
            <Building2 className="h-4 w-4" />
            <span className="hidden sm:inline">Offices</span>
            <Badge variant="secondary" className="ml-1">{stats.offices}</Badge>
          </TabsTrigger>
          <TabsTrigger value="completed" className="gap-2">
            <CheckCircle2 className="h-4 w-4" />
            <span className="hidden sm:inline">Completed</span>
            <Badge variant="secondary" className="ml-1">{stats.completed}</Badge>
          </TabsTrigger>
          <TabsTrigger value="archived" className="gap-2">
            <Archive className="h-4 w-4" />
            <span className="hidden sm:inline">Archived</span>
            <Badge variant="secondary" className="ml-1">{stats.archived}</Badge>
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Filters */}
      <Card>
        <CardContent className="flex flex-col gap-4 p-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder={activeTab === "offices" ? "Search offices..." : "Search projects..."}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              aria-label="Search projects"
              data-testid="input-search-projects"
            />
          </div>
          {activeTab !== "offices" && (
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-40" data-testid="select-status-filter">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Planning">Planning</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="On Hold">On Hold</SelectItem>
                <SelectItem value="Completed">Completed</SelectItem>
                <SelectItem value="Cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          )}
        </CardContent>
      </Card>

      {/* Projects Table */}
      <Card>
        <CardHeader>
          <CardTitle>
            {activeTab === "projects" && "All Projects"}
            {activeTab === "offices" && "Office Locations"}
            {activeTab === "completed" && "Completed Projects"}
            {activeTab === "archived" && "Archived Projects"}
          </CardTitle>
          <CardDescription>
            {filteredProjects.length} {activeTab === "offices" ? "office" : "project"}{filteredProjects.length !== 1 ? "s" : ""} found
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredProjects.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              {activeTab === "offices" ? (
                <Building2 className="h-12 w-12 text-muted-foreground/50" />
              ) : (
                <FolderKanban className="h-12 w-12 text-muted-foreground/50" />
              )}
              <h3 className="mt-4 text-lg font-semibold">
                No {activeTab === "offices" ? "offices" : "projects"} found
              </h3>
              <p className="text-sm text-muted-foreground">
                {searchQuery || statusFilter !== "all"
                  ? "Try adjusting your filters"
                  : `Create your first ${activeTab === "offices" ? "office" : "project"} to get started`}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    {/* P.O Number - first column for non-office projects */}
                    {activeTab !== "offices" && <TableHead>P.O #</TableHead>}
                    <TableHead>Project</TableHead>
                    <TableHead>Client</TableHead>
                    <TableHead>Location</TableHead>
                    {activeTab !== "offices" && <TableHead>Duration</TableHead>}
                    <TableHead>Status</TableHead>
                    {activeTab !== "offices" && <TableHead className="text-center">Tasks</TableHead>}
                    {activeTab !== "offices" && <TableHead className="text-right">Progress</TableHead>}
                    {activeTab !== "offices" && <TableHead className="text-right">Hours</TableHead>}
                    {activeTab !== "offices" && <TableHead className="text-right">Expenses</TableHead>}
                    <TableHead className="text-center">View</TableHead>
                    <TableHead className="w-[80px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pagination.paginatedData.map((project) => (
                    <TableRow key={project.id} data-testid={`row-project-${project.id}`}>
                      {/* P.O Number column */}
                      {activeTab !== "offices" && (
                        <TableCell>
                          {(project as any).poNumber ? (
                            <span className="text-sm font-mono">{(project as any).poNumber}</span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                      )}
                      {/* Project name and code */}
                      <TableCell>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-medium">{project.name}</p>
                            {project.isOffice && (
                              <Badge variant="outline" className="gap-1 text-xs">
                                <Building2 className="h-3 w-3" />
                                Office
                              </Badge>
                            )}
                          </div>
                          {project.code && (
                            <p className="text-xs text-muted-foreground">{project.code}</p>
                          )}
                        </div>
                      </TableCell>
                      {/* Client */}
                      <TableCell>
                        {project.client || <span className="text-muted-foreground">-</span>}
                      </TableCell>
                      {/* Location */}
                      <TableCell>
                        {project.locationName ? (
                          <div className="flex items-center gap-1 text-sm">
                            <MapPin className="h-3 w-3 text-muted-foreground" />
                            <span className="max-w-[200px] truncate">{project.locationName}</span>
                          </div>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      {/* Duration - only for non-office */}
                      {activeTab !== "offices" && (
                        <TableCell>
                          {project.startDate && project.deadline ? (
                            <span className="text-sm">
                              {format(new Date(project.startDate), "MMM d")} -{" "}
                              {format(new Date(project.deadline), "MMM d, yyyy")}
                            </span>
                          ) : project.startDate ? (
                            <span className="text-sm">
                              Starts {format(new Date(project.startDate), "MMM d, yyyy")}
                            </span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                      )}
                      {/* Status */}
                      <TableCell>
                        <Badge variant="secondary" className={statusColors[project.status] || ""}>
                          {project.status}
                        </Badge>
                      </TableCell>
                      {/* Tasks column - shows completed/total */}
                      {activeTab !== "offices" && (
                        <TableCell className="text-center">
                          <span className="text-sm">
                            {project.completedTasks ?? 0}/{project.taskCount ?? 0}
                          </span>
                        </TableCell>
                      )}
                      {/* Progress */}
                      {activeTab !== "offices" && (
                        <TableCell className="text-right">
                          <span className="text-sm">{project.progress ?? 0}%</span>
                        </TableCell>
                      )}
                      {/* Hours */}
                      {activeTab !== "offices" && (
                        <TableCell className="text-right">
                          {project.allocatedHours ? (
                            <span className="text-sm">
                              {project.hoursUsed ?? 0}/{parseFloat(project.allocatedHours).toFixed(0)}h
                            </span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                      )}
                      {/* Expenses column - shows total approved expenses */}
                      {activeTab !== "offices" && (
                        <TableCell className="text-right">
                          {(project.totalApprovedExpenses ?? 0) > 0 ? (
                            <span className="text-sm font-medium">
                              ₱{(project.totalApprovedExpenses ?? 0).toLocaleString()}
                            </span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                      )}
                      {/* View button */}
                      <TableCell className="text-center">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleViewDetails(project)}
                          aria-label={`View details for ${project.name}`}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                      {/* Actions menu */}
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" aria-label={`Actions for ${project.name}`} data-testid={`button-project-menu-${project.id}`}>
                              <MoreHorizontal className="h-4 w-4" aria-hidden="true" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewDetails(project)}>
                              <Eye className="mr-2 h-4 w-4" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleAssign(project)}>
                              <UserPlus className="mr-2 h-4 w-4" />
                              Assign Employees
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => handleEdit(project)}>
                              <Pencil className="mr-2 h-4 w-4" />
                              Edit Project
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleDelete(project)}
                              className="text-destructive"
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete Project
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <TablePagination
                currentPage={pagination.currentPage}
                pageSize={pagination.pageSize}
                totalPages={pagination.totalPages}
                totalItems={pagination.totalItems}
                startIndex={pagination.startIndex}
                endIndex={pagination.endIndex}
                canGoNext={pagination.canGoNext}
                canGoPrevious={pagination.canGoPrevious}
                onPageChange={pagination.goToPage}
                onPageSizeChange={pagination.setPageSize}
                onNextPage={pagination.goToNextPage}
                onPreviousPage={pagination.goToPreviousPage}
                onFirstPage={pagination.goToFirstPage}
                onLastPage={pagination.goToLastPage}
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle>Edit Project</DialogTitle>
            <DialogDescription>
              Update project details and location settings.
            </DialogDescription>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto py-2 pr-2">
            {projectFormFields}
          </div>
          <DialogFooter className="flex-shrink-0 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => selectedProject && updateProjectMutation.mutate({ id: selectedProject.id, data: projectForm })}
              disabled={!projectForm.name || updateProjectMutation.isPending}
              data-testid="button-update-project"
            >
              {updateProjectMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Project?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete "{selectedProject?.name}". This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => selectedProject && deleteProjectMutation.mutate(selectedProject.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteProjectMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Employee Assignment Dialog */}
      <Dialog open={isAssignDialogOpen} onOpenChange={setIsAssignDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle>Assign Employees</DialogTitle>
            <DialogDescription>
              Manage employee assignments for {selectedProject?.name}
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto space-y-4 py-2 pr-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
              <Input
                placeholder="Search employees..."
                value={employeeSearch}
                onChange={(e) => setEmployeeSearch(e.target.value)}
                className="pl-9"
                aria-label="Search employees to assign"
                data-testid="input-search-employees"
              />
            </div>

            {/* Currently Assigned */}
            {projectDetails?.assignments && projectDetails.assignments.length > 0 && (
              <div className="space-y-2">
                <Label className="text-sm font-medium">Currently Assigned ({projectDetails.assignments.length})</Label>
                <div className="space-y-1">
                  {projectDetails.assignments.map((assignment) => {
                    const emp = employees.find(e => e.id === assignment.employeeId);
                    return (
                      <div key={assignment.id} className="flex items-center justify-between p-2 rounded-md bg-muted/50">
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{emp ? `${emp.firstName} ${emp.lastName}` : "Unknown"}</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => selectedProject && unassignEmployeeMutation.mutate({
                            projectId: selectedProject.id,
                            assignmentId: assignment.id,
                          })}
                          data-testid={`button-unassign-${assignment.employeeId}`}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Available Employees */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Available Employees</Label>
              <div className="space-y-1">
                {filteredEmployees.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    {employeeSearch ? "No matching employees found" : "All employees are assigned"}
                  </p>
                ) : (
                  filteredEmployees.slice(0, 10).map((emp) => (
                    <div key={emp.id} className="flex items-center justify-between p-2 rounded-md hover-elevate">
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <span className="text-sm">{emp.firstName} {emp.lastName}</span>
                          <p className="text-xs text-muted-foreground">{emp.position || emp.role}</p>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => selectedProject && assignEmployeeMutation.mutate({
                          projectId: selectedProject.id,
                          employeeId: emp.id,
                        })}
                        disabled={assignEmployeeMutation.isPending}
                        data-testid={`button-assign-${emp.id}`}
                      >
                        <UserPlus className="h-3 w-3 mr-1" />
                        Assign
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          <DialogFooter className="flex-shrink-0 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsAssignDialogOpen(false)}>
              Done
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Project Details Modal */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="max-w-4xl h-[90vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <div className="flex items-center gap-3">
              <DialogTitle className="text-xl">{selectedProject?.name}</DialogTitle>
              {selectedProject && (
                <Badge variant="secondary" className={statusColors[selectedProject.status] || ""}>
                  {selectedProject.status}
                </Badge>
              )}
            </div>
            <DialogDescription className="flex items-center gap-4 mt-2">
              {(selectedProject as any)?.poNumber && (
                <span className="text-sm">
                  <strong>P.O:</strong> {(selectedProject as any).poNumber}
                </span>
              )}
              {selectedProject?.client && (
                <span className="text-sm">
                  <strong>Client:</strong> {selectedProject.client}
                </span>
              )}
              {selectedProject?.code && (
                <span className="text-sm text-muted-foreground">
                  {selectedProject.code}
                </span>
              )}
            </DialogDescription>
          </DialogHeader>

          <ScrollArea className="flex-1 min-h-0 pr-4">
            <div className="space-y-6 py-4">
              {/* KPI Cards */}
              {!selectedProject?.isOffice && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {/* Hours Tracking */}
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                        <Clock className="h-4 w-4" />
                        Hours
                      </div>
                      <div className="text-lg font-semibold">
                        {selectedProject?.hoursUsed ?? 0}h / {selectedProject?.allocatedHours ? `${parseFloat(selectedProject.allocatedHours).toFixed(0)}h` : "N/A"}
                      </div>
                      {selectedProject?.allocatedHours && (
                        <Progress
                          value={Math.min(
                            ((selectedProject.hoursUsed ?? 0) / parseFloat(selectedProject.allocatedHours)) * 100,
                            100
                          )}
                          className="h-2 mt-2"
                        />
                      )}
                    </CardContent>
                  </Card>

                  {/* Task Progress */}
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                        <ClipboardList className="h-4 w-4" />
                        Tasks
                      </div>
                      <div className="text-lg font-semibold">
                        {selectedProject?.completedTasks ?? 0}/{selectedProject?.taskCount ?? 0} Complete
                      </div>
                      <Progress value={selectedProject?.progress ?? 0} className="h-2 mt-2" />
                    </CardContent>
                  </Card>

                  {/* Total Expenses */}
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                        <DollarSign className="h-4 w-4" />
                        Expenses
                      </div>
                      <div className="text-lg font-semibold">
                        ₱{(selectedProject?.totalApprovedExpenses ?? 0).toLocaleString()}
                      </div>
                      <p className="text-xs text-muted-foreground">Approved expenses</p>
                      {(selectedProject?.estimatedMealAllowance ?? 0) > 0 && (
                        <div className="mt-2 pt-2 border-t">
                          <div className="flex justify-between items-center">
                            <span className="text-xs text-muted-foreground">Meal Allowance</span>
                            <span className="text-xs font-semibold">₱{(selectedProject?.estimatedMealAllowance ?? 0).toLocaleString()}</span>
                          </div>
                          <p className="text-[10px] text-muted-foreground">
                            ₱{parseFloat(selectedProject?.mealAllowance || "0").toLocaleString()}/head/day
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Amount Paid (Labor Cost) */}
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                        <Banknote className="h-4 w-4" />
                        Amount Paid
                      </div>
                      <div className="text-lg font-semibold">
                        ₱{(selectedProject?.totalLaborCost ?? 0).toLocaleString()}
                      </div>
                      <p className="text-xs text-muted-foreground">Based on hours logged</p>
                    </CardContent>
                  </Card>

                  {/* Assigned Team */}
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                        <Users className="h-4 w-4" />
                        Team
                      </div>
                      <div className="text-lg font-semibold">
                        {projectDetails?.assignments?.length ?? 0} members
                      </div>
                      {selectedProject?.projectManagerId && (
                        <p className="text-xs text-muted-foreground">
                          PM: {getEmployeeName(selectedProject.projectManagerId)}
                        </p>
                      )}
                    </CardContent>
                  </Card>

                  {/* Timeline */}
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                        <Calendar className="h-4 w-4" />
                        Timeline
                      </div>
                      <div className="text-sm font-semibold">
                        {selectedProject?.startDate
                          ? format(new Date(selectedProject.startDate), "MMM d, yyyy")
                          : "Not set"}
                        {selectedProject?.deadline && (
                          <> - {format(new Date(selectedProject.deadline), "MMM d, yyyy")}</>
                        )}
                      </div>
                      {selectedProject?.deadline && (
                        <p className="text-xs text-muted-foreground">
                          {new Date(selectedProject.deadline) > new Date()
                            ? `${Math.ceil((new Date(selectedProject.deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days remaining`
                            : "Deadline passed"}
                        </p>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Project Description */}
              {selectedProject?.description && (
                <div className="space-y-2">
                  <h4 className="font-medium flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Description
                  </h4>
                  <p className="text-sm text-muted-foreground">{selectedProject.description}</p>
                </div>
              )}

              <Separator />

              {/* Tasks Shortcuts */}
              {!selectedProject?.isOffice && (
                <div className="space-y-3">
                  <h4 className="font-medium flex items-center gap-2">
                    <ClipboardList className="h-4 w-4" />
                    Project Tasks ({projectTasks.length})
                  </h4>
                  {projectTasks.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No tasks created yet.</p>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {projectTasks.slice(0, 6).map((task) => {
                        const taskStatusColors: Record<string, string> = {
                          Todo: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200",
                          In_Progress: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
                          Blocked: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
                          Done: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
                        };
                        return (
                          <Link key={task.id} href={`/tasks?taskId=${task.id}`} onClick={() => setIsDetailsDialogOpen(false)}>
                            <Card className="cursor-pointer hover:bg-muted/50 hover:shadow-md transition-all">
                              <CardContent className="p-3 flex items-center justify-between">
                                <div className="flex items-center gap-2 min-w-0">
                                  {task.status === "Done" ? (
                                    <CheckCircle2 className="h-4 w-4 text-green-500 flex-shrink-0" />
                                  ) : (
                                    <ClipboardList className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                                  )}
                                  <span className="text-sm truncate">{task.title}</span>
                                </div>
                                <Badge variant="secondary" className={`text-xs flex-shrink-0 ${taskStatusColors[task.status] || ""}`}>
                                  {task.status.replace("_", " ")}
                                </Badge>
                              </CardContent>
                            </Card>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                  {projectTasks.length > 6 && (
                    <p className="text-sm text-muted-foreground">
                      And {projectTasks.length - 6} more tasks...
                    </p>
                  )}
                </div>
              )}

              <Separator />

              {/* Comments Section */}
              <div className="space-y-3">
                <h4 className="font-medium flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Project Comments ({projectComments.length})
                </h4>

                {/* Comment Input */}
                <div className="space-y-3">
                  <Textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Add a comment about this project..."
                    className="min-h-[80px]"
                  />

                  {/* Image Upload */}
                  <PhotoUploader
                    value={commentAttachments}
                    onChange={(value) => setCommentAttachments(value ? (Array.isArray(value) ? value : [value]) : [])}
                    multiple={true}
                    maxFiles={5}
                    accept={["image/jpeg", "image/png", "image/webp", "image/gif"]}
                    maxSizeMB={5}
                    showCamera={true}
                    placeholder="Add images to your comment (optional)"
                    className="mt-2"
                  />
                </div>
                <div className="flex justify-end">
                  <Button
                    onClick={handleAddComment}
                    disabled={!newComment.trim() || addCommentMutation.isPending}
                    size="sm"
                  >
                    {addCommentMutation.isPending ? (
                      "Posting..."
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Post Comment
                      </>
                    )}
                  </Button>
                </div>

                {/* Comments List */}
                {commentsLoading ? (
                  <div className="space-y-3">
                    {[1, 2].map((i) => (
                      <Skeleton key={i} className="h-20 w-full" />
                    ))}
                  </div>
                ) : projectComments.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No comments yet. Be the first to comment!
                  </p>
                ) : (
                  <div className="space-y-3">
                    {projectComments.map((comment) => {
                      const author = employees.find((e) => e.id === comment.authorId);
                      return (
                        <div key={comment.id} className="flex gap-3 p-3 rounded-lg bg-muted/30">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="text-xs">
                              {author ? getInitials(author.firstName, author.lastName) : "?"}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-medium">
                                {author ? `${author.firstName} ${author.lastName}` : "Unknown User"}
                              </span>
                              <span className="text-xs text-muted-foreground">
                                {format(new Date(comment.createdAt), "MMM d, yyyy h:mm a")}
                              </span>
                            </div>
                            <p className="text-sm whitespace-pre-wrap">{comment.content}</p>
                            {comment.attachments && comment.attachments.length > 0 && (
                              <div className="flex flex-wrap gap-2 mt-3">
                                {comment.attachments.map((att, idx) => (
                                  att.url?.startsWith('data:image/') ? (
                                    <a
                                      key={idx}
                                      href={att.url}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="block"
                                    >
                                      <img
                                        src={att.url}
                                        alt={att.name}
                                        className="h-20 w-20 object-cover rounded-lg border hover:opacity-90 transition-opacity cursor-pointer"
                                      />
                                    </a>
                                  ) : (
                                    <Badge key={idx} variant="outline" className="gap-1">
                                      <Paperclip className="h-3 w-3" />
                                      {att.name}
                                    </Badge>
                                  )
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </ScrollArea>

          <DialogFooter className="flex-shrink-0 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsDetailsDialogOpen(false)}>
              Close
            </Button>
            <Button onClick={() => {
              setIsDetailsDialogOpen(false);
              if (selectedProject) handleEdit(selectedProject);
            }}>
              <Pencil className="h-4 w-4 mr-2" />
              Edit Project
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
