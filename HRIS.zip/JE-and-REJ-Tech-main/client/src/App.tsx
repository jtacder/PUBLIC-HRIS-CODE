import { Switch, Route } from "wouter";
import { lazy, Suspense } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import { Skeleton } from "@/components/ui/skeleton";
import { TourProvider, WelcomeModal, TourHelpIcon } from "@/components/tour";
import { usePageTour } from "@/hooks/usePageTour";
import { dashboardAdminSteps, dashboardEmployeeSteps } from "@/lib/tour/steps";
import { OfflineIndicator } from "@/components/offline-indicator";
import { NotificationCenter } from "@/components/notification-center";

import LandingPage from "@/pages/landing";
import LoginPage from "@/pages/login";
import ResetPasswordPage from "@/pages/reset-password";
import NotFound from "@/pages/not-found";

const DashboardPage = lazy(() => import("@/pages/dashboard"));
const EmployeeDashboardPage = lazy(() => import("@/pages/employee-dashboard"));
const EmployeesPage = lazy(() => import("@/pages/employees"));
const ProjectsPage = lazy(() => import("@/pages/projects"));
const TasksPage = lazy(() => import("@/pages/tasks"));
const AttendancePage = lazy(() => import("@/pages/attendance"));
const PayrollPage = lazy(() => import("@/pages/payroll"));
const TwoOhOneFilesPage = lazy(() => import("@/pages/201-files"));
const DisciplinaryPage = lazy(() => import("@/pages/disciplinary"));
const ExpensesPage = lazy(() => import("@/pages/expenses"));
const HRSettingsPage = lazy(() => import("@/pages/hr-settings"));
const HRRequestsPage = lazy(() => import("@/pages/hr-requests"));
const AuditLogsPage = lazy(() => import("@/pages/audit-logs"));
const DevotionalManagementPage = lazy(() => import("@/pages/devotional-management"));
const PermissionManagementPage = lazy(() => import("@/pages/permission-management"));
const ScheduleManagementPage = lazy(() => import("@/pages/schedule-management"));
const NotificationManagementPage = lazy(() => import("@/pages/notification-management"));

const MyTasksPage = lazy(() => import("@/pages/my-tasks"));
const MyPayslipsPage = lazy(() => import("@/pages/my-payslips"));
const MyDisciplinaryPage = lazy(() => import("@/pages/my-disciplinary"));
const MyRequestsPage = lazy(() => import("@/pages/my-requests"));
const MyProfilePage = lazy(() => import("@/pages/my-profile"));

function AuthenticatedLayout({ children }: { children: React.ReactNode }) {
  const { user, hasPermission, isSuperadmin, isAdmin: isLegacyAdmin } = useAuth();
  const hasAdminAccess = isSuperadmin || hasPermission("dashboard.view_admin") || isLegacyAdmin;
  const pageTour = usePageTour(hasAdminAccess);

  // Fallback to dashboard steps if no page-specific tour
  const tourSteps = pageTour?.steps || (hasAdminAccess ? dashboardAdminSteps : dashboardEmployeeSteps);
  const tourId = pageTour?.tourId || (hasAdminAccess ? 'dashboard-admin' : 'dashboard-employee');

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:p-4 focus:bg-background focus:text-foreground"
        >
          Skip to main content
        </a>
        <AppSidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex h-14 items-center justify-between gap-4 border-b bg-background px-4 lg:px-6">
            <SidebarTrigger data-testid="button-sidebar-toggle" aria-label="Toggle sidebar navigation" data-tour="sidebar-toggle" />
            <div className="flex items-center gap-2">
              <TourHelpIcon tourId={tourId} steps={tourSteps} />
              <NotificationCenter />
              <ThemeToggle />
            </div>
          </header>
          <main id="main-content" className="flex-1 overflow-y-auto p-4 lg:p-6" tabIndex={-1}>
            {children}
          </main>
        </div>
        <WelcomeModal
          userName={user?.firstName}
          role={user?.role as 'ADMIN' | 'HR' | 'ENGINEER' | 'WORKER'}
          dashboardSteps={tourSteps}
        />
      </div>
    </SidebarProvider>
  );
}

function Router() {
  const { user, isLoading, hasPermission, isSuperadmin, isAdmin: isLegacyAdmin } = useAuth();

  // Show loading state
  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Skeleton className="h-12 w-12 rounded-full" />
          <Skeleton className="h-4 w-32" />
        </div>
      </div>
    );
  }

  // Not authenticated - show landing or login
  if (!user) {
    return (
      <Switch>
        <Route path="/login" component={LoginPage} />
        <Route path="/reset-password" component={ResetPasswordPage} />
        <Route component={LandingPage} />
      </Switch>
    );
  }

  // Use new permission-based checks with fallback to legacy role check
  const hasAdminAccess = isSuperadmin || hasPermission("dashboard.view_admin") || isLegacyAdmin;

  // Role-based dashboard selection
  const DashboardComponent = hasAdminAccess ? DashboardPage : EmployeeDashboardPage;

  const PageLoader = (
    <div className="flex h-64 items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <Skeleton className="h-8 w-8 rounded-full" />
        <Skeleton className="h-4 w-24" />
      </div>
    </div>
  );

  return (
    <AuthenticatedLayout>
      <Suspense fallback={PageLoader}>
        <Switch>
          <Route path="/" component={DashboardComponent} />
          <Route path="/dashboard" component={DashboardPage} />
          <Route path="/my-dashboard" component={EmployeeDashboardPage} />

          <Route path="/projects" component={ProjectsPage} />
          <Route path="/tasks" component={TasksPage} />
          <Route path="/attendance" component={AttendancePage} />

          {/* Schedule Management - requires schedules.view */}
          {(hasAdminAccess || hasPermission("schedules.view")) && (
            <Route path="/schedule-management" component={ScheduleManagementPage} />
          )}

          {/* Admin routes - now permission-gated */}
          {(hasAdminAccess || hasPermission("employees.view")) && (
            <Route path="/employees" component={EmployeesPage} />
          )}
          {(hasAdminAccess || hasPermission("payroll.view")) && (
            <Route path="/payroll" component={PayrollPage} />
          )}
          {(hasAdminAccess || hasPermission("documents.view")) && (
            <Route path="/201-files" component={TwoOhOneFilesPage} />
          )}
          {(hasAdminAccess || hasPermission("disciplinary.view_all")) && (
            <Route path="/disciplinary" component={DisciplinaryPage} />
          )}
          {(hasAdminAccess || hasPermission("leave.view_all")) && (
            <Route path="/hr-requests" component={HRRequestsPage} />
          )}
          {/* Expenses accessible to Admin/HR/superadmin and Engineers only */}
          {(hasAdminAccess || hasPermission("expenses.view_all") || user?.role === "ENGINEER") && (
            <Route path="/expenses" component={ExpensesPage} />
          )}
          {(hasAdminAccess || hasPermission("hr_settings.view")) && (
            <Route path="/hr-settings" component={HRSettingsPage} />
          )}
          {(hasAdminAccess || hasPermission("devotionals.manage")) && (
            <Route path="/devotionals" component={DevotionalManagementPage} />
          )}
          {(hasAdminAccess || hasPermission("audit.view")) && (
            <Route path="/audit-logs" component={AuditLogsPage} />
          )}

          {/* Permission Management - requires permissions.view */}
          {(isSuperadmin || hasPermission("permissions.view")) && (
            <Route path="/permissions" component={PermissionManagementPage} />
          )}

          {/* Notification Management - Admin/HR only */}
          {hasAdminAccess && (
            <Route path="/notification-management" component={NotificationManagementPage} />
          )}

          {/* Employee self-service routes */}
          <Route path="/my-tasks" component={MyTasksPage} />
          <Route path="/my-payslips" component={MyPayslipsPage} />
          <Route path="/my-disciplinary" component={MyDisciplinaryPage} />
          <Route path="/my-requests" component={MyRequestsPage} />
          <Route path="/my-profile" component={MyProfilePage} />

          <Route component={NotFound} />
        </Switch>
      </Suspense>
    </AuthenticatedLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <TourProvider>
          <Toaster />
          <Router />
          {/* PWA offline indicator - shows when user loses network connection */}
          <OfflineIndicator />
        </TourProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
