import { useEffect, useRef, useState, useCallback } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { QrCode, Camera, XCircle, CheckCircle, Loader2 } from "lucide-react";

interface QRScannerProps {
  onScanSuccess: (qrData: { token: string; name: string; employeeNo: string }) => void;
  onScanError?: (error: string) => void;
  isProcessing?: boolean;
  scannedEmployee?: { name: string; employeeNo: string } | null;
}

export function QRScanner({
  onScanSuccess,
  onScanError,
  isProcessing = false,
  scannedEmployee = null
}: QRScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [shouldStartScanner, setShouldStartScanner] = useState(false);
  const [scanError, setScanError] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);

  // Use a ref for onScanSuccess to avoid stale closures inside the scanner callback.
  // The html5-qrcode scanner captures the callback at start() time, so without this
  // ref the callback would reference stale employees/attendanceLogs data.
  const onScanSuccessRef = useRef(onScanSuccess);
  useEffect(() => {
    onScanSuccessRef.current = onScanSuccess;
  }, [onScanSuccess]);

  // Guard ref to prevent the success callback from firing multiple times.
  // html5-qrcode calls the success callback on EVERY frame that contains a QR code
  // (up to fps rate). Without this guard, a QR badge held in front of a desktop
  // webcam fires onScanSuccess ~10x/sec, causing cascading API calls and state
  // updates that freeze the UI.
  const hasScannedRef = useRef(false);

  const stopScanner = useCallback(async () => {
    if (scannerRef.current) {
      try {
        const state = scannerRef.current.getState();
        // Only attempt stop if scanner is actively scanning (state 2 = SCANNING)
        if (state === 2) {
          await scannerRef.current.stop();
        }
      } catch (err) {
        console.error("Error stopping scanner:", err);
      }
      try {
        scannerRef.current.clear();
      } catch {
        // clear() can throw if the element is already gone (unmount race)
      }
      scannerRef.current = null;
    }
    setIsScanning(false);
  }, []);

  const initScanner = useCallback(async () => {
    setScanError(null);
    setCameraError(null);
    hasScannedRef.current = false;

    // If a previous scanner instance exists, stop it first to release the camera.
    // This prevents orphaned camera streams when initScanner is called again
    // without a full unmount cycle (e.g., user clicks "Start" while scanner is
    // in a degraded state).
    if (scannerRef.current) {
      try {
        const state = scannerRef.current.getState();
        if (state === 2) {
          await scannerRef.current.stop();
        }
        scannerRef.current.clear();
      } catch {
        // best-effort cleanup
      }
      scannerRef.current = null;
    }

    try {
      const scanner = new Html5Qrcode("qr-reader");
      scannerRef.current = scanner;

      const scanConfig = {
        fps: 10,
        qrbox: { width: 250, height: 250 },
      };

      const successCallback = (decodedText: string) => {
        // Guard: only process the first successful decode.
        if (hasScannedRef.current) return;

        try {
          const qrData = JSON.parse(decodedText);
          if (qrData.token && qrData.name) {
            hasScannedRef.current = true;

            // Stop the scanner immediately to release the camera before the
            // parent component transitions to the photo step. This eliminates
            // the race between html5-qrcode async stop() and getUserMedia()
            // for the photo camera on single-camera desktop systems.
            scanner.stop().catch((err: unknown) => {
              console.error("Error stopping scanner after scan:", err);
            });

            // Use the ref to always call the latest onScanSuccess, avoiding
            // stale closure over employees/attendanceLogs data.
            onScanSuccessRef.current(qrData);
          } else {
            setScanError("Invalid QR code format");
          }
        } catch {
          setScanError("Invalid QR code. Please scan a valid employee QR.");
        }
      };

      const errorCallback = () => {};

      // Try "environment" (rear camera) first. On desktop systems that only
      // have a front-facing webcam, this will fail — so we fall back to "user".
      try {
        await scanner.start(
          { facingMode: "environment" },
          scanConfig,
          successCallback,
          errorCallback
        );
      } catch {
        // Environment camera not available (typical on desktop) — try front camera
        await scanner.start(
          { facingMode: "user" },
          scanConfig,
          successCallback,
          errorCallback
        );
      }
    } catch (err: any) {
      console.error("Scanner error:", err);
      setCameraError(err.message || "Unable to start camera. Please grant camera permissions.");
      setIsScanning(false);
      setShouldStartScanner(false);
    }
  }, [stopScanner]);

  // Start scanner after DOM element is rendered
  useEffect(() => {
    if (shouldStartScanner && isScanning) {
      const timer = setTimeout(() => {
        initScanner();
        setShouldStartScanner(false);
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [shouldStartScanner, isScanning, initScanner]);

  const startScanner = useCallback(() => {
    hasScannedRef.current = false;
    setIsScanning(true);
    setShouldStartScanner(true);
  }, []);

  useEffect(() => {
    return () => {
      stopScanner();
    };
  }, [stopScanner]);

  const resetScanner = useCallback(() => {
    setScanError(null);
    hasScannedRef.current = false;
    startScanner();
  }, [startScanner]);

  return (
    <div className="space-y-4">
      {scannedEmployee ? (
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-2">
            <CheckCircle className="h-6 w-6 text-green-500" />
            <span className="font-medium">QR Code Scanned Successfully</span>
          </div>
          <Card className="bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800">
            <CardContent className="p-4 text-center">
              <p className="text-lg font-semibold">{scannedEmployee.name}</p>
              <p className="text-sm text-muted-foreground">
                Employee ID: {scannedEmployee.employeeNo || "Not Assigned"}
              </p>
            </CardContent>
          </Card>
          {isProcessing && (
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Processing attendance...</span>
            </div>
          )}
        </div>
      ) : (
        <>
          {!isScanning ? (
            <div className="text-center space-y-4">
              <div className="w-64 h-64 mx-auto bg-muted/30 rounded-lg border-2 border-dashed border-muted-foreground/30 flex flex-col items-center justify-center">
                <QrCode className="h-16 w-16 text-muted-foreground/50 mb-4" />
                <p className="text-sm text-muted-foreground px-4">
                  Click below to start scanning your employee QR code
                </p>
              </div>

              {cameraError && (
                <div className="flex items-center justify-center gap-2 text-destructive text-sm">
                  <XCircle className="h-4 w-4" />
                  <span>{cameraError}</span>
                </div>
              )}

              <Button
                onClick={startScanner}
                size="lg"
                className="gap-2"
                data-testid="button-start-scan"
              >
                <Camera className="h-5 w-5" />
                Start QR Scanner
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div
                id="qr-reader"
                className="mx-auto overflow-hidden rounded-lg"
                style={{ width: "100%", maxWidth: "400px", minHeight: "300px" }}
              />

              {scanError && (
                <div className="flex items-center justify-center gap-2 text-destructive text-sm">
                  <XCircle className="h-4 w-4" />
                  <span>{scanError}</span>
                  <Button variant="ghost" size="sm" onClick={resetScanner}>
                    Try Again
                  </Button>
                </div>
              )}

              <div className="text-center">
                <Badge variant="outline" className="animate-pulse">
                  <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                  Scanning for QR Code...
                </Badge>
              </div>

              <div className="text-center">
                <Button
                  variant="outline"
                  onClick={stopScanner}
                  data-testid="button-stop-scan"
                >
                  Cancel Scan
                </Button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
