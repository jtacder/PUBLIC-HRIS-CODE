import * as React from "react";
import { cn } from "@/lib/utils";

interface AnimatedBackgroundProps {
  className?: string;
  variant?: "gradient" | "particles" | "geometric" | "electrical";
}

/**
 * AnimatedBackground - A subtle, performant animated background
 * Uses CSS animations for performance optimization
 */
export function AnimatedBackground({
  className,
  variant = "gradient",
}: AnimatedBackgroundProps) {
  if (variant === "gradient") {
    return <GradientMeshBackground className={className} />;
  }

  if (variant === "geometric") {
    return <GeometricBackground className={className} />;
  }

  if (variant === "electrical") {
    return <ElectricalBackground className={className} />;
  }

  return <GradientMeshBackground className={className} />;
}

/**
 * Gradient Mesh Animation - Subtle flowing gradients
 */
function GradientMeshBackground({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "fixed inset-0 -z-10 overflow-hidden",
        className
      )}
    >
      {/* Base gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" />

      {/* Animated gradient orbs */}
      <div
        className="absolute -top-1/2 -left-1/2 w-full h-full rounded-full opacity-30 blur-3xl animate-blob"
        style={{
          background: "radial-gradient(circle, rgba(59, 130, 246, 0.4) 0%, transparent 70%)",
          animationDelay: "0s",
        }}
      />
      <div
        className="absolute -bottom-1/2 -right-1/2 w-full h-full rounded-full opacity-30 blur-3xl animate-blob"
        style={{
          background: "radial-gradient(circle, rgba(147, 51, 234, 0.3) 0%, transparent 70%)",
          animationDelay: "2s",
        }}
      />
      <div
        className="absolute top-1/4 right-1/4 w-3/4 h-3/4 rounded-full opacity-20 blur-3xl animate-blob"
        style={{
          background: "radial-gradient(circle, rgba(234, 179, 8, 0.25) 0%, transparent 70%)",
          animationDelay: "4s",
        }}
      />

      {/* Subtle grid overlay */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Vignette effect */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/50 via-transparent to-slate-900/30" />
    </div>
  );
}

/**
 * Geometric Background - Subtle floating shapes
 */
function GeometricBackground({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "fixed inset-0 -z-10 overflow-hidden bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900",
        className
      )}
    >
      {/* Floating geometric shapes */}
      {[...Array(6)].map((_, i) => (
        <div
          key={i}
          className="absolute border border-white/5 rounded-lg animate-float"
          style={{
            width: `${100 + i * 50}px`,
            height: `${100 + i * 50}px`,
            left: `${10 + i * 15}%`,
            top: `${5 + i * 12}%`,
            animationDelay: `${i * 0.8}s`,
            animationDuration: `${15 + i * 2}s`,
            transform: `rotate(${i * 15}deg)`,
          }}
        />
      ))}

      {/* Accent lines */}
      <div className="absolute top-0 left-1/4 w-px h-full bg-gradient-to-b from-transparent via-blue-500/20 to-transparent" />
      <div className="absolute top-0 right-1/3 w-px h-full bg-gradient-to-b from-transparent via-amber-500/10 to-transparent" />

      {/* Subtle radial gradient overlay */}
      <div className="absolute inset-0 bg-radial-gradient opacity-50" />
    </div>
  );
}

/**
 * Electrical Background - Sophisticated Neon Edition
 * Refined for "Premium Dark Mode Enterprise" aesthetic
 * Key changes: Fewer elements, slower animations, softer glows, better hierarchy
 */
function ElectricalBackground({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "fixed inset-0 -z-10 overflow-hidden",
        className
      )}
    >
      {/* Base dark background - deeper, more professional */}
      <div
        className="absolute inset-0"
        style={{
          background: `
            radial-gradient(ellipse at 15% 15%, rgba(0, 168, 255, 0.06) 0%, transparent 45%),
            radial-gradient(ellipse at 85% 85%, rgba(255, 51, 85, 0.04) 0%, transparent 45%),
            linear-gradient(180deg, #08080c 0%, #0d0d14 50%, #08080c 100%)
          `,
        }}
      />

      {/* Subtle Circuit Grid - reduced opacity for sophistication */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 168, 255, 0.015) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 168, 255, 0.015) 1px, transparent 1px)
          `,
          backgroundSize: "80px 80px",
        }}
      />

      {/* Reduced Wire Set - Only 4 horizontal, 2 vertical for cleaner look */}
      <div className="wire-h wire-h-1" />
      <div className="wire-h wire-h-2" />
      <div className="wire-h wire-h-red wire-h-3" />
      <div className="wire-h wire-h-4" />

      {/* Vertical Wires - Minimal */}
      <div className="wire-v wire-v-1" />
      <div className="wire-v wire-v-red wire-v-2" />

      {/* Floating Tool Icons - Reduced to 3 key icons */}
      {/* Zap/Lightning - Brand Icon */}
      <div className="floating-icon icon-1">
        <svg viewBox="0 0 24 24"><path d="M7 2v11h3v9l7-12h-4l4-8z"/></svg>
      </div>
      {/* Wrench */}
      <div className="floating-icon icon-2">
        <svg viewBox="0 0 24 24"><path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/></svg>
      </div>
      {/* Circuit */}
      <div className="floating-icon floating-icon-red icon-3">
        <svg viewBox="0 0 24 24"><path d="M20 18c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2H0v2h24v-2h-4zM4 6h16v10H4V6z"/></svg>
      </div>

      {/* Single Subtle Arc - decorative element */}
      <div className="arc-container arc-1">
        <svg viewBox="0 0 200 120">
          <path className="arc-path" d="M10 110 Q 100 10, 190 110"/>
        </svg>
      </div>

      {/* Soft Ambient Corner Glows - using box-shadow style approach */}
      <div
        className="absolute top-0 left-0 w-1/2 h-1/2 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at 0% 0%, rgba(0, 168, 255, 0.08) 0%, transparent 60%)",
        }}
      />
      <div
        className="absolute bottom-0 right-0 w-1/2 h-1/2 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at 100% 100%, rgba(255, 51, 85, 0.06) 0%, transparent 60%)",
        }}
      />

      {/* Dark overlay for better text contrast - the key to "Enterprise Grade" */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "linear-gradient(rgba(8, 8, 12, 0.4), rgba(8, 8, 12, 0.2), rgba(8, 8, 12, 0.5))",
        }}
      />

      {/* Vignette effect - strengthened for focus */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#08080c]/70 via-transparent to-[#08080c]/50 pointer-events-none" />

      {/* Refined animation styles - Slower, Softer, Subtler */}
      <style>{`
        /* ========== SOPHISTICATED WIRE ANIMATIONS ========== */
        .wire-h {
          position: absolute;
          height: 1.5px;
          background: linear-gradient(90deg,
            transparent 0%,
            rgba(0, 168, 255, 0.3) 15%,
            rgba(0, 168, 255, 0.7) 50%,
            rgba(0, 168, 255, 0.3) 85%,
            transparent 100%);
          filter: drop-shadow(0 0 4px rgba(0, 168, 255, 0.4));
          animation: wireFlowH linear infinite;
          opacity: 0;
        }

        .wire-h::before {
          content: '';
          position: absolute;
          right: -4px;
          top: -2px;
          width: 5px;
          height: 5px;
          background: rgba(0, 168, 255, 0.9);
          border-radius: 50%;
          box-shadow: 0 0 8px rgba(0, 168, 255, 0.6), 0 0 16px rgba(0, 168, 255, 0.3);
        }

        /* Slower, staggered animations - 15-25 second durations */
        .wire-h-1 { top: 12%; width: 300px; left: -300px; animation-duration: 18s; animation-delay: 0s; }
        .wire-h-2 { top: 38%; width: 250px; left: -250px; animation-duration: 22s; animation-delay: 6s; }
        .wire-h-3 { top: 62%; width: 280px; left: -280px; animation-duration: 20s; animation-delay: 12s; }
        .wire-h-4 { top: 85%; width: 220px; left: -220px; animation-duration: 25s; animation-delay: 3s; }

        .wire-h-red {
          background: linear-gradient(90deg,
            transparent 0%,
            rgba(255, 51, 85, 0.25) 15%,
            rgba(255, 51, 85, 0.6) 50%,
            rgba(255, 51, 85, 0.25) 85%,
            transparent 100%);
          filter: drop-shadow(0 0 4px rgba(255, 51, 85, 0.35));
        }

        .wire-h-red::before {
          background: rgba(255, 51, 85, 0.85);
          box-shadow: 0 0 8px rgba(255, 51, 85, 0.5), 0 0 16px rgba(255, 51, 85, 0.25);
        }

        @keyframes wireFlowH {
          0% { transform: translateX(0); opacity: 0; }
          3% { opacity: 0.25; }
          50% { opacity: 0.35; }
          97% { opacity: 0.25; }
          100% { transform: translateX(calc(100vw + 350px)); opacity: 0; }
        }

        /* Vertical Wires - Minimal */
        .wire-v {
          position: absolute;
          width: 1.5px;
          background: linear-gradient(180deg,
            transparent 0%,
            rgba(0, 168, 255, 0.3) 15%,
            rgba(0, 168, 255, 0.7) 50%,
            rgba(0, 168, 255, 0.3) 85%,
            transparent 100%);
          filter: drop-shadow(0 0 4px rgba(0, 168, 255, 0.4));
          animation: wireFlowV linear infinite;
          opacity: 0;
        }

        .wire-v::before {
          content: '';
          position: absolute;
          bottom: -4px;
          left: -2px;
          width: 5px;
          height: 5px;
          background: rgba(0, 168, 255, 0.9);
          border-radius: 50%;
          box-shadow: 0 0 8px rgba(0, 168, 255, 0.6), 0 0 16px rgba(0, 168, 255, 0.3);
        }

        .wire-v-1 { left: 8%; height: 220px; top: -220px; animation-duration: 20s; animation-delay: 4s; }
        .wire-v-2 { right: 12%; height: 200px; top: -200px; animation-duration: 24s; animation-delay: 10s; }

        .wire-v-red {
          background: linear-gradient(180deg,
            transparent 0%,
            rgba(255, 51, 85, 0.25) 15%,
            rgba(255, 51, 85, 0.6) 50%,
            rgba(255, 51, 85, 0.25) 85%,
            transparent 100%);
          filter: drop-shadow(0 0 4px rgba(255, 51, 85, 0.35));
        }

        .wire-v-red::before {
          background: rgba(255, 51, 85, 0.85);
          box-shadow: 0 0 8px rgba(255, 51, 85, 0.5), 0 0 16px rgba(255, 51, 85, 0.25);
        }

        @keyframes wireFlowV {
          0% { transform: translateY(0); opacity: 0; }
          3% { opacity: 0.25; }
          50% { opacity: 0.35; }
          97% { opacity: 0.25; }
          100% { transform: translateY(calc(100vh + 250px)); opacity: 0; }
        }

        /* ========== SUBTLE FLOATING ICONS ========== */
        .floating-icon {
          position: absolute;
          opacity: 0;
          animation: floatIconSubtle 30s ease-in-out infinite;
        }

        .floating-icon svg {
          width: 28px;
          height: 28px;
          fill: rgba(0, 168, 255, 0.4);
        }

        .floating-icon-red svg {
          fill: rgba(255, 51, 85, 0.35);
        }

        .icon-1 { top: 15%; left: 6%; animation-delay: 0s; }
        .icon-2 { bottom: 25%; right: 8%; animation-delay: 10s; }
        .icon-3 { top: 55%; left: 4%; animation-delay: 20s; }

        @keyframes floatIconSubtle {
          0%, 100% { transform: translateY(0) rotate(0deg); opacity: 0.1; }
          25% { transform: translateY(-15px) rotate(3deg); opacity: 0.2; }
          50% { transform: translateY(-8px) rotate(-2deg); opacity: 0.15; }
          75% { transform: translateY(-18px) rotate(2deg); opacity: 0.2; }
        }

        /* ========== SINGLE SUBTLE ARC ========== */
        .arc-container {
          position: absolute;
          width: 200px;
          height: 120px;
          opacity: 0.15;
        }

        .arc-container svg {
          width: 100%;
          height: 100%;
        }

        .arc-path {
          fill: none;
          stroke: rgba(0, 168, 255, 0.5);
          stroke-width: 1;
          stroke-dasharray: 8 12;
          filter: drop-shadow(0 0 3px rgba(0, 168, 255, 0.3));
          animation: arcDashSlow 3s linear infinite;
        }

        .arc-1 { bottom: 20%; right: 15%; }

        @keyframes arcDashSlow {
          to { stroke-dashoffset: -40; }
        }

        /* Hide decorative elements on mobile for clean performance */
        @media (max-width: 768px) {
          .arc-container,
          .floating-icon,
          .wire-v {
            display: none;
          }

          /* Keep only 2 horizontal wires on mobile */
          .wire-h-2,
          .wire-h-4 {
            display: none;
          }
        }
      `}</style>
    </div>
  );
}

export default AnimatedBackground;
