export { AnimatedBackground, default } from "./AnimatedBackground";
