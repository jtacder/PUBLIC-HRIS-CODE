import { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  compressImage,
  validateFile,
  formatFileSize,
  isImageFile,
  isPdfFile,
  fileToBase64,
} from "@/lib/image-compression";
import {
  Upload,
  Camera,
  X,
  Image as ImageIcon,
  FileText,
  Loader2,
  ZoomIn,
  RotateCcw,
} from "lucide-react";
import { cn } from "@/lib/utils";

export interface UploadedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  dataUrl: string;
  isImage: boolean;
}

export interface PhotoUploaderProps {
  /** Current value(s) - can be a single dataUrl or array of dataUrls */
  value?: string | string[];
  /** Callback when files change */
  onChange: (value: string | string[] | null) => void;
  /** Allow multiple files */
  multiple?: boolean;
  /** Maximum number of files (when multiple=true) */
  maxFiles?: number;
  /** Allowed file types */
  accept?: string[];
  /** Maximum file size in MB */
  maxSizeMB?: number;
  /** Show camera capture button */
  showCamera?: boolean;
  /** Whether the uploader is disabled */
  disabled?: boolean;
  /** Placeholder text */
  placeholder?: string;
  /** Custom class name */
  className?: string;
  /** Aspect ratio for preview (e.g., "1/1" for square) */
  aspectRatio?: string;
  /** Label for the upload area */
  label?: string;
  /** Whether this is for a circular avatar */
  isAvatar?: boolean;
}

export function PhotoUploader({
  value,
  onChange,
  multiple = false,
  maxFiles = 5,
  accept = ["image/jpeg", "image/png", "image/webp"],
  maxSizeMB = 5,
  showCamera = true,
  disabled = false,
  placeholder = "Drag & drop or click to upload",
  className,
  aspectRatio,
  label,
  isAvatar = false,
}: PhotoUploaderProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  // Normalize value to array for internal handling
  const files: string[] = value
    ? Array.isArray(value)
      ? value
      : [value]
    : [];

  const acceptString = accept.join(",");
  const acceptsImages = accept.some(t => t.startsWith("image/"));
  const acceptsPdf = accept.includes("application/pdf");

  const processFiles = useCallback(async (fileList: FileList | File[]) => {
    const filesToProcess = Array.from(fileList);

    // Check max files limit
    if (multiple) {
      const totalFiles = files.length + filesToProcess.length;
      if (totalFiles > maxFiles) {
        toast({
          title: "Too many files",
          description: `Maximum ${maxFiles} files allowed`,
          variant: "destructive",
        });
        return;
      }
    } else if (filesToProcess.length > 1) {
      filesToProcess.splice(1);
    }

    setIsProcessing(true);
    setProcessingProgress(0);

    const processedFiles: string[] = [];

    for (let i = 0; i < filesToProcess.length; i++) {
      const file = filesToProcess[i];

      // Validate file
      const validation = validateFile(file, { allowedTypes: accept, maxSizeMB });
      if (!validation.valid) {
        toast({
          title: "Invalid file",
          description: validation.error,
          variant: "destructive",
        });
        continue;
      }

      try {
        let dataUrl: string;

        if (isImageFile(file)) {
          // Compress images
          dataUrl = await compressImage(file, {
            maxSizeMB: 1, // Compress to 1MB max
            maxWidthOrHeight: 1920,
            quality: 0.85,
          });
        } else {
          // For PDFs and other files, just convert to base64
          dataUrl = await fileToBase64(file);
        }

        processedFiles.push(dataUrl);
      } catch (error) {
        console.error("Error processing file:", error);
        toast({
          title: "Processing error",
          description: `Failed to process ${file.name}`,
          variant: "destructive",
        });
      }

      setProcessingProgress(((i + 1) / filesToProcess.length) * 100);
    }

    setIsProcessing(false);
    setProcessingProgress(0);

    if (processedFiles.length > 0) {
      if (multiple) {
        onChange([...files, ...processedFiles]);
      } else {
        onChange(processedFiles[0]);
      }
    }
  }, [files, multiple, maxFiles, accept, maxSizeMB, onChange, toast]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!disabled) setIsDragging(true);
  }, [disabled]);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (disabled) return;

    const droppedFiles = e.dataTransfer.files;
    if (droppedFiles.length > 0) {
      processFiles(droppedFiles);
    }
  }, [disabled, processFiles]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = e.target.files;
    if (selectedFiles && selectedFiles.length > 0) {
      processFiles(selectedFiles);
    }
    // Reset input
    e.target.value = "";
  }, [processFiles]);

  const handleRemoveFile = useCallback((index: number) => {
    if (multiple) {
      const newFiles = files.filter((_, i) => i !== index);
      onChange(newFiles.length > 0 ? newFiles : null);
    } else {
      onChange(null);
    }
  }, [files, multiple, onChange]);

  const handleClearAll = useCallback(() => {
    onChange(null);
  }, [onChange]);

  const getFileTypeIcon = (dataUrl: string) => {
    if (dataUrl.startsWith("data:image/")) {
      return <ImageIcon className="h-8 w-8 text-muted-foreground" />;
    }
    if (dataUrl.startsWith("data:application/pdf")) {
      return <FileText className="h-8 w-8 text-red-500" />;
    }
    return <FileText className="h-8 w-8 text-muted-foreground" />;
  };

  const isImage = (dataUrl: string) => dataUrl.startsWith("data:image/");

  return (
    <div className={cn("space-y-3", className)}>
      {label && (
        <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
          {label}
        </label>
      )}

      {/* Upload Area */}
      {(multiple || files.length === 0) && (
        <div
          className={cn(
            "relative border-2 border-dashed rounded-lg transition-all duration-200",
            isDragging
              ? "border-primary bg-primary/5"
              : "border-muted-foreground/25 hover:border-muted-foreground/50",
            disabled && "opacity-50 cursor-not-allowed",
            isAvatar ? "w-32 h-32 mx-auto" : "p-6"
          )}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept={acceptString}
            multiple={multiple}
            onChange={handleFileSelect}
            disabled={disabled}
            className="hidden"
          />

          {/* Camera input for mobile */}
          {showCamera && acceptsImages && (
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleFileSelect}
              disabled={disabled}
              className="hidden"
            />
          )}

          {isProcessing ? (
            <div className="flex flex-col items-center justify-center py-4">
              <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
              <p className="text-sm text-muted-foreground mb-2">Processing...</p>
              <Progress value={processingProgress} className="w-full max-w-xs" />
            </div>
          ) : (
            <div
              className={cn(
                "flex flex-col items-center justify-center cursor-pointer",
                isAvatar ? "h-full" : "py-4"
              )}
              onClick={() => !disabled && fileInputRef.current?.click()}
            >
              <Upload className={cn("text-muted-foreground mb-2", isAvatar ? "h-6 w-6" : "h-10 w-10")} />
              <p className={cn("text-center text-muted-foreground", isAvatar ? "text-xs" : "text-sm")}>
                {isAvatar ? "Upload" : placeholder}
              </p>
              {!isAvatar && (
                <p className="text-xs text-muted-foreground mt-1">
                  {accept.map(t => t.split('/')[1].toUpperCase()).join(', ')} up to {maxSizeMB}MB
                </p>
              )}

              {/* Action buttons */}
              {!isAvatar && showCamera && acceptsImages && (
                <div className="flex gap-2 mt-4">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      cameraInputRef.current?.click();
                    }}
                    disabled={disabled}
                  >
                    <Camera className="h-4 w-4 mr-2" />
                    Camera
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Preview Grid */}
      {files.length > 0 && (
        <div className={cn(
          "grid gap-3",
          multiple ? "grid-cols-2 sm:grid-cols-3 md:grid-cols-4" : "",
          isAvatar ? "flex justify-center" : ""
        )}>
          {files.map((file, index) => (
            <div
              key={index}
              className={cn(
                "relative group",
                isAvatar ? "w-32 h-32" : "aspect-square",
                !multiple && !isAvatar && "max-w-xs"
              )}
            >
              {isImage(file) ? (
                <div
                  className={cn(
                    "w-full h-full overflow-hidden bg-muted",
                    isAvatar ? "rounded-full" : "rounded-lg"
                  )}
                  style={aspectRatio ? { aspectRatio } : undefined}
                >
                  <img
                    src={file}
                    alt={`Upload ${index + 1}`}
                    className="w-full h-full object-cover cursor-pointer"
                    onClick={() => setPreviewImage(file)}
                  />
                </div>
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center bg-muted rounded-lg p-4">
                  {getFileTypeIcon(file)}
                  <p className="text-xs text-muted-foreground mt-2 truncate max-w-full">
                    PDF Document
                  </p>
                </div>
              )}

              {/* Remove button */}
              {!disabled && (
                <button
                  type="button"
                  onClick={() => handleRemoveFile(index)}
                  className={cn(
                    "absolute bg-destructive text-destructive-foreground rounded-full p-1",
                    "opacity-0 group-hover:opacity-100 transition-opacity",
                    "hover:bg-destructive/90 focus:opacity-100",
                    isAvatar ? "-top-1 -right-1" : "top-2 right-2"
                  )}
                  aria-label="Remove file"
                >
                  <X className="h-4 w-4" />
                </button>
              )}

              {/* Zoom button for images */}
              {isImage(file) && !isAvatar && (
                <button
                  type="button"
                  onClick={() => setPreviewImage(file)}
                  className="absolute bottom-2 right-2 bg-black/50 text-white rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/70"
                  aria-label="View full size"
                >
                  <ZoomIn className="h-4 w-4" />
                </button>
              )}
            </div>
          ))}

          {/* Add more button for multiple */}
          {multiple && files.length < maxFiles && !disabled && (
            <div
              className="aspect-square border-2 border-dashed border-muted-foreground/25 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-muted-foreground/50 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="h-6 w-6 text-muted-foreground" />
              <span className="text-xs text-muted-foreground mt-1">Add more</span>
            </div>
          )}
        </div>
      )}

      {/* Clear all button */}
      {multiple && files.length > 1 && !disabled && (
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={handleClearAll}
          className="text-destructive hover:text-destructive"
        >
          <RotateCcw className="h-4 w-4 mr-2" />
          Clear all
        </Button>
      )}

      {/* File count badge */}
      {multiple && files.length > 0 && (
        <div className="flex items-center gap-2">
          <Badge variant="secondary">
            {files.length} / {maxFiles} files
          </Badge>
        </div>
      )}

      {/* Image Preview Dialog */}
      <Dialog open={!!previewImage} onOpenChange={() => setPreviewImage(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] p-0 overflow-hidden">
          <DialogHeader className="p-4 pb-0">
            <DialogTitle>Image Preview</DialogTitle>
          </DialogHeader>
          <div className="p-4 flex items-center justify-center overflow-auto">
            {previewImage && (
              <img
                src={previewImage}
                alt="Full size preview"
                className="max-w-full max-h-[70vh] object-contain rounded-lg"
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default PhotoUploader;
