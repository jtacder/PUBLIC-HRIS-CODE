/**
 * Guide Provider Component
 *
 * Provides guide context to the entire application.
 * Manages guide state, controls, and integration with react-joyride.
 * Includes element existence checks and fallback behavior.
 */

import React, { createContext, useContext, useState, useCallback, useEffect, useMemo, useRef } from 'react';
import Joyride, { CallBackProps, STATUS, ACTIONS, EVENTS, Step } from 'react-joyride';
import { defaultGuideOptions, guideStyles, guideLocale } from '@/lib/tour/tour-config';
import {
  getTourProgress,
  markTourCompleted,
  markTourSkipped,
  saveCurrentStep,
  getCurrentStep,
  resetTour,
  isFirstTimeUser,
  markNotFirstTime,
  TourId,
} from '@/lib/tour/tour-storage';

interface TourContextValue {
  // State
  isRunning: boolean;
  currentTourId: TourId | null;
  currentStepIndex: number;
  totalSteps: number;
  isFirstTime: boolean;

  // Actions
  startTour: (tourId: TourId, steps: Step[]) => void;
  stopTour: () => void;
  nextStep: () => void;
  prevStep: () => void;
  goToStep: (index: number) => void;
  restartTour: (tourId: TourId) => void;

  // Status checks
  isTourActive: (tourId: TourId) => boolean;
  getTourProgress: () => ReturnType<typeof getTourProgress>;
}

const TourContext = createContext<TourContextValue | null>(null);

interface TourProviderProps {
  children: React.ReactNode;
}

/**
 * Check if a target element exists in the DOM
 */
function doesTargetExist(target: string | HTMLElement): boolean {
  if (target === 'body') return true;
  if (typeof target === 'string') {
    try {
      const element = document.querySelector(target);
      return element !== null;
    } catch {
      return false;
    }
  }
  return target instanceof HTMLElement && document.body.contains(target);
}

/**
 * Process steps to handle missing targets
 * - Converts steps with missing targets to body-centered fallback
 * - Preserves content and title from original step
 */
function processStepsForMissingTargets(steps: Step[]): Step[] {
  return steps.map((step) => {
    const target = step.target;
    if (doesTargetExist(target)) {
      return step;
    }
    // Fallback to body if target doesn't exist
    return {
      ...step,
      target: 'body',
      placement: 'center' as const,
    };
  });
}

export function TourProvider({ children }: TourProviderProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [currentTourId, setCurrentTourId] = useState<TourId | null>(null);
  const [steps, setSteps] = useState<Step[]>([]);
  const [stepIndex, setStepIndex] = useState(0);
  const [isFirstTime, setIsFirstTime] = useState(false);
  const startTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Check first time user on mount
  useEffect(() => {
    setIsFirstTime(isFirstTimeUser());
  }, []);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (startTimeoutRef.current) {
        clearTimeout(startTimeoutRef.current);
      }
    };
  }, []);

  const startTour = useCallback((tourId: TourId, tourSteps: Step[]) => {
    // Clear any pending start
    if (startTimeoutRef.current) {
      clearTimeout(startTimeoutRef.current);
    }

    // Small delay to ensure elements have rendered
    startTimeoutRef.current = setTimeout(() => {
      // Process steps for missing targets
      const processedSteps = processStepsForMissingTargets(tourSteps);

      // Get saved progress or start from beginning
      const savedStep = getCurrentStep(tourId);
      const startIndex = savedStep < processedSteps.length ? savedStep : 0;

      setCurrentTourId(tourId);
      setSteps(processedSteps);
      setStepIndex(startIndex);
      setIsRunning(true);
    }, 100);
  }, []);

  const stopTour = useCallback(() => {
    if (startTimeoutRef.current) {
      clearTimeout(startTimeoutRef.current);
    }
    setIsRunning(false);
    setCurrentTourId(null);
    setSteps([]);
    setStepIndex(0);
  }, []);

  const nextStep = useCallback(() => {
    if (stepIndex < steps.length - 1) {
      const newIndex = stepIndex + 1;
      setStepIndex(newIndex);
      if (currentTourId) {
        saveCurrentStep(currentTourId, newIndex);
      }
    }
  }, [stepIndex, steps.length, currentTourId]);

  const prevStep = useCallback(() => {
    if (stepIndex > 0) {
      const newIndex = stepIndex - 1;
      setStepIndex(newIndex);
      if (currentTourId) {
        saveCurrentStep(currentTourId, newIndex);
      }
    }
  }, [stepIndex, currentTourId]);

  const goToStep = useCallback((index: number) => {
    if (index >= 0 && index < steps.length) {
      setStepIndex(index);
      if (currentTourId) {
        saveCurrentStep(currentTourId, index);
      }
    }
  }, [steps.length, currentTourId]);

  const restartTour = useCallback((tourId: TourId) => {
    resetTour(tourId);
    setStepIndex(0);
  }, []);

  const isTourActive = useCallback((tourId: TourId) => {
    return isRunning && currentTourId === tourId;
  }, [isRunning, currentTourId]);

  const handleJoyrideCallback = useCallback((data: CallBackProps) => {
    const { action, index, status, type } = data;

    // Handle target not found - skip to next step
    if (type === EVENTS.TARGET_NOT_FOUND) {
      const nextIndex = index + 1;
      if (nextIndex < steps.length) {
        setStepIndex(nextIndex);
        if (currentTourId) {
          saveCurrentStep(currentTourId, nextIndex);
        }
      }
      return;
    }

    // Handle step changes - only advance on STEP_AFTER
    if (type === EVENTS.STEP_AFTER) {
      if (action === ACTIONS.NEXT) {
        const newIndex = index + 1;
        setStepIndex(newIndex);
        if (currentTourId) {
          saveCurrentStep(currentTourId, newIndex);
        }
      } else if (action === ACTIONS.PREV) {
        const newIndex = index - 1;
        setStepIndex(newIndex);
        if (currentTourId) {
          saveCurrentStep(currentTourId, newIndex);
        }
      }
    }

    // Handle tour completion
    if (status === STATUS.FINISHED) {
      if (currentTourId) {
        markTourCompleted(currentTourId);
      }
      stopTour();
      setIsFirstTime(false);
    }

    // Handle tour skip
    if (status === STATUS.SKIPPED) {
      if (currentTourId) {
        markTourSkipped(currentTourId);
      }
      stopTour();
      markNotFirstTime();
      setIsFirstTime(false);
    }

    // Handle close button
    if (action === ACTIONS.CLOSE) {
      // Save current position but don't mark as skipped
      if (currentTourId) {
        saveCurrentStep(currentTourId, index);
      }
      stopTour();
    }
  }, [currentTourId, steps.length, stopTour]);

  const contextValue = useMemo<TourContextValue>(() => ({
    isRunning,
    currentTourId,
    currentStepIndex: stepIndex,
    totalSteps: steps.length,
    isFirstTime,
    startTour,
    stopTour,
    nextStep,
    prevStep,
    goToStep,
    restartTour,
    isTourActive,
    getTourProgress,
  }), [
    isRunning,
    currentTourId,
    stepIndex,
    steps.length,
    isFirstTime,
    startTour,
    stopTour,
    nextStep,
    prevStep,
    goToStep,
    restartTour,
    isTourActive,
  ]);

  return (
    <TourContext.Provider value={contextValue}>
      {children}
      <Joyride
        callback={handleJoyrideCallback}
        continuous
        run={isRunning}
        stepIndex={stepIndex}
        steps={steps}
        styles={guideStyles}
        locale={guideLocale}
        disableScrollParentFix
        {...defaultGuideOptions}
      />
    </TourContext.Provider>
  );
}

export function useTourContext(): TourContextValue {
  const context = useContext(TourContext);
  if (!context) {
    throw new Error('useTourContext must be used within a TourProvider');
  }
  return context;
}

export { TourContext };
