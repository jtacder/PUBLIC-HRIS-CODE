/**
 * Guide Button Component
 *
 * Button to start/restart guides on any page.
 * Shows completion status and provides quick access to guides.
 */

import React from 'react';
import { HelpCircle, RotateCcw, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useTour } from '@/hooks/useTour';
import type { Step } from 'react-joyride';
import type { TourId } from '@/lib/tour/tour-storage';

interface GuideButtonProps {
  tourId: TourId;
  steps: Step[];
  variant?: 'default' | 'icon' | 'text';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function GuideButton({
  tourId,
  steps,
  variant = 'default',
  size = 'sm',
  className = '',
}: GuideButtonProps) {
  const { isActive, isCompleted, start, restart } = useTour({ tourId, steps });

  if (variant === 'icon') {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              onClick={isCompleted ? restart : start}
              disabled={isActive}
              className={className}
            >
              {isCompleted ? (
                <CheckCircle2 className="h-4 w-4 text-green-500" />
              ) : (
                <HelpCircle className="h-4 w-4" />
              )}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            {isCompleted ? 'Restart Guide' : 'Start Guide'}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  if (variant === 'text') {
    return (
      <button
        onClick={isCompleted ? restart : start}
        disabled={isActive}
        className={`text-sm text-blue-600 hover:text-blue-800 hover:underline disabled:opacity-50 ${className}`}
      >
        {isCompleted ? 'Retake Guide' : 'Take Guide'}
      </button>
    );
  }

  // Default variant with dropdown for completed guides
  if (isCompleted) {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            size={size === 'sm' ? 'sm' : 'default'}
            className={`gap-2 ${className}`}
            disabled={isActive}
          >
            <CheckCircle2 className="h-4 w-4 text-green-500" />
            Guide Completed
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={restart} className="gap-2">
            <RotateCcw className="h-4 w-4" />
            Restart Guide
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  return (
    <Button
      variant="outline"
      size={size === 'sm' ? 'sm' : 'default'}
      onClick={start}
      disabled={isActive}
      className={`gap-2 ${className}`}
    >
      <HelpCircle className="h-4 w-4" />
      {isActive ? 'Guide in Progress...' : 'Start Guide'}
    </Button>
  );
}

/**
 * Compact guide help icon for page headers
 */
interface GuideHelpIconProps {
  tourId: TourId;
  steps: Step[];
  className?: string;
}

export function GuideHelpIcon({ tourId, steps, className = '' }: GuideHelpIconProps) {
  const { isActive, isCompleted, start, restart } = useTour({ tourId, steps });

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={isCompleted ? restart : start}
            disabled={isActive}
            className={`inline-flex items-center justify-center rounded-full p-1.5
              text-gray-500 hover:text-blue-600 hover:bg-blue-50
              transition-colors disabled:opacity-50 ${className}`}
          >
            {isCompleted ? (
              <CheckCircle2 className="h-5 w-5 text-green-500" />
            ) : (
              <HelpCircle className="h-5 w-5" />
            )}
          </button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{isCompleted ? 'Restart page guide' : 'Start page guide'}</p>
          <p className="text-xs text-gray-400">{steps.length} steps</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// Backward compatibility exports
export const TourButton = GuideButton;
export const TourHelpIcon = GuideHelpIcon;
