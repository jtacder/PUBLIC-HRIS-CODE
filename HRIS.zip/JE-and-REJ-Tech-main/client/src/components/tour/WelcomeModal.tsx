/**
 * Welcome Modal Component
 *
 * Displayed to first-time users offering to start the guided guide.
 * Provides options to take the guide or skip it.
 */

import React, { useEffect, useState } from 'react';
import { Sparkles, ArrowRight, X } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useIsFirstTimeUser } from '@/hooks/useTour';
import { markNotFirstTime, TOUR_IDS } from '@/lib/tour/tour-storage';
import { useTourContext } from './TourProvider';
import type { Step } from 'react-joyride';

interface WelcomeModalProps {
  userName?: string;
  role?: 'ADMIN' | 'HR' | 'ENGINEER' | 'WORKER';
  dashboardSteps: Step[];
}

export function WelcomeModal({ userName, role, dashboardSteps }: WelcomeModalProps) {
  const [open, setOpen] = useState(false);
  const isFirstTime = useIsFirstTimeUser();
  const { startTour } = useTourContext();

  useEffect(() => {
    // Show modal only for first-time users after a short delay
    if (isFirstTime) {
      const timer = setTimeout(() => {
        setOpen(true);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [isFirstTime]);

  const handleStartGuide = () => {
    setOpen(false);
    // Start the appropriate dashboard guide based on role
    const guideId = role === 'ADMIN' || role === 'HR'
      ? TOUR_IDS.DASHBOARD_ADMIN
      : TOUR_IDS.DASHBOARD_EMPLOYEE;
    startTour(guideId, dashboardSteps);
  };

  const handleSkip = () => {
    markNotFirstTime();
    setOpen(false);
  };

  const isAdmin = role === 'ADMIN' || role === 'HR';

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
            <Sparkles className="h-6 w-6 text-blue-600" />
          </div>
          <DialogTitle className="text-center text-xl">
            Welcome to JE & REJ TECH{userName ? `, ${userName}` : ''}!
          </DialogTitle>
          <DialogDescription className="text-center">
            {isAdmin ? (
              <>
                As an {role} user, you have access to powerful HR and management tools.
                Would you like a guided walkthrough to learn how to use all the features?
              </>
            ) : (
              <>
                Your company uses JE & REJ TECH for attendance, payroll, and more.
                Would you like a quick guide to learn how to use the system?
              </>
            )}
          </DialogDescription>
        </DialogHeader>

        <div className="my-4 space-y-3">
          <div className="flex items-start gap-3 rounded-lg bg-gray-50 p-3">
            <div className="mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-xs text-white">
              1
            </div>
            <div>
              <p className="font-medium text-sm">Interactive Walkthrough</p>
              <p className="text-xs text-gray-500">
                Step-by-step guidance for every feature
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3 rounded-lg bg-gray-50 p-3">
            <div className="mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-xs text-white">
              2
            </div>
            <div>
              <p className="font-medium text-sm">Page-by-Page Guides</p>
              <p className="text-xs text-gray-500">
                Each page has its own detailed guide
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3 rounded-lg bg-gray-50 p-3">
            <div className="mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-xs text-white">
              3
            </div>
            <div>
              <p className="font-medium text-sm">Restart Anytime</p>
              <p className="text-xs text-gray-500">
                Use the help icon to retake any guide
              </p>
            </div>
          </div>
        </div>

        <DialogFooter className="flex-col gap-2 sm:flex-col">
          <Button onClick={handleStartGuide} className="w-full gap-2">
            Yes, show me around
            <ArrowRight className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            onClick={handleSkip}
            className="w-full text-gray-500"
          >
            Skip for now
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/**
 * Guide Progress Modal
 *
 * Shows overall guide completion progress across all pages.
 */
interface GuideProgressModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  guides: Array<{
    id: string;
    name: string;
    completed: boolean;
  }>;
}

export function GuideProgressModal({ open, onOpenChange, guides }: GuideProgressModalProps) {
  const completedCount = guides.filter(g => g.completed).length;
  const percentage = Math.round((completedCount / guides.length) * 100);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Guide Progress</DialogTitle>
          <DialogDescription>
            Track your progress through the application guides.
          </DialogDescription>
        </DialogHeader>

        <div className="my-4">
          {/* Progress bar */}
          <div className="mb-4">
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-600">{completedCount} of {guides.length} completed</span>
              <span className="font-medium">{percentage}%</span>
            </div>
            <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-600 transition-all duration-300"
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>

          {/* Guide list */}
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {guides.map(guide => (
              <div
                key={guide.id}
                className={`flex items-center justify-between rounded-lg p-2 ${
                  guide.completed ? 'bg-green-50' : 'bg-gray-50'
                }`}
              >
                <span className={guide.completed ? 'text-green-700' : 'text-gray-700'}>
                  {guide.name}
                </span>
                {guide.completed && (
                  <span className="text-xs text-green-600 font-medium">Completed</span>
                )}
              </div>
            ))}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Backward compatibility export
export const TourProgressModal = GuideProgressModal;
