import { useState, useEffect, useRef, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { MapPin, Navigation, Loader2, Map, X, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  GoogleMap,
  useJsApiLoader,
  Marker,
  Circle,
  Autocomplete,
} from "@react-google-maps/api";

interface MapPickerProps {
  latitude: number | null;
  longitude: number | null;
  onChange: (lat: number, lng: number) => void;
  geoRadius?: number;
  onRadiusChange?: (radius: number) => void;
}

// Default center (Philippines - Manila)
const DEFAULT_CENTER = { lat: 14.5995, lng: 120.9842 };
const DEFAULT_ZOOM = 13;

// Libraries to load for Google Maps
const libraries: ("places")[] = ["places"];

// Map container style
const mapContainerStyle = {
  width: "100%",
  height: "400px",
  borderRadius: "0.5rem",
};

// Map options
const mapOptions: google.maps.MapOptions = {
  disableDefaultUI: false,
  zoomControl: true,
  streetViewControl: false,
  mapTypeControl: true,
  fullscreenControl: true,
};

// Circle options for geofence
const getCircleOptions = (radius: number): google.maps.CircleOptions => ({
  strokeColor: "#3b82f6",
  strokeOpacity: 0.8,
  strokeWeight: 2,
  fillColor: "#3b82f6",
  fillOpacity: 0.2,
  radius: radius,
  clickable: false,
});

export function MapPicker({
  latitude,
  longitude,
  onChange,
  geoRadius = 100,
  onRadiusChange,
}: MapPickerProps) {
  const { toast } = useToast();
  const [manualLat, setManualLat] = useState(latitude?.toString() || "");
  const [manualLng, setManualLng] = useState(longitude?.toString() || "");
  const prevPropsRef = useRef({ latitude, longitude });

  // Map dialog state
  const [isMapOpen, setIsMapOpen] = useState(false);
  const [isGettingLocation, setIsGettingLocation] = useState(false);

  // Temporary coordinates while picking on map
  const [tempLat, setTempLat] = useState<number | null>(null);
  const [tempLng, setTempLng] = useState<number | null>(null);

  // Map refs
  const mapRef = useRef<google.maps.Map | null>(null);
  const autocompleteRef = useRef<google.maps.places.Autocomplete | null>(null);

  // Load Google Maps API
  const { isLoaded, loadError } = useJsApiLoader({
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "",
    libraries,
  });

  // Sync manual inputs with props
  useEffect(() => {
    const propsChanged =
      prevPropsRef.current.latitude !== latitude ||
      prevPropsRef.current.longitude !== longitude;

    if (propsChanged) {
      setManualLat(latitude?.toString() || "");
      setManualLng(longitude?.toString() || "");
    }
    prevPropsRef.current = { latitude, longitude };
  }, [latitude, longitude]);

  // Initialize temp coordinates when dialog opens
  useEffect(() => {
    if (isMapOpen) {
      setTempLat(latitude || null);
      setTempLng(longitude || null);
    }
  }, [isMapOpen, latitude, longitude]);

  const handleLatChange = (value: string) => {
    setManualLat(value);
    const lat = parseFloat(value);
    const lng = parseFloat(manualLng);
    if (
      !isNaN(lat) &&
      !isNaN(lng) &&
      lat >= -90 &&
      lat <= 90 &&
      lng >= -180 &&
      lng <= 180
    ) {
      onChange(lat, lng);
    }
  };

  const handleLngChange = (value: string) => {
    setManualLng(value);
    const lat = parseFloat(manualLat);
    const lng = parseFloat(value);
    if (
      !isNaN(lat) &&
      !isNaN(lng) &&
      lat >= -90 &&
      lat <= 90 &&
      lng >= -180 &&
      lng <= 180
    ) {
      onChange(lat, lng);
    }
  };

  const onMapLoad = useCallback((map: google.maps.Map) => {
    mapRef.current = map;
  }, []);

  const onAutocompleteLoad = useCallback(
    (autocomplete: google.maps.places.Autocomplete) => {
      autocompleteRef.current = autocomplete;
    },
    []
  );

  const onPlaceChanged = useCallback(() => {
    if (autocompleteRef.current) {
      const place = autocompleteRef.current.getPlace();
      if (place.geometry?.location) {
        const lat = place.geometry.location.lat();
        const lng = place.geometry.location.lng();
        setTempLat(lat);
        setTempLng(lng);

        // Pan to the new location
        if (mapRef.current) {
          mapRef.current.panTo({ lat, lng });
          mapRef.current.setZoom(17);
        }

        toast({
          title: "Location Found",
          description: place.formatted_address?.slice(0, 100) || place.name,
        });
      }
    }
  }, [toast]);

  const handleMapClick = useCallback((e: google.maps.MapMouseEvent) => {
    if (e.latLng) {
      setTempLat(e.latLng.lat());
      setTempLng(e.latLng.lng());
    }
  }, []);

  const handleMarkerDragEnd = useCallback((e: google.maps.MapMouseEvent) => {
    if (e.latLng) {
      setTempLat(e.latLng.lat());
      setTempLng(e.latLng.lng());
    }
  }, []);

  const handleGetCurrentLocation = useCallback(() => {
    if (!navigator.geolocation) {
      toast({
        title: "Not Supported",
        description: "Geolocation is not supported by your browser",
        variant: "destructive",
      });
      return;
    }

    setIsGettingLocation(true);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude: lat, longitude: lng } = position.coords;
        setTempLat(lat);
        setTempLng(lng);

        if (mapRef.current) {
          mapRef.current.panTo({ lat, lng });
          mapRef.current.setZoom(17);
        }

        setIsGettingLocation(false);
        toast({
          title: "Location Found",
          description: `Accuracy: ±${Math.round(position.coords.accuracy)}m`,
        });
      },
      (error) => {
        setIsGettingLocation(false);
        let message = "Unable to get your location";
        if (error.code === error.PERMISSION_DENIED) {
          message = "Location permission denied";
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          message = "Location unavailable";
        } else if (error.code === error.TIMEOUT) {
          message = "Location request timed out";
        }
        toast({
          title: "Location Error",
          description: message,
          variant: "destructive",
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0,
      }
    );
  }, [toast]);

  const handleConfirmLocation = () => {
    if (tempLat !== null && tempLng !== null) {
      onChange(tempLat, tempLng);
      setManualLat(tempLat.toFixed(7));
      setManualLng(tempLng.toFixed(7));
      setIsMapOpen(false);
      toast({
        title: "Location Set",
        description: `${tempLat.toFixed(6)}, ${tempLng.toFixed(6)}`,
      });
    }
  };

  const handleOpenMap = () => {
    setTempLat(latitude || null);
    setTempLng(longitude || null);
    setIsMapOpen(true);
  };

  // Determine map center
  const mapCenter =
    tempLat !== null && tempLng !== null
      ? { lat: tempLat, lng: tempLng }
      : latitude && longitude
        ? { lat: latitude, lng: longitude }
        : DEFAULT_CENTER;

  const mapZoom =
    latitude && longitude ? 16 : tempLat && tempLng ? 16 : DEFAULT_ZOOM;

  // Show error if API key is missing
  const apiKeyMissing = !import.meta.env.VITE_GOOGLE_MAPS_API_KEY;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4" />
          <span>Enter the project location coordinates</span>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleOpenMap}
          className="gap-2"
        >
          <Map className="h-4 w-4" />
          Pick on Map
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="latitude">Latitude</Label>
          <Input
            id="latitude"
            type="text"
            placeholder="14.5995"
            value={manualLat}
            onChange={(e) => handleLatChange(e.target.value)}
            data-testid="input-latitude"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="longitude">Longitude</Label>
          <Input
            id="longitude"
            type="text"
            placeholder="120.9842"
            value={manualLng}
            onChange={(e) => handleLngChange(e.target.value)}
            data-testid="input-longitude"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="geoRadius">Geo-fence Radius (m)</Label>
          <Input
            id="geoRadius"
            type="number"
            placeholder="100"
            value={geoRadius}
            onChange={(e) => onRadiusChange?.(parseInt(e.target.value) || 100)}
            data-testid="input-geo-radius"
          />
        </div>
      </div>

      {manualLat &&
        manualLng &&
        !isNaN(parseFloat(manualLat)) &&
        !isNaN(parseFloat(manualLng)) && (
          <p className="text-xs text-muted-foreground">
            Location: {parseFloat(manualLat).toFixed(6)},{" "}
            {parseFloat(manualLng).toFixed(6)}
          </p>
        )}

      {/* Map Picker Dialog */}
      <Dialog open={isMapOpen} onOpenChange={setIsMapOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Map className="h-5 w-5" />
              Select Location on Map
            </DialogTitle>
            <DialogDescription>
              Search for an address or business, click on the map to place a
              pin, or drag the marker to adjust the position.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* API Key Missing Warning */}
            {apiKeyMissing && (
              <div className="rounded-lg border border-yellow-500 bg-yellow-50 p-3 text-sm text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-200">
                <p className="font-medium">Google Maps API Key Missing</p>
                <p className="text-xs mt-1">
                  Add VITE_GOOGLE_MAPS_API_KEY to your .env file. Get a key from{" "}
                  <a
                    href="https://console.cloud.google.com/apis/credentials"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline"
                  >
                    Google Cloud Console
                  </a>
                </p>
              </div>
            )}

            {/* Load Error */}
            {loadError && (
              <div className="rounded-lg border border-red-500 bg-red-50 p-3 text-sm text-red-800 dark:bg-red-900/20 dark:text-red-200">
                <p className="font-medium">Failed to load Google Maps</p>
                <p className="text-xs mt-1">
                  Please check your API key and ensure Maps JavaScript API and
                  Places API are enabled.
                </p>
              </div>
            )}

            {/* Search Bar with Autocomplete */}
            {isLoaded && (
              <div className="flex gap-2">
                <Autocomplete
                  onLoad={onAutocompleteLoad}
                  onPlaceChanged={onPlaceChanged}
                  options={{
                    componentRestrictions: { country: "ph" },
                    fields: [
                      "formatted_address",
                      "geometry",
                      "name",
                      "place_id",
                    ],
                  }}
                  className="flex-1"
                >
                  <div className="relative flex-1">
                    <Input
                      placeholder="Search for an address or place..."
                      className="w-full"
                    />
                  </div>
                </Autocomplete>
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleGetCurrentLocation}
                  disabled={isGettingLocation}
                  className="gap-2"
                >
                  {isGettingLocation ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Navigation className="h-4 w-4" />
                  )}
                  Current Location
                </Button>
              </div>
            )}

            {/* Map Container */}
            <div className="relative rounded-lg border overflow-hidden">
              {!isLoaded && (
                <div className="h-[400px] flex items-center justify-center bg-muted">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              )}
              {isLoaded && (
                <GoogleMap
                  mapContainerStyle={mapContainerStyle}
                  center={mapCenter}
                  zoom={mapZoom}
                  onClick={handleMapClick}
                  onLoad={onMapLoad}
                  options={mapOptions}
                >
                  {/* Marker */}
                  {tempLat !== null && tempLng !== null && (
                    <>
                      <Marker
                        position={{ lat: tempLat, lng: tempLng }}
                        draggable={true}
                        onDragEnd={handleMarkerDragEnd}
                      />
                      {/* Geofence Circle */}
                      <Circle
                        center={{ lat: tempLat, lng: tempLng }}
                        options={getCircleOptions(geoRadius)}
                      />
                    </>
                  )}
                </GoogleMap>
              )}
            </div>

            {/* Coordinates Display */}
            {tempLat !== null && tempLng !== null && (
              <div className="flex items-center justify-between rounded-lg border bg-muted/50 p-3">
                <div className="space-y-1">
                  <p className="text-sm font-medium">Selected Coordinates</p>
                  <p className="text-xs text-muted-foreground font-mono">
                    Lat: {tempLat.toFixed(7)}, Lng: {tempLng.toFixed(7)}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">
                    Geo-fence Radius
                  </p>
                  <p className="text-sm font-medium">{geoRadius} meters</p>
                </div>
              </div>
            )}
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsMapOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={handleConfirmLocation}
              disabled={tempLat === null || tempLng === null}
              className="gap-2"
            >
              <Check className="h-4 w-4" />
              Confirm Location
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
