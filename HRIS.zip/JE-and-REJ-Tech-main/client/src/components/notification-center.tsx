import { useState } from "react";
import { useLocation } from "wouter";
import { formatDistanceToNow } from "date-fns";
import {
  useUnreadCount,
  useNotifications,
  useMarkAsRead,
  useMarkAllAsRead,
  useDeleteNotification,
  useNotificationWebSocket,
  type NotificationData,
} from "@/hooks/use-notifications";
import { getPhotoDisplayUrl } from "@/lib/photo-url";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Bell,
  BellOff,
  Check,
  CheckCheck,
  Trash2,
  Calendar,
  DollarSign,
  Clock,
  ListTodo,
  Receipt,
  Wallet,
  AlertTriangle,
  FolderOpen,
  Shield,
  Settings,
  BookOpen,
  X,
} from "lucide-react";
import { getInitials } from "@/lib/utils";

// Category icon mapping
const categoryIcons: Record<string, React.ReactNode> = {
  leave: <Calendar className="h-4 w-4 text-green-500" />,
  payroll: <DollarSign className="h-4 w-4 text-blue-500" />,
  attendance: <Clock className="h-4 w-4 text-orange-500" />,
  tasks: <ListTodo className="h-4 w-4 text-purple-500" />,
  expenses: <Receipt className="h-4 w-4 text-emerald-500" />,
  cash_advance: <Wallet className="h-4 w-4 text-yellow-600" />,
  disciplinary: <AlertTriangle className="h-4 w-4 text-red-500" />,
  projects: <FolderOpen className="h-4 w-4 text-indigo-500" />,
  permissions: <Shield className="h-4 w-4 text-gray-500" />,
  system: <Settings className="h-4 w-4 text-gray-600" />,
  devotional: <BookOpen className="h-4 w-4 text-amber-600" />,
};

// Priority colors
const priorityStyles: Record<string, string> = {
  urgent: "border-l-4 border-l-red-500 bg-red-50 dark:bg-red-950/20",
  high: "border-l-4 border-l-orange-500 bg-orange-50 dark:bg-orange-950/20",
  normal: "",
  low: "opacity-80",
};

function NotificationItem({
  data,
  onRead,
  onDelete,
  onNavigate,
}: {
  data: NotificationData;
  onRead: (id: string) => void;
  onDelete: (id: string) => void;
  onNavigate: (url: string) => void;
}) {
  const { notification, actor } = data;

  const handleClick = () => {
    if (!notification.isRead) {
      onRead(notification.id);
    }
    if (notification.actionUrl) {
      onNavigate(notification.actionUrl);
    }
  };

  return (
    <div
      className={`group flex gap-3 px-4 py-3 hover:bg-muted/50 cursor-pointer transition-colors ${
        !notification.isRead ? "bg-primary/5" : ""
      } ${priorityStyles[notification.priority] || ""}`}
      onClick={handleClick}
    >
      {/* Icon or Actor Avatar */}
      <div className="flex-shrink-0 mt-0.5">
        {actor ? (
          <Avatar className="h-8 w-8">
            <AvatarImage src={getPhotoDisplayUrl(actor.profilePhotoUrl) || undefined} />
            <AvatarFallback className="text-xs">
              {getInitials(actor.firstName, actor.lastName)}
            </AvatarFallback>
          </Avatar>
        ) : (
          <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
            {categoryIcons[notification.category] || <Bell className="h-4 w-4" />}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <p className={`text-sm leading-tight ${!notification.isRead ? "font-semibold" : "font-medium"}`}>
            {notification.title}
          </p>
          {!notification.isRead && (
            <span className="flex-shrink-0 h-2 w-2 rounded-full bg-primary mt-1.5" />
          )}
        </div>
        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
          {notification.message}
        </p>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-[10px] text-muted-foreground">
            {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
          </span>
          <Badge variant="outline" className="text-[10px] px-1 py-0 h-4">
            {notification.category.replace("_", " ")}
          </Badge>
        </div>
      </div>

      {/* Actions (visible on hover) */}
      <div className="flex-shrink-0 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        {!notification.isRead && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onRead(notification.id);
            }}
            className="p-1 rounded hover:bg-muted"
            title="Mark as read"
          >
            <Check className="h-3 w-3 text-muted-foreground" />
          </button>
        )}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onDelete(notification.id);
          }}
          className="p-1 rounded hover:bg-destructive/10"
          title="Delete"
        >
          <Trash2 className="h-3 w-3 text-muted-foreground" />
        </button>
      </div>
    </div>
  );
}

export function NotificationCenter() {
  const [open, setOpen] = useState(false);
  const [, navigate] = useLocation();

  // Initialize WebSocket connection
  useNotificationWebSocket();

  // Queries
  const { data: unreadData } = useUnreadCount();
  const { data: notificationsData, isLoading } = useNotifications({ limit: 30 });

  // Mutations
  const markAsRead = useMarkAsRead();
  const markAllAsRead = useMarkAllAsRead();
  const deleteNotification = useDeleteNotification();

  const unreadCount = unreadData?.count || 0;
  const notificationsList = notificationsData || [];

  const handleRead = (id: string) => {
    markAsRead.mutate(id);
  };

  const handleDelete = (id: string) => {
    deleteNotification.mutate(id);
  };

  const handleNavigate = (url: string) => {
    setOpen(false);
    navigate(url);
  };

  const handleMarkAllRead = () => {
    markAllAsRead.mutate();
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative"
          aria-label={`Notifications${unreadCount > 0 ? ` (${unreadCount} unread)` : ""}`}
          data-tour="notification-bell"
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 flex h-5 w-5 items-center justify-center">
              <span className="absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75 animate-ping" />
              <span className="relative inline-flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white">
                {unreadCount > 99 ? "99+" : unreadCount}
              </span>
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 p-0" align="end" sideOffset={8}>
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-sm">Notifications</h3>
            {unreadCount > 0 && (
              <Badge variant="secondary" className="text-xs px-1.5 py-0">
                {unreadCount} new
              </Badge>
            )}
          </div>
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="text-xs h-7"
              onClick={handleMarkAllRead}
              disabled={markAllAsRead.isPending}
            >
              <CheckCheck className="h-3 w-3 mr-1" />
              Mark all read
            </Button>
          )}
        </div>

        {/* Notifications List */}
        <ScrollArea className="max-h-[400px]">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin h-5 w-5 border-2 border-primary border-t-transparent rounded-full" />
            </div>
          ) : notificationsList.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center px-4">
              <BellOff className="h-10 w-10 text-muted-foreground/30 mb-3" />
              <p className="text-sm font-medium text-muted-foreground">No notifications</p>
              <p className="text-xs text-muted-foreground/70 mt-1">
                You're all caught up! New notifications will appear here.
              </p>
            </div>
          ) : (
            <div className="divide-y">
              {notificationsList.map((item) => (
                <NotificationItem
                  key={item.notification.id}
                  data={item}
                  onRead={handleRead}
                  onDelete={handleDelete}
                  onNavigate={handleNavigate}
                />
              ))}
            </div>
          )}
        </ScrollArea>

        {/* Footer */}
        {notificationsList.length > 0 && (
          <div className="border-t px-4 py-2">
            <Button
              variant="ghost"
              size="sm"
              className="w-full text-xs h-7"
              onClick={() => {
                setOpen(false);
                navigate("/my-profile?tab=notifications");
              }}
            >
              View all & manage preferences
            </Button>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}
