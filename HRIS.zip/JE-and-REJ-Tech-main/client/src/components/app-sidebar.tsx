import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import {
  LayoutDashboard,
  Users,
  CalendarClock,
  Banknote,
  LogOut,
  ChevronRight,
  FolderKanban,
  CheckSquare,
  AlertTriangle,
  Receipt,
  FileText,
  Settings,
  Wallet,
  UserRound,
  ClipboardList,
  History,
  BookOpen,
  Shield,
  Crown,
  CalendarRange,
  Bell,
} from "lucide-react";
import logoImage from "@/assets/logo.png";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  SidebarRail,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getInitials } from "@/lib/utils";

// Navigation items with permission requirements
interface NavItem {
  title: string;
  url: string;
  icon: any;
  permission?: string; // Required permission code (if any)
  superadminOnly?: boolean; // Only show for superadmins
}

const adminCoreNavigation: NavItem[] = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
    permission: "dashboard.view_admin",
  },
  {
    title: "Employees",
    url: "/employees",
    icon: Users,
    permission: "employees.view",
  },
  {
    title: "Projects",
    url: "/projects",
    icon: FolderKanban,
    permission: "projects.view",
  },
  {
    title: "Tasks",
    url: "/tasks",
    icon: CheckSquare,
    permission: "tasks.view_all",
  },
  {
    title: "Schedules",
    url: "/schedule-management",
    icon: CalendarRange,
    permission: "schedules.view",
  },
];

const adminHrNavigation: NavItem[] = [
  {
    title: "Attendance",
    url: "/attendance",
    icon: CalendarClock,
    permission: "attendance.view_all",
  },
  {
    title: "Payroll",
    url: "/payroll",
    icon: Banknote,
    permission: "payroll.view",
  },
  {
    title: "201 Files",
    url: "/201-files",
    icon: FileText,
    permission: "documents.view",
  },
  {
    title: "Disciplinary",
    url: "/disciplinary",
    icon: AlertTriangle,
    permission: "disciplinary.view_all",
  },
  {
    title: "Leave & Loans",
    url: "/hr-requests",
    icon: ClipboardList,
    permission: "leave.view_all",
  },
  {
    title: "HR Settings",
    url: "/hr-settings",
    icon: Settings,
    permission: "hr_settings.view",
  },
  {
    title: "Devotionals",
    url: "/devotionals",
    icon: BookOpen,
    permission: "devotionals.manage",
  },
  {
    title: "Audit Trail",
    url: "/audit-logs",
    icon: History,
    permission: "audit.view",
  },
];

const adminFinanceNavigation: NavItem[] = [
  {
    title: "Expenses",
    url: "/expenses",
    icon: Receipt,
    permission: "expenses.view_all",
  },
];

const adminSystemNavigation: NavItem[] = [
  {
    title: "Permissions",
    url: "/permissions",
    icon: Shield,
    permission: "permissions.view",
  },
  {
    title: "Notifications",
    url: "/notification-management",
    icon: Bell,
  },
];

// Employee navigation for non-admin users (My Dashboard at "/" since they don't have admin dashboard)
const employeeNavigation = [
  {
    title: "My Dashboard",
    url: "/",
    icon: LayoutDashboard,
  },
  {
    title: "Clock In/Out",
    url: "/attendance",
    icon: CalendarClock,
  },
  {
    title: "My Tasks",
    url: "/my-tasks",
    icon: CheckSquare,
  },
  {
    title: "My Payslips",
    url: "/my-payslips",
    icon: Wallet,
  },
  {
    title: "My Records",
    url: "/my-disciplinary",
    icon: AlertTriangle,
  },
  {
    title: "Requests",
    url: "/my-requests",
    icon: FileText,
  },
  {
    title: "My Profile",
    url: "/my-profile",
    icon: UserRound,
  },
];

// Personal portal navigation for admin users (My Dashboard at "/my-dashboard" to avoid conflict with admin dashboard)
const myPortalNavigation: NavItem[] = [
  {
    title: "My Dashboard",
    url: "/my-dashboard",
    icon: LayoutDashboard,
  },
  {
    title: "My Tasks",
    url: "/my-tasks",
    icon: CheckSquare,
  },
  {
    title: "My Payslips",
    url: "/my-payslips",
    icon: Wallet,
  },
  {
    title: "My Records",
    url: "/my-disciplinary",
    icon: AlertTriangle,
  },
  {
    title: "My Requests",
    url: "/my-requests",
    icon: FileText,
  },
  {
    title: "My Profile",
    url: "/my-profile",
    icon: UserRound,
  },
];

export function AppSidebar() {
  const [location] = useLocation();
  const { user, logout, hasPermission, isSuperadmin, isAdmin: isLegacyAdmin } = useAuth();

  // Use new permission-based check, falling back to legacy role check
  const hasAdminAccess = isSuperadmin || hasPermission("dashboard.view_admin") || isLegacyAdmin;
  const isEngineer = user?.role === "ENGINEER";

  // Filter navigation items based on permissions
  const filterNavItems = (items: NavItem[]) => {
    return items.filter((item) => {
      // Superadmins see everything
      if (isSuperadmin) return true;
      // Legacy admin roles (ADMIN, HR) see all non-superadmin-only items
      // This provides backward compatibility while permission system is being refined
      if (isLegacyAdmin && !item.superadminOnly) return true;
      // If item has superadminOnly flag, only superadmins can see it
      if (item.superadminOnly) return false;
      // If item has a permission requirement, check it
      if (item.permission) {
        return hasPermission(item.permission);
      }
      // Items without permission requirements (like employeeNavigation) are visible to everyone
      return true;
    });
  };

  const renderNavItems = (items: NavItem[]) => {
    const filteredItems = filterNavItems(items);
    if (filteredItems.length === 0) return null;

    return (
      <SidebarMenu>
        {filteredItems.map((item) => {
          const isActive = location === item.url;
          return (
            <SidebarMenuItem key={item.title}>
              <SidebarMenuButton
                asChild
                isActive={isActive}
                tooltip={item.title}
              >
                <Link href={item.url} data-testid={`nav-${item.title.toLowerCase().replace(/\s+/g, '-')}`}>
                  <item.icon className="h-4 w-4" />
                  <span>{item.title}</span>
                  {isActive && (
                    <ChevronRight className="ml-auto h-4 w-4 opacity-60" />
                  )}
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          );
        })}
      </SidebarMenu>
    );
  };

  return (
    <Sidebar>
      <SidebarHeader className="border-b border-sidebar-border p-4">
        <Link href="/" className="flex items-center gap-3">
          <div className="h-10 w-10 flex-shrink-0">
            <img 
              src={logoImage} 
              alt="JE & REJ TECH CORP" 
              className="h-full w-full object-contain"
            />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-bold text-sidebar-foreground">
              JE & REJ TECH
            </span>
            <span className="text-[10px] text-sidebar-foreground/60">
              Employee Portal
            </span>
          </div>
        </Link>
      </SidebarHeader>

      <SidebarContent className="custom-scrollbar">
        {hasAdminAccess ? (
          <>
            <SidebarGroup>
              <SidebarGroupLabel>Operations</SidebarGroupLabel>
              <SidebarGroupContent>
                {renderNavItems(adminCoreNavigation)}
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup>
              <SidebarGroupLabel>Human Resources</SidebarGroupLabel>
              <SidebarGroupContent>
                {renderNavItems(adminHrNavigation)}
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup>
              <SidebarGroupLabel>Finance</SidebarGroupLabel>
              <SidebarGroupContent>
                {renderNavItems(adminFinanceNavigation)}
              </SidebarGroupContent>
            </SidebarGroup>

            {/* System Administration - Only visible to superadmins or those with permissions.view */}
            {/* Fallback: Also show for ADMIN role users (legacy check) until permission system is fully integrated */}
            {(isSuperadmin || hasPermission("permissions.view") || user?.role === "ADMIN") && (
              <SidebarGroup>
                <SidebarGroupLabel className="flex items-center gap-1">
                  {(isSuperadmin || user?.role === "ADMIN") && <Crown className="h-3 w-3 text-yellow-500" />}
                  Administration
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  {renderNavItems(adminSystemNavigation)}
                </SidebarGroupContent>
              </SidebarGroup>
            )}

            {/* My Portal - Personal employee features for admin users */}
            {/* Admin users are still employees and need access to their personal portal */}
            <SidebarGroup>
              <SidebarGroupLabel className="flex items-center gap-1">
                <UserRound className="h-3 w-3 text-blue-500" />
                My Portal
              </SidebarGroupLabel>
              <SidebarGroupContent>
                {renderNavItems(myPortalNavigation)}
              </SidebarGroupContent>
            </SidebarGroup>
          </>
        ) : isEngineer ? (
          <>
            <SidebarGroup>
              <SidebarGroupLabel>My Work</SidebarGroupLabel>
              <SidebarGroupContent>
                {renderNavItems(employeeNavigation)}
              </SidebarGroupContent>
            </SidebarGroup>
            <SidebarGroup>
              <SidebarGroupLabel>Projects</SidebarGroupLabel>
              <SidebarGroupContent>
                {renderNavItems([
                  { title: "Projects", url: "/projects", icon: FolderKanban },
                  { title: "Tasks", url: "/tasks", icon: CheckSquare },
                ])}
              </SidebarGroupContent>
            </SidebarGroup>
            <SidebarGroup>
              <SidebarGroupLabel>Finance</SidebarGroupLabel>
              <SidebarGroupContent>
                {renderNavItems([
                  { title: "Expenses", url: "/expenses", icon: Receipt },
                ])}
              </SidebarGroupContent>
            </SidebarGroup>
          </>
        ) : (
          <SidebarGroup>
            <SidebarGroupLabel>My Work</SidebarGroupLabel>
            <SidebarGroupContent>
              {renderNavItems(employeeNavigation)}
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border p-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9 border border-sidebar-border">
            <AvatarFallback className="bg-sidebar-accent text-sidebar-accent-foreground text-sm">
              {getInitials(user?.firstName, user?.lastName)}
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-1 flex-col overflow-hidden">
            <span className="truncate text-sm font-medium text-sidebar-foreground flex items-center gap-1">
              {user?.firstName} {user?.lastName}
              {isSuperadmin && (
                <span title="Superadmin">
                  <Crown className="h-3 w-3 text-yellow-500" />
                </span>
              )}
            </span>
            <span className="truncate text-xs text-sidebar-foreground/60">
              {user?.email}
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => logout()}
            className="h-8 w-8 text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent"
            data-testid="button-logout"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}
