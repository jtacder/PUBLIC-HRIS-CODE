import * as React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { BookOpen, Sparkles, Flame, CheckCircle2, Clock } from "lucide-react";
import type { DevotionalContent, DevotionalProgress } from "@/hooks/use-devotional";

interface DevotionalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onMarkRead: () => void;
  onReadLater: () => void;
  isLoading?: boolean;
  isMarkingRead?: boolean;
  content: DevotionalContent | null;
  day: number;
  totalDays: number;
  todayRead: boolean;
  progress: DevotionalProgress;
}

export function DevotionalModal({
  isOpen,
  onClose,
  onMarkRead,
  onReadLater,
  isLoading = false,
  isMarkingRead = false,
  content,
  day,
  totalDays,
  todayRead,
  progress,
}: DevotionalModalProps) {
  const percentComplete = Math.round((day / totalDays) * 100);

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <DialogHeader className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-gradient-to-br from-amber-100 to-amber-50 dark:from-amber-900/20 dark:to-amber-800/10">
              <Sparkles className="h-5 w-5 text-amber-600" />
            </div>
            <DialogTitle className="text-xl font-semibold">
              Daily Devotional
            </DialogTitle>
          </div>
          <DialogDescription className="text-sm text-muted-foreground">
            Start your day with scripture and reflection
          </DialogDescription>
        </DialogHeader>

        {/* Day Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium text-foreground">
              Day {day} of {totalDays}
            </span>
            <span className="text-muted-foreground">{percentComplete}% complete</span>
          </div>
          <Progress value={percentComplete} className="h-2" />
        </div>

        <Separator />

        {/* Content */}
        {isLoading ? (
          <div className="space-y-4 py-4">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-4 w-1/3" />
            <Skeleton className="h-32 w-full" />
          </div>
        ) : content ? (
          <div className="space-y-4 py-2">
            {/* Scripture Verse */}
            <div className="relative p-4 rounded-lg bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 border border-slate-200 dark:border-slate-700">
              <div className="absolute top-2 left-3 text-4xl text-slate-300 dark:text-slate-600 font-serif">
                "
              </div>
              <blockquote className="pt-4 px-4 text-lg italic text-slate-700 dark:text-slate-300 leading-relaxed">
                {content.verse}
              </blockquote>
              <cite className="block mt-3 text-right text-sm font-semibold text-slate-600 dark:text-slate-400">
                — {content.reference}
              </cite>
            </div>

            {/* Theme Badge */}
            {content.theme && (
              <div className="flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Theme:</span>
                <Badge variant="secondary">{content.theme}</Badge>
              </div>
            )}

            <Separator />

            {/* Reflection/Excerpt */}
            <div className="space-y-2">
              <h4 className="font-medium text-foreground flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-amber-500" />
                Today's Reflection
              </h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {content.excerpt}
              </p>
            </div>
          </div>
        ) : (
          <div className="py-8 text-center space-y-4">
            <BookOpen className="h-12 w-12 mx-auto text-muted-foreground/50" />
            <div>
              <p className="font-medium text-foreground">No devotional available</p>
              <p className="text-sm text-muted-foreground">
                Content for today hasn't been added yet.
              </p>
            </div>
          </div>
        )}

        <Separator />

        {/* Streak Info */}
        <div className="flex items-center justify-center gap-6 py-2 text-sm">
          <div className="flex items-center gap-2">
            <Flame className="h-4 w-4 text-orange-500" />
            <span className="text-muted-foreground">Streak:</span>
            <span className="font-semibold text-foreground">
              {progress.currentStreak} days
            </span>
          </div>
          <div className="h-4 w-px bg-border" />
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-green-500" />
            <span className="text-muted-foreground">Total:</span>
            <span className="font-semibold text-foreground">
              {progress.totalDaysRead} days
            </span>
          </div>
        </div>

        {/* Footer Actions */}
        <DialogFooter className="gap-2 sm:gap-0">
          {todayRead ? (
            <div className="flex items-center gap-2 text-sm text-green-600 dark:text-green-400">
              <CheckCircle2 className="h-4 w-4" />
              <span>Already read today</span>
            </div>
          ) : (
            <>
              <Button
                variant="outline"
                onClick={onReadLater}
                disabled={isMarkingRead}
                className="flex items-center gap-2"
              >
                <Clock className="h-4 w-4" />
                Read Later
              </Button>
              <Button
                onClick={onMarkRead}
                disabled={isMarkingRead || !content}
                className="flex items-center gap-2"
              >
                {isMarkingRead ? (
                  <>
                    <span className="animate-spin">...</span>
                    Marking...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="h-4 w-4" />
                    Mark as Read
                  </>
                )}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default DevotionalModal;
