import * as React from "react";
import { useDevotional, useDevotionalWidget, type DevotionalWidgetState } from "@/hooks/use-devotional";
import { DevotionalModal } from "./DevotionalModal";
import { DevotionalFAB } from "./DevotionalFAB";

interface DevotionalWidgetProps {
  /**
   * If true, automatically show modal on first load if today's devotional is unread
   */
  autoShow?: boolean;
  /**
   * Callback when devotional is marked as read
   */
  onMarkRead?: () => void;
}

export function DevotionalWidget({
  autoShow = true,
  onMarkRead,
}: DevotionalWidgetProps) {
  const {
    todayDevotional,
    day,
    totalDays,
    todayRead,
    progress,
    isLoading,
    markAsRead,
    isMarkingRead,
  } = useDevotional();

  const { getInitialState, dismissForToday, shouldShowWidget } = useDevotionalWidget();

  // State for widget display mode
  const [widgetState, setWidgetState] = React.useState<DevotionalWidgetState>('fab');
  const [hasInitialized, setHasInitialized] = React.useState(false);

  // Initialize widget state based on reading status
  React.useEffect(() => {
    if (!isLoading && !hasInitialized) {
      if (autoShow && shouldShowWidget()) {
        const initialState = getInitialState(todayRead);
        setWidgetState(initialState);
      } else {
        setWidgetState('fab');
      }
      setHasInitialized(true);
    }
  }, [isLoading, todayRead, autoShow, hasInitialized, getInitialState, shouldShowWidget]);

  // Handle marking as read
  const handleMarkRead = () => {
    markAsRead(undefined, {
      onSuccess: () => {
        setWidgetState('fab');
        onMarkRead?.();
      },
    });
  };

  // Handle "Read Later" - dismiss modal but show FAB
  const handleReadLater = () => {
    dismissForToday();
    setWidgetState('fab');
  };

  // Handle closing modal (same as read later)
  const handleCloseModal = () => {
    handleReadLater();
  };

  // Handle FAB click - show modal
  const handleFABClick = () => {
    setWidgetState('modal');
  };

  // Don't render anything while loading initially
  if (isLoading && !hasInitialized) {
    return null;
  }

  // Don't render if widget should be hidden
  if (widgetState === 'hidden') {
    return null;
  }

  return (
    <>
      {/* Modal State */}
      <DevotionalModal
        isOpen={widgetState === 'modal'}
        onClose={handleCloseModal}
        onMarkRead={handleMarkRead}
        onReadLater={handleReadLater}
        isLoading={isLoading}
        isMarkingRead={isMarkingRead}
        content={todayDevotional}
        day={day}
        totalDays={totalDays}
        todayRead={todayRead}
        progress={progress}
      />

      {/* FAB State - always visible when not in modal */}
      {widgetState === 'fab' && (
        <DevotionalFAB
          onClick={handleFABClick}
          hasUnread={!todayRead && !!todayDevotional}
          streak={progress.currentStreak}
        />
      )}
    </>
  );
}

// Export a standalone modal for direct usage
export { DevotionalModal } from "./DevotionalModal";
export { DevotionalFAB } from "./DevotionalFAB";

export default DevotionalWidget;
