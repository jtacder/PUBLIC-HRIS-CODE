import * as React from "react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

interface DevotionalFABProps {
  onClick: () => void;
  hasUnread?: boolean;
  streak?: number;
  className?: string;
}

export function DevotionalFAB({
  onClick,
  hasUnread = false,
  streak = 0,
  className,
}: DevotionalFABProps) {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            onClick={onClick}
            size="lg"
            className={cn(
              "fixed bottom-6 right-6 z-50",
              "h-14 w-14 rounded-full",
              "bg-gradient-to-br from-amber-500 to-amber-600",
              "hover:from-amber-600 hover:to-amber-700",
              "shadow-lg shadow-amber-500/25",
              "transition-all duration-300 ease-out",
              "hover:scale-110 hover:shadow-xl hover:shadow-amber-500/30",
              "group",
              // Pulse animation when unread
              hasUnread && "animate-pulse",
              className
            )}
          >
            {/* Icon */}
            <div className="relative">
              <BookOpen className="h-6 w-6 text-white transition-transform group-hover:scale-110" />

              {/* Sparkle effect */}
              <Sparkles className="absolute -top-1 -right-1 h-3 w-3 text-amber-200 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>

            {/* Unread badge */}
            {hasUnread && (
              <span className="absolute -top-1 -right-1 flex h-5 w-5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-5 w-5 bg-red-500 items-center justify-center text-[10px] font-bold text-white">
                  !
                </span>
              </span>
            )}

            {/* Streak badge */}
            {streak > 0 && !hasUnread && (
              <Badge
                variant="secondary"
                className="absolute -top-1 -right-1 h-5 min-w-[20px] px-1 text-[10px] font-bold bg-orange-500 text-white border-0"
              >
                {streak}
              </Badge>
            )}
          </Button>
        </TooltipTrigger>
        <TooltipContent side="left" className="mr-2">
          <p className="font-medium">
            {hasUnread ? "Today's Devotional" : "View Devotional"}
          </p>
          {streak > 0 && (
            <p className="text-xs text-muted-foreground">
              {streak} day streak!
            </p>
          )}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// Alternative minimal FAB version
export function DevotionalFABMinimal({
  onClick,
  hasUnread = false,
  className,
}: Omit<DevotionalFABProps, "streak">) {
  return (
    <Button
      onClick={onClick}
      variant="outline"
      size="icon"
      className={cn(
        "fixed bottom-6 right-6 z-50",
        "h-12 w-12 rounded-full",
        "bg-background/80 backdrop-blur-sm",
        "border-2 border-amber-200 dark:border-amber-800",
        "hover:border-amber-400 dark:hover:border-amber-600",
        "hover:bg-amber-50 dark:hover:bg-amber-950/50",
        "shadow-md",
        "transition-all duration-200",
        hasUnread && "animate-bounce",
        className
      )}
    >
      <BookOpen className="h-5 w-5 text-amber-600 dark:text-amber-400" />
      {hasUnread && (
        <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-red-500" />
      )}
    </Button>
  );
}

export default DevotionalFAB;
