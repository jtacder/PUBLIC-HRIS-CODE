import { useState } from "react";
import { Check, ChevronsUpDown, Search, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  employeeNo?: string | null;
  position?: string | null;
}

interface SearchableEmployeeSelectProps {
  employees: Employee[];
  value: string | null | undefined;
  onValueChange: (value: string) => void;
  placeholder?: string;
  allowUnassigned?: boolean;
  unassignedLabel?: string;
  allowAll?: boolean;
  allLabel?: string;
  disabled?: boolean;
  "data-testid"?: string;
  className?: string;
}

export function SearchableEmployeeSelect({
  employees,
  value,
  onValueChange,
  placeholder = "Select employee...",
  allowUnassigned = false,
  unassignedLabel = "Unassigned",
  allowAll = false,
  allLabel = "All Employees",
  disabled = false,
  "data-testid": testId,
  className,
}: SearchableEmployeeSelectProps) {
  const [open, setOpen] = useState(false);

  const selectedEmployee = employees.find((emp) => emp.id === value);
  const displayValue = selectedEmployee
    ? `${selectedEmployee.firstName} ${selectedEmployee.lastName}`
    : value === "all"
    ? allLabel
    : value === "" || value === "unassigned"
    ? unassignedLabel
    : null;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          aria-label={placeholder}
          disabled={disabled}
          data-testid={testId}
          className={cn(
            "w-full justify-between font-normal",
            !displayValue && "text-muted-foreground",
            className
          )}
        >
          <span className="flex items-center gap-2 truncate">
            <User className="h-4 w-4 shrink-0 opacity-50" aria-hidden="true" />
            <span className="truncate">{displayValue || placeholder}</span>
          </span>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" aria-hidden="true" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[300px] p-0" align="start">
        <Command>
          <CommandInput 
            placeholder="Search employees..." 
            aria-label="Search employees"
          />
          <CommandList>
            <CommandEmpty>No employee found.</CommandEmpty>
            <CommandGroup>
              {allowAll && (
                <CommandItem
                  value="all-employees"
                  onSelect={() => {
                    onValueChange("all");
                    setOpen(false);
                  }}
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4",
                      value === "all" ? "opacity-100" : "opacity-0"
                    )}
                    aria-hidden="true"
                  />
                  <span className="font-medium">{allLabel}</span>
                </CommandItem>
              )}
              {allowUnassigned && (
                <CommandItem
                  value="unassigned"
                  onSelect={() => {
                    onValueChange("");
                    setOpen(false);
                  }}
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4",
                      value === "" || value === "unassigned" ? "opacity-100" : "opacity-0"
                    )}
                    aria-hidden="true"
                  />
                  <span className="text-muted-foreground">{unassignedLabel}</span>
                </CommandItem>
              )}
              {employees.map((employee) => (
                <CommandItem
                  key={employee.id}
                  value={`${employee.firstName} ${employee.lastName} ${employee.employeeNo || ""}`}
                  onSelect={() => {
                    onValueChange(employee.id);
                    setOpen(false);
                  }}
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4",
                      value === employee.id ? "opacity-100" : "opacity-0"
                    )}
                    aria-hidden="true"
                  />
                  <div className="flex flex-col">
                    <span>
                      {employee.firstName} {employee.lastName}
                    </span>
                    {employee.employeeNo && (
                      <span className="text-xs text-muted-foreground">
                        {employee.employeeNo}
                        {employee.position && ` - ${employee.position}`}
                      </span>
                    )}
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
