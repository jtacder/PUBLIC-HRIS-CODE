import { useNetworkStatus } from "@/hooks/use-network-status";
import { WifiOff, Wifi, RefreshCw } from "lucide-react";
import { useState, useEffect } from "react";

/**
 * Offline Indicator Component
 *
 * Displays a banner when the user goes offline and hides when back online.
 * Uses the Network Information API for additional connection details when available.
 *
 * Features:
 * - Shows immediately when offline
 * - Provides refresh/retry option
 * - Shows connection quality information when available
 * - Smooth animation for appearing/disappearing
 */
export function OfflineIndicator() {
  const { isOnline, effectiveType, isInitialized } = useNetworkStatus();
  const [showBanner, setShowBanner] = useState(false);
  const [isReconnecting, setIsReconnecting] = useState(false);

  // Delay hiding the banner slightly for smoother UX
  useEffect(() => {
    if (!isOnline) {
      setShowBanner(true);
    } else {
      // Add a small delay before hiding to show "reconnected" state
      const timer = setTimeout(() => {
        setShowBanner(false);
        setIsReconnecting(false);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [isOnline]);

  // Don't render until we've checked network status
  if (!isInitialized) {
    return null;
  }

  // Don't show if online and banner is hidden
  if (isOnline && !showBanner) {
    return null;
  }

  const handleRetry = () => {
    setIsReconnecting(true);
    // Trigger a network check by attempting to fetch
    fetch("/api/health/live", { method: "HEAD", cache: "no-store" })
      .then(() => {
        // If successful, the online event should fire
        setIsReconnecting(false);
      })
      .catch(() => {
        setIsReconnecting(false);
      });
  };

  return (
    <div
      role="status"
      aria-live="polite"
      className={`fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-md rounded-lg p-4 shadow-lg transition-all duration-300 ${
        isOnline
          ? "bg-green-600 text-white"
          : "bg-amber-600 text-white"
      }`}
    >
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {isOnline ? (
            <Wifi className="h-5 w-5 animate-pulse" />
          ) : (
            <WifiOff className="h-5 w-5" />
          )}
          <div>
            <p className="font-medium">
              {isOnline ? "Back online!" : "You're offline"}
            </p>
            {!isOnline && (
              <p className="text-sm opacity-90">
                {effectiveType
                  ? `Last connection: ${effectiveType}`
                  : "Check your internet connection"}
              </p>
            )}
          </div>
        </div>

        {!isOnline && (
          <button
            onClick={handleRetry}
            disabled={isReconnecting}
            className="flex items-center gap-1 rounded-md bg-white/20 px-3 py-1.5 text-sm font-medium transition-colors hover:bg-white/30 disabled:opacity-50"
          >
            <RefreshCw
              className={`h-4 w-4 ${isReconnecting ? "animate-spin" : ""}`}
            />
            {isReconnecting ? "Checking..." : "Retry"}
          </button>
        )}
      </div>

      {!isOnline && (
        <p className="mt-2 text-xs opacity-80">
          Some features may be limited while offline. Your changes will sync when
          you're back online.
        </p>
      )}
    </div>
  );
}

/**
 * Compact offline indicator for navbar/header
 */
export function OfflineBadge() {
  const { isOnline } = useNetworkStatus();

  if (isOnline) {
    return null;
  }

  return (
    <div className="flex items-center gap-1.5 rounded-full bg-amber-100 px-2.5 py-1 text-xs font-medium text-amber-800">
      <WifiOff className="h-3 w-3" />
      <span>Offline</span>
    </div>
  );
}
