import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import {
  Download,
  RefreshCw,
  Send,
  History,
  AlertCircle,
  CheckCircle2,
  Clock,
} from "lucide-react";
import { TablePagination } from "@/components/ui/table-pagination";
import { usePagination } from "@/hooks/use-pagination";

interface ThirteenthMonthAccrual {
  id: string | null;
  employeeId: string;
  year: number;
  accumulatedBasicPay: string;
  accruedAmount: string;
  monthsWorked: string;
  releasedAmount: string;
  releasedPercentage: string;
  status: "Pending" | "Partial" | "Released";
}

interface EmployeeWithAccrual {
  employee: {
    id: string;
    firstName: string;
    lastName: string;
    employeeNo: string | null;
    position: string | null;
    department: string | null;
    startDate: string | null;
    status: string;
  };
  accrual: ThirteenthMonthAccrual;
}

interface ThirteenthMonthData {
  data: EmployeeWithAccrual[];
  summary: {
    year: number;
    totalAccrued: number;
    totalReleased: number;
    employeeCount: number;
    pendingCount: number;
    partialCount: number;
    releasedCount: number;
  };
}

interface DraftCutoff {
  cutoffStart: string;
  cutoffEnd: string;
  draftCount: number;
  label: string;
}

interface ReleasePreview {
  employeeId: string;
  employeeName: string;
  employeeNo: string | null;
  accruedAmount: number;
  alreadyReleased: number;
  releasedPercentage: number;
  remainingPercentage: number;
  releaseAmount: number;
  payrollRecordId: string;
}

interface ThirteenthMonthRelease {
  id: string;
  employeeId: string;
  year: number;
  releaseAmount: string;
  releasePercentage: string;
  cutoffStart: string;
  cutoffEnd: string;
  releasedAt: string;
  notes: string | null;
  employeeName: string;
  employeeNo: string | null;
}

export function ThirteenthMonthTab() {
  const { toast } = useToast();
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [isReleaseDialogOpen, setIsReleaseDialogOpen] = useState(false);
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false);
  const [selectedEmployees, setSelectedEmployees] = useState<string[]>([]);
  const [selectedCutoff, setSelectedCutoff] = useState<string>("");
  const [releasePercentage, setReleasePercentage] = useState("100");
  const [releaseNotes, setReleaseNotes] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch 13th month data
  const { data: thirteenthMonthData, isLoading } = useQuery<ThirteenthMonthData>({
    queryKey: ["/api/settings/13th-month", { year: selectedYear }],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/settings/13th-month?year=${selectedYear}`);
      return response.json();
    },
  });

  // Fetch available draft cutoffs
  const { data: draftCutoffs = [] } = useQuery<DraftCutoff[]>({
    queryKey: ["/api/settings/13th-month/draft-cutoffs"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/settings/13th-month/draft-cutoffs");
      return response.json();
    },
  });

  // Fetch release preview
  const { data: releasePreview, refetch: refetchPreview } = useQuery<{
    preview: ReleasePreview[];
    summary: { employeeCount: number; totalReleaseAmount: number; releasePercentage: number };
  }>({
    queryKey: [
      "/api/settings/13th-month/preview",
      {
        year: selectedYear,
        cutoffStart: selectedCutoff.split("_")[0],
        cutoffEnd: selectedCutoff.split("_")[1],
        employeeIds: selectedEmployees.join(","),
        releasePercentage,
      },
    ],
    queryFn: async () => {
      if (!selectedCutoff) return { preview: [], summary: { employeeCount: 0, totalReleaseAmount: 0, releasePercentage: 100 } };
      const [cutoffStart, cutoffEnd] = selectedCutoff.split("_");
      const params = new URLSearchParams({
        year: selectedYear.toString(),
        cutoffStart,
        cutoffEnd,
        releasePercentage,
      });
      if (selectedEmployees.length > 0) {
        params.set("employeeIds", selectedEmployees.join(","));
      }
      const response = await apiRequest("GET", `/api/settings/13th-month/preview?${params}`);
      return response.json();
    },
    enabled: isReleaseDialogOpen && !!selectedCutoff,
  });

  // Fetch release history
  const { data: releaseHistory = [] } = useQuery<ThirteenthMonthRelease[]>({
    queryKey: ["/api/settings/13th-month/history", { year: selectedYear }],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/settings/13th-month/history?year=${selectedYear}`);
      return response.json();
    },
    enabled: isHistoryDialogOpen,
  });

  // Sync mutation
  const syncMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/settings/13th-month/sync", { year: selectedYear });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings/13th-month"] });
      toast({ title: "Sync Complete", description: `Synced ${data.synced} employee accruals.` });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to sync accruals.", variant: "destructive" });
    },
  });

  // Release mutation
  const releaseMutation = useMutation({
    mutationFn: async () => {
      const [cutoffStart, cutoffEnd] = selectedCutoff.split("_");
      const response = await apiRequest("POST", "/api/settings/13th-month/release", {
        year: selectedYear,
        cutoffStart,
        cutoffEnd,
        employeeIds: selectedEmployees.length > 0 ? selectedEmployees : undefined,
        releasePercentage: parseFloat(releasePercentage),
        notes: releaseNotes || undefined,
      });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings/13th-month"] });
      queryClient.invalidateQueries({ queryKey: ["/api/payroll"] });
      setIsReleaseDialogOpen(false);
      setSelectedEmployees([]);
      setSelectedCutoff("");
      setReleasePercentage("100");
      setReleaseNotes("");
      toast({
        title: "13th Month Released",
        description: `Released for ${data.releasedCount} employees. Total: ₱${data.totalAmount.toLocaleString()}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Release Failed",
        description: error.message || "Failed to release 13th month.",
        variant: "destructive",
      });
    },
  });

  // Export handler
  const handleExport = async () => {
    try {
      const response = await apiRequest("GET", `/api/settings/13th-month/export?year=${selectedYear}`);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `13th-month-report-${selectedYear}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast({ title: "Export Complete", description: "Report downloaded successfully." });
    } catch {
      toast({ title: "Error", description: "Failed to export report.", variant: "destructive" });
    }
  };

  // Format currency
  const formatCurrency = (value: string | number) => {
    const num = typeof value === "string" ? parseFloat(value) : value;
    return `₱${num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Released":
        return (
          <Badge variant="default" className="bg-green-500">
            <CheckCircle2 className="h-3 w-3 mr-1" />
            Released
          </Badge>
        );
      case "Partial":
        return (
          <Badge variant="secondary" className="bg-yellow-500 text-white">
            <Clock className="h-3 w-3 mr-1" />
            Partial
          </Badge>
        );
      default:
        return (
          <Badge variant="outline">
            <AlertCircle className="h-3 w-3 mr-1" />
            Pending
          </Badge>
        );
    }
  };

  // Filter data based on search
  const filteredData = thirteenthMonthData?.data.filter((item) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      item.employee.firstName.toLowerCase().includes(searchLower) ||
      item.employee.lastName.toLowerCase().includes(searchLower) ||
      (item.employee.employeeNo?.toLowerCase() || "").includes(searchLower) ||
      (item.employee.department?.toLowerCase() || "").includes(searchLower)
    );
  }) || [];

  // Pagination
  const pagination = usePagination(filteredData, { initialPageSize: 10 });

  const paginatedData = pagination.paginatedData;

  // Handle select all
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedEmployees(filteredData.filter(d => d.accrual.status !== "Released").map((d) => d.employee.id));
    } else {
      setSelectedEmployees([]);
    }
  };

  // Handle individual select
  const handleSelectEmployee = (employeeId: string, checked: boolean) => {
    if (checked) {
      setSelectedEmployees([...selectedEmployees, employeeId]);
    } else {
      setSelectedEmployees(selectedEmployees.filter((id) => id !== employeeId));
    }
  };

  const selectableEmployees = filteredData.filter(d => d.accrual.status !== "Released");
  const allSelected = selectableEmployees.length > 0 && selectableEmployees.every(d => selectedEmployees.includes(d.employee.id));

  return (
    <Card>
      <CardHeader className="flex flex-col gap-4 space-y-0">
        <div className="flex flex-row items-center justify-between gap-2">
          <div>
            <CardTitle>13th Month Pay</CardTitle>
            <CardDescription>
              Track and release 13th month bonus based on DOLE requirements (Total Basic Pay / 12)
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select value={selectedYear.toString()} onValueChange={(value) => setSelectedYear(parseInt(value))}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[...Array(5)].map((_, i) => {
                  const year = new Date().getFullYear() - 2 + i;
                  return (
                    <SelectItem key={year} value={year.toString()}>
                      {year}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Summary Cards */}
        {thirteenthMonthData && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t">
            <div className="bg-muted/50 rounded-lg p-3">
              <div className="text-sm text-muted-foreground">Total Accrued</div>
              <div className="text-xl font-bold">{formatCurrency(thirteenthMonthData.summary.totalAccrued)}</div>
            </div>
            <div className="bg-muted/50 rounded-lg p-3">
              <div className="text-sm text-muted-foreground">Total Released</div>
              <div className="text-xl font-bold text-green-600">{formatCurrency(thirteenthMonthData.summary.totalReleased)}</div>
            </div>
            <div className="bg-muted/50 rounded-lg p-3">
              <div className="text-sm text-muted-foreground">Employees</div>
              <div className="text-xl font-bold">{thirteenthMonthData.summary.employeeCount}</div>
            </div>
            <div className="bg-muted/50 rounded-lg p-3">
              <div className="text-sm text-muted-foreground">Status</div>
              <div className="flex gap-2 text-sm">
                <span className="text-yellow-600">{thirteenthMonthData.summary.pendingCount} Pending</span>
                <span className="text-green-600">{thirteenthMonthData.summary.releasedCount} Released</span>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-2 pt-2 border-t">
          <Button
            variant="outline"
            onClick={() => syncMutation.mutate()}
            disabled={syncMutation.isPending}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${syncMutation.isPending ? "animate-spin" : ""}`} />
            {syncMutation.isPending ? "Syncing..." : "Sync Accruals"}
          </Button>
          <Button
            onClick={() => setIsReleaseDialogOpen(true)}
            disabled={draftCutoffs.length === 0}
          >
            <Send className="h-4 w-4 mr-2" />
            Release 13th Month
          </Button>
          <Button variant="outline" onClick={() => setIsHistoryDialogOpen(true)}>
            <History className="h-4 w-4 mr-2" />
            Release History
          </Button>
          <Button variant="outline" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>

        {/* Search */}
        <div className="pt-2">
          <Input
            placeholder="Search by name, employee no, or department..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-sm"
          />
        </div>
      </CardHeader>

      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        ) : filteredData.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No 13th month data found for {selectedYear}. Click "Sync Accruals" to calculate from released payrolls.
          </div>
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={allSelected}
                      onCheckedChange={handleSelectAll}
                      aria-label="Select all"
                    />
                  </TableHead>
                  <TableHead>Employee</TableHead>
                  <TableHead>Months</TableHead>
                  <TableHead>Accumulated Basic</TableHead>
                  <TableHead>13th Month</TableHead>
                  <TableHead>Released</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedData.map((item) => (
                  <TableRow key={item.employee.id}>
                    <TableCell>
                      <Checkbox
                        checked={selectedEmployees.includes(item.employee.id)}
                        onCheckedChange={(checked) => handleSelectEmployee(item.employee.id, !!checked)}
                        disabled={item.accrual.status === "Released"}
                        aria-label={`Select ${item.employee.firstName}`}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">
                        {item.employee.firstName} {item.employee.lastName}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {item.employee.employeeNo || "No ID"} · {item.employee.department || "No Dept"}
                      </div>
                    </TableCell>
                    <TableCell>{parseFloat(item.accrual.monthsWorked).toFixed(1)}</TableCell>
                    <TableCell>{formatCurrency(item.accrual.accumulatedBasicPay)}</TableCell>
                    <TableCell className="font-semibold">{formatCurrency(item.accrual.accruedAmount)}</TableCell>
                    <TableCell>
                      <div>{formatCurrency(item.accrual.releasedAmount)}</div>
                      {parseFloat(item.accrual.releasedPercentage) > 0 && (
                        <div className="text-xs text-muted-foreground">
                          {parseFloat(item.accrual.releasedPercentage).toFixed(0)}%
                        </div>
                      )}
                    </TableCell>
                    <TableCell>{getStatusBadge(item.accrual.status)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <TablePagination
              currentPage={pagination.currentPage}
              pageSize={pagination.pageSize}
              totalPages={pagination.totalPages}
              totalItems={pagination.totalItems}
              startIndex={pagination.startIndex}
              endIndex={pagination.endIndex}
              canGoNext={pagination.canGoNext}
              canGoPrevious={pagination.canGoPrevious}
              onPageChange={pagination.goToPage}
              onPageSizeChange={pagination.setPageSize}
              onNextPage={pagination.goToNextPage}
              onPreviousPage={pagination.goToPreviousPage}
              onFirstPage={pagination.goToFirstPage}
              onLastPage={pagination.goToLastPage}
            />
          </>
        )}
      </CardContent>

      {/* Release Dialog */}
      <Dialog open={isReleaseDialogOpen} onOpenChange={setIsReleaseDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Release 13th Month Pay</DialogTitle>
            <DialogDescription>
              Release 13th month bonus to draft payslips. This will add the bonus amount to the selected employees' payslips.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {draftCutoffs.length === 0 ? (
              <div className="bg-destructive/10 text-destructive p-4 rounded-lg flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                <span>No draft payslips found. Please compute payroll first before releasing 13th month.</span>
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <Label>Target Payslip Cutoff</Label>
                  <Select value={selectedCutoff} onValueChange={setSelectedCutoff}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select cutoff period" />
                    </SelectTrigger>
                    <SelectContent>
                      {draftCutoffs.map((cutoff) => (
                        <SelectItem key={`${cutoff.cutoffStart}_${cutoff.cutoffEnd}`} value={`${cutoff.cutoffStart}_${cutoff.cutoffEnd}`}>
                          {cutoff.label} ({cutoff.draftCount} drafts)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Release Percentage</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min="1"
                      max="100"
                      value={releasePercentage}
                      onChange={(e) => setReleasePercentage(e.target.value)}
                      className="w-24"
                    />
                    <span className="text-muted-foreground">%</span>
                    <span className="text-sm text-muted-foreground ml-2">
                      (Use 50% for November, 50% for December)
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Notes (Optional)</Label>
                  <Input
                    value={releaseNotes}
                    onChange={(e) => setReleaseNotes(e.target.value)}
                    placeholder="e.g., December 2026 13th Month Release"
                  />
                </div>

                <div className="space-y-2">
                  <Label>
                    Selected Employees: {selectedEmployees.length > 0 ? selectedEmployees.length : "All eligible"}
                  </Label>
                  {selectedEmployees.length > 0 && (
                    <Button variant="ghost" className="p-0 h-auto text-sm text-primary underline-offset-4 hover:underline" onClick={() => setSelectedEmployees([])}>
                      Clear selection (release to all)
                    </Button>
                  )}
                </div>

                {/* Preview */}
                {selectedCutoff && releasePreview && releasePreview.preview.length > 0 && (
                  <div className="border rounded-lg p-4 space-y-3">
                    <div className="font-medium">Release Preview</div>
                    <div className="max-h-48 overflow-y-auto space-y-2">
                      {releasePreview.preview.map((item) => (
                        <div key={item.employeeId} className="flex justify-between text-sm">
                          <span>{item.employeeName}</span>
                          <span className="font-medium">{formatCurrency(item.releaseAmount)}</span>
                        </div>
                      ))}
                    </div>
                    <div className="border-t pt-2 flex justify-between font-semibold">
                      <span>Total ({releasePreview.summary.employeeCount} employees)</span>
                      <span>{formatCurrency(releasePreview.summary.totalReleaseAmount)}</span>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsReleaseDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => releaseMutation.mutate()}
              disabled={!selectedCutoff || releaseMutation.isPending || draftCutoffs.length === 0}
            >
              {releaseMutation.isPending ? "Releasing..." : "Confirm Release"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* History Dialog */}
      <Dialog open={isHistoryDialogOpen} onOpenChange={setIsHistoryDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Release History - {selectedYear}</DialogTitle>
            <DialogDescription>View all 13th month releases for the selected year.</DialogDescription>
          </DialogHeader>

          {releaseHistory.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No releases found for {selectedYear}.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Employee</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>%</TableHead>
                  <TableHead>Cutoff</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {releaseHistory.map((release) => (
                  <TableRow key={release.id}>
                    <TableCell>{format(new Date(release.releasedAt), "MMM dd, yyyy")}</TableCell>
                    <TableCell>
                      <div className="font-medium">{release.employeeName}</div>
                      <div className="text-xs text-muted-foreground">{release.employeeNo}</div>
                    </TableCell>
                    <TableCell>{formatCurrency(release.releaseAmount)}</TableCell>
                    <TableCell>{parseFloat(release.releasePercentage).toFixed(0)}%</TableCell>
                    <TableCell className="text-sm">
                      {release.cutoffStart} to {release.cutoffEnd}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsHistoryDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
