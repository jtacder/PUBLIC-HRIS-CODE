import { useState, useEffect, useCallback, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "./use-auth";

/**
 * Convert a base64 VAPID public key to Uint8Array for the Push API
 */
function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export function usePushNotifications() {
  const { user } = useAuth();
  const [isSupported, setIsSupported] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission>("default");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const registrationRef = useRef<ServiceWorkerRegistration | null>(null);

  // Check if push is supported
  useEffect(() => {
    const supported = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
    setIsSupported(supported);
    if (supported) {
      setPermission(Notification.permission);
    }
  }, []);

  // Get VAPID public key from server
  const { data: pushConfig } = useQuery<{ enabled: boolean; publicKey: string | null }>({
    queryKey: ["/api/notifications/push/vapid-key"],
    enabled: !!user?.employeeId && isSupported,
  });

  // Register service worker and check subscription status
  useEffect(() => {
    if (!isSupported || !user?.employeeId) return;

    navigator.serviceWorker
      .register("/sw-notifications.js")
      .then((reg) => {
        registrationRef.current = reg;
        return reg.pushManager.getSubscription();
      })
      .then((sub) => {
        setIsSubscribed(!!sub);
      })
      .catch((err) => {
        console.error("Service worker registration failed:", err);
      });
  }, [isSupported, user?.employeeId]);

  /**
   * Ensure service worker is registered and ready.
   * Handles the race condition where the user clicks Enable before
   * the useEffect registration has completed.
   */
  async function ensureServiceWorkerReady(): Promise<ServiceWorkerRegistration> {
    // If we already have a registration, return it
    if (registrationRef.current) {
      return registrationRef.current;
    }

    // Try registering the service worker directly
    try {
      const reg = await navigator.serviceWorker.register("/sw-notifications.js");
      registrationRef.current = reg;
      return reg;
    } catch (err) {
      console.error("Service worker registration failed:", err);
      throw new Error(
        "Failed to register the notification service worker. " +
        "Make sure you are accessing the app directly in your browser (not inside an iframe or Replit webview)."
      );
    }
  }

  // Subscribe to push
  const subscribeMutation = useMutation({
    mutationFn: async () => {
      // Check browser support
      if (!isSupported) {
        throw new Error(
          "Push notifications are not supported in this browser. Try Chrome, Edge, or Firefox."
        );
      }

      // Check VAPID key availability
      if (!pushConfig?.enabled || !pushConfig?.publicKey) {
        throw new Error(
          "Push notifications are not configured on the server. " +
          "The administrator needs to set VAPID keys in the server environment."
        );
      }

      // Ensure service worker is registered (handles race condition)
      const registration = await ensureServiceWorkerReady();

      // Wait for the service worker to be active
      if (registration.installing || registration.waiting) {
        await new Promise<void>((resolve) => {
          const sw = registration.installing || registration.waiting;
          if (!sw) {
            resolve();
            return;
          }
          sw.addEventListener("statechange", function handler() {
            if (sw.state === "activated") {
              sw.removeEventListener("statechange", handler);
              resolve();
            }
          });
          // Timeout fallback - don't wait forever
          setTimeout(resolve, 5000);
        });
      }

      // Request notification permission from the browser
      const perm = await Notification.requestPermission();
      setPermission(perm);
      if (perm !== "granted") {
        throw new Error(
          "Notification permission was denied. To enable notifications, " +
          "tap the lock icon in your browser's address bar and allow notifications for this site."
        );
      }

      // Subscribe via Push API
      let subscription: PushSubscription;
      try {
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(pushConfig.publicKey),
        });
      } catch (pushError: any) {
        console.error("Push subscription failed:", pushError);
        throw new Error(
          "Failed to subscribe to push notifications. " +
          (pushError?.message || "Please try again or contact your administrator.")
        );
      }

      // Send subscription to server
      const subJson = subscription.toJSON();
      await apiRequest("POST", "/api/notifications/push/subscribe", {
        endpoint: subJson.endpoint,
        keys: subJson.keys,
      });

      setIsSubscribed(true);
      return subscription;
    },
  });

  // Unsubscribe from push
  const unsubscribeMutation = useMutation({
    mutationFn: async () => {
      const registration = registrationRef.current;
      if (!registration) return;

      const subscription = await registration.pushManager.getSubscription();
      if (subscription) {
        // Unsubscribe from browser
        await subscription.unsubscribe();

        // Remove from server
        await apiRequest("POST", "/api/notifications/push/unsubscribe", {
          endpoint: subscription.endpoint,
        });
      }

      setIsSubscribed(false);
    },
  });

  const subscribe = useCallback(() => {
    subscribeMutation.mutate();
  }, [subscribeMutation]);

  const unsubscribe = useCallback(() => {
    unsubscribeMutation.mutate();
  }, [unsubscribeMutation]);

  return {
    isSupported,
    isEnabled: pushConfig?.enabled ?? false,
    permission,
    isSubscribed,
    subscribe,
    unsubscribe,
    isSubscribing: subscribeMutation.isPending,
    isUnsubscribing: unsubscribeMutation.isPending,
    error: subscribeMutation.error || unsubscribeMutation.error,
  };
}
