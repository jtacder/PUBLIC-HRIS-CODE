import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useCallback } from "react";
import { apiRequest, clearCsrfToken } from "@/lib/queryClient";

export interface AuthUser {
  id: string;
  email: string;
  employeeId: string;
  role: string;
  roleId?: string | null;
  firstName: string;
  lastName: string;
  isSuperadmin?: boolean;
  permissions?: string[];
}

interface AuthResponse {
  user: AuthUser;
}

async function fetchUser(): Promise<AuthUser | null> {
  const response = await fetch("/api/auth/me", {
    credentials: "include",
  });

  if (response.status === 401) {
    return null;
  }

  if (!response.ok) {
    throw new Error(`${response.status}: ${response.statusText}`);
  }

  const data: AuthResponse = await response.json();
  return data.user;
}

async function logout(): Promise<void> {
  await apiRequest("POST", "/api/auth/logout", {});
}

export function useAuth() {
  const queryClient = useQueryClient();

  const { data: user, isLoading, refetch } = useQuery<AuthUser | null>({
    queryKey: ["/api/auth/me"],
    queryFn: fetchUser,
    retry: false,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  const logoutMutation = useMutation({
    mutationFn: logout,
    onSuccess: () => {
      // Clear cached CSRF token on logout
      clearCsrfToken();
      queryClient.setQueryData(["/api/auth/me"], null);
      window.location.href = "/";
    },
  });

  // Permission checking helpers
  const hasPermission = useCallback(
    (permissionCode: string): boolean => {
      if (!user) return false;
      if (user.isSuperadmin) return true;
      return user.permissions?.includes(permissionCode) ?? false;
    },
    [user]
  );

  const hasAnyPermission = useCallback(
    (...permissionCodes: string[]): boolean => {
      if (!user) return false;
      if (user.isSuperadmin) return true;
      return permissionCodes.some((code) => user.permissions?.includes(code));
    },
    [user]
  );

  const hasAllPermissions = useCallback(
    (...permissionCodes: string[]): boolean => {
      if (!user) return false;
      if (user.isSuperadmin) return true;
      return permissionCodes.every((code) => user.permissions?.includes(code));
    },
    [user]
  );

  // Legacy role check (for backward compatibility)
  const isAdmin = user?.isSuperadmin || user?.role === "ADMIN" || user?.role === "HR";
  const isLegacyHR = user?.role === "HR";
  const isLegacyAdmin = user?.role === "ADMIN";

  /**
   * Combined permission check that supports both legacy roles AND modern permissions
   * This ensures backward compatibility while allowing gradual migration
   *
   * Usage:
   *   hasAccessTo("employees.view")
   *   hasAccessTo("employees.view", { legacyRoles: ["ADMIN", "HR"] })
   *
   * Access is granted if:
   *   1. User is superadmin, OR
   *   2. User has the specified permission, OR
   *   3. User has one of the specified legacy roles
   */
  const hasAccessTo = useCallback(
    (
      permissionCode: string,
      options?: { legacyRoles?: string[] }
    ): boolean => {
      if (!user) return false;
      if (user.isSuperadmin) return true;

      // Check modern permission
      if (user.permissions?.includes(permissionCode)) return true;

      // Check legacy roles if specified
      if (options?.legacyRoles && user.role) {
        if (options.legacyRoles.includes(user.role.toUpperCase())) return true;
      }

      return false;
    },
    [user]
  );

  // Refresh permissions from server
  const refreshPermissions = useCallback(async () => {
    await refetch();
  }, [refetch]);

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    logout: logoutMutation.mutate,
    isLoggingOut: logoutMutation.isPending,
    // Permission helpers
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    hasAccessTo, // Combined check for backward compatibility
    isSuperadmin: user?.isSuperadmin ?? false,
    isAdmin,
    isLegacyHR,
    isLegacyAdmin,
    permissions: user?.permissions ?? [],
    refreshPermissions,
  };
}
