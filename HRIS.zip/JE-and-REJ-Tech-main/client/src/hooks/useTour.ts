/**
 * useTour Hook
 *
 * Custom hook for managing tours on individual pages.
 * Provides a simple interface for starting and controlling page-specific tours.
 */

import { useCallback, useMemo } from 'react';
import type { Step } from 'react-joyride';
import { useTourContext } from '@/components/tour/TourProvider';
import {
  isTourCompleted,
  isTourSkipped,
  resetTour,
  TourId,
} from '@/lib/tour/tour-storage';

interface UseTourOptions {
  tourId: TourId;
  steps: Step[];
  autoStart?: boolean;
}

interface UseTourReturn {
  // State
  isActive: boolean;
  isCompleted: boolean;
  isSkipped: boolean;
  currentStep: number;
  totalSteps: number;

  // Actions
  start: () => void;
  stop: () => void;
  restart: () => void;
  next: () => void;
  prev: () => void;
  goTo: (index: number) => void;
}

export function useTour({ tourId, steps }: UseTourOptions): UseTourReturn {
  const {
    isRunning,
    currentTourId,
    currentStepIndex,
    startTour,
    stopTour,
    nextStep,
    prevStep,
    goToStep,
    restartTour,
  } = useTourContext();

  const isActive = isRunning && currentTourId === tourId;
  const isCompleted = useMemo(() => isTourCompleted(tourId), [tourId]);
  const isSkipped = useMemo(() => isTourSkipped(tourId), [tourId]);

  const start = useCallback(() => {
    startTour(tourId, steps);
  }, [tourId, steps, startTour]);

  const stop = useCallback(() => {
    if (isActive) {
      stopTour();
    }
  }, [isActive, stopTour]);

  const restart = useCallback(() => {
    resetTour(tourId);
    restartTour(tourId);
    startTour(tourId, steps);
  }, [tourId, steps, restartTour, startTour]);

  const next = useCallback(() => {
    if (isActive) {
      nextStep();
    }
  }, [isActive, nextStep]);

  const prev = useCallback(() => {
    if (isActive) {
      prevStep();
    }
  }, [isActive, prevStep]);

  const goTo = useCallback((index: number) => {
    if (isActive) {
      goToStep(index);
    }
  }, [isActive, goToStep]);

  return {
    isActive,
    isCompleted,
    isSkipped,
    currentStep: isActive ? currentStepIndex : 0,
    totalSteps: steps.length,
    start,
    stop,
    restart,
    next,
    prev,
    goTo,
  };
}

/**
 * Hook for checking if any tour is currently running
 */
export function useIsTourRunning(): boolean {
  const { isRunning } = useTourContext();
  return isRunning;
}

/**
 * Hook for getting the current tour ID
 */
export function useCurrentTourId(): TourId | null {
  const { currentTourId } = useTourContext();
  return currentTourId;
}

/**
 * Hook for checking first-time user status
 */
export function useIsFirstTimeUser(): boolean {
  const { isFirstTime } = useTourContext();
  return isFirstTime;
}
