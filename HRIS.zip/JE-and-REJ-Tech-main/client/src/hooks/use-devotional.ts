import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

// Types for devotional data
export interface DevotionalContent {
  id: string;
  verse: string;
  reference: string;
  excerpt: string;
  theme: string | null;
}

export interface DevotionalProgress {
  totalDaysRead: number;
  currentStreak: number;
  longestStreak: number;
}

export interface TodayDevotionalResponse {
  day: number;
  totalDays: number;
  todayRead: boolean;
  progress: DevotionalProgress;
  content: DevotionalContent | null;
  message?: string;
}

export interface MarkReadResponse {
  success: boolean;
  message: string;
  newStreak: number;
  totalDaysRead: number;
}

export interface FullProgressResponse {
  started: boolean;
  startDate?: string;
  lastReadDay?: number;
  lastReadDate?: string;
  totalDaysRead?: number;
  currentStreak?: number;
  longestStreak?: number;
  todayRead?: boolean;
  percentComplete?: number;
  recentReadings?: Array<{
    date: string;
    dayNumber: number;
    isFavorite: boolean;
  }>;
  message?: string;
}

// Fetch today's devotional
async function fetchTodayDevotional(): Promise<TodayDevotionalResponse> {
  const response = await fetch("/api/devotionals/today", {
    credentials: "include",
  });

  if (!response.ok) {
    throw new Error(`${response.status}: ${response.statusText}`);
  }

  return response.json();
}

// Fetch full progress
async function fetchProgress(): Promise<FullProgressResponse> {
  const response = await fetch("/api/devotionals/progress", {
    credentials: "include",
  });

  if (!response.ok) {
    throw new Error(`${response.status}: ${response.statusText}`);
  }

  return response.json();
}

// Mark as read
async function markAsRead(personalNote?: string): Promise<MarkReadResponse> {
  const response = await apiRequest("POST", "/api/devotionals/mark-read", {
    personalNote,
  });

  return response.json();
}

// Toggle favorite
async function toggleFavorite(logId: string, isFavorite: boolean): Promise<void> {
  await apiRequest("POST", `/api/devotionals/favorite/${logId}`, {
    isFavorite,
  });
}

/**
 * Custom hook for managing devotional state
 */
export function useDevotional() {
  const queryClient = useQueryClient();

  // Fetch today's devotional
  const {
    data: todayData,
    isLoading: isTodayLoading,
    error: todayError,
    refetch: refetchToday,
  } = useQuery<TodayDevotionalResponse>({
    queryKey: ["/api/devotionals/today"],
    queryFn: fetchTodayDevotional,
    staleTime: 1000 * 60 * 5, // 5 minutes
    retry: 1,
  });

  // Fetch full progress
  const {
    data: progressData,
    isLoading: isProgressLoading,
    refetch: refetchProgress,
  } = useQuery<FullProgressResponse>({
    queryKey: ["/api/devotionals/progress"],
    queryFn: fetchProgress,
    staleTime: 1000 * 60 * 5, // 5 minutes
    retry: 1,
  });

  // Mark as read mutation
  const markReadMutation = useMutation({
    mutationFn: (personalNote?: string) => markAsRead(personalNote),
    onSuccess: () => {
      // Invalidate and refetch relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/devotionals/today"] });
      queryClient.invalidateQueries({ queryKey: ["/api/devotionals/progress"] });
    },
  });

  // Toggle favorite mutation
  const toggleFavoriteMutation = useMutation({
    mutationFn: ({ logId, isFavorite }: { logId: string; isFavorite: boolean }) =>
      toggleFavorite(logId, isFavorite),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devotionals/progress"] });
      queryClient.invalidateQueries({ queryKey: ["/api/devotionals/favorites"] });
    },
  });

  return {
    // Today's devotional data
    todayDevotional: todayData?.content ?? null,
    day: todayData?.day ?? 0,
    totalDays: todayData?.totalDays ?? 365,
    todayRead: todayData?.todayRead ?? false,

    // Progress data
    progress: todayData?.progress ?? {
      totalDaysRead: 0,
      currentStreak: 0,
      longestStreak: 0,
    },
    fullProgress: progressData,

    // Loading states
    isLoading: isTodayLoading,
    isProgressLoading,
    error: todayError,

    // Actions
    markAsRead: markReadMutation.mutate,
    isMarkingRead: markReadMutation.isPending,
    markReadError: markReadMutation.error,

    toggleFavorite: toggleFavoriteMutation.mutate,
    isTogglingFavorite: toggleFavoriteMutation.isPending,

    // Refresh functions
    refetchToday,
    refetchProgress,
  };
}

/**
 * Hook for managing devotional widget visibility state
 */
export type DevotionalWidgetState = 'modal' | 'fab' | 'hidden';

export function useDevotionalWidget() {
  // This could be enhanced with localStorage persistence
  // For now, returning simple state management helpers

  const getInitialState = (todayRead: boolean): DevotionalWidgetState => {
    // Check if user dismissed for today
    const dismissedToday = localStorage.getItem('devotional_dismissed_date');
    const today = new Date().toISOString().split('T')[0];

    if (dismissedToday === today) {
      return 'fab'; // Show as FAB if dismissed today
    }

    return todayRead ? 'fab' : 'modal'; // Show modal if not read, FAB if read
  };

  const dismissForToday = () => {
    const today = new Date().toISOString().split('T')[0];
    localStorage.setItem('devotional_dismissed_date', today);
  };

  const hideCompletely = () => {
    const today = new Date().toISOString().split('T')[0];
    localStorage.setItem('devotional_hidden_date', today);
  };

  const shouldShowWidget = (): boolean => {
    const hiddenDate = localStorage.getItem('devotional_hidden_date');
    const today = new Date().toISOString().split('T')[0];
    return hiddenDate !== today;
  };

  return {
    getInitialState,
    dismissForToday,
    hideCompletely,
    shouldShowWidget,
  };
}
