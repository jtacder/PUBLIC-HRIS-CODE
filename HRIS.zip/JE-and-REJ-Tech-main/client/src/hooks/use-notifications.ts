import { useState, useEffect, useCallback, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "./use-auth";

// ============================================
// TYPES
// ============================================

export interface NotificationData {
  notification: {
    id: string;
    recipientId: string;
    title: string;
    message: string;
    category: string;
    priority: string;
    actionUrl: string | null;
    entityType: string | null;
    entityId: string | null;
    actorId: string | null;
    isRead: boolean;
    readAt: string | null;
    pushSent: boolean;
    emailSent: boolean;
    isBroadcast: boolean;
    createdAt: string;
    expiresAt: string | null;
  };
  actor: {
    id: string;
    firstName: string;
    lastName: string;
    profilePhotoUrl: string | null;
  } | null;
}

export interface NotificationPreferences {
  id: string;
  employeeId: string;
  enabled: boolean;
  preferences: Record<string, Record<string, boolean>>;
  quietHoursStart: string | null;
  quietHoursEnd: string | null;
  categories: Record<string, { label: string; description: string }>;
  defaults: Record<string, Record<string, boolean>>;
}

// ============================================
// WEBSOCKET HOOK
// ============================================

export function useNotificationWebSocket() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttemptsRef = useRef(0);

  const connect = useCallback(() => {
    if (!user?.employeeId) return;
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const ws = new WebSocket(`${protocol}//${window.location.host}/ws/notifications`);

    ws.onopen = () => {
      reconnectAttemptsRef.current = 0;
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === "notification") {
          // Invalidate queries to refresh notification data
          queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
          queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
        }
      } catch {
        // Ignore malformed messages
      }
    };

    ws.onclose = () => {
      wsRef.current = null;
      // Exponential backoff reconnect (max 30 seconds)
      if (user?.employeeId) {
        const delay = Math.min(1000 * Math.pow(2, reconnectAttemptsRef.current), 30000);
        reconnectAttemptsRef.current++;
        reconnectTimeoutRef.current = setTimeout(connect, delay);
      }
    };

    ws.onerror = () => {
      ws.close();
    };

    wsRef.current = ws;
  }, [user?.employeeId, queryClient]);

  useEffect(() => {
    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [connect]);

  return wsRef;
}

// ============================================
// NOTIFICATION QUERIES & MUTATIONS
// ============================================

export function useUnreadCount() {
  const { user } = useAuth();
  return useQuery<{ count: number }>({
    queryKey: ["/api/notifications/unread-count"],
    enabled: !!user?.employeeId,
    refetchInterval: 5 * 60 * 1000, // Fallback poll every 5 minutes (reduced from 60s to lower compute usage)
  });
}

export function useNotifications(options?: { limit?: number; unreadOnly?: boolean; category?: string }) {
  const { user } = useAuth();
  const params = new URLSearchParams();
  if (options?.limit) params.set("limit", String(options.limit));
  if (options?.unreadOnly) params.set("unreadOnly", "true");
  if (options?.category) params.set("category", options.category);

  const queryString = params.toString();
  const key = queryString ? `/api/notifications?${queryString}` : "/api/notifications";

  return useQuery<NotificationData[]>({
    queryKey: [key],
    enabled: !!user?.employeeId,
  });
}

export function useMarkAsRead() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (notificationId: string) => {
      const res = await apiRequest("PATCH", `/api/notifications/${notificationId}/read`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });
}

export function useMarkAllAsRead() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PATCH", "/api/notifications/read-all");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });
}

export function useDeleteNotification() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (notificationId: string) => {
      const res = await apiRequest("DELETE", `/api/notifications/${notificationId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });
}

export function useNotificationPreferences() {
  const { user } = useAuth();
  return useQuery<NotificationPreferences>({
    queryKey: ["/api/notifications/preferences"],
    enabled: !!user?.employeeId,
  });
}

export function useUpdatePreferences() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (updates: {
      enabled?: boolean;
      preferences?: Record<string, Record<string, boolean>>;
      quietHoursStart?: string | null;
      quietHoursEnd?: string | null;
    }) => {
      const res = await apiRequest("PATCH", "/api/notifications/preferences", updates);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/preferences"] });
    },
  });
}
