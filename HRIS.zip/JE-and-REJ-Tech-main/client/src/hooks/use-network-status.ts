import { useState, useEffect, useCallback } from "react";

interface NetworkStatus {
  /** Whether the browser reports being online */
  isOnline: boolean;
  /** Whether the network status has been checked at least once */
  isInitialized: boolean;
  /** Last time the status changed */
  lastChanged: Date | null;
  /** Connection effective type (if available) */
  effectiveType: "slow-2g" | "2g" | "3g" | "4g" | null;
  /** Downlink speed in Mbps (if available) */
  downlink: number | null;
  /** Whether the connection is metered/limited (if available) */
  saveData: boolean;
}

/**
 * Hook to monitor network connectivity status
 *
 * Uses the Navigator.onLine API and online/offline events to track
 * whether the user has network connectivity.
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { isOnline, effectiveType } = useNetworkStatus();
 *
 *   if (!isOnline) {
 *     return <div>You are offline</div>;
 *   }
 *
 *   return <div>Connected ({effectiveType})</div>;
 * }
 * ```
 */
export function useNetworkStatus(): NetworkStatus {
  const [status, setStatus] = useState<NetworkStatus>(() => ({
    isOnline: typeof navigator !== "undefined" ? navigator.onLine : true,
    isInitialized: false,
    lastChanged: null,
    effectiveType: null,
    downlink: null,
    saveData: false,
  }));

  // Get connection info if available (Network Information API)
  const getConnectionInfo = useCallback(() => {
    const connection =
      (navigator as any).connection ||
      (navigator as any).mozConnection ||
      (navigator as any).webkitConnection;

    if (connection) {
      return {
        effectiveType: connection.effectiveType || null,
        downlink: connection.downlink || null,
        saveData: connection.saveData || false,
      };
    }

    return {
      effectiveType: null,
      downlink: null,
      saveData: false,
    };
  }, []);

  // Handle online event
  const handleOnline = useCallback(() => {
    const connectionInfo = getConnectionInfo();
    setStatus((prev) => ({
      ...prev,
      isOnline: true,
      lastChanged: new Date(),
      ...connectionInfo,
    }));
    console.log("Network status: online");
  }, [getConnectionInfo]);

  // Handle offline event
  const handleOffline = useCallback(() => {
    setStatus((prev) => ({
      ...prev,
      isOnline: false,
      lastChanged: new Date(),
    }));
    console.log("Network status: offline");
  }, []);

  // Handle connection change (Network Information API)
  const handleConnectionChange = useCallback(() => {
    const connectionInfo = getConnectionInfo();
    setStatus((prev) => ({
      ...prev,
      ...connectionInfo,
    }));
    console.log("Network connection changed:", connectionInfo);
  }, [getConnectionInfo]);

  useEffect(() => {
    // Initialize with current status
    const connectionInfo = getConnectionInfo();
    setStatus({
      isOnline: navigator.onLine,
      isInitialized: true,
      lastChanged: null,
      ...connectionInfo,
    });

    // Add event listeners
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    // Listen for connection changes if supported
    const connection =
      (navigator as any).connection ||
      (navigator as any).mozConnection ||
      (navigator as any).webkitConnection;

    if (connection) {
      connection.addEventListener("change", handleConnectionChange);
    }

    // Cleanup
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);

      if (connection) {
        connection.removeEventListener("change", handleConnectionChange);
      }
    };
  }, [handleOnline, handleOffline, handleConnectionChange, getConnectionInfo]);

  return status;
}

/**
 * Simple hook that just returns whether online or not
 */
export function useOnlineStatus(): boolean {
  const { isOnline } = useNetworkStatus();
  return isOnline;
}
