import { useState, useMemo, useCallback, useEffect } from "react";

export type PageSize = 10 | 25 | 50 | "all";

export interface UsePaginationOptions {
  initialPageSize?: PageSize;
  initialPage?: number;
}

export interface UsePaginationReturn<T> {
  // Current page (1-indexed)
  currentPage: number;
  // Current page size
  pageSize: PageSize;
  // Total number of pages
  totalPages: number;
  // Total number of items
  totalItems: number;
  // Paginated data for current page
  paginatedData: T[];
  // Start index (1-indexed) for display
  startIndex: number;
  // End index for display
  endIndex: number;
  // Navigation functions
  goToPage: (page: number) => void;
  goToNextPage: () => void;
  goToPreviousPage: () => void;
  goToFirstPage: () => void;
  goToLastPage: () => void;
  // Page size control
  setPageSize: (size: PageSize) => void;
  // Navigation state
  canGoNext: boolean;
  canGoPrevious: boolean;
  // Reset pagination (useful when filters change)
  resetPagination: () => void;
}

export function usePagination<T>(
  data: T[],
  options: UsePaginationOptions = {}
): UsePaginationReturn<T> {
  const { initialPageSize = 10, initialPage = 1 } = options;

  const [currentPage, setCurrentPage] = useState(initialPage);
  const [pageSize, setPageSizeState] = useState<PageSize>(initialPageSize);

  const totalItems = data.length;

  const totalPages = useMemo(() => {
    if (pageSize === "all") return 1;
    return Math.max(1, Math.ceil(totalItems / pageSize));
  }, [totalItems, pageSize]);

  // Reset to page 1 when data changes significantly (e.g., filter applied)
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(1);
    }
  }, [totalPages, currentPage]);

  const paginatedData = useMemo(() => {
    if (pageSize === "all") return data;

    const startIdx = (currentPage - 1) * pageSize;
    const endIdx = startIdx + pageSize;
    return data.slice(startIdx, endIdx);
  }, [data, currentPage, pageSize]);

  const startIndex = useMemo(() => {
    if (totalItems === 0) return 0;
    if (pageSize === "all") return 1;
    return (currentPage - 1) * pageSize + 1;
  }, [currentPage, pageSize, totalItems]);

  const endIndex = useMemo(() => {
    if (totalItems === 0) return 0;
    if (pageSize === "all") return totalItems;
    return Math.min(currentPage * pageSize, totalItems);
  }, [currentPage, pageSize, totalItems]);

  const canGoNext = currentPage < totalPages;
  const canGoPrevious = currentPage > 1;

  const goToPage = useCallback((page: number) => {
    const validPage = Math.max(1, Math.min(page, totalPages));
    setCurrentPage(validPage);
  }, [totalPages]);

  const goToNextPage = useCallback(() => {
    if (canGoNext) {
      setCurrentPage(prev => prev + 1);
    }
  }, [canGoNext]);

  const goToPreviousPage = useCallback(() => {
    if (canGoPrevious) {
      setCurrentPage(prev => prev - 1);
    }
  }, [canGoPrevious]);

  const goToFirstPage = useCallback(() => {
    setCurrentPage(1);
  }, []);

  const goToLastPage = useCallback(() => {
    setCurrentPage(totalPages);
  }, [totalPages]);

  const setPageSize = useCallback((size: PageSize) => {
    setPageSizeState(size);
    setCurrentPage(1); // Reset to first page when page size changes
  }, []);

  const resetPagination = useCallback(() => {
    setCurrentPage(1);
  }, []);

  return {
    currentPage,
    pageSize,
    totalPages,
    totalItems,
    paginatedData,
    startIndex,
    endIndex,
    goToPage,
    goToNextPage,
    goToPreviousPage,
    goToFirstPage,
    goToLastPage,
    setPageSize,
    canGoNext,
    canGoPrevious,
    resetPagination,
  };
}
