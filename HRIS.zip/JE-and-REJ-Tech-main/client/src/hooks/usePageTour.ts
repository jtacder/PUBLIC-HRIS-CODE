/**
 * Hook to get the appropriate tour for the current page
 */

import { useLocation } from 'wouter';
import { Step } from 'react-joyride';
import { TOUR_IDS, TourId } from '@/lib/tour/tour-storage';
import {
  dashboardAdminSteps,
  dashboardEmployeeSteps,
  employeesSteps,
  attendanceSteps,
  payrollSteps,
  files201Steps,
  disciplinarySteps,
  hrRequestsSteps,
  hrSettingsSteps,
  expensesSteps,
  auditLogsSteps,
  devotionalsSteps,
  projectsSteps,
  tasksSteps,
  myTasksSteps,
  myPayslipsSteps,
  myRequestsSteps,
  myProfileSteps,
  myExpensesSteps,
  myDisciplinarySteps,
  sidebarNavigationSteps,
} from '@/lib/tour/steps';

interface PageTourConfig {
  tourId: TourId;
  steps: Step[];
  pageName: string;
}

const tourConfigByPath: Record<string, PageTourConfig> = {
  '/': { tourId: TOUR_IDS.DASHBOARD_ADMIN, steps: dashboardAdminSteps, pageName: 'Dashboard' },
  '/dashboard': { tourId: TOUR_IDS.DASHBOARD_ADMIN, steps: dashboardAdminSteps, pageName: 'Dashboard' },
  '/my-dashboard': { tourId: TOUR_IDS.DASHBOARD_EMPLOYEE, steps: dashboardEmployeeSteps, pageName: 'My Dashboard' },
  '/employees': { tourId: TOUR_IDS.EMPLOYEES, steps: employeesSteps, pageName: 'Employees' },
  '/attendance': { tourId: TOUR_IDS.ATTENDANCE, steps: attendanceSteps, pageName: 'Attendance' },
  '/payroll': { tourId: TOUR_IDS.PAYROLL, steps: payrollSteps, pageName: 'Payroll' },
  '/201-files': { tourId: TOUR_IDS.FILES_201, steps: files201Steps, pageName: '201 Files' },
  '/disciplinary': { tourId: TOUR_IDS.DISCIPLINARY, steps: disciplinarySteps, pageName: 'Disciplinary' },
  '/hr-requests': { tourId: TOUR_IDS.HR_REQUESTS, steps: hrRequestsSteps, pageName: 'HR Requests' },
  '/hr-settings': { tourId: TOUR_IDS.HR_SETTINGS, steps: hrSettingsSteps, pageName: 'HR Settings' },
  '/expenses': { tourId: TOUR_IDS.EXPENSES, steps: expensesSteps, pageName: 'Expenses' },
  '/audit-logs': { tourId: TOUR_IDS.AUDIT_LOGS, steps: auditLogsSteps, pageName: 'Audit Logs' },
  '/devotionals': { tourId: TOUR_IDS.DEVOTIONALS, steps: devotionalsSteps, pageName: 'Devotionals' },
  '/projects': { tourId: TOUR_IDS.PROJECTS, steps: projectsSteps, pageName: 'Projects' },
  '/tasks': { tourId: TOUR_IDS.TASKS, steps: tasksSteps, pageName: 'Tasks' },
  '/my-tasks': { tourId: TOUR_IDS.MY_TASKS, steps: myTasksSteps, pageName: 'My Tasks' },
  '/my-payslips': { tourId: TOUR_IDS.MY_PAYSLIPS, steps: myPayslipsSteps, pageName: 'My Payslips' },
  '/my-requests': { tourId: TOUR_IDS.MY_REQUESTS, steps: myRequestsSteps, pageName: 'My Requests' },
  '/my-profile': { tourId: TOUR_IDS.MY_PROFILE, steps: myProfileSteps, pageName: 'My Profile' },
  '/my-expenses': { tourId: TOUR_IDS.MY_EXPENSES, steps: myExpensesSteps, pageName: 'My Expenses' },
  '/my-disciplinary': { tourId: TOUR_IDS.MY_DISCIPLINARY, steps: myDisciplinarySteps, pageName: 'My Disciplinary' },
};

export function usePageTour(isAdmin: boolean = false): PageTourConfig | null {
  const [location] = useLocation();

  // Get the base path (without query params)
  const basePath = location.split('?')[0];

  // Check for exact match first
  let config = tourConfigByPath[basePath];

  // Handle root path based on role
  if (basePath === '/' || basePath === '/dashboard') {
    config = isAdmin
      ? { tourId: TOUR_IDS.DASHBOARD_ADMIN, steps: dashboardAdminSteps, pageName: 'Dashboard' }
      : { tourId: TOUR_IDS.DASHBOARD_EMPLOYEE, steps: dashboardEmployeeSteps, pageName: 'My Dashboard' };
  }

  return config || null;
}

export { sidebarNavigationSteps };
