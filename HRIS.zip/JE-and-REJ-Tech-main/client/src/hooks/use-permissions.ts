import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useCallback } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "./use-auth";

// Types for permission system
export interface Permission {
  id: string;
  feature: string;
  action: string;
  code: string;
  name: string;
  description: string | null;
  category: string;
  sortOrder: number;
  isActive: boolean;
}

export interface Role {
  id: string;
  name: string;
  displayName: string;
  description: string | null;
  isSystemRole: boolean;
  isSuperadmin: boolean;
  employeeCount?: number;
}

export interface RoleWithPermissions {
  role: Role;
  permissions: Permission[];
}

export interface EmployeeWithRole {
  id: string;
  firstName: string;
  lastName: string;
  email: string | null;
  position: string | null;
  department: string | null;
  role: string;
  roleId: string | null;
  status: string;
  assignedRole: Role | null;
  individualPermissionCount: number;
}

export interface EmployeePermissionDetails {
  role: Role | null;
  rolePermissions: Permission[];
  individualPermissions: Permission[];
  effectivePermissions: string[];
  isSuperadmin: boolean;
}

/**
 * Hook to manage permissions in the frontend
 */
export function usePermissions() {
  const { hasPermission, hasAnyPermission, hasAllPermissions, isSuperadmin, user } = useAuth();

  return {
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    isSuperadmin,
    canManagePermissions: hasPermission("permissions.manage"),
    canViewPermissions: hasPermission("permissions.view"),
  };
}

/**
 * Hook to fetch all available permissions
 */
export function useAllPermissions() {
  return useQuery<Permission[]>({
    queryKey: ["/api/permissions"],
    queryFn: async () => {
      const response = await fetch("/api/permissions", { credentials: "include" });
      if (!response.ok) throw new Error("Failed to fetch permissions");
      return response.json();
    },
  });
}

/**
 * Hook to fetch permissions grouped by category and feature
 */
export function useGroupedPermissions() {
  return useQuery<Record<string, Record<string, Permission[]>>>({
    queryKey: ["/api/permissions/grouped"],
    queryFn: async () => {
      const response = await fetch("/api/permissions/grouped", { credentials: "include" });
      if (!response.ok) throw new Error("Failed to fetch grouped permissions");
      return response.json();
    },
  });
}

/**
 * Hook to fetch all roles
 */
export function useRoles() {
  return useQuery<Role[]>({
    queryKey: ["/api/permissions/roles"],
    queryFn: async () => {
      const response = await fetch("/api/permissions/roles", { credentials: "include" });
      if (!response.ok) throw new Error("Failed to fetch roles");
      return response.json();
    },
  });
}

/**
 * Hook to fetch a role with its permissions
 */
export function useRoleWithPermissions(roleId: string | null) {
  return useQuery<RoleWithPermissions>({
    queryKey: ["/api/permissions/roles", roleId],
    queryFn: async () => {
      const response = await fetch(`/api/permissions/roles/${roleId}`, { credentials: "include" });
      if (!response.ok) throw new Error("Failed to fetch role");
      return response.json();
    },
    enabled: !!roleId,
  });
}

/**
 * Hook to fetch employees with their roles
 */
export function useEmployeesWithRoles() {
  return useQuery<EmployeeWithRole[]>({
    queryKey: ["/api/permissions/employees-with-roles"],
    queryFn: async () => {
      const response = await fetch("/api/permissions/employees-with-roles", { credentials: "include" });
      if (!response.ok) throw new Error("Failed to fetch employees");
      return response.json();
    },
  });
}

/**
 * Hook to fetch an employee's permission details
 */
export function useEmployeePermissions(employeeId: string | null) {
  return useQuery<EmployeePermissionDetails>({
    queryKey: ["/api/permissions/employees", employeeId],
    queryFn: async () => {
      const response = await fetch(`/api/permissions/employees/${employeeId}`, { credentials: "include" });
      if (!response.ok) throw new Error("Failed to fetch employee permissions");
      return response.json();
    },
    enabled: !!employeeId,
  });
}

/**
 * Hook for role mutations
 */
export function useRoleMutations() {
  const queryClient = useQueryClient();

  const createRole = useMutation({
    mutationFn: async (data: {
      name: string;
      displayName: string;
      description?: string;
      isSuperadmin?: boolean;
      permissionIds?: string[];
    }) => {
      return apiRequest("POST", "/api/permissions/roles", data);
    },
    onSuccess: () => {
      // Invalidate and force refetch to ensure UI updates immediately
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/roles"] });
      queryClient.refetchQueries({ queryKey: ["/api/permissions/roles"] });
    },
  });

  const updateRole = useMutation({
    mutationFn: async ({ id, ...data }: { id: string; displayName?: string; description?: string }) => {
      return apiRequest("PUT", `/api/permissions/roles/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/roles"] });
      queryClient.refetchQueries({ queryKey: ["/api/permissions/roles"] });
    },
  });

  const deleteRole = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/permissions/roles/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/roles"] });
      queryClient.refetchQueries({ queryKey: ["/api/permissions/roles"] });
    },
  });

  const updateRolePermissions = useMutation({
    mutationFn: async ({ roleId, permissionIds }: { roleId: string; permissionIds: string[] }) => {
      return apiRequest("PUT", `/api/permissions/roles/${roleId}/permissions`, { permissionIds });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/roles", variables.roleId] });
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/employees-with-roles"] });
      queryClient.refetchQueries({ queryKey: ["/api/permissions/roles"] });
      queryClient.refetchQueries({ queryKey: ["/api/permissions/employees-with-roles"] });
    },
  });

  return {
    createRole,
    updateRole,
    deleteRole,
    updateRolePermissions,
  };
}

/**
 * Hook for user permission mutations
 */
export function useUserPermissionMutations() {
  const queryClient = useQueryClient();

  const changeUserRole = useMutation({
    mutationFn: async ({ employeeId, roleId }: { employeeId: string; roleId: string | null }) => {
      return apiRequest("PUT", `/api/permissions/employees/${employeeId}/role`, { roleId });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/employees", variables.employeeId] });
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/employees-with-roles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/roles"] });
    },
  });

  const updateUserPermissions = useMutation({
    mutationFn: async ({ employeeId, permissionIds }: { employeeId: string; permissionIds: string[] }) => {
      return apiRequest("PUT", `/api/permissions/employees/${employeeId}/permissions`, { permissionIds });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/employees", variables.employeeId] });
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/employees-with-roles"] });
    },
  });

  const grantPermission = useMutation({
    mutationFn: async ({
      employeeId,
      permissionId,
      expiresAt,
    }: {
      employeeId: string;
      permissionId: string;
      expiresAt?: string;
    }) => {
      return apiRequest("POST", `/api/permissions/employees/${employeeId}/grant`, {
        permissionId,
        expiresAt,
      });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/employees", variables.employeeId] });
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/employees-with-roles"] });
    },
  });

  const revokePermission = useMutation({
    mutationFn: async ({ employeeId, permissionId }: { employeeId: string; permissionId: string }) => {
      return apiRequest("POST", `/api/permissions/employees/${employeeId}/revoke`, { permissionId });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/employees", variables.employeeId] });
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/employees-with-roles"] });
    },
  });

  return {
    changeUserRole,
    updateUserPermissions,
    grantPermission,
    revokePermission,
  };
}
