/**
 * Photo/File URL utility for handling both legacy base64 and Object Storage files.
 * Provides backwards compatibility during migration.
 */

/**
 * Check if a URL is a legacy base64 data URI (for images)
 */
export function isBase64Photo(url: string | null | undefined): boolean {
  if (!url) return false;
  return url.startsWith("data:image/");
}

/**
 * Check if a URL is a base64 data URI (any type including PDFs)
 */
export function isBase64DataUri(url: string | null | undefined): boolean {
  if (!url) return false;
  return url.startsWith("data:");
}

/**
 * Check if a URL is an Object Storage key
 */
export function isObjectStorageKey(url: string | null | undefined): boolean {
  if (!url) return false;
  // Object storage keys start with folder names like "attendance-photos/", "profile-photos/", etc.
  return (
    url.startsWith("attendance-photos/") ||
    url.startsWith("profile-photos/") ||
    url.startsWith("task-photos/") ||
    url.startsWith("receipt-photos/")
  );
}

/**
 * Check if a file key is a PDF based on extension
 */
export function isPdfKey(url: string | null | undefined): boolean {
  if (!url) return false;
  return url.toLowerCase().endsWith(".pdf");
}

/**
 * Check if a file key is an image based on extension
 */
export function isImageKey(url: string | null | undefined): boolean {
  if (!url) return false;
  const lowerUrl = url.toLowerCase();
  return (
    lowerUrl.endsWith(".jpg") ||
    lowerUrl.endsWith(".jpeg") ||
    lowerUrl.endsWith(".png") ||
    lowerUrl.endsWith(".webp") ||
    lowerUrl.endsWith(".gif")
  );
}

/**
 * Get the display URL for a photo.
 * Handles both legacy base64 and new Object Storage formats.
 *
 * @param photoValue - Either a base64 data URI or an Object Storage key
 * @returns URL that can be used in an <img> src attribute
 */
export function getPhotoDisplayUrl(photoValue: string | null | undefined): string | null {
  if (!photoValue) return null;

  // Legacy base64 format - use as-is
  if (isBase64Photo(photoValue)) {
    return photoValue;
  }

  // Object Storage key - construct the API URL
  if (isObjectStorageKey(photoValue)) {
    return `/api/photos/${encodeURIComponent(photoValue)}`;
  }

  // Unknown format - could be an external URL or other format
  // Return as-is and let the browser handle it
  return photoValue;
}

/**
 * React hook-friendly version that returns a display URL
 * Use this in components to get the correct src for images
 *
 * Example:
 * ```tsx
 * const photoSrc = usePhotoUrl(attendanceLog.photoSnapshotUrl);
 * return <img src={photoSrc || "/placeholder.jpg"} alt="Photo" />;
 * ```
 */
export function usePhotoUrl(photoValue: string | null | undefined): string | null {
  return getPhotoDisplayUrl(photoValue);
}
