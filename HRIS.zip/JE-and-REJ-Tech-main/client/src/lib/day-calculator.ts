/**
 * Day Calculator Utility for Devotional System
 * Calculates the current day in the 365-day rotating plan
 */

export interface DayInfo {
  currentDay: number;       // 1-365 (day of year)
  totalDays: number;        // Always 365
  year: number;             // 1, 2, or 3 (based on how many years since start)
  weekNumber: number;       // 1-52
  percentComplete: number;  // 0-100 (progress through current year)
  startDate: Date;
  currentDate: Date;
  yearPhase: 'Foundation' | 'Growth' | 'Mastery';
}

/**
 * Get the day of year (1-365 or 366 for leap years)
 */
export function getDayOfYear(date: Date = new Date()): number {
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = date.getTime() - start.getTime();
  const oneDay = 1000 * 60 * 60 * 24;
  const dayOfYear = Math.floor(diff / oneDay);
  // Clamp to 365 max (for leap years, day 366 becomes day 365)
  return Math.min(dayOfYear, 365);
}

/**
 * Get the week number of the year (1-52)
 */
export function getWeekNumber(date: Date = new Date()): number {
  const start = new Date(date.getFullYear(), 0, 1);
  const diff = date.getTime() - start.getTime();
  const oneWeek = 1000 * 60 * 60 * 24 * 7;
  return Math.ceil(diff / oneWeek);
}

/**
 * Calculate which year the user is in (1, 2, or 3) based on start date
 */
export function calculateYearNumber(startDate: Date, currentDate: Date = new Date()): number {
  const diffTime = currentDate.getTime() - startDate.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  const yearNumber = Math.floor(diffDays / 365) + 1;
  // Cap at year 3, then cycle back (or stay at 3 for mastery)
  return Math.min(yearNumber, 3);
}

/**
 * Get the year phase based on year number
 */
export function getYearPhase(yearNumber: number): 'Foundation' | 'Growth' | 'Mastery' {
  switch (yearNumber) {
    case 1:
      return 'Foundation';
    case 2:
      return 'Growth';
    case 3:
    default:
      return 'Mastery';
  }
}

/**
 * Calculate complete day information for the devotional plan
 */
export function calculatePlanDay(startDate: Date, currentDate: Date = new Date()): DayInfo {
  const currentDay = getDayOfYear(currentDate);
  const weekNumber = getWeekNumber(currentDate);
  const year = calculateYearNumber(startDate, currentDate);
  const yearPhase = getYearPhase(year);
  const percentComplete = Math.round((currentDay / 365) * 100);

  return {
    currentDay,
    totalDays: 365,
    year,
    weekNumber,
    percentComplete,
    startDate,
    currentDate,
    yearPhase,
  };
}

/**
 * Format date as YYYY-MM-DD string
 */
export function formatDateString(date: Date = new Date()): string {
  return date.toISOString().split('T')[0];
}

/**
 * Check if two dates are the same day
 */
export function isSameDay(date1: Date, date2: Date): boolean {
  return (
    date1.getFullYear() === date2.getFullYear() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getDate() === date2.getDate()
  );
}

/**
 * Get yesterday's date
 */
export function getYesterday(): Date {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  return yesterday;
}

/**
 * Calculate streak message based on streak count
 */
export function getStreakMessage(streak: number): string {
  if (streak === 0) return "Start your streak today!";
  if (streak === 1) return "Great start! Day 1 complete.";
  if (streak < 7) return `${streak} days and counting!`;
  if (streak < 30) return `${streak} day streak! Keep it up!`;
  if (streak < 100) return `Amazing ${streak} day streak!`;
  return `Incredible ${streak} day streak!`;
}
