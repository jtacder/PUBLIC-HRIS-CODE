import { QueryClient, QueryFunction } from "@tanstack/react-query";

/**
 * API version prefix for all versioned endpoints
 * Use this constant when constructing API URLs to ensure consistency
 */
export const API_VERSION = "/api/v1";

/**
 * Convert a legacy /api/ path to the versioned /api/v1/ path
 * This helper ensures backward compatibility during migration
 */
export function versionedApiPath(path: string): string {
  // If path already starts with /api/v1, return as-is
  if (path.startsWith("/api/v1")) {
    return path;
  }
  // If path starts with /api/, replace with /api/v1/
  if (path.startsWith("/api/")) {
    return path.replace("/api/", "/api/v1/");
  }
  // If path doesn't start with /, add the version prefix
  if (!path.startsWith("/")) {
    return `${API_VERSION}/${path}`;
  }
  // Otherwise, prepend the version prefix
  return `${API_VERSION}${path}`;
}

let csrfToken: string | null = null;

export async function getCsrfToken(): Promise<string> {
  if (csrfToken) return csrfToken;

  // Auth endpoints remain at /api/auth (not versioned for stability)
  const res = await fetch("/api/auth/csrf-token", {
    credentials: "include",
  });

  if (res.ok) {
    const data = await res.json();
    csrfToken = data.token;
    return csrfToken || "";
  }

  return "";
}

// Call this after login/logout to refresh CSRF token
export function clearCsrfToken(): void {
  csrfToken = null;
}

// Force refresh the CSRF token (used after login)
export async function refreshCsrfToken(): Promise<string> {
  csrfToken = null;
  // Add cache-busting parameter to ensure fresh fetch
  const res = await fetch(`/api/auth/csrf-token?_=${Date.now()}`, {
    credentials: "include",
    cache: "no-store",
  });
  
  if (res.ok) {
    const data = await res.json();
    csrfToken = data.token;
    return csrfToken || "";
  }
  
  return "";
}

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

/**
 * Check if a path should use versioned API
 * Auth and health endpoints remain non-versioned for stability
 */
function shouldVersionPath(url: string): boolean {
  // Auth endpoints remain non-versioned
  if (url.includes("/api/auth/")) return false;
  // Health endpoints remain non-versioned
  if (url.includes("/api/health")) return false;
  // Already versioned
  if (url.includes("/api/v1/")) return false;
  // All other /api/ endpoints should be versioned
  return url.startsWith("/api/");
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  // Apply API versioning to eligible endpoints
  const versionedUrl = shouldVersionPath(url) ? versionedApiPath(url) : url;

  const headers: Record<string, string> = {};

  if (data) {
    headers["Content-Type"] = "application/json";
  }

  // Add CSRF token for state-changing requests
  if (["POST", "PUT", "PATCH", "DELETE"].includes(method.toUpperCase())) {
    const token = await getCsrfToken();
    if (token) {
      headers["x-csrf-token"] = token;
    }
  }

  const res = await fetch(versionedUrl, {
    method,
    headers,
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    // Construct URL from query key and apply versioning
    const url = queryKey.join("/") as string;
    const versionedUrl = shouldVersionPath(url) ? versionedApiPath(url) : url;

    const res = await fetch(versionedUrl, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      // Refetch data when user returns to the browser tab/window
      refetchOnWindowFocus: true,
      // Data becomes stale after 2 minutes (increased from 30s to reduce compute usage)
      // For low-traffic apps, this reduces unnecessary API calls while keeping data reasonably fresh
      staleTime: 2 * 60 * 1000,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
