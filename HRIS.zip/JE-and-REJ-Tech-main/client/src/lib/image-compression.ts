/**
 * Image compression utility for optimizing photos before upload.
 * Compresses images to a target size while maintaining quality.
 */

export interface CompressionOptions {
  maxSizeMB?: number;      // Maximum file size in MB (default: 1)
  maxWidthOrHeight?: number; // Maximum dimension (default: 1920)
  quality?: number;         // Initial quality (0-1, default: 0.9)
  minQuality?: number;      // Minimum quality to try (default: 0.5)
}

const DEFAULT_OPTIONS: Required<CompressionOptions> = {
  maxSizeMB: 1,
  maxWidthOrHeight: 1920,
  quality: 0.9,
  minQuality: 0.5,
};

/**
 * Calculate the size of a base64 string in bytes
 */
function getBase64Size(base64: string): number {
  // Remove data URI prefix if present
  const base64Data = base64.split(',')[1] || base64;
  // Each base64 character represents 6 bits, so 4 characters = 3 bytes
  // Padding characters (=) don't count
  const padding = (base64Data.match(/=/g) || []).length;
  return (base64Data.length * 3) / 4 - padding;
}

/**
 * Compress an image file to a target size
 */
export async function compressImage(
  file: File,
  options: CompressionOptions = {}
): Promise<string> {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const maxSizeBytes = opts.maxSizeMB * 1024 * 1024;

  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      const img = new Image();

      img.onload = () => {
        // Calculate new dimensions while maintaining aspect ratio
        let { width, height } = img;

        if (width > opts.maxWidthOrHeight || height > opts.maxWidthOrHeight) {
          if (width > height) {
            height = (height / width) * opts.maxWidthOrHeight;
            width = opts.maxWidthOrHeight;
          } else {
            width = (width / height) * opts.maxWidthOrHeight;
            height = opts.maxWidthOrHeight;
          }
        }

        // Create canvas and draw resized image
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Failed to get canvas context'));
          return;
        }

        // Use high-quality image smoothing
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        // Iteratively reduce quality until size is under limit
        let quality = opts.quality;
        let result = canvas.toDataURL('image/jpeg', quality);

        while (getBase64Size(result) > maxSizeBytes && quality > opts.minQuality) {
          quality -= 0.05;
          result = canvas.toDataURL('image/jpeg', quality);
        }

        resolve(result);
      };

      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = e.target?.result as string;
    };

    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

/**
 * Compress a base64 image string
 */
export async function compressBase64Image(
  base64: string,
  options: CompressionOptions = {}
): Promise<string> {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const maxSizeBytes = opts.maxSizeMB * 1024 * 1024;

  // If already small enough and no resize needed, return as-is
  if (getBase64Size(base64) <= maxSizeBytes) {
    return base64;
  }

  return new Promise((resolve, reject) => {
    const img = new Image();

    img.onload = () => {
      let { width, height } = img;

      // Resize if needed
      if (width > opts.maxWidthOrHeight || height > opts.maxWidthOrHeight) {
        if (width > height) {
          height = (height / width) * opts.maxWidthOrHeight;
          width = opts.maxWidthOrHeight;
        } else {
          width = (width / height) * opts.maxWidthOrHeight;
          height = opts.maxWidthOrHeight;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Failed to get canvas context'));
        return;
      }

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, 0, 0, width, height);

      let quality = opts.quality;
      let result = canvas.toDataURL('image/jpeg', quality);

      while (getBase64Size(result) > maxSizeBytes && quality > opts.minQuality) {
        quality -= 0.05;
        result = canvas.toDataURL('image/jpeg', quality);
      }

      resolve(result);
    };

    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = base64;
  });
}

/**
 * Check if a file is an image
 */
export function isImageFile(file: File): boolean {
  return file.type.startsWith('image/');
}

/**
 * Check if a file is a PDF
 */
export function isPdfFile(file: File): boolean {
  return file.type === 'application/pdf';
}

/**
 * Format file size for display
 */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Validate file type and size
 */
export interface ValidationResult {
  valid: boolean;
  error?: string;
}

export function validateFile(
  file: File,
  options: {
    allowedTypes?: string[];
    maxSizeMB?: number;
  } = {}
): ValidationResult {
  const {
    allowedTypes = ['image/jpeg', 'image/png', 'image/webp'],
    maxSizeMB = 5
  } = options;

  if (!allowedTypes.includes(file.type)) {
    const typeNames = allowedTypes.map(t => t.split('/')[1].toUpperCase()).join(', ');
    return { valid: false, error: `File type not allowed. Please use: ${typeNames}` };
  }

  if (file.size > maxSizeMB * 1024 * 1024) {
    return { valid: false, error: `File size exceeds ${maxSizeMB}MB limit` };
  }

  return { valid: true };
}

/**
 * Convert a File to base64 data URI (for PDFs and other non-image files)
 */
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}
