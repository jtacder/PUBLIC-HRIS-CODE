/**
 * Tests for Client Utility Functions
 *
 * Tests all client-side utility functions including:
 * - Currency formatting
 * - Date/Time formatting
 * - UI helper functions
 */

import { describe, it, expect, vi } from 'vitest';
import {
  formatCurrency,
  formatDate,
  formatTime,
  formatDateTime,
  getInitials,
  getRoleDisplayName,
  getStatusColorClass,
} from './utils';

describe('formatCurrency', () => {
  it('should format number as Philippine Peso', () => {
    const result = formatCurrency(1000);
    expect(result).toContain('1,000');
    expect(result).toContain('₱');
  });

  it('should format string amount as currency', () => {
    const result = formatCurrency('5000.50');
    expect(result).toContain('5,000.50');
  });

  it('should handle zero amount', () => {
    const result = formatCurrency(0);
    expect(result).toContain('0.00');
  });

  it('should format large amounts with comma separators', () => {
    const result = formatCurrency(1000000);
    expect(result).toContain('1,000,000');
  });

  it('should show 2 decimal places', () => {
    const result = formatCurrency(100.5);
    expect(result).toContain('100.50');
  });

  it('should round to 2 decimal places', () => {
    const result = formatCurrency(100.555);
    expect(result).toContain('100.56');
  });

  it('should handle negative amounts', () => {
    const result = formatCurrency(-500);
    expect(result).toContain('500');
    expect(result).toMatch(/-|₱-/);
  });
});

describe('formatDate', () => {
  it('should format date string', () => {
    const result = formatDate('2025-01-15');
    expect(result).toMatch(/Jan|January/);
    expect(result).toContain('15');
    expect(result).toContain('2025');
  });

  it('should format Date object', () => {
    const date = new Date(2025, 0, 15);
    const result = formatDate(date);
    expect(result).toMatch(/Jan|January/);
  });

  it('should return "-" for null', () => {
    const result = formatDate(null);
    expect(result).toBe('-');
  });

  it('should return "-" for undefined', () => {
    const result = formatDate(undefined);
    expect(result).toBe('-');
  });

  it('should return "-" for invalid date string', () => {
    const result = formatDate('invalid-date');
    expect(result).toBe('-');
  });

  it('should format ISO date string correctly', () => {
    const result = formatDate('2025-06-30T10:30:00.000Z');
    expect(result).toMatch(/Jun|June/);
  });
});

describe('formatTime', () => {
  it('should format time in 12-hour format', () => {
    const date = new Date('2025-01-15T14:30:00');
    const result = formatTime(date);
    expect(result).toMatch(/2:30|PM/i);
  });

  it('should return "-" for null', () => {
    const result = formatTime(null);
    expect(result).toBe('-');
  });

  it('should return "-" for undefined', () => {
    const result = formatTime(undefined);
    expect(result).toBe('-');
  });

  it('should format morning time correctly', () => {
    // Use UTC time to get predictable Manila timezone output
    // Midnight UTC = 8:00 AM Manila
    const date = new Date('2025-01-15T00:00:00Z');
    const result = formatTime(date);
    expect(result).toMatch(/8:00|AM/i);
  });

  it('should format midnight correctly', () => {
    const date = new Date('2025-01-15T00:00:00');
    const result = formatTime(date);
    expect(result).toMatch(/12:00|AM/i);
  });

  it('should format noon correctly', () => {
    const date = new Date('2025-01-15T12:00:00');
    const result = formatTime(date);
    expect(result).toMatch(/12:00|PM/i);
  });
});

describe('formatDateTime', () => {
  it('should format date and time together', () => {
    const date = new Date('2025-01-15T14:30:00');
    const result = formatDateTime(date);
    expect(result).toMatch(/Jan|January/);
    expect(result).toContain('15');
    expect(result).toMatch(/2:30|PM/i);
  });

  it('should return "-" for null', () => {
    const result = formatDateTime(null);
    expect(result).toBe('-');
  });

  it('should return "-" for undefined', () => {
    const result = formatDateTime(undefined);
    expect(result).toBe('-');
  });

  it('should return "-" for invalid date', () => {
    const result = formatDateTime('invalid');
    expect(result).toBe('-');
  });
});

describe('getInitials', () => {
  it('should return initials from first and last name', () => {
    const result = getInitials('Juan', 'Dela Cruz');
    expect(result).toBe('JD');
  });

  it('should return uppercase initials', () => {
    const result = getInitials('juan', 'dela cruz');
    expect(result).toBe('JD');
  });

  it('should handle null firstName', () => {
    const result = getInitials(null, 'Dela Cruz');
    expect(result).toBe('D');
  });

  it('should handle null lastName', () => {
    const result = getInitials('Juan', null);
    expect(result).toBe('J');
  });

  it('should handle undefined values', () => {
    const result = getInitials(undefined, undefined);
    expect(result).toBe('?');
  });

  it('should handle empty strings', () => {
    const result = getInitials('', '');
    expect(result).toBe('?');
  });

  it('should handle single character names', () => {
    const result = getInitials('A', 'B');
    expect(result).toBe('AB');
  });
});

describe('getRoleDisplayName', () => {
  it('should return "Administrator" for ADMIN', () => {
    const result = getRoleDisplayName('ADMIN');
    expect(result).toBe('Administrator');
  });

  it('should return "HR Manager" for HR', () => {
    const result = getRoleDisplayName('HR');
    expect(result).toBe('HR Manager');
  });

  it('should return "Site Engineer" for ENGINEER', () => {
    const result = getRoleDisplayName('ENGINEER');
    expect(result).toBe('Site Engineer');
  });

  it('should return "Skilled Worker" for WORKER', () => {
    const result = getRoleDisplayName('WORKER');
    expect(result).toBe('Skilled Worker');
  });

  it('should return original role for unknown roles', () => {
    const result = getRoleDisplayName('UNKNOWN');
    expect(result).toBe('UNKNOWN');
  });
});

describe('getStatusColorClass', () => {
  it('should return green classes for Active status', () => {
    const result = getStatusColorClass('Active');
    expect(result).toContain('green');
  });

  it('should return amber classes for Probationary status', () => {
    const result = getStatusColorClass('Probationary');
    expect(result).toContain('amber');
  });

  it('should return red classes for Suspended status', () => {
    const result = getStatusColorClass('Suspended');
    expect(result).toContain('red');
  });

  it('should return gray classes for Terminated status', () => {
    const result = getStatusColorClass('Terminated');
    expect(result).toContain('gray');
  });

  it('should return gray classes for Draft status', () => {
    const result = getStatusColorClass('Draft');
    expect(result).toContain('gray');
  });

  it('should return blue classes for Approved status', () => {
    const result = getStatusColorClass('Approved');
    expect(result).toContain('blue');
  });

  it('should return green classes for Released status', () => {
    const result = getStatusColorClass('Released');
    expect(result).toContain('green');
  });

  it('should return green classes for Verified status', () => {
    const result = getStatusColorClass('Verified');
    expect(result).toContain('green');
  });

  it('should return amber classes for Pending status', () => {
    const result = getStatusColorClass('Pending');
    expect(result).toContain('amber');
  });

  it('should return red classes for Flagged status', () => {
    const result = getStatusColorClass('Flagged');
    expect(result).toContain('red');
  });

  it('should return purple classes for Off-site status', () => {
    const result = getStatusColorClass('Off-site');
    expect(result).toContain('purple');
  });

  it('should return default gray classes for unknown status', () => {
    const result = getStatusColorClass('Unknown');
    expect(result).toContain('gray');
  });
});
