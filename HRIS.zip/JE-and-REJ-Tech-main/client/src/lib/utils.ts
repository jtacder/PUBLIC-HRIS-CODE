import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Format currency in Philippine Peso
export function formatCurrency(amount: number | string): string {
  const numAmount = typeof amount === "string" ? parseFloat(amount) : amount;
  return new Intl.NumberFormat("en-PH", {
    style: "currency",
    currency: "PHP",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(numAmount);
}

// Format date - always display in Philippine timezone (Asia/Manila)
// Server sends timestamps with +08:00 offset, so parsing is straightforward
export function formatDate(date: Date | string | null | undefined): string {
  if (!date) return "-";
  const d = typeof date === "string" ? new Date(date) : date;
  if (isNaN(d.getTime())) return "-";
  return new Intl.DateTimeFormat("en-PH", {
    year: "numeric",
    month: "short",
    day: "numeric",
    timeZone: "Asia/Manila",
  }).format(d);
}

// Format time - always display in Philippine timezone (Asia/Manila)
export function formatTime(date: Date | string | null | undefined): string {
  if (!date) return "-";
  const d = typeof date === "string" ? new Date(date) : date;
  if (isNaN(d.getTime())) return "-";
  return new Intl.DateTimeFormat("en-PH", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "Asia/Manila",
  }).format(d);
}

// Format datetime - always display in Philippine timezone (Asia/Manila)
export function formatDateTime(date: Date | string | null | undefined): string {
  if (!date) return "-";
  const d = typeof date === "string" ? new Date(date) : date;
  if (isNaN(d.getTime())) return "-";
  return new Intl.DateTimeFormat("en-PH", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "Asia/Manila",
  }).format(d);
}

// Get initials from name
export function getInitials(firstName?: string | null, lastName?: string | null): string {
  const first = firstName?.charAt(0)?.toUpperCase() || "";
  const last = lastName?.charAt(0)?.toUpperCase() || "";
  return first + last || "?";
}

// Get role display name
export function getRoleDisplayName(role: string): string {
  const roleMap: Record<string, string> = {
    ADMIN: "Administrator",
    HR: "HR Manager",
    ENGINEER: "Site Engineer",
    WORKER: "Skilled Worker",
  };
  return roleMap[role] || role;
}

// Get status color classes
export function getStatusColorClass(status: string): string {
  const statusColors: Record<string, string> = {
    Active: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
    Probationary: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
    Suspended: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
    Terminated: "bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-400",
    Draft: "bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-400",
    Approved: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
    Released: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
    Verified: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
    Pending: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
    Flagged: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
    "Off-site": "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
  };
  return statusColors[status] || "bg-gray-100 text-gray-700";
}
