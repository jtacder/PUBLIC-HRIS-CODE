/**
 * My Tasks Page Tour Steps
 *
 * Tour for employee task viewing and management.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const myTasksSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to My Tasks! Here you can view all tasks assigned to you, update their status, and track your work progress.`,
    title: 'My Tasks',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `Your tasks page includes:

🔍 Status Filter - Filter by task status
⚡ Priority Filter - Filter by urgency
📋 Task List - All your assigned tasks
📊 Statistics - Your productivity metrics`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Task Status
  {
    target: 'body',
    content: `Task Status:

⚪ To Do - Not yet started
🔵 In Progress - Currently working on
🟡 Blocked - Stuck on something
🟢 Done - Completed

Update your status as work progresses.`,
    title: 'Task Status',
    placement: 'center',
    disableBeacon: true,
  },

  // Priority
  {
    target: 'body',
    content: `Task Priority:

🟥 Urgent - Do immediately
🟧 High - Important, prioritize
🟦 Medium - Standard priority
⬜ Low - When time permits

Work on higher priority tasks first.`,
    title: 'Priority Levels',
    placement: 'center',
    disableBeacon: true,
  },

  // Task Card
  {
    target: 'body',
    content: `Each Task Shows:

📋 Title - What needs to be done
📌 Status - Current progress
⚡ Priority - How urgent
📅 Due Date - When it's due
📁 Project - Related project (if any)

Click any task to view full details.`,
    title: 'Task Information',
    placement: 'center',
    disableBeacon: true,
  },

  // Due Dates
  {
    target: 'body',
    content: `Due Date Indicators:

📅 Normal - On track
🟡 Yellow/Orange - Due soon
🔴 Red - Overdue

Prioritize tasks that are due soon or overdue!`,
    title: 'Due Dates',
    placement: 'center',
    disableBeacon: true,
  },

  // Updating Tasks
  {
    target: 'body',
    content: `Updating Your Tasks:

1️⃣ To Do → In Progress (when you start)
2️⃣ In Progress → Done (when complete)
3️⃣ Any → Blocked (if stuck)

Keep status updated for accurate tracking.`,
    title: 'Updating Status',
    placement: 'center',
    disableBeacon: true,
  },

  // Comments
  {
    target: 'body',
    content: `Task Comments:

Use comments to:
💬 Provide progress updates
❓ Ask questions
📝 Request clarification
⚠️ Report issues

Comments are visible to your supervisor.`,
    title: 'Adding Comments',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the My Tasks tour!

Best Practices:
✅ Review tasks daily
✅ Update status regularly
✅ Prioritize by due date and priority
✅ Ask questions via comments
✅ Mark complete when done

Stay organized and productive!

Use the help icon (?) to restart this tour.`,
    title: 'Tasks Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default myTasksSteps;
