/**
 * Projects Page Tour Steps
 *
 * Comprehensive tour for project management.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const projectsSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to Project Management! This page lets you create, track, and manage all company projects. Monitor progress, assign team members, and track timelines.`,
    title: 'Project Management',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `The projects page includes:

➕ Add Project Button - Create new projects
🔍 Search Box - Find projects quickly
📊 Status Filter - Filter by project status
📋 Project List - All projects in card/table view`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Project Status
  {
    target: 'body',
    content: `Project Status Types:

🔵 Planning - Setting up, not started
🟢 Active - Work in progress
🟡 On Hold - Temporarily paused
✅ Completed - Finished
⛔ Cancelled - Stopped

Filter by status to focus on active work.`,
    title: 'Project Status',
    placement: 'center',
    disableBeacon: true,
  },

  // Project Card
  {
    target: 'body',
    content: `Each Project Card Shows:

📋 Project Name - Click to view details
📌 Status Badge - Current status
📅 Timeline - Start and end dates
👥 Team Members - Assigned employees
📊 Progress - % complete from tasks`,
    title: 'Project Information',
    placement: 'center',
    disableBeacon: true,
  },

  // Creating Projects
  {
    target: 'body',
    content: `Creating a New Project:

1️⃣ Project Name - Clear, descriptive title
2️⃣ Description - Scope, objectives, notes
3️⃣ Location - Physical site (optional)
4️⃣ Timeline - Start and target end dates
5️⃣ Team - Assign employees
6️⃣ Status - Initial status`,
    title: 'Creating Projects',
    placement: 'center',
    disableBeacon: true,
  },

  // Team Assignment
  {
    target: 'body',
    content: `Assigning Team Members:

• Search employees by name
• Select multiple team members
• Team can view project in their dashboard
• Remove with X button

Consider skills and workload when assigning.`,
    title: 'Team Assignment',
    placement: 'center',
    disableBeacon: true,
  },

  // Project Location
  {
    target: 'body',
    content: `Project Location:

Set the physical project site by:
• Typing address
• Selecting on map
• Using coordinates

Location enables:
• Geo-fenced attendance
• Site-based reporting
• Location tracking`,
    title: 'Project Location',
    placement: 'center',
    disableBeacon: true,
  },

  // Project Tasks
  {
    target: 'body',
    content: `Project Tasks:

Click "View Tasks" to see all tasks for a project:
• Tasks break down the project work
• Track task completion for progress
• Progress bar = completed/total tasks

Create tasks from the project detail page.`,
    title: 'Project Tasks',
    placement: 'center',
    disableBeacon: true,
  },

  // Managing Projects
  {
    target: 'body',
    content: `Managing Projects:

✏️ Edit - Update project details
📋 View Tasks - See all project tasks
🔄 Update Status - Change project status
🗑️ Delete - Remove project (use cancel instead)

All changes are logged in audit trail.`,
    title: 'Project Management',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the Project Management tour!

Project Workflow:
1. Create project with details
2. Assign team members
3. Create tasks under the project
4. Track progress through tasks
5. Update status as work progresses
6. Mark complete when done

Use projects to organize all your work!

Use the help icon (?) to restart this tour.`,
    title: 'Projects Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default projectsSteps;
