/**
 * Tour Steps Index
 *
 * Central export for all tour step definitions.
 */

// Admin/HR Page Tours
export { dashboardAdminSteps } from './dashboard-admin';
export { employeesSteps } from './employees';
export { attendanceSteps } from './attendance';
export { payrollSteps } from './payroll';
export { files201Steps } from './201-files';
export { disciplinarySteps } from './disciplinary';
export { hrRequestsSteps } from './hr-requests';
export { hrSettingsSteps } from './hr-settings';
export { expensesSteps } from './expenses';
export { auditLogsSteps } from './audit-logs';
export { projectsSteps } from './projects';
export { tasksSteps } from './tasks';
export { devotionalsSteps } from './devotionals';

// Employee Self-Service Tours
export { dashboardEmployeeSteps } from './dashboard-employee';
export { myTasksSteps } from './my-tasks';
export { myPayslipsSteps } from './my-payslips';
export { myRequestsSteps } from './my-requests';
export { myProfileSteps } from './my-profile';
export { myExpensesSteps } from './my-expenses';
export { myDisciplinarySteps } from './my-disciplinary';

// Navigation Tour
export { sidebarNavigationSteps } from './sidebar-navigation';

// All tours for easy access
import { dashboardAdminSteps } from './dashboard-admin';
import { employeesSteps } from './employees';
import { attendanceSteps } from './attendance';
import { payrollSteps } from './payroll';
import { files201Steps } from './201-files';
import { disciplinarySteps } from './disciplinary';
import { hrRequestsSteps } from './hr-requests';
import { hrSettingsSteps } from './hr-settings';
import { expensesSteps } from './expenses';
import { auditLogsSteps } from './audit-logs';
import { projectsSteps } from './projects';
import { tasksSteps } from './tasks';
import { devotionalsSteps } from './devotionals';
import { dashboardEmployeeSteps } from './dashboard-employee';
import { myTasksSteps } from './my-tasks';
import { myPayslipsSteps } from './my-payslips';
import { myRequestsSteps } from './my-requests';
import { myProfileSteps } from './my-profile';
import { myExpensesSteps } from './my-expenses';
import { myDisciplinarySteps } from './my-disciplinary';
import { sidebarNavigationSteps } from './sidebar-navigation';
import type { Step } from 'react-joyride';
import { TOUR_IDS, TourId } from '../tour-storage';

/**
 * Get tour steps by tour ID
 */
export function getTourStepsById(tourId: TourId): Step[] {
  const tourMap: Record<TourId, Step[]> = {
    [TOUR_IDS.DASHBOARD_ADMIN]: dashboardAdminSteps,
    [TOUR_IDS.EMPLOYEES]: employeesSteps,
    [TOUR_IDS.ATTENDANCE]: attendanceSteps,
    [TOUR_IDS.PAYROLL]: payrollSteps,
    [TOUR_IDS.FILES_201]: files201Steps,
    [TOUR_IDS.DISCIPLINARY]: disciplinarySteps,
    [TOUR_IDS.HR_REQUESTS]: hrRequestsSteps,
    [TOUR_IDS.HR_SETTINGS]: hrSettingsSteps,
    [TOUR_IDS.EXPENSES]: expensesSteps,
    [TOUR_IDS.AUDIT_LOGS]: auditLogsSteps,
    [TOUR_IDS.PROJECTS]: projectsSteps,
    [TOUR_IDS.TASKS]: tasksSteps,
    [TOUR_IDS.DEVOTIONALS]: devotionalsSteps,
    [TOUR_IDS.DASHBOARD_EMPLOYEE]: dashboardEmployeeSteps,
    [TOUR_IDS.MY_TASKS]: myTasksSteps,
    [TOUR_IDS.MY_PAYSLIPS]: myPayslipsSteps,
    [TOUR_IDS.MY_REQUESTS]: myRequestsSteps,
    [TOUR_IDS.MY_PROFILE]: myProfileSteps,
    [TOUR_IDS.MY_EXPENSES]: myExpensesSteps,
    [TOUR_IDS.MY_DISCIPLINARY]: myDisciplinarySteps,
    [TOUR_IDS.SIDEBAR]: sidebarNavigationSteps,
    [TOUR_IDS.WELCOME]: dashboardAdminSteps, // Welcome uses dashboard tour
  };

  return tourMap[tourId] || [];
}

/**
 * Get tour metadata
 */
export interface TourMetadata {
  id: TourId;
  name: string;
  description: string;
  stepCount: number;
  category: 'admin' | 'hr' | 'employee' | 'navigation';
}

export const tourMetadata: TourMetadata[] = [
  // Admin/HR Tours
  {
    id: TOUR_IDS.DASHBOARD_ADMIN,
    name: 'Admin Dashboard',
    description: 'Overview of the admin/HR dashboard with all metrics and shortcuts',
    stepCount: dashboardAdminSteps.length,
    category: 'admin',
  },
  {
    id: TOUR_IDS.EMPLOYEES,
    name: 'Employee Management',
    description: 'Complete guide to managing employee records and accounts',
    stepCount: employeesSteps.length,
    category: 'hr',
  },
  {
    id: TOUR_IDS.ATTENDANCE,
    name: 'Attendance Management',
    description: 'Clock in/out, QR scanning, and attendance tracking',
    stepCount: attendanceSteps.length,
    category: 'hr',
  },
  {
    id: TOUR_IDS.PAYROLL,
    name: 'Payroll Management',
    description: 'Payroll generation, deductions, and salary release',
    stepCount: payrollSteps.length,
    category: 'hr',
  },
  {
    id: TOUR_IDS.FILES_201,
    name: '201 Files',
    description: 'Complete employee records and documentation',
    stepCount: files201Steps.length,
    category: 'hr',
  },
  {
    id: TOUR_IDS.DISCIPLINARY,
    name: 'Disciplinary Management',
    description: 'NTE issuance and disciplinary case management',
    stepCount: disciplinarySteps.length,
    category: 'hr',
  },
  {
    id: TOUR_IDS.HR_REQUESTS,
    name: 'Leave & Cash Advance',
    description: 'Processing leave requests and cash advances',
    stepCount: hrRequestsSteps.length,
    category: 'hr',
  },
  {
    id: TOUR_IDS.HR_SETTINGS,
    name: 'HR Settings',
    description: 'Configuring payroll cutoffs, leave types, and holidays',
    stepCount: hrSettingsSteps.length,
    category: 'hr',
  },
  {
    id: TOUR_IDS.EXPENSES,
    name: 'Expense Management',
    description: 'Processing expense reports and reimbursements',
    stepCount: expensesSteps.length,
    category: 'admin',
  },
  {
    id: TOUR_IDS.AUDIT_LOGS,
    name: 'Audit Logs',
    description: 'System activity tracking and compliance',
    stepCount: auditLogsSteps.length,
    category: 'admin',
  },
  {
    id: TOUR_IDS.PROJECTS,
    name: 'Project Management',
    description: 'Creating and managing projects',
    stepCount: projectsSteps.length,
    category: 'admin',
  },
  {
    id: TOUR_IDS.TASKS,
    name: 'Task Management',
    description: 'Task creation, assignment, and tracking',
    stepCount: tasksSteps.length,
    category: 'admin',
  },
  {
    id: TOUR_IDS.DEVOTIONALS,
    name: 'Devotional Management',
    description: 'Managing daily devotional content',
    stepCount: devotionalsSteps.length,
    category: 'admin',
  },

  // Employee Tours
  {
    id: TOUR_IDS.DASHBOARD_EMPLOYEE,
    name: 'My Dashboard',
    description: 'Your personal dashboard overview',
    stepCount: dashboardEmployeeSteps.length,
    category: 'employee',
  },
  {
    id: TOUR_IDS.MY_TASKS,
    name: 'My Tasks',
    description: 'Viewing and managing your assigned tasks',
    stepCount: myTasksSteps.length,
    category: 'employee',
  },
  {
    id: TOUR_IDS.MY_PAYSLIPS,
    name: 'My Payslips',
    description: 'Viewing your salary and payslip history',
    stepCount: myPayslipsSteps.length,
    category: 'employee',
  },
  {
    id: TOUR_IDS.MY_REQUESTS,
    name: 'My Requests',
    description: 'Submitting leave and cash advance requests',
    stepCount: myRequestsSteps.length,
    category: 'employee',
  },
  {
    id: TOUR_IDS.MY_PROFILE,
    name: 'My Profile',
    description: 'Viewing your personal and employment information',
    stepCount: myProfileSteps.length,
    category: 'employee',
  },
  {
    id: TOUR_IDS.MY_EXPENSES,
    name: 'My Expenses',
    description: 'Submitting expense reports for reimbursement',
    stepCount: myExpensesSteps.length,
    category: 'employee',
  },
  {
    id: TOUR_IDS.MY_DISCIPLINARY,
    name: 'My Disciplinary Records',
    description: 'Viewing and responding to disciplinary matters',
    stepCount: myDisciplinarySteps.length,
    category: 'employee',
  },

  // Navigation
  {
    id: TOUR_IDS.SIDEBAR,
    name: 'Sidebar Navigation',
    description: 'Overview of all menu options',
    stepCount: sidebarNavigationSteps.length,
    category: 'navigation',
  },
];

/**
 * Get tours for a specific category
 */
export function getToursByCategory(category: TourMetadata['category']): TourMetadata[] {
  return tourMetadata.filter(tour => tour.category === category);
}

/**
 * Get total step count across all tours
 */
export function getTotalStepCount(): number {
  return tourMetadata.reduce((total, tour) => total + tour.stepCount, 0);
}
