/**
 * Attendance Page Tour Steps
 *
 * Comprehensive tour for the attendance management page.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const attendanceSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to Attendance Management! This is where you track all employee clock-ins and clock-outs. You can also manually record attendance and view historical records.`,
    title: 'Attendance Management',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `The attendance page includes:

📅 Date Range Picker - Select dates to view
📊 Status Filter Tabs - Filter by status
📱 QR Scanner Button - Quick clock-in/out
✋ Manual Entry Button - For special cases
📋 Attendance Table - All records`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // QR Scanner
  {
    target: 'body',
    content: `QR Scanner for Attendance:

When an employee scans their QR code:
1. Camera detects and reads the code
2. System identifies the employee
3. Clock-in/out is recorded automatically
4. Optional: Photo captured for verification
5. Optional: GPS location logged

Make sure QR codes are well-lit and in focus.`,
    title: 'QR Scanner',
    placement: 'center',
    disableBeacon: true,
  },

  // Face Verification
  {
    target: 'body',
    content: `Face Verification (Optional Security):

When enabled:
• Employee shows QR code
• System captures their face
• Verifies against stored photo
• Records attendance if match

This prevents "buddy punching" (one employee clocking in for another).`,
    title: 'Face Verification',
    placement: 'center',
    disableBeacon: true,
  },

  // Manual Entry
  {
    target: 'body',
    content: `Manual Entry for Special Cases:

Use when:
• Forgotten QR code
• System downtime
• Off-site work
• Corrections needed

Requirements:
• Select employee from dropdown
• Choose Clock In or Clock Out
• Enter date and time
• Provide mandatory remarks

⚠️ All manual entries are flagged in the audit log.`,
    title: 'Manual Entry',
    placement: 'center',
    disableBeacon: true,
  },

  // Table Columns
  {
    target: 'body',
    content: `Attendance Table Columns:

👤 Employee - Name and ID
📅 Date - Record date
⏰ Clock In - Time arrived
⏰ Clock Out - Time left
⏱️ Hours Worked - Total (auto-calculated)
⚠️ Late Minutes - From scheduled start
📈 OT Hours - Overtime worked
📉 Undertime - Left early`,
    title: 'Attendance Columns',
    placement: 'center',
    disableBeacon: true,
  },

  // Status Indicators
  {
    target: 'body',
    content: `Attendance Status Indicators:

🟢 On Time - Clocked in within grace period
🟡 Late - Clocked in after grace period
🔴 Absent - No clock-in recorded
🟠 Incomplete - Missing clock-out
🔵 Half Day - Worked less than 4 hours

Click any row for full details including:
• Photo evidence (if captured)
• GPS location
• Remarks and notes`,
    title: 'Status Indicators',
    placement: 'center',
    disableBeacon: true,
  },

  // OT and Undertime
  {
    target: 'body',
    content: `Overtime & Undertime:

⏰ Overtime (OT) Rates:
• Regular OT: 125% of hourly rate
• Night OT (10PM-6AM): 137.5%
• Holiday OT: Higher rates apply

📉 Undertime:
• Deducted from salary
• May require approval
• Emergency/medical may be excused

OT must be pre-approved per company policy.`,
    title: 'OT & Undertime',
    placement: 'center',
    disableBeacon: true,
  },

  // Location and Photo
  {
    target: 'body',
    content: `Location & Photo Evidence:

📍 Location Data:
• GPS coordinates recorded
• Distance from office calculated
• Geo-fence violations flagged

📸 Photo Evidence:
• Captured at clock-in/out
• Face verification scores shown
• Can be reviewed for disputes

⚠️ Flag appears if location is outside allowed radius.`,
    title: 'Location & Photo',
    placement: 'center',
    disableBeacon: true,
  },

  // Editing and Export
  {
    target: 'body',
    content: `Editing & Exporting:

✏️ Edit Records:
• Adjust times for corrections
• Add or modify remarks
• Mark as excused (with approval)
All edits are logged with your user ID.

📤 Export Data:
• CSV format for Excel
• Filtered by current view
• Use for payroll verification`,
    title: 'Edit & Export',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `Great job! You've completed the Attendance Management tour.

Daily Checklist:
✅ Check attendance regularly for issues
✅ Follow up on incomplete records
✅ Review late employees
✅ Verify OT hours before payroll
✅ Use manual entry sparingly with documentation

Use the help icon (?) anytime to restart this tour!`,
    title: 'Attendance Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default attendanceSteps;
