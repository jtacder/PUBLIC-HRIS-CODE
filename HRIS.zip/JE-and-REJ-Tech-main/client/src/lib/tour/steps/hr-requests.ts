/**
 * HR Requests Page Tour Steps
 *
 * Comprehensive tour for leave requests and cash advance management.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const hrRequestsSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to Leave & Cash Advance Management! This is where you process employee requests for leave and cash advances.

Pending items requiring your action are highlighted.`,
    title: 'Leave & Cash Advance Management',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `This page has two main sections:

📅 Leave Requests Tab
Employee leave applications (vacation, sick, etc.)

💰 Cash Advances Tab
Employee cash advance requests

Toggle "Show Pending Only" to focus on items needing action.`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Leave Types
  {
    target: 'body',
    content: `Leave Types Available:

🏖️ Annual Leave - Vacation days
🏥 Sick Leave - Medical reasons
🚨 Emergency Leave - Urgent matters
👶 Maternity/Paternity Leave
📚 Service Incentive Leave
🔧 Others - As configured

Each type may have different policies.`,
    title: 'Leave Types',
    placement: 'center',
    disableBeacon: true,
  },

  // Leave Request Details
  {
    target: 'body',
    content: `Leave Request Information:

📅 Dates - Start and end date
📊 Days Requested - Auto-calculated working days
📝 Reason - Employee's stated purpose
📉 Leave Balance - Available/Remaining

⚠️ Warning appears if insufficient balance.`,
    title: 'Leave Request Details',
    placement: 'center',
    disableBeacon: true,
  },

  // Leave Actions
  {
    target: 'body',
    content: `Leave Request Actions:

✅ Approve:
• Deducts from employee's balance
• Marks dates as on leave
• Notifies employee
• Updates payroll

❌ Reject:
• Provide rejection reason
• Employee is notified
• Balance unchanged`,
    title: 'Processing Leave',
    placement: 'center',
    disableBeacon: true,
  },

  // Leave Status
  {
    target: 'body',
    content: `Leave Request Status:

⚪ Pending - Awaiting your decision
🟢 Approved - Leave granted
🔴 Rejected - Leave denied
🟡 Cancelled - Withdrawn by employee

Process pending requests promptly to help employees plan.`,
    title: 'Leave Status',
    placement: 'center',
    disableBeacon: true,
  },

  // Cash Advance Overview
  {
    target: 'body',
    content: `Cash Advances:

Employees can request cash advances that are repaid through payroll deductions.

Request shows:
• Amount requested (₱)
• Purpose/reason
• Current status
• Repayment progress

Review against company policy limits.`,
    title: 'Cash Advances',
    placement: 'center',
    disableBeacon: true,
  },

  // CA Status Flow
  {
    target: 'body',
    content: `Cash Advance Workflow:

⚪ Pending - Awaiting approval
🟡 Approved - Ready to disburse
🟢 Disbursed - Cash given to employee
🔵 Partially Paid - Being repaid via payroll
✅ Fully Paid - Completely repaid

Status progresses through each stage.`,
    title: 'CA Status Flow',
    placement: 'center',
    disableBeacon: true,
  },

  // CA Actions
  {
    target: 'body',
    content: `Processing Cash Advances:

1️⃣ Review & Approve request
2️⃣ Disburse funds to employee
3️⃣ Setup Deduction Schedule:
   • Amount per cutoff
   • Number of installments
   • Start date

Deductions appear automatically in payroll.`,
    title: 'CA Processing',
    placement: 'center',
    disableBeacon: true,
  },

  // Repayment Tracking
  {
    target: 'body',
    content: `Repayment Tracking:

View repayment history:
• Each deduction made
• Remaining balance
• Expected completion date

Monitor to ensure proper repayment. Outstanding balances carry forward until fully paid.`,
    title: 'Repayment Tracking',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the Leave & Cash Advance Management tour!

Key reminders:
✅ Process pending requests promptly
✅ Check leave balances before approving
✅ Document rejection reasons
✅ Set up proper repayment schedules for CA
✅ Monitor CA repayment progress

Use the help icon (?) to restart this tour!`,
    title: 'HR Requests Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default hrRequestsSteps;
