/**
 * Disciplinary Page Tour Steps
 *
 * Comprehensive tour for NTE (Notice to Explain) management.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const disciplinarySteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to Disciplinary Management! This page handles Notice to Explain (NTE) documents - a formal process for addressing employee incidents and violations.

Proper documentation protects both the company and employees.`,
    title: 'Disciplinary Management',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `The disciplinary page includes:

📋 Issue NTE Button - Create new NTE
🔍 Status Filter - Filter by status
📊 NTE Table - All disciplinary records
👁️ View/Resolve - Manage each case`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // NTE Status
  {
    target: 'body',
    content: `NTE Status Types:

🔴 Pending Response - Awaiting employee explanation
🟡 Responded - Employee has submitted explanation
🟢 Resolved - Case has been closed
⚠️ Escalated - Requires further action

Filter to focus on specific status types.`,
    title: 'Understanding Status',
    placement: 'center',
    disableBeacon: true,
  },

  // Issuing NTE
  {
    target: 'body',
    content: `Issuing a New NTE:

When creating an NTE, you'll provide:
1. Employee - Who is being issued the NTE
2. Incident Details - What happened, when, where
3. Policy Violated - Which rule/policy was broken
4. Incident Date - When it occurred
5. Response Deadline - Usually 48-72 hours`,
    title: 'Creating an NTE',
    placement: 'center',
    disableBeacon: true,
  },

  // Evidence
  {
    target: 'body',
    content: `Attach Supporting Evidence:

📷 Photos - CCTV, screenshots
📄 Documents - Reports, records
📝 Witness Statements
🔗 Other relevant files

Proper documentation strengthens the case.
Be factual and objective in all descriptions.`,
    title: 'Attaching Evidence',
    placement: 'center',
    disableBeacon: true,
  },

  // Employee Response
  {
    target: 'body',
    content: `Employee Response:

After NTE issuance:
• Employee receives notification
• They have until deadline to respond
• Response submitted through their portal
• You review their explanation

If no response by deadline:
• Send reminder or escalate
• Document the non-response`,
    title: 'Employee Response',
    placement: 'center',
    disableBeacon: true,
  },

  // Resolution
  {
    target: 'body',
    content: `Resolving an NTE:

After reviewing the employee's explanation, decide:
• No Action - Explanation accepted
• Verbal Warning - Documented counseling
• Written Warning - Formal warning letter
• Suspension - Temporary suspension
• Other Action - As per policy

Document your decision and rationale clearly.`,
    title: 'Resolution Options',
    placement: 'center',
    disableBeacon: true,
  },

  // Escalation
  {
    target: 'body',
    content: `When to Escalate:

• Repeated offenses by same employee
• Severe violations requiring management
• No response from employee
• Need higher authority decision

Escalated cases are tracked separately with special attention.`,
    title: 'Escalation',
    placement: 'center',
    disableBeacon: true,
  },

  // History
  {
    target: 'body',
    content: `Case History:

Each NTE maintains a complete audit trail:
• When NTE was issued
• When employee responded
• All actions taken
• Resolution details
• Who made decisions and when

This is crucial for legal compliance.`,
    title: 'Case History',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the Disciplinary Management tour!

NTE Process Flow:
1. Issue NTE with incident details
2. Wait for employee response (48-72 hrs)
3. Review explanation
4. Make resolution decision
5. Document outcome
6. Follow up if needed

⚠️ Important: Always be fair, objective, and follow due process!

Use the help icon (?) to restart this tour.`,
    title: 'Disciplinary Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default disciplinarySteps;
