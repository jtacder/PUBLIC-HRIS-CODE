/**
 * Employee Dashboard Guide Steps
 *
 * Comprehensive guide for the employee self-service dashboard.
 * Uses body target for presentation-style guide.
 */

import type { Step } from 'react-joyride';

export const dashboardEmployeeSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to your personal dashboard! This is your central hub for viewing your work information, attendance, tasks, and more. Let's explore everything available to you.`,
    title: 'Your Dashboard',
    placement: 'center',
    disableBeacon: true,
  },

  // Cutoff and Attendance
  {
    target: 'body',
    content: `Your Dashboard Shows:

Current Cutoff Period - The pay period for your next paycheck

Attendance Summary:
• Days Present - Days you clocked in
• Days Absent - Days missed
• Late Instances - Times you were late
• Total Late Minutes accumulated`,
    title: 'Cutoff & Attendance',
    placement: 'center',
    disableBeacon: true,
  },

  // Salary and OT
  {
    target: 'body',
    content: `Salary Information:

OT Hours - Overtime worked this period (paid at premium rate)

Expected Salary - Estimated pay:
• Days worked × Daily rate
• Plus overtime pay
• Before deductions

Final amount may vary after processing.`,
    title: 'Salary & Overtime',
    placement: 'center',
    disableBeacon: true,
  },

  // Pending Items
  {
    target: 'body',
    content: `Pending Items:

Pending Tasks - Tasks assigned to you needing attention

Pending NTEs - Notice to Explain requiring your response (address promptly!)

Check these regularly and take action.`,
    title: 'Pending Items',
    placement: 'center',
    disableBeacon: true,
  },

  // Leave Balance
  {
    target: 'body',
    content: `Leave Balance:

Each leave type shows:
• Allocated - Days available to you
• Used - Days already taken
• Remaining - Days you can still use

Common types:
• Vacation Leave
• Sick Leave
• Emergency Leave

Plan your leaves within your balance.`,
    title: 'Leave Balance',
    placement: 'center',
    disableBeacon: true,
  },

  // Today's Attendance
  {
    target: 'body',
    content: `Today's Attendance:

Shows your status for today:
• Clock-in time (if clocked in)
• Clock-out time (if clocked out)
• Status (On Time, Late, etc.)

If you haven't clocked in, you'll see a reminder.

Use the Clock In/Out button for quick access.`,
    title: "Today's Attendance",
    placement: 'center',
    disableBeacon: true,
  },

  // Quick Actions
  {
    target: 'body',
    content: `Quick Action Buttons:

• View Payslips - Check your salary history
• Submit Leave Request - Request time off
• View Tasks - See assigned work
• View Profile - Check your information

These shortcuts help you navigate quickly.`,
    title: 'Quick Actions',
    placement: 'center',
    disableBeacon: true,
  },

  // Devotional
  {
    target: 'body',
    content: `Daily Devotional:

Today's devotional or verse of the day
Click to expand and read the full reflection
A moment of inspiration for your day!`,
    title: 'Daily Devotional',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the Dashboard guide!

From your dashboard you can:
• Check your attendance
• View leave balances
• See pending tasks
• Access payslips
• Clock in/out
• Read daily devotionals

Explore the sidebar menu for more features!

Use the help icon (?) to restart this guide.`,
    title: 'Dashboard Guide Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default dashboardEmployeeSteps;
