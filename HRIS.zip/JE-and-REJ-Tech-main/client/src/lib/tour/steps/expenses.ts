/**
 * Expenses Page Tour Steps
 *
 * Comprehensive tour for expense management and reimbursement.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const expensesSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to Expense Management! This page handles all company expense reports from employees. You can review, approve, reject, and track reimbursements.`,
    title: 'Expense Management',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `The expenses page includes:

🔍 Status Filter - Filter by approval status
📂 Category Filter - Filter by expense type
📅 Date Range - Filter by date
📋 Expense Table - All expense reports
📊 Summary - Totals and statistics`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Expense Categories
  {
    target: 'body',
    content: `Expense Categories:

🛠️ Materials - Project supplies, equipment
✈️ Travel - Transportation, lodging
⚡ Utilities - Office utilities
🍽️ Meals - Client meals, team meals
📦 Others - Miscellaneous expenses

Categories help with accounting classification.`,
    title: 'Expense Categories',
    placement: 'center',
    disableBeacon: true,
  },

  // Expense Details
  {
    target: 'body',
    content: `Expense Report Details:

Each expense report shows:
• Submitted By - Employee name
• Category - Type of expense
• Amount - In Philippine Peso (₱)
• Date Incurred - When spent
• Description - Purpose and details
• Receipt - Attached proof`,
    title: 'Expense Details',
    placement: 'center',
    disableBeacon: true,
  },

  // Receipt Verification
  {
    target: 'body',
    content: `Receipt Verification:

When reviewing receipts, verify:
✅ Amount matches the claim
✅ Date is correct
✅ Items match description
✅ Official receipt or acknowledgment
✅ Within allowable period

Click the receipt column to view attached images.`,
    title: 'Verifying Receipts',
    placement: 'center',
    disableBeacon: true,
  },

  // Expense Status
  {
    target: 'body',
    content: `Expense Status:

⚪ Pending - Awaiting your decision
🟢 Approved - Ready for reimbursement
🔴 Rejected - Denied with reason
✅ Reimbursed - Payment completed

Process pending expenses promptly.`,
    title: 'Expense Status',
    placement: 'center',
    disableBeacon: true,
  },

  // Approval Process
  {
    target: 'body',
    content: `Processing Expenses:

✅ Approve:
• Verify receipt and details
• Expense is marked for payment
• Finance can process reimbursement
• Employee is notified

❌ Reject:
• Provide rejection reason
• Common reasons: missing receipt, non-business expense, exceeds limits`,
    title: 'Approval Process',
    placement: 'center',
    disableBeacon: true,
  },

  // Reimbursement
  {
    target: 'body',
    content: `Marking as Reimbursed:

After finance disburses payment:
1. Click "Mark Reimbursed"
2. Enter payment reference number
3. Expense is finalized

Only mark as reimbursed after actual payment is made.`,
    title: 'Reimbursement',
    placement: 'center',
    disableBeacon: true,
  },

  // Summary and Export
  {
    target: 'body',
    content: `Summary & Export:

📊 Summary shows:
• Total pending amount
• Total approved amount
• Total reimbursed this period
• Breakdown by category

📤 Export data:
• CSV format for Excel
• PDF report for records
• Useful for monthly reconciliation`,
    title: 'Summary & Export',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the Expense Management tour!

Expense Process:
1. Employee submits expense + receipt
2. HR/Admin reviews and approves/rejects
3. Finance processes reimbursement
4. Expense marked as reimbursed

Tips:
✅ Always verify receipts
✅ Check expense dates
✅ Document rejection reasons
✅ Export reports monthly

Use the help icon (?) to restart this tour.`,
    title: 'Expenses Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default expensesSteps;
