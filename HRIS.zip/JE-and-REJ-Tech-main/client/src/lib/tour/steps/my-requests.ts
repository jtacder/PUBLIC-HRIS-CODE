/**
 * My Requests Page Tour Steps
 *
 * Tour for employee leave and cash advance request submission.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const myRequestsSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to My Requests! Here you can submit leave requests and cash advance applications, and track their status.`,
    title: 'My Requests',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `This page has two sections:

📅 Leave Requests Tab
Submit and track time-off requests

💰 Cash Advances Tab
Apply for and track salary advances`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Leave Types
  {
    target: 'body',
    content: `Available Leave Types:

🏖️ Vacation Leave - Personal time off
🏥 Sick Leave - Illness/medical
🚨 Emergency Leave - Urgent matters
👶 Maternity/Paternity - Child-related
📚 Others as available

Choose the appropriate type for your situation.`,
    title: 'Leave Types',
    placement: 'center',
    disableBeacon: true,
  },

  // Submitting Leave
  {
    target: 'body',
    content: `Submitting a Leave Request:

1️⃣ Check your leave balance first
2️⃣ Select leave type
3️⃣ Choose start and end dates
4️⃣ Provide a reason
5️⃣ Submit

Days are auto-calculated (excludes weekends/holidays).`,
    title: 'Submitting Leave',
    placement: 'center',
    disableBeacon: true,
  },

  // Leave Status
  {
    target: 'body',
    content: `Leave Request Status:

⚪ Pending - Awaiting HR approval
🟢 Approved - Leave granted
🔴 Rejected - Request denied
🟡 Cancelled - Withdrawn by you

You can cancel pending requests if plans change.`,
    title: 'Leave Status',
    placement: 'center',
    disableBeacon: true,
  },

  // Cash Advance
  {
    target: 'body',
    content: `Cash Advances:

These are loans deducted from future payroll. Use responsibly for:
• Medical emergencies
• Educational expenses
• Family emergencies

Consider if you can afford the repayment.`,
    title: 'Cash Advances',
    placement: 'center',
    disableBeacon: true,
  },

  // CA Application
  {
    target: 'body',
    content: `Applying for Cash Advance:

1️⃣ Enter amount needed
2️⃣ Provide purpose/reason
3️⃣ Submit application

Consider:
• Your salary (can you afford repayment?)
• Company limits (max advance allowed)
• Existing balances (outstanding advances)`,
    title: 'CA Application',
    placement: 'center',
    disableBeacon: true,
  },

  // CA Status
  {
    target: 'body',
    content: `Cash Advance Status:

⚪ Pending - Awaiting approval
🟡 Approved - Ready for disbursement
🟢 Disbursed - Cash received
🔵 Being Repaid - Deductions ongoing
✅ Fully Paid - Completed

Track your repayment progress.`,
    title: 'CA Status',
    placement: 'center',
    disableBeacon: true,
  },

  // Outstanding Balance
  {
    target: 'body',
    content: `Outstanding CA Balance:

Shows:
• Total borrowed
• Amount repaid
• Remaining balance

This is automatically deducted from your payroll each cutoff.`,
    title: 'Outstanding Balance',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the My Requests tour!

Key Points:
✅ Check leave balance before requesting
✅ Submit leave requests in advance
✅ Use cash advances responsibly
✅ Track your request status
✅ Contact HR for any issues

Plan your leaves and finances wisely!

Use the help icon (?) to restart this tour.`,
    title: 'Requests Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default myRequestsSteps;
