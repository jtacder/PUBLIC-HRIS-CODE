/**
 * Devotionals Page Tour Steps
 *
 * Comprehensive tour for devotional content management.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const devotionalsSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to Devotional Management! This page lets you manage daily spiritual content for employee engagement. Create meaningful devotionals to inspire your team.`,
    title: 'Devotional Management',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `The devotionals page includes:

➕ Add Devotional - Create new entry
📅 Calendar View - Browse by date
📋 Devotional List - All entries
📥 Import/Export - Bulk operations`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Devotional Content
  {
    target: 'body',
    content: `Each Devotional Contains:

📅 Date - When to display
📖 Bible Verse - The scripture
📚 Reference - Book Chapter:Verse
🏷️ Theme - Topic (e.g., Perseverance)
💭 Reflection - The message/content`,
    title: 'Devotional Content',
    placement: 'center',
    disableBeacon: true,
  },

  // Creating Devotionals
  {
    target: 'body',
    content: `Creating a Devotional:

1️⃣ Select Date - When to show
2️⃣ Enter Bible Verse - The scripture text
3️⃣ Add Reference - e.g., "John 3:16"
4️⃣ Set Theme - Topic like "Faith" or "Teamwork"
5️⃣ Write Reflection - Brief, meaningful message

You can prepare devotionals in advance!`,
    title: 'Creating Devotionals',
    placement: 'center',
    disableBeacon: true,
  },

  // Writing Tips
  {
    target: 'body',
    content: `Tips for Great Devotionals:

📝 Keep reflections brief but meaningful
🏢 Make it relevant to work life
💪 Be encouraging and positive
🌍 Use diverse Bible passages
📅 Plan ahead - prepare a week in advance`,
    title: 'Writing Tips',
    placement: 'center',
    disableBeacon: true,
  },

  // Calendar View
  {
    target: 'body',
    content: `Calendar View:

• Days with devotionals are highlighted
• Today's devotional is emphasized
• Click any date to view/edit
• Easy to spot gaps in schedule`,
    title: 'Calendar View',
    placement: 'center',
    disableBeacon: true,
  },

  // Import/Export
  {
    target: 'body',
    content: `Bulk Operations:

📥 Import:
• Upload CSV file
• One row per devotional
• Great for bulk setup

📤 Export:
• Backup your content
• Share with others
• Archive for records`,
    title: 'Import & Export',
    placement: 'center',
    disableBeacon: true,
  },

  // Employee View
  {
    target: 'body',
    content: `How Employees See Devotionals:

• Access from dashboard widget
• Daily devotional shown
• Can browse past devotionals
• Encouraging start to the day

Devotionals help build positive workplace culture!`,
    title: 'Employee View',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the Devotionals Management tour!

Best Practices:
✅ Plan ahead - prepare weekly
✅ Choose relevant themes
✅ Keep reflections concise
✅ Use diverse Bible passages
✅ Import from trusted sources

Devotionals help build a positive workplace culture!

Use the help icon (?) to restart this tour.`,
    title: 'Devotionals Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default devotionalsSteps;
