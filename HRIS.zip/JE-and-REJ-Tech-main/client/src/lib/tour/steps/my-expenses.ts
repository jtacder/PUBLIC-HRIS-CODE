/**
 * My Expenses Page Tour Steps
 *
 * Tour for employee expense submission.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const myExpensesSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to My Expenses! Submit expense reports for reimbursement and track their status.`,
    title: 'My Expenses',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `Your expenses page includes:

➕ Submit Expense - Create new expense report
📋 Expense List - All your submissions
📊 Summary - Totals by status`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Submitting Expense
  {
    target: 'body',
    content: `Submitting an Expense:

1️⃣ Select Category:
• Materials - Supplies, equipment
• Travel - Transportation, lodging
• Meals - Business meals
• Utilities - Office utilities
• Others - Miscellaneous

2️⃣ Enter amount (₱)
3️⃣ Select date incurred
4️⃣ Describe the expense
5️⃣ Attach receipt`,
    title: 'Submitting Expenses',
    placement: 'center',
    disableBeacon: true,
  },

  // Receipt Requirement
  {
    target: 'body',
    content: `Receipt Requirements:

📸 Take clear photo of receipt
📅 Show date and amount
💰 Amount must match claim
📝 Items should match description

⚠️ Expenses without receipts may be rejected!`,
    title: 'Attach Receipt',
    placement: 'center',
    disableBeacon: true,
  },

  // Expense Status
  {
    target: 'body',
    content: `Expense Status:

⚪ Pending - Awaiting approval
🟢 Approved - Ready for reimbursement
🔴 Rejected - Denied (see reason)
✅ Reimbursed - Payment completed`,
    title: 'Expense Status',
    placement: 'center',
    disableBeacon: true,
  },

  // Rejection
  {
    target: 'body',
    content: `If Rejected:

Check the rejection reason. Common issues:
• Missing receipt
• Non-business expense
• Exceeds limits
• Past submission deadline

You may be able to resubmit with corrections.`,
    title: 'Handling Rejection',
    placement: 'center',
    disableBeacon: true,
  },

  // Summary
  {
    target: 'body',
    content: `Your Expense Summary:

📊 Total submitted
⏳ Pending amount
✅ Approved amount
💰 Reimbursed amount

Track your reimbursement progress.`,
    title: 'Expense Summary',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the My Expenses tour!

Expense Tips:
✅ Submit expenses promptly
✅ Always attach receipts
✅ Use correct categories
✅ Provide clear descriptions
✅ Track reimbursement status

Follow company expense policy!

Use the help icon (?) to restart this tour.`,
    title: 'Expenses Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default myExpensesSteps;
