/**
 * Payroll Page Tour Steps
 *
 * Comprehensive tour for the payroll management page.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const payrollSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to Payroll Management! This is where you calculate, review, approve, and release employee salaries. The system handles all Philippine statutory deductions automatically.`,
    title: 'Payroll Management',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `Payroll Page Components:

📅 Cutoff Selector - Choose pay period
🔄 Generate Payroll - Calculate all payslips
📊 Summary Cards - Total gross, deductions, net
📋 Payslip Table - Individual employee payslips
✅ Approval Controls - Approve and release`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Generate Payroll
  {
    target: 'body',
    content: `Generate Payroll Process:

When you click "Generate Payroll":
1. System pulls attendance for the period
2. Calculates basic pay (rate × days)
3. Adds overtime pay
4. Applies all statutory deductions
5. Generates individual payslips

⚠️ Important: Ensure all attendance is finalized before generating!

If regenerating, this will recalculate all values and reset approvals.`,
    title: 'Generate Payroll',
    placement: 'center',
    disableBeacon: true,
  },

  // Summary Cards
  {
    target: 'body',
    content: `Payroll Summary:

👥 Total Employees - Number included in payroll

💵 Total Gross Pay:
• Basic Pay (Rate × Days)
• Overtime Pay
• Holiday Pay
• Allowances

➖ Total Deductions:
• SSS, PhilHealth, PAG-IBIG
• Withholding Tax
• Cash Advances
• Other deductions

💰 Total Net Pay - Amount to disburse`,
    title: 'Payroll Summary',
    placement: 'center',
    disableBeacon: true,
  },

  // Payslip Table
  {
    target: 'body',
    content: `Payslip Table Columns:

👤 Employee - Name and ID
📅 Days Worked - Working days this period
💵 Basic Pay - Daily Rate × Days
⏰ OT Pay - Overtime earnings
💰 Gross Pay - Total before deductions
➖ Deductions - SSS, Tax, etc.
💵 Net Pay - Take-home amount
📌 Status - Pending/Approved/Released`,
    title: 'Payslip Table',
    placement: 'center',
    disableBeacon: true,
  },

  // Deductions Explained
  {
    target: 'body',
    content: `Statutory Deductions (Auto-calculated):

📋 SSS Contribution:
• Based on monthly salary bracket
• Using 2024 contribution table

🏥 PhilHealth:
• 5% of basic salary
• Employee pays 2.5%

🏠 PAG-IBIG:
• 2% of salary (max ₱200/month)

📊 Withholding Tax (TRAIN Law):
• First ₱250,000/year = 0%
• Progressive rates above`,
    title: 'Understanding Deductions',
    placement: 'center',
    disableBeacon: true,
  },

  // Overtime Calculation
  {
    target: 'body',
    content: `Overtime Pay Calculation:

Hourly Rate = Daily Rate ÷ 8

📈 Regular OT: Hourly × Hours × 1.25
🌙 Night OT (10PM-6AM): Hourly × Hours × 1.375
🎉 Holiday OT: Higher multipliers apply

All approved OT is included automatically.

Cash advance deductions are also applied per the configured repayment schedule.`,
    title: 'OT & Deductions',
    placement: 'center',
    disableBeacon: true,
  },

  // View Payslip
  {
    target: 'body',
    content: `Viewing Payslip Details:

Click any payslip to see:
• Complete computation breakdown
• All deduction details
• Year-to-date (YTD) totals
• Print-ready format

The detailed view shows:
• Daily rate used
• Days worked count
• Each deduction formula
• Net pay calculation`,
    title: 'Payslip Details',
    placement: 'center',
    disableBeacon: true,
  },

  // Approval Process
  {
    target: 'body',
    content: `Approval & Release Process:

1️⃣ Review all payslips for accuracy
2️⃣ Click "Approve" for individual or "Approve All"
3️⃣ Once approved, payslips are locked
4️⃣ Disburse funds to employees
5️⃣ Click "Release" to mark as paid

Status Flow:
⚪ Pending → 🟡 Approved → 🟢 Released

Only mark as released after actual payment!`,
    title: 'Approval & Release',
    placement: 'center',
    disableBeacon: true,
  },

  // Printing
  {
    target: 'body',
    content: `Printing & Exporting:

🖨️ Print Payslip:
• Standard Philippine format
• For employee records
• For accounting files

📤 Export Payroll:
• CSV/Excel format
• For bank uploads
• For audit purposes`,
    title: 'Print & Export',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `Excellent! You've completed the Payroll Management tour.

Payroll Process Checklist:
1. ✅ Finalize all attendance
2. ✅ Review cash advance deductions
3. ✅ Generate payroll
4. ✅ Verify summary totals
5. ✅ Review individual payslips
6. ✅ Approve payslips
7. ✅ Disburse funds
8. ✅ Mark as released

Use the help icon (?) anytime to restart this tour!`,
    title: 'Payroll Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default payrollSteps;
