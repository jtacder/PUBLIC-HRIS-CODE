/**
 * Employees Page Guide Steps
 *
 * Comprehensive guide for the employee management page.
 * Uses body target for presentation-style guide.
 */

import type { Step } from 'react-joyride';

export const employeesSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to Employee Management! This is where you manage all employee records, profiles, and account settings. Let's explore every feature in detail.`,
    title: 'Employee Management',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `The page header shows the total count of employees and provides quick access to adding new employees.

Key Features:
• Add New Employee button - Create new records
• Search box - Find employees quickly
• Status and Role filters - Filter the list
• Employee table - View and manage all employees`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Search and Filters
  {
    target: 'body',
    content: `Search and Filter Options:

Search Box:
Find employees by name, email, ID, or position. Results filter as you type.

Status Filter:
• Active - Currently employed
• Probationary - Under evaluation
• Suspended - Temporarily not working
• Terminated - No longer employed
• Inactive - On extended leave

Role Filter:
• Admin - Full system access
• HR - Human resources access
• Engineer - Project management
• Worker - Basic employee access`,
    title: 'Search & Filters',
    placement: 'center',
    disableBeacon: true,
  },

  // Employee Table Columns
  {
    target: 'body',
    content: `Employee Table Columns:

• Name - Full name (Last, First format)
• Email - Login username
• Role - System access level
• Status - Employment status (color-coded)
• Position - Job title
• Daily Rate - For payroll calculation

Click column headers to sort. Click a row to view full profile.`,
    title: 'Understanding the Table',
    placement: 'center',
    disableBeacon: true,
  },

  // Actions Menu
  {
    target: 'body',
    content: `Employee Actions (three-dot menu):

• View Profile - See complete employee details
• Edit Employee - Modify information
• Reset Password - Generate new temporary password
• Generate QR - Create attendance QR code
• Activate/Deactivate - Toggle employee status

All actions are logged in the audit trail.`,
    title: 'Employee Actions',
    placement: 'center',
    disableBeacon: true,
  },

  // Add Employee Form
  {
    target: 'body',
    content: `Adding a New Employee:

When you click "Add Employee", fill out these sections:

1. Personal Information
   • Full name (match official documents)
   • Contact details, address
   • Emergency contact

2. Employment Details
   • Position/Job Title
   • Daily Rate - critical for payroll
   • Start date and status`,
    title: 'Add Employee - Personal & Employment',
    placement: 'center',
    disableBeacon: true,
  },

  // Government IDs and Account
  {
    target: 'body',
    content: `3. Government IDs (Required for compliance)
   • SSS Number - Social Security
   • TIN - Tax ID
   • PhilHealth ID
   • PAG-IBIG ID

4. Account Setup
   • Email (login username)
   • Initial password
   • Role selection
   • "Must reset password" option (recommended)

All fields marked with * are required.`,
    title: 'Add Employee - IDs & Account',
    placement: 'center',
    disableBeacon: true,
  },

  // Bulk Operations
  {
    target: 'body',
    content: `Bulk Operations:

Bulk Import:
Upload CSV with multiple employees. Great for initial setup or large hiring batches. Use the provided template.

Export:
Download employee list to CSV/Excel. Apply filters first to export specific subsets.

Pagination:
Navigate through pages (10 employees per page by default).`,
    title: 'Bulk Operations',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `Excellent! You've completed the Employee Management guide.

Key reminders:
• Keep employee information up to date
• Use proper roles to control access
• Verify government IDs for accurate deductions
• Generate QR codes for efficient attendance
• Deactivate (don't delete) former employees

Use the help icon (?) anytime to restart this guide!`,
    title: 'Employee Management Guide Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default employeesSteps;
