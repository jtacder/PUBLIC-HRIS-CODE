/**
 * 201 Files Page Tour Steps
 *
 * Comprehensive tour for employee 201 file management.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const files201Steps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to 201 Files! This page provides comprehensive employee records as required by Philippine labor law (DOLE). Access complete employment history, documents, and records for any employee.

"201 File" is the standard term in Philippine HR for an employee's complete record folder.`,
    title: '201 Files',
    placement: 'center',
    disableBeacon: true,
  },

  // Navigation
  {
    target: 'body',
    content: `Finding an Employee's 201 File:

🔍 Search Box - Type name or employee ID
📋 Employee Directory - Browse all employees
🔘 Filters - By department or status

Click any employee to load their complete 201 file with all tabs.`,
    title: 'Finding Records',
    placement: 'center',
    disableBeacon: true,
  },

  // Personal Profile Tab
  {
    target: 'body',
    content: `Personal Profile Tab:

Contains personal information:
• Full legal name (as per government IDs)
• Date of birth and age
• Civil status
• Complete home address
• Phone and email
• Emergency contact person & number

Keep this information current!`,
    title: 'Personal Profile',
    placement: 'center',
    disableBeacon: true,
  },

  // Employment Tab
  {
    target: 'body',
    content: `Employment History Tab:

Current employment details:
• Position/Job Title
• Department/Division
• Employment Status (Regular, Probationary, etc.)
• Date Hired
• Current Daily Rate
• Supervisor/Manager

Also shows historical records of previous positions and salary changes.`,
    title: 'Employment History',
    placement: 'center',
    disableBeacon: true,
  },

  // Government IDs Tab
  {
    target: 'body',
    content: `Government IDs Tab:

Required for statutory compliance:
• SSS Number - Social Security benefits
• TIN - Income tax reporting
• PhilHealth Number - Health insurance
• PAG-IBIG Number - Housing fund

⚠️ Verify these match official documents. Incorrect IDs cause remittance problems.`,
    title: 'Government IDs',
    placement: 'center',
    disableBeacon: true,
  },

  // Disciplinary Tab
  {
    target: 'body',
    content: `Disciplinary Records Tab:

Complete disciplinary history:
• All NTEs (Notice to Explain) issued
• Warnings received
• Suspensions
• Incident dates and types
• Actions taken
• Resolution outcomes

This record is confidential. Handle appropriately.`,
    title: 'Disciplinary Records',
    placement: 'center',
    disableBeacon: true,
  },

  // Leave Tab
  {
    target: 'body',
    content: `Leave Records Tab:

Leave balances:
• Allocated - Days granted this year
• Used - Days already taken
• Remaining - Available balance

Leave history shows:
• Every leave taken
• Dates and duration
• Type of leave (Annual, Sick, etc.)
• Approval status`,
    title: 'Leave Records',
    placement: 'center',
    disableBeacon: true,
  },

  // Payroll Tab
  {
    target: 'body',
    content: `Payroll Records Tab:

Complete payroll history:
• Every payslip issued
• Gross and net amounts
• Deduction breakdown
• Click any payslip for details

Year-to-Date (YTD) Summary:
• Total gross earnings
• Total deductions by type
• Total net pay received
• Tax withheld YTD

Useful for annual tax reporting (BIR 2316).`,
    title: 'Payroll Records',
    placement: 'center',
    disableBeacon: true,
  },

  // Cash Advance Tab
  {
    target: 'body',
    content: `Cash Advance History Tab:

Track all cash advances:
• Date and amount borrowed
• Purpose stated
• Repayment schedule
• Payments made
• Remaining balance

Monitor employee's borrowing history and outstanding balances.`,
    title: 'Cash Advance History',
    placement: 'center',
    disableBeacon: true,
  },

  // Documents Tab
  {
    target: 'body',
    content: `Documents Tab:

Store important documents:
• Employment contracts
• Job offers/appointments
• Certificates/credentials
• Training records
• Other important files

Features:
• Click to view/download
• Upload new documents
• Organize by category
• Track document dates

Accepted formats: PDF, images, Word documents.`,
    title: 'Document Storage',
    placement: 'center',
    disableBeacon: true,
  },

  // Actions
  {
    target: 'body',
    content: `201 File Actions:

🖨️ Print 201 File:
Generate printable version for:
• Official records
• DOLE compliance
• Employee separation
• Legal requirements

✏️ Edit Profile:
Update information directly. All changes logged in audit trail.`,
    title: '201 File Actions',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the 201 Files tour!

201 File Contains:
• Personal Information
• Employment History
• Government IDs
• Disciplinary Records
• Leave History
• Payroll Records
• Cash Advances
• Documents

⚠️ Remember: 201 files are confidential. Access only for legitimate HR purposes.

Use the help icon (?) to restart this tour.`,
    title: '201 Files Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default files201Steps;
