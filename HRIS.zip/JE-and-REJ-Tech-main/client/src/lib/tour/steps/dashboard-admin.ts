/**
 * Admin/HR Dashboard Tour Steps
 *
 * Interactive tour for the admin/HR dashboard page.
 * Targets actual elements for highlighting.
 */

import type { Step } from 'react-joyride';

export const dashboardAdminSteps: Step[] = [
  // Welcome - centered
  {
    target: '[data-tour="dashboard-header"]',
    content: 'Welcome to the JE & REJ TECH Dashboard!\n\nThis is your central command center where you can monitor your entire organization at a glance.\n\nLet\'s explore all the features available to you.',
    title: 'Welcome to Your Dashboard',
    placement: 'bottom',
    disableBeacon: true,
  },

  // Stats Grid
  {
    target: '[data-tour="stats-grid"]',
    content: 'These cards show your organization\'s key metrics.\n\nThey update in real-time as employees clock in and data changes throughout the day.',
    title: 'Key Metrics Overview',
    placement: 'bottom',
    disableBeacon: true,
  },

  // Total Employees Card
  {
    target: '[data-tour="stat-total-employees"]',
    content: 'Total Employees Card\n\nShows all employees in the system regardless of status:\n• Active\n• Probationary\n• Suspended\n• Inactive',
    title: 'Total Employees',
    placement: 'bottom',
    disableBeacon: true,
  },

  // Attendance Card
  {
    target: '[data-tour="stat-attendance"]',
    content: 'Today\'s Attendance\n\nReal-time count of employees who have clocked in today.\n\nCompare with active employees to quickly see your attendance rate.',
    title: 'Today\'s Attendance',
    placement: 'bottom',
    disableBeacon: true,
  },

  // Payroll Card
  {
    target: '[data-tour="stat-payroll"]',
    content: 'Estimated Payroll\n\nShows the current cutoff period and estimated amounts:\n• Basic Pay = Daily Rate × Days Worked\n• OT Pay = Based on approved overtime\n• Total = Gross payroll before deductions\n\nUse this to plan your payroll disbursement.',
    title: 'Payroll Estimate',
    placement: 'bottom',
    disableBeacon: true,
  },

  // Attendance Rate Card
  {
    target: '[data-tour="stat-attendance-rate"]',
    content: 'Attendance Rate\n\nPercentage of active employees who have clocked in today.\n\nThe progress bar gives you a quick visual indicator.',
    title: 'Attendance Rate',
    placement: 'bottom',
    disableBeacon: true,
  },

  // Extended Stats Section
  {
    target: '[data-tour="extended-stats"]',
    content: 'Additional Statistics\n\nThese cards show:\n• Active Projects - Ongoing work\n• Pending Expenses - Awaiting approval\n• Open NTEs - Disciplinary cases pending\n\nClick any card to navigate to that page.',
    title: 'Projects, Expenses & NTEs',
    placement: 'top',
    disableBeacon: true,
  },

  // Attendance Widgets
  {
    target: '[data-tour="attendance-widgets"]',
    content: 'Attendance Alerts\n\n• Pending OT - Overtime needing approval\n• Late Today - Employees who arrived late\n• Not Clocked In - Employees missing today\n\nRed/orange highlights indicate items needing attention.',
    title: 'Attendance Alerts',
    placement: 'top',
    disableBeacon: true,
  },

  // Quick Actions
  {
    target: '[data-tour="quick-actions"]',
    content: 'Quick Actions\n\nShortcuts to common tasks:\n• View Attendance - Monitor time logs\n• Add Employee - Register new team member\n• Process Payroll - Compute this cutoff\n\nClick any action to go directly to that page.',
    title: 'Quick Actions',
    placement: 'top',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: 'You\'ve completed the Dashboard tour!\n\nKey tips for daily use:\n• Check the dashboard regularly\n• Address pending items promptly\n• Review late employees for patterns\n• Use quick actions for common tasks\n\nEach page has its own tour - look for the help icon (?) in the header!',
    title: 'Dashboard Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default dashboardAdminSteps;
