/**
 * Audit Logs Page Tour Steps
 *
 * Comprehensive tour for the system audit trail.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const auditLogsSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to Audit Logs! This page shows a complete trail of all actions taken in the system. Essential for compliance, security, and accountability.

Nothing is deleted - all changes are tracked permanently.`,
    title: 'Audit Trail',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `The audit log page includes:

👤 User Filter - Filter by who made changes
📋 Action Filter - Filter by type of action
📁 Entity Filter - Filter by what was changed
📅 Date Range - Filter by when`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Action Types
  {
    target: 'body',
    content: `Action Types Logged:

➕ CREATE - New records created
✏️ UPDATE - Existing records modified
🗑️ DELETE - Records removed
✅ APPROVE - Items approved
❌ REJECT - Items rejected
📤 RELEASE - Payroll/items released
🔐 LOGIN/LOGOUT - Session activities`,
    title: 'Action Types',
    placement: 'center',
    disableBeacon: true,
  },

  // Entity Types
  {
    target: 'body',
    content: `Entities Tracked:

👤 Employee - Employee record changes
⏰ Attendance - Clock in/out records
💰 Payroll - Payslip and salary changes
🏖️ Leave - Leave request changes
💵 Cash Advance - CA transactions
⚙️ Settings - System configuration`,
    title: 'Entities Tracked',
    placement: 'center',
    disableBeacon: true,
  },

  // Log Details
  {
    target: 'body',
    content: `Each Log Entry Shows:

📅 Timestamp - Exact date and time (UTC+8)
👤 User - Who performed the action
📋 Action - What type of action
📁 Entity - What was changed
📝 Details - Brief description
🌐 IP Address - Where the action came from`,
    title: 'Log Entry Details',
    placement: 'center',
    disableBeacon: true,
  },

  // Before/After
  {
    target: 'body',
    content: `Viewing Change Details:

Click any log entry to see:
• Previous Values (before change)
• New Values (after change)
• All fields affected

Side-by-side comparison makes changes easy to spot.`,
    title: 'Change Details',
    placement: 'center',
    disableBeacon: true,
  },

  // Security Notes
  {
    target: 'body',
    content: `Security & Compliance:

🔒 Audit logs cannot be modified or deleted
📋 All admin access is logged
❌ Failed login attempts are recorded
⚠️ Sensitive data changes are flagged

This ensures accountability and compliance.`,
    title: 'Security Features',
    placement: 'center',
    disableBeacon: true,
  },

  // Export
  {
    target: 'body',
    content: `Exporting Logs:

Export audit logs for:
• Compliance reporting
• Security audits
• Legal documentation
• External reviews

Export respects current filters applied.`,
    title: 'Export Logs',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the Audit Logs tour!

Audit Log Uses:
✅ Track who made what changes
✅ Investigate discrepancies
✅ Compliance documentation
✅ Security monitoring
✅ Accountability records

The audit trail is your organization's activity history. Review regularly for security and compliance.

Use the help icon (?) to restart this tour.`,
    title: 'Audit Logs Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default auditLogsSteps;
