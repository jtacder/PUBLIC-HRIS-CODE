/**
 * My Payslips Page Tour Steps
 *
 * Tour for the employee payslip viewing page.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const myPayslipsSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to My Payslips! Here you can view all your salary records, download payslips, and track your earnings history.`,
    title: 'My Payslips',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `Your payslips page includes:

📅 Year Filter - View payslips by year
📋 Payslip List - All your salary records
📊 Summary - Gross, deductions, net pay
🖨️ Print/Download - Get PDF copies`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Payslip Information
  {
    target: 'body',
    content: `Each Payslip Shows:

📅 Cutoff Period - Pay period dates
💵 Gross Pay - Total before deductions
➖ Deductions - SSS, Tax, etc.
💰 Net Pay - Your take-home amount
📌 Status - Pending or Released`,
    title: 'Payslip Information',
    placement: 'center',
    disableBeacon: true,
  },

  // Gross Pay
  {
    target: 'body',
    content: `Gross Pay Breakdown:

💵 Basic Pay = Daily Rate × Days Worked
⏰ Overtime Pay = OT Hours × OT Rate
➕ Allowances (if any)

This is your total earnings before deductions.`,
    title: 'Understanding Gross Pay',
    placement: 'center',
    disableBeacon: true,
  },

  // Deductions
  {
    target: 'body',
    content: `Deductions Include:

📋 SSS Contribution - Social Security
🏥 PhilHealth - Health insurance
🏠 PAG-IBIG - Housing fund
📊 Withholding Tax - Income tax
💵 Cash Advance - If any outstanding

These are mandatory deductions.`,
    title: 'Understanding Deductions',
    placement: 'center',
    disableBeacon: true,
  },

  // Net Pay
  {
    target: 'body',
    content: `Net Pay:

💰 Net Pay = Gross Pay - Total Deductions

This is your take-home pay - the amount you actually receive.`,
    title: 'Net Pay',
    placement: 'center',
    disableBeacon: true,
  },

  // Status
  {
    target: 'body',
    content: `Payslip Status:

🟡 Pending - Still being processed
🟢 Released - Payment completed

Wait for "Released" status before expecting payment in your account.`,
    title: 'Payslip Status',
    placement: 'center',
    disableBeacon: true,
  },

  // Print/Download
  {
    target: 'body',
    content: `Print or Download Payslip:

Keep copies for:
📂 Personal records
🏦 Bank requirements
💳 Loan applications
📊 Tax purposes

Click the print/download button on any payslip.`,
    title: 'Print & Download',
    placement: 'center',
    disableBeacon: true,
  },

  // YTD
  {
    target: 'body',
    content: `Year-to-Date (YTD) Totals:

📊 Total gross earnings this year
➖ Total deductions this year
💰 Total net pay this year

Useful for annual tax reporting (BIR 2316).`,
    title: 'Year-to-Date',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the My Payslips tour!

Your payslips show:
✅ Detailed earnings breakdown
✅ All deductions itemized
✅ Your take-home pay
✅ Year-to-date totals

Check payslips after each pay period to verify accuracy. Report any discrepancies to HR.

Use the help icon (?) to restart this tour.`,
    title: 'Payslips Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default myPayslipsSteps;
