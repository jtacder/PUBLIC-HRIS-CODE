/**
 * My Profile Page Tour Steps
 *
 * Tour for employee profile viewing.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const myProfileSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to My Profile! View your personal information, employment details, and work history all in one place.`,
    title: 'My Profile',
    placement: 'center',
    disableBeacon: true,
  },

  // Profile Overview
  {
    target: 'body',
    content: `Your Profile Shows:

👤 Name and Photo
💼 Position/Job Title
🏢 Department
🆔 Employee ID

This is your official employee record.`,
    title: 'Profile Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Personal Information
  {
    target: 'body',
    content: `Personal Information:

📛 Full Name
📅 Date of Birth
📞 Contact Number
📧 Email Address
🏠 Home Address

Contact HR if any information needs updating.`,
    title: 'Personal Information',
    placement: 'center',
    disableBeacon: true,
  },

  // Employment Details
  {
    target: 'body',
    content: `Employment Details:

💼 Position
🏢 Department
📅 Start Date
📌 Employment Status
💰 Daily Rate

This information is maintained by HR.`,
    title: 'Employment Details',
    placement: 'center',
    disableBeacon: true,
  },

  // Government IDs
  {
    target: 'body',
    content: `Government IDs:

📋 SSS Number
📊 TIN (Tax ID)
🏥 PhilHealth ID
🏠 PAG-IBIG ID

Verify these are correct for proper deductions and benefits.`,
    title: 'Government IDs',
    placement: 'center',
    disableBeacon: true,
  },

  // Leave Balance
  {
    target: 'body',
    content: `Leave Balance:

Shows for each leave type:
• Allocated days
• Days used
• Remaining balance

Plan your leaves within your available balance.`,
    title: 'Leave Balance',
    placement: 'center',
    disableBeacon: true,
  },

  // Cash Advance
  {
    target: 'body',
    content: `Cash Advance Status:

• Active advances
• Outstanding balance
• Repayment progress

Track your cash advance repayments here.`,
    title: 'Cash Advances',
    placement: 'center',
    disableBeacon: true,
  },

  // QR Code
  {
    target: 'body',
    content: `Your Personal QR Code:

📱 Show when clocking in/out at QR stations
📥 Download for printing if needed
🔒 Keep it secure - it's linked to your account`,
    title: 'Your QR Code',
    placement: 'center',
    disableBeacon: true,
  },

  // Security
  {
    target: 'body',
    content: `Account Security:

🔐 Change Password option available
• Use a strong password
• Don't share with anyone
• Change periodically

Contact HR if you forgot your password.`,
    title: 'Account Security',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the My Profile tour!

Important:
✅ Verify your information is correct
✅ Keep emergency contact updated
✅ Notify HR of any changes
✅ Check leave balances regularly
✅ Keep your QR code accessible

Your profile is your official employee record.

Use the help icon (?) to restart this tour.`,
    title: 'Profile Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default myProfileSteps;
