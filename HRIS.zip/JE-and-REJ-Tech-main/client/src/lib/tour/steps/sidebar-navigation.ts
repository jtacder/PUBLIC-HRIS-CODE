/**
 * Sidebar Navigation Tour Steps
 *
 * Tour for the main sidebar menu navigation.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const sidebarNavigationSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: 'Let\'s explore the sidebar navigation! This is how you access all features of JE & REJ TECH. The menu adapts to your role.',
    title: 'Sidebar Navigation',
    placement: 'center',
    disableBeacon: true,
  },

  // Toggle and User
  {
    target: 'body',
    content: `Sidebar Controls:

📱 Toggle Button - Open/close sidebar (mobile: tap menu icon)

👤 User Profile Area:
• Your name and role
• Profile picture
• Click to access profile or logout`,
    title: 'Sidebar Basics',
    placement: 'center',
    disableBeacon: true,
  },

  // Dashboard
  {
    target: 'body',
    content: `Dashboard - Your Home Screen:

📊 Key metrics at a glance
⏰ Attendance status
⏳ Pending items
⚡ Quick actions

Start here every day!`,
    title: 'Dashboard',
    placement: 'center',
    disableBeacon: true,
  },

  // Operations (Admin/HR)
  {
    target: 'body',
    content: `Operations Section (Admin/HR only):

👥 Employees - Manage employee records
📁 Projects - Project management
📋 Tasks - Task management

Core operational functions.`,
    title: 'Operations',
    placement: 'center',
    disableBeacon: true,
  },

  // HR Section
  {
    target: 'body',
    content: `Human Resources Section:

⏰ Attendance - Clock in/out, QR scanning
💰 Payroll - Salary processing
📂 201 Files - Complete employee records
📋 Disciplinary - NTE management
🏖️ Leave & CA - Request processing
⚙️ HR Settings - Configuration`,
    title: 'Human Resources',
    placement: 'center',
    disableBeacon: true,
  },

  // Finance Section
  {
    target: 'body',
    content: `Finance Section:

💵 Expenses - Expense report management

Process employee expense reports and reimbursements.`,
    title: 'Finance',
    placement: 'center',
    disableBeacon: true,
  },

  // Other Admin Pages
  {
    target: 'body',
    content: `Additional Admin Pages:

📖 Devotionals - Daily spiritual content
📊 Audit Logs - System activity trail

Manage devotionals and track all system changes.`,
    title: 'Other Admin Features',
    placement: 'center',
    disableBeacon: true,
  },

  // My Work Section
  {
    target: 'body',
    content: `My Work Section (All Employees):

📊 My Dashboard - Personal overview
📋 My Tasks - Assigned work
💰 My Payslips - Salary history
📅 My Requests - Leave & CA
👤 My Profile - Your information
💵 My Expenses - Expense submissions
📝 My Disciplinary - NTE records`,
    title: 'My Work',
    placement: 'center',
    disableBeacon: true,
  },

  // Theme and Logout
  {
    target: 'body',
    content: `Bottom Controls:

🌓 Theme Toggle - Light/Dark mode
Your preference is saved.

🚪 Logout - Sign out when:
• Leaving the computer
• Using shared devices
• Done for the day`,
    title: 'Theme & Logout',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the Sidebar Navigation tour!

The sidebar gives you access to everything:
✅ Dashboard for overview
✅ Specific pages for each function
✅ Your personal work section
✅ Settings and logout

Each page has its own tour - look for the help icon (?)!

Use the help icon to restart this tour.`,
    title: 'Navigation Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default sidebarNavigationSteps;
