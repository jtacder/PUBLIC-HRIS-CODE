/**
 * HR Settings Page Tour Steps
 *
 * Comprehensive tour for HR configuration.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const hrSettingsSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to HR Settings! This is where you configure all HR-related settings including payroll periods, leave policies, holidays, and leave allocations.

⚠️ Changes here affect the entire organization.`,
    title: 'HR Configuration',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `HR Settings has four main sections:

📅 Payroll Cutoffs - Define pay periods
🏖️ Leave Types - Configure leave categories
🎉 Holidays - Manage holiday calendar
📊 Leave Allocation - Assign leave balances

Each tab configures different aspects of HR operations.`,
    title: 'Settings Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Payroll Cutoffs
  {
    target: 'body',
    content: `Payroll Cutoffs:

Define your pay periods (most Philippine companies use semi-monthly):

📅 Period 1: 1st - 15th (payout around 20th)
📅 Period 2: 16th - End of month (payout around 5th)

For each cutoff, specify:
• Start Date - First day of period
• End Date - Last day of period
• Payout Date - When salaries are released`,
    title: 'Payroll Cutoffs',
    placement: 'center',
    disableBeacon: true,
  },

  // Leave Types
  {
    target: 'body',
    content: `Leave Types Configuration:

For each leave type, define:
• Name - e.g., "Vacation Leave"
• Accrual Mode:
  - Annual (all days at year start)
  - Monthly (days accrue monthly)
  - None (manual allocation only)
• Default Allocation - Days per year
• Paid/Unpaid status
• Cash Convertible option`,
    title: 'Leave Types',
    placement: 'center',
    disableBeacon: true,
  },

  // Common Leave Types
  {
    target: 'body',
    content: `Common Leave Types:

🏖️ Vacation Leave - Paid time off
🏥 Sick Leave - Medical reasons
🚨 Emergency Leave - Urgent situations
👶 Maternity/Paternity Leave
📚 Service Incentive Leave (5 days per PH law)

Add custom types based on company policy.`,
    title: 'Common Leave Types',
    placement: 'center',
    disableBeacon: true,
  },

  // Holidays
  {
    target: 'body',
    content: `Holiday Calendar:

Philippine holidays are categorized:

🔴 Regular Holidays - 200% pay if worked
🟡 Special Non-Working Days - 130% pay if worked

Add both national holidays and company-specific holidays. The system uses these for:
• Attendance tracking
• Payroll calculations
• Leave day calculations`,
    title: 'Holidays',
    placement: 'center',
    disableBeacon: true,
  },

  // Common Holidays
  {
    target: 'body',
    content: `Common Philippine Holidays:

Regular Holidays:
• New Year's Day
• Araw ng Kagitingan
• Maundy Thursday, Good Friday
• Labor Day, Independence Day
• National Heroes Day, Bonifacio Day
• Christmas Day, Rizal Day

Special Non-Working:
• Chinese New Year
• Black Saturday, All Saints Day
• And others as declared`,
    title: 'Philippine Holidays',
    placement: 'center',
    disableBeacon: true,
  },

  // Leave Allocation
  {
    target: 'body',
    content: `Leave Allocation:

Assign leave balances to employees:

👤 Individual Allocation:
• Select employee
• Choose leave type
• Enter days to add

👥 Bulk Allocation:
• Select multiple employees
• Apply same days
• Great for annual refresh`,
    title: 'Leave Allocation',
    placement: 'center',
    disableBeacon: true,
  },

  // Allocation History
  {
    target: 'body',
    content: `Allocation History:

Track all leave allocations:
• Who received leave
• How many days
• When allocated
• By whom

Complete audit trail for all changes.

Annual refresh typically happens at year start.`,
    title: 'Allocation History',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the HR Settings tour!

Configuration Checklist:
✅ Payroll Cutoffs - Set up pay periods
✅ Leave Types - Define leave categories
✅ Holidays - Add all holidays for the year
✅ Leave Allocation - Assign leave balances

⚠️ Changes affect all employees. Test with a small group first when making major changes.

Use the help icon (?) to restart this tour.`,
    title: 'HR Settings Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default hrSettingsSteps;
