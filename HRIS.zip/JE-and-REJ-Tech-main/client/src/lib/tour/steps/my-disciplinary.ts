/**
 * My Disciplinary Page Tour Steps
 *
 * Tour for employee disciplinary records viewing.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const myDisciplinarySteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to My Disciplinary Records. Here you can view any Notice to Explain (NTE) documents issued to you and submit your explanations.`,
    title: 'My Disciplinary Records',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `This page shows:

📋 Active NTEs - Requiring your response
📜 NTE History - Past disciplinary matters
📌 Resolution Status - Outcomes of cases

Address pending NTEs promptly!`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // NTE Card
  {
    target: 'body',
    content: `Each NTE Shows:

📅 Date issued
📝 Incident description
⏰ Response deadline
📌 Current status

Click to view full details and respond.`,
    title: 'NTE Details',
    placement: 'center',
    disableBeacon: true,
  },

  // Response Deadline
  {
    target: 'body',
    content: `Response Deadline:

⏰ Usually 48-72 hours from issuance
🔴 Highlighted in red if approaching
⚠️ Failure to respond may escalate the matter

Submit your explanation before this date!`,
    title: 'Deadline',
    placement: 'center',
    disableBeacon: true,
  },

  // Submitting Response
  {
    target: 'body',
    content: `Writing Your Response:

📝 Address the specific incident
💭 Explain circumstances
🤝 Accept responsibility if applicable
📎 Attach supporting documents

Be honest, clear, and professional.`,
    title: 'Your Response',
    placement: 'center',
    disableBeacon: true,
  },

  // Evidence
  {
    target: 'body',
    content: `Supporting Evidence:

You may attach:
🏥 Medical certificates
⚠️ Proof of emergency
📝 Witness statements
📄 Other relevant documents

Evidence can support your explanation.`,
    title: 'Attach Evidence',
    placement: 'center',
    disableBeacon: true,
  },

  // Resolution
  {
    target: 'body',
    content: `NTE Outcomes:

✅ No Action - Explanation accepted
⚠️ Warning Issued - Verbal or written
🚫 Other Action - Suspension, etc.

Review any resolution notes from HR.`,
    title: 'Resolution',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the My Disciplinary Records tour!

Important:
✅ Respond to NTEs promptly
✅ Be honest in your explanation
✅ Attach supporting evidence
✅ Meet the deadline
✅ Follow company policies

A clean record is important for your career.

Use the help icon (?) to restart this tour.`,
    title: 'Disciplinary Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default myDisciplinarySteps;
