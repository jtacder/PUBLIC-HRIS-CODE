/**
 * Tasks Page Tour Steps
 *
 * Comprehensive tour for task management.
 * Uses body target for presentation-style tour.
 */

import type { Step } from 'react-joyride';

export const tasksSteps: Step[] = [
  // Welcome
  {
    target: 'body',
    content: `Welcome to Task Management! This page lets you create, assign, and track all tasks. Break down projects into actionable items and monitor progress.`,
    title: 'Task Management',
    placement: 'center',
    disableBeacon: true,
  },

  // Page Overview
  {
    target: 'body',
    content: `The tasks page includes:

➕ Add Task Button - Create new tasks
🔍 Search Box - Find tasks quickly
📊 Filters - Status, priority, assignee, project
📋 Task List - All tasks in list/board view`,
    title: 'Page Overview',
    placement: 'center',
    disableBeacon: true,
  },

  // Task Status
  {
    target: 'body',
    content: `Task Status:

⚪ To Do - Not yet started
🔵 In Progress - Currently being worked on
🟡 Blocked - Stuck, waiting for something
🟢 Done - Completed

Update status as work progresses.`,
    title: 'Task Status',
    placement: 'center',
    disableBeacon: true,
  },

  // Task Priority
  {
    target: 'body',
    content: `Task Priority Levels:

⬜ Low - Nice to have, no rush
🟦 Medium - Standard priority
🟧 High - Important, needs attention
🟥 Urgent - Critical, do immediately

Work on higher priority tasks first.`,
    title: 'Priority Levels',
    placement: 'center',
    disableBeacon: true,
  },

  // Task Information
  {
    target: 'body',
    content: `Each Task Shows:

📋 Title - Clear, actionable description
📌 Status - Current progress
⚡ Priority - Urgency level
👤 Assignee - Who's responsible
📅 Due Date - Target completion
📁 Project - Linked project (if any)`,
    title: 'Task Information',
    placement: 'center',
    disableBeacon: true,
  },

  // Creating Tasks
  {
    target: 'body',
    content: `Creating a New Task:

1️⃣ Title - Clear, actionable (use verbs)
   "Review Q4 budget", "Fix login error"

2️⃣ Description - What needs to be done
   Include acceptance criteria

3️⃣ Assignee - Who will do it
4️⃣ Priority - How urgent
5️⃣ Due Date - When it's needed
6️⃣ Project - Link if applicable`,
    title: 'Creating Tasks',
    placement: 'center',
    disableBeacon: true,
  },

  // Task Details
  {
    target: 'body',
    content: `Task Detail View:

Click any task to see:
• Full description
• Status history
• Comments/discussion
• Activity log

Make updates and collaborate here.`,
    title: 'Task Details',
    placement: 'center',
    disableBeacon: true,
  },

  // Comments
  {
    target: 'body',
    content: `Task Comments:

Use comments for:
💬 Progress updates
❓ Questions
📝 Information sharing
🤝 Requesting help

All comments are saved and visible to the team.`,
    title: 'Task Comments',
    placement: 'center',
    disableBeacon: true,
  },

  // Filters
  {
    target: 'body',
    content: `Using Filters:

Filter tasks by:
• Status - See only "In Progress" tasks
• Priority - Focus on "Urgent" items
• Assignee - Check someone's workload
• Project - See project-specific tasks

Combine filters for precise views.`,
    title: 'Filtering Tasks',
    placement: 'center',
    disableBeacon: true,
  },

  // Completion
  {
    target: 'body',
    content: `You've completed the Task Management tour!

Task Workflow:
1. Create task with clear title
2. Assign to appropriate person
3. Set priority and due date
4. Track status updates
5. Use comments for discussion
6. Mark done when complete

Use tasks to organize all your work!

Use the help icon (?) to restart this tour.`,
    title: 'Tasks Tour Complete!',
    placement: 'center',
    disableBeacon: true,
  },
];

export default tasksSteps;
