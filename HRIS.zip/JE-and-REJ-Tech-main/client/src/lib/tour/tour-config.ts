/**
 * Guide Configuration
 *
 * Central configuration for all guide settings including
 * default options, styling, and behavior.
 */

import type { Props as JoyrideProps, Styles } from 'react-joyride';

/**
 * Default Joyride options applied to all guides
 */
export const defaultGuideOptions: Partial<JoyrideProps> = {
  continuous: true,
  showProgress: true,
  showSkipButton: true,
  disableOverlayClose: false,
  disableCloseOnEsc: false,
  spotlightClicks: true, // Allow clicking highlighted elements
  hideCloseButton: false,
  scrollToFirstStep: true, // Scroll to first step
  scrollOffset: 100,
  disableScrolling: false, // Allow scrolling to elements
  floaterProps: {
    disableAnimation: false,
  },
};

/**
 * Custom styles for guide tooltips matching JE & REJ TECH theme
 */
export const guideStyles: Partial<Styles> = {
  options: {
    arrowColor: '#ffffff',
    backgroundColor: '#ffffff',
    overlayColor: 'rgba(0, 0, 0, 0.6)',
    primaryColor: '#2563eb', // Blue-600
    spotlightShadow: '0 0 20px rgba(37, 99, 235, 0.6)',
    textColor: '#1f2937', // Gray-800
    width: 420,
    zIndex: 10000,
  },
  tooltip: {
    borderRadius: '12px',
    boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
    padding: '24px',
    maxHeight: '80vh',
    overflow: 'auto',
  },
  tooltipContainer: {
    textAlign: 'left',
  },
  tooltipTitle: {
    fontSize: '18px',
    fontWeight: 600,
    marginBottom: '12px',
    color: '#111827',
  },
  tooltipContent: {
    fontSize: '14px',
    lineHeight: '1.7',
    color: '#4b5563',
    padding: '8px 0',
    whiteSpace: 'pre-line' as const, // Preserve line breaks
  },
  tooltipFooter: {
    marginTop: '16px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  buttonNext: {
    backgroundColor: '#2563eb',
    borderRadius: '8px',
    color: '#ffffff',
    fontSize: '14px',
    fontWeight: 500,
    padding: '10px 20px',
    outline: 'none',
    border: 'none',
    cursor: 'pointer',
  },
  buttonBack: {
    backgroundColor: 'transparent',
    color: '#6b7280',
    fontSize: '14px',
    fontWeight: 500,
    marginRight: '8px',
    cursor: 'pointer',
  },
  buttonSkip: {
    backgroundColor: 'transparent',
    color: '#9ca3af',
    fontSize: '13px',
    cursor: 'pointer',
  },
  buttonClose: {
    color: '#9ca3af',
    height: '14px',
    width: '14px',
    position: 'absolute',
    right: '12px',
    top: '12px',
  },
  spotlight: {
    borderRadius: '8px',
  },
  overlay: {
    mixBlendMode: undefined,
  },
  beacon: {
    display: 'none', // We use custom beacons
  },
  beaconInner: {
    backgroundColor: '#2563eb',
  },
  beaconOuter: {
    backgroundColor: 'rgba(37, 99, 235, 0.2)',
    border: '2px solid #2563eb',
  },
};

/**
 * Guide step locale/text customization
 */
export const guideLocale = {
  back: 'Back',
  close: 'Close',
  last: 'Finish Guide',
  next: 'Next',
  open: 'Open the dialog',
  skip: 'Skip Guide',
};

/**
 * Guide categories for organization
 */
export const guideCategories = {
  hrManagement: {
    name: 'HR Management',
    description: 'Guides for employee, payroll, and HR operations',
    guides: ['employees', 'attendance', 'payroll', '201-files', 'disciplinary', 'hr-requests', 'hr-settings'],
  },
  projectManagement: {
    name: 'Project Management',
    description: 'Guides for projects and tasks',
    guides: ['projects', 'tasks'],
  },
  finance: {
    name: 'Finance',
    description: 'Guides for expenses and financial operations',
    guides: ['expenses'],
  },
  administration: {
    name: 'Administration',
    description: 'Guides for system administration',
    guides: ['audit-logs', 'devotionals'],
  },
  employeeSelfService: {
    name: 'Employee Self-Service',
    description: 'Guides for employee personal features',
    guides: ['dashboard-employee', 'my-tasks', 'my-payslips', 'my-requests', 'my-profile', 'my-expenses', 'my-disciplinary'],
  },
};

/**
 * Role-based guide recommendations
 */
export const guidesByRole = {
  ADMIN: [
    'dashboard-admin',
    'sidebar-navigation',
    'employees',
    'attendance',
    'payroll',
    '201-files',
    'disciplinary',
    'hr-requests',
    'hr-settings',
    'projects',
    'tasks',
    'expenses',
    'audit-logs',
    'devotionals',
  ],
  HR: [
    'dashboard-admin',
    'sidebar-navigation',
    'employees',
    'attendance',
    'payroll',
    '201-files',
    'disciplinary',
    'hr-requests',
    'hr-settings',
    'expenses',
    'audit-logs',
    'devotionals',
  ],
  ENGINEER: [
    'dashboard-employee',
    'sidebar-navigation',
    'my-tasks',
    'my-payslips',
    'my-requests',
    'my-profile',
    'my-expenses',
    'projects',
    'tasks',
  ],
  WORKER: [
    'dashboard-employee',
    'sidebar-navigation',
    'my-tasks',
    'my-payslips',
    'my-requests',
    'my-profile',
    'my-expenses',
    'my-disciplinary',
  ],
};

/**
 * Get guides for a specific role
 */
export function getGuidesForRole(role: keyof typeof guidesByRole): string[] {
  return guidesByRole[role] || guidesByRole.WORKER;
}

/**
 * Check if a guide is available for a role
 */
export function isGuideAvailableForRole(guideId: string, role: keyof typeof guidesByRole): boolean {
  const guides = getGuidesForRole(role);
  return guides.includes(guideId);
}

// Backward compatibility exports (deprecated)
export const defaultTourOptions = defaultGuideOptions;
export const tourStyles = guideStyles;
export const tourLocale = guideLocale;
export const tourCategories = guideCategories;
export const toursByRole = guidesByRole;
export const getToursForRole = getGuidesForRole;
export const isTourAvailableForRole = isGuideAvailableForRole;
