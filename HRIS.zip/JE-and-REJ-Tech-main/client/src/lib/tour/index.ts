/**
 * Tour Library Index
 *
 * Main entry point for tour functionality.
 */

// Storage and state management
export {
  getTourProgress,
  saveTourProgress,
  markTourCompleted,
  markTourSkipped,
  isTourCompleted,
  isTourSkipped,
  isFirstTimeUser,
  markNotFirstTime,
  saveCurrentStep,
  getCurrentStep,
  resetTour,
  resetAllTours,
  getTourStats,
  TOUR_IDS,
  type TourId,
  type TourProgress,
} from './tour-storage';

// Configuration
export {
  defaultTourOptions,
  tourStyles,
  tourLocale,
  tourCategories,
  toursByRole,
  getToursForRole,
  isTourAvailableForRole,
} from './tour-config';

// Tour steps
export {
  getTourStepsById,
  tourMetadata,
  getToursByCategory,
  getTotalStepCount,
  type TourMetadata,
  // Individual tour steps exports
  dashboardAdminSteps,
  employeesSteps,
  attendanceSteps,
  payrollSteps,
  files201Steps,
  disciplinarySteps,
  hrRequestsSteps,
  hrSettingsSteps,
  expensesSteps,
  auditLogsSteps,
  projectsSteps,
  tasksSteps,
  devotionalsSteps,
  dashboardEmployeeSteps,
  myTasksSteps,
  myPayslipsSteps,
  myRequestsSteps,
  myProfileSteps,
  myExpensesSteps,
  myDisciplinarySteps,
  sidebarNavigationSteps,
} from './steps';
