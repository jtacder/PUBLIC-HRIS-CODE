/**
 * Guide Storage Utility
 *
 * Manages guide completion state in localStorage.
 * Tracks which guides have been completed, skipped, or are in progress.
 */

const GUIDE_STORAGE_KEY = 'electromanage_tour_progress'; // Keep key for backward compatibility

export interface GuideProgress {
  completedTours: string[]; // Keep field names for backward compatibility with stored data
  skippedTours: string[];
  lastTourDate: string | null;
  isFirstTimeUser: boolean;
  currentStep: Record<string, number>;
}

const defaultProgress: GuideProgress = {
  completedTours: [],
  skippedTours: [],
  lastTourDate: null,
  isFirstTimeUser: true,
  currentStep: {},
};

/**
 * Get guide progress from localStorage
 */
export function getGuideProgress(): GuideProgress {
  try {
    const stored = localStorage.getItem(GUIDE_STORAGE_KEY);
    if (stored) {
      return { ...defaultProgress, ...JSON.parse(stored) };
    }
    return defaultProgress;
  } catch (error) {
    console.error('Error reading guide progress:', error);
    return defaultProgress;
  }
}

/**
 * Save guide progress to localStorage
 */
export function saveGuideProgress(progress: Partial<GuideProgress>): void {
  try {
    const current = getGuideProgress();
    const updated = { ...current, ...progress };
    localStorage.setItem(GUIDE_STORAGE_KEY, JSON.stringify(updated));
  } catch (error) {
    console.error('Error saving guide progress:', error);
  }
}

/**
 * Mark a guide as completed
 */
export function markGuideCompleted(guideId: string): void {
  const progress = getGuideProgress();
  if (!progress.completedTours.includes(guideId)) {
    progress.completedTours.push(guideId);
  }
  // Remove from skipped if it was there
  progress.skippedTours = progress.skippedTours.filter(id => id !== guideId);
  progress.lastTourDate = new Date().toISOString();
  progress.isFirstTimeUser = false;
  // Clear current step for this guide
  delete progress.currentStep[guideId];
  saveGuideProgress(progress);
}

/**
 * Mark a guide as skipped
 */
export function markGuideSkipped(guideId: string): void {
  const progress = getGuideProgress();
  if (!progress.skippedTours.includes(guideId)) {
    progress.skippedTours.push(guideId);
  }
  progress.isFirstTimeUser = false;
  // Clear current step for this guide
  delete progress.currentStep[guideId];
  saveGuideProgress(progress);
}

/**
 * Check if a guide has been completed
 */
export function isGuideCompleted(guideId: string): boolean {
  const progress = getGuideProgress();
  return progress.completedTours.includes(guideId);
}

/**
 * Check if a guide has been skipped
 */
export function isGuideSkipped(guideId: string): boolean {
  const progress = getGuideProgress();
  return progress.skippedTours.includes(guideId);
}

/**
 * Check if this is a first-time user
 */
export function isFirstTimeUser(): boolean {
  const progress = getGuideProgress();
  return progress.isFirstTimeUser;
}

/**
 * Mark user as no longer first-time
 */
export function markNotFirstTime(): void {
  saveGuideProgress({ isFirstTimeUser: false });
}

/**
 * Save current step progress for a guide
 */
export function saveCurrentStep(guideId: string, stepIndex: number): void {
  const progress = getGuideProgress();
  progress.currentStep[guideId] = stepIndex;
  saveGuideProgress(progress);
}

/**
 * Get current step for a guide
 */
export function getCurrentStep(guideId: string): number {
  const progress = getGuideProgress();
  return progress.currentStep[guideId] || 0;
}

/**
 * Reset a specific guide (allow user to retake it)
 */
export function resetGuide(guideId: string): void {
  const progress = getGuideProgress();
  progress.completedTours = progress.completedTours.filter(id => id !== guideId);
  progress.skippedTours = progress.skippedTours.filter(id => id !== guideId);
  delete progress.currentStep[guideId];
  saveGuideProgress(progress);
}

/**
 * Reset all guides (full reset)
 */
export function resetAllGuides(): void {
  localStorage.removeItem(GUIDE_STORAGE_KEY);
}

/**
 * Get statistics about guide completion
 */
export function getGuideStats(totalGuides: number): {
  completed: number;
  skipped: number;
  remaining: number;
  percentComplete: number;
} {
  const progress = getGuideProgress();
  const completed = progress.completedTours.length;
  const skipped = progress.skippedTours.length;
  const remaining = totalGuides - completed - skipped;
  const percentComplete = totalGuides > 0 ? Math.round((completed / totalGuides) * 100) : 0;

  return { completed, skipped, remaining, percentComplete };
}

/**
 * Get list of all available guide IDs
 */
export const GUIDE_IDS = {
  // Admin/HR Guides
  DASHBOARD_ADMIN: 'dashboard-admin',
  EMPLOYEES: 'employees',
  ATTENDANCE: 'attendance',
  PAYROLL: 'payroll',
  FILES_201: '201-files',
  DISCIPLINARY: 'disciplinary',
  HR_REQUESTS: 'hr-requests',
  HR_SETTINGS: 'hr-settings',
  EXPENSES: 'expenses',
  AUDIT_LOGS: 'audit-logs',
  PROJECTS: 'projects',
  TASKS: 'tasks',
  DEVOTIONALS: 'devotionals',

  // Employee Guides
  DASHBOARD_EMPLOYEE: 'dashboard-employee',
  MY_TASKS: 'my-tasks',
  MY_PAYSLIPS: 'my-payslips',
  MY_REQUESTS: 'my-requests',
  MY_PROFILE: 'my-profile',
  MY_EXPENSES: 'my-expenses',
  MY_DISCIPLINARY: 'my-disciplinary',

  // Navigation
  SIDEBAR: 'sidebar-navigation',

  // Welcome
  WELCOME: 'welcome',
} as const;

export type GuideId = typeof GUIDE_IDS[keyof typeof GUIDE_IDS];

// Backward compatibility exports (deprecated)
export type TourProgress = GuideProgress;
export type TourId = GuideId;
export const TOUR_IDS = GUIDE_IDS;
export const getTourProgress = getGuideProgress;
export const saveTourProgress = saveGuideProgress;
export const markTourCompleted = markGuideCompleted;
export const markTourSkipped = markGuideSkipped;
export const isTourCompleted = isGuideCompleted;
export const isTourSkipped = isGuideSkipped;
export const resetTour = resetGuide;
export const resetAllTours = resetAllGuides;
export const getTourStats = getGuideStats;
